# 网页代码审查与模型讨论包

打包日期：2026-10-27，Asia/Shanghai。用途：代码审查、定位问题、模型结构和研究改进。此包是本地源码快照和讨论材料，运行还需外部源码、数据、权重和仿真环境。

## 上传顺序

解压 ZIP 后，上传 web_upload/ 中的 UTF-8 TXT。不要把成功接收 ZIP 解释成模型已解压并读完全部代码。TXT 是本次核查的 Claude 和 ChatGPT 官方文档都明确支持的格式。

1. 第一轮上传 00_CONTEXT_AND_INDEX.txt、01_MODELS_AND_LANI.txt，先核对输入输出、继承关系和任务合同，再讨论模型。01 同时包含 LANI DINO 继承的 Aerial 模型，避免只看到适配层。
2. 审查 Aerial 数据和训练，补传 02_AERIAL_DATA_AND_TRAINING.txt。LANI 的数据和训练已在 01。
3. 审查自主推理、AirSim 和计分，补传 03_INFERENCE_AND_EVALUATION.txt。LANI 自主评测入口是 01 中的 scripts/verify_lani.py，根 evaluate.py 是 Aerial/FOV 入口。
4. 审查采集与审核，补传 04_COLLECTION_AND_AUDIT.txt。
5. 有具体问题后，再传 05_TESTS_DATA_AND_CONTRACTS.txt、06_TESTS_MODELS.txt 或 07_TESTS_CLOSED_LOOP.txt。LANI 小型测试已在 01。

长期讨论可建私有 Project，按主题引用文件。普通聊天每轮聚焦一个模块，要求模型列出实际依据和缺失材料。上传了全部材料，也不能将一次回答当作已完成全项目逐行审查。ChatGPT Free 当前每项目最多 5 文件，上传帮助列出每天 3 次文件上传额度；可先用 00、01、02，按配额和问题补充后续卷。付费项目规则见下方来源。

## 包内材料

- web_upload/：8 份网页可读 TXT。00 为导读、路径索引、四份依赖清单和精选历史证据；01 至 07 覆盖全部 29 份现用 Python，每份只收录一次。
- source_snapshot/：原目录、原字节的 Python 与四份 requirements，共 33 文件。可据此校对网页模型生成的补丁。
- context/project_docs/：README.md、AGENTS.md、CLAUDE.md 的讨论副本。具体环境根目录换为中性路径，原文件保持原样，前后 SHA 与替换规则记入清单。文档含历史信息，不等于同一时点的当前状态。
- context/evidence/：5 份精选 LANI JSON，为 2026-10-21 审计与队列状态快照。本轮未远程核查 2026-10-27 的队列状态。
- PACKAGE_MANIFEST.json：收录清单、源文件与导出文件 SHA256、分卷映射、原文所在字节偏移、排除规则和核验结果。
- SHA256SUMS.txt：包内材料校验值，不包含该清单自身；ZIP 校验值在旁边的 .zip.sha256.txt。

完整源码仅指根入口、uavnav/、scripts/、tests/ 内的现用 Python，不含 runs/plan 中的历史快照和第三方仓库。项目说明副本位于归档 context/，默认网页卷使用下面的约束摘要，以控制阅读负担；需要核对全文时可将对应说明内容粘贴给模型。

## 任务合同不能混用

| 任务 | 动作与 STOP | 成功与预算 | 边界 |
|---|---|---|---|
| LANI，lani_v1 | Forward、TurnRight、TurnLeft、Stop，STOP=3 | XZ 严格小于 5 个 Unity 场景单位，40 次移动，另记停止通信 | 正式分母保留教师超过 40 步的任务 |
| AerialVLN-S，aerialvln_s_v1 | 八动作，STOP=0 | XY 20 米，正式 eval_adapter_v2 为 500 动作，开发 200 步另列 | 2/3 为偏航、6/7 为侧移，分类准确率不等于导航 SR |
| 历史 FOV，uav_vln_fov | 历史对象接近与航点路径 | 对应历史合同，含旧 3D 10 米口径 | 保留旧 checkpoint/forward 语义，不与路线分数混报 |

策略只读当前观测、完整任务指令、已执行动作及合法过去记忆。目标真值、未来帧、参考路线和教师动作只用于监督或离线评价。新任务 reset；完整 episode 连续分块，块间 carry/detach。不能随机打散帧冒充记忆训练。train/dev 的路线、episode、采集来源依对应合同隔离；词表只从 train 构建。当前固定 seed0，未经授权不执行多 seed 队列。新增方法和计分应显式版本化，原始失败、来源和已有结果保持原义。

## 模型与研究讨论入口

目标是轻量空中视觉语言导航，计划在 16GB Jetson 完成在线推理；本包没有新增板上测量。Aerial 默认路线模型为 aerial_route_recurrent_v2；v5 使用冻结 DINOv3 ViT-S/16，首轮 224、hidden=128，沿用文本、区域融合、GRU 和动作头。v3 的 CLIP 子句路径与 v5 的 DINO 路径不同，不应未经说明叠加。

LANI 在 uavnav/lani/，DINO 学生继承 uavnav/avln/model.py::AerialDinoRouteNet，01 已纳入该共享模型。原生 RGB128，DINO 内部重采样到 224，GA 保持 128，放大不增加原图细节。GA-LSTM 动态导入 CIFF 原类并适配现代接口；项目以 BC 重训，不能称原论文 A3C 复现。预训练权限、输入和计算差异必须公开，不能把模型差值直接归因融合或记忆。

门控、GRU、注意力、正则化、替换骨干本身不作为已证实的主创新。候选改进先说明具体失败机制，再给单因素修改、对应消融、计算预算和否证条件。测试通过、参数量减少或教师准确率提高都不自动等于导航收益。

LANI 有效 train/dev/test 为 19762/4182/4260 个 segment，动作前含 STOP 状态为 506066/107603/109593。项目词表仅由 train 构建、PAD0/UNK1，与官方 2293 词表分开。best 按 dev 无权教师 CE 选择，不能称导航最优。六条短任务只认证环境和简单策略链路，不是完整 dev/test 学习成绩。

最近收回的 LANI 队列状态为 2026-10-21 21:49:38，完整导航结果为 null；只能解释当时状态，本轮没有连接服务器。不能推断今天队列仍在运行或已完成。README 较早的 v5 尚无训练描述，后来已有 2026-10-21 局部 1epoch 诊断更新；存在局部训练事实，仍缺完整来源导航证据。历史文档不能当同一时点的事实表。

## 外部依赖

归档外仍需冻结的 DINOv3/AirVLN/CIFF 源码、真实预训练资产、官方标注、独立真实 RGB 缓存及 Unity/AirSim 场景。四份 requirements 是分层说明，不是完整 lockfile，不保证任意 Python/CUDA/Jetson 组合可直接运行。

- DINOv3 依配置指向独立源码和权重，按 SHA 绑定。本包没有复制完整 DINOv3 仓库。
- GA-LSTM 需要 CIFF src/baselines/chaplot_model_default.py；LANI 环境需要其 parser/server、配置及 Linux Unity/X 显示。未提供这些第三方文件时，模型应说明上游内部实现未直接审阅，不能把本地适配层当完整网络。
- AirVLN Seq2Seq/CMA 需要上游原类与真实 DDPPO 资产，不能用自写近似类替代。
- Aerial 闭环需要 AirSim/RPC、场景和对应计分依赖，回放分类不能提供自主导航成绩。

上游公开入口：DINOv3 https://github.com/facebookresearch/dinov3 ，AirVLN https://github.com/AirVLN/AirVLN ，CIFF https://github.com/lil-lab/ciff 。这些链接是来源指引，不表示本轮核对了它们最新版本，应以冻结 SHA 为准。

## 排除范围

不收录数据集、RGB/depth、渲染缓存、权重、场景二进制、虚拟环境、完整 runs/plan、下载残片、旧 exports、父级全量 progress/constraints、SSH 配置、凭据、Cookie 和 Webhook。少量证据仅从明确白名单复制。原有证据、失败记录和旧讨论包保留，未删除。

源码/测试中的 localhost、fixture 和默认数据目录属于接口语义，保持原字节；文档副本只替换环境根目录，不把代码改成伪代码。不宣称关键词扫描能够证明不存在所有秘密。本轮没有把任何项目文件上传到外部服务。

## 可复制的开场提问

### 模型结构和研究改进

你收到的是一份有时间边界的研究代码快照。请先读 00 和 01，分清 LANI 四动作、Aerial 八动作和历史 FOV。先核对实际策略输入，视觉/文本/历史/记忆/动作头的数据流，类继承和动态外部依赖，训练及推理状态生命周期。引用原始路径、函数和可核对的原文件行号，不引用合并 TXT 行号。明确哪些内容已直接读到，哪些依据注释或调用推断，哪些材料尚缺。完成结构核对后，只选择一个有证据的瓶颈提出改进，并给必要实验、配对条件和失败判据。不要把教师准确率当导航成绩，也不要仅凭骨干或门控声称创新。

### 代码审查和问题定位

请按模块审查。本轮先检查我指定的路径和问题；未读完不能声明全项目无问题。优先核当前观测与未来信息边界、划分隔离、动作/STOP 合同、carry/detach/reset、损失归一和真实更新次数、checkpoint 来源、异常及失败如何影响评分分母。确认问题需给触发条件、原始路径/函数/原行号、影响、最小修复和能证伪的验证。区分确认缺陷、待补证据和性能候选。不修改旧结果，不假定未提供的数据/权重/服务器状态。如需测试或审核实现，指出需要 04 至 07 中哪个卷。

## 平台核查依据

日期：2026-10-27；套餐、界面及后续官方规则可能变化。上传容量不是每轮上下文，也不是逐行阅读证明。

- ChatGPT 上传帮助明确支持 TXT；文档每文件 512MB，文本/文档每文件 200 万 tokens；Free 当前每天 3 次文件上传。https://help.openai.com/en/articles/8555545-uploading-files-and-audio-to-chatgpt
- ChatGPT Projects：Free 每项目 5 文件、Go/Plus 25 文件、Edu/Pro/Business/Enterprise 40 文件。https://help.openai.com/en/articles/10169521-projects-in-chatgpt
- Claude 上传帮助明确支持 TXT；聊天每文件 500MB、每聊天最多 20 文件；Projects 每文件 30MB，文本仍有上下文限制。https://support.claude.com/en/articles/8241126-upload-files-to-claude
- Claude 付费 Projects 的 RAG 检索相关片段，不是每轮同时加载全部材料。https://support.claude.com/en/articles/11473015-retrieval-augmented-generation-rag-for-projects

各卷低于 1MB；未用平台 tokenizer，不给伪精确 token 数。清单只统计字节、Unicode 字符和原文行数。包内不含本轮新增真实训练、导航或部署结论。
