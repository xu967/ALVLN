# AGENTS.md

This file provides guidance to Codex (claude.ai/code) when working with code in this repository.

## 项目定位

2026-10-21用户另授权完整LANI训练与dev/test开源比较，作为独立分支。入口仍为`train.py --dataset lani_v1`及`scripts/verify_lani.py --mode collect|evaluate|pipeline`，实现位于`uavnav/lani/`。LANI原生RGB128、四动作Forward/TurnRight/TurnLeft/Stop，STOP索引3，XZ严格小于5场景单位，正式40次移动；不可套用下文Aerial八动作/STOP0/20m。完整train/dev/test有效segment19762/4182/4260，教师超预算任务仍保留；词表只由train构建，PAD0/UNK1。学生冻结DINOv3/224与原CIFF GA-LSTM/128在同BC配方重训，GA属于BC适配，不称原A3C复现；旧checkpoint拒绝混用。当前证据和冻结完整队列见`plan/lani_verification_20261021/`及根progress，未测完整导航指标null。服务器操作仍主agent单连接，先核GPU/共享盘真实写入，保所有失败，不改上游。

轻量空中视觉语言导航（AVLN）研究代码。当前主任务是 AerialVLN-S 长程语言路线导航：输入前视 RGB、完整指令和已执行动作历史，输出八类离散动作（0 为 STOP）。数据协议为 `aerialvln_s_v1`，成功判定使用 XY 20 米。旧 FOV 对象接近任务保留为历史路径，不得与新路线任务混用。

项目根目录在上一级：`../constraints.md`、`../progress.md`、`../AGENTS.md`、`plan/修改方案.md` 是执行规则、当前状态、分工约束和量化合同的入口。开工前先读，尤其是 `constraints.md` 第 27 至 47 条。本目录 `README.md` 是数据合同、采集流程和历史实验边界的完整说明。项目没有 Git 元数据、构建步骤、格式化器或 linter。

`runs/` 与 `plan/` 中的文件是实验证据和冻结来源，不是临时产物。`../idea/` 是上游仓库，保持原样。

## 环境与常用命令

所有命令从 `code/` 目录执行，统一加 `-B` 禁止生成字节码。2026-10-20 本机原 `/path/to/python` 已不存在，已核现有 `/path/to/python`（Python 3.13、torch 2.7.1+cu118）可做 CPU 回归；GPU 验证前另核硬件与 CUDA 兼容性。服务器使用 `/opt/conda/bin/python`。下文 `python` 指代对应环境。

```bash
# 全量回归
python -B -m unittest discover -s tests -v

# 单个用例或单个文件
python -B -m unittest discover -s tests -k <test_name> -v
python -B -m unittest discover -s tests -p "test_data.py" -v

# 入口帮助
python -B evaluate.py --help
python -B scripts/verify_stage2.py --help
python -B scripts/audit_training.py --help
```

训练没有独立编译步骤。AerialVLN-S 训练默认使用 CUDA，需要独立 train/validation 缓存清单和真实数据；CUDA 不可用时拒绝静默回退，正式训练需先确认 GPU 资源：

```bash
export UAVNAV_DATASET=aerialvln_s_v1
export UAVNAV_DATA_ROOT=/project-data/aerialvln/DATA/data/aerialvln-s
export UAVNAV_CACHE_MANIFEST=/project-data/aerialvln/cache/full/pass0/train_index.json
export UAVNAV_VALIDATION_CACHE_MANIFEST=/project-data/aerialvln/cache/full/development_index.json
export UAVNAV_DEVICE=cuda
export UAVNAV_WORKERS=0
export UAVNAV_NAME=<新实验名>
python -B train.py
```

DINOv3 v5 只替换视觉前端，首轮对照保持冻结、224 输入和 hidden=128；训练实现支持224/320，320须独立登记分辨率实验：

```bash
export UAVNAV_ARCHITECTURE=aerial_route_dino_v5
export UAVNAV_DINO_REPO=../idea/DINOv3
export UAVNAV_DINO_WEIGHTS=<dinov3_vits16_pretrain_lvd1689m-08c60483.pth>
export UAVNAV_DINO_VARIANT=vits16
export UAVNAV_IMGSZ=224
export UAVNAV_NAME=<新实验名>
python -B train.py
```

v5 不做 R18 特征缓存，也不接入 CLIP；首次训练必须提供存在的 DINOv3 源码和权重，随机初始化会被拒绝。架构直接构造唯一视觉/文本路径，混用 DINO 配置、CLIP 文本缓存或不兼容视觉缓存会被拒绝。构造清理保持旧权重前向；DINO/v3新随机初值可能变化，新run记录 `model_construction_version` 和初值SHA，不用同seed替代共享参数配对。

闭环评测需要场景已启动；正式合同要求完整 val split、AirSim、`eval_adapter_v2` 和 500 动作预算：

```bash
python -B evaluate.py --dataset aerialvln_s_v1 --backend airsim \
  --data-root "$UAVNAV_DATA_ROOT" --split val_unseen \
  --scene-endpoints <全部场景端点JSON> --scene-id <当前执行scene> \
  --checkpoint <冻结checkpoint> --device cuda \
  --metric-protocol eval_adapter_v2 --require-formal-protocol --max-steps 500 \
  --output <新的评测目录>
```

同一评测目录继续下一场景时只追加 `--resume`。`--backend replay` 只做教师分类诊断，不产生导航成绩。

数据采集、合并、开发名单冻结与 DAgger 统一走 `scripts/verify_stage2.py` 的 `--mode collect|merge|plan-development|dagger|integration|learnability`。采集和 DAgger 首次即填写 `--resume-collection`，并显式提供 `--scene-build-dir` 与 `--capture-session-id`。

训练结果复算：

```bash
python -B scripts/audit_training.py --run-dir runs/train/<experiment> \
  --output-dir runs/train/<experiment>/audit --device cuda --workers 0
python -B scripts/audit_training.py --mode loss-scale --run-dir <run> --output-json <证据JSON>
```

`scripts/audit_dataset.py` 只审核历史 FOV 数据。`scripts/verify_stage2.py` 的 `integration` 和 `learnability` 通过 `train(overrides=...)` 复用同一训练入口，仅覆盖验收范围。

## 架构

### 配置与入口

`train.py::aerial_training_parameters()` 是路线训练的唯一默认配置入口，环境变量和显式 `overrides` 在此汇总。`train(dataset, overrides)` 统一正式训练和验收调用；AerialVLN-S 走 `uavnav/avln/fit.py::fit_aerial()`，旧 FOV 走 `fit()`。超参数不另设 CLI，新增开关必须进入该入口并经 `validate_training_controls` 校验。

`evaluate.py` 负责数据/名单选择、预检、AirSim attempt 调度和指标汇总。参数校验在导入 PyTorch 前完成，便于无 GPU 环境查看用法。

### 数据合同

`uavnav/avln/data.py` 是数据层的核心：

- 官方标注只读，严格校验字段、动作/位姿一致性、STOP 位置和来源 SHA；train 单点 STOP 候选只打隔离标记，不改原件。
- 真实渲染缓存清单绑定标注 SHA、render protocol、场景构建和 capture session。训练、验证、多 render pass 的来源和会话必须独立。
- 采样策略为 `aerialvln_s_before_action_v1`，取动作前观测；历史策略 `action_onehot8_v1` 只包含过去已执行动作。
- 按 `(scene_id, episode_id)` 组成完整 episode，帧必须从 0 连续到末 STOP。循环模型按完整 episode 连续分块训练，chunk 间携带并 detach GRU 状态，新 episode 清零。
- 开发集从官方 train 按几何路线身份成组划分（`aerial_train_geometry_grouped_v1`），不使用 episode ID 或逐帧随机拆分。
- `preprocess_rgb()` 与推理共用；`collate()` 生成模型输入。

### 模型版本

`uavnav/avln/model.py` 中的继承链保持历史 checkpoint 语义：

- `WaypointNet`：旧 FOV 航点回归。
- `GroundedWaypointNet`：文字查询的区域视觉策略。
- `AerialRouteNet`：`aerial_route_v1`，八动作。
- `AerialRecurrentRouteNet`：`aerial_route_recurrent_v2`，跨步 GRU 记忆、冻结视觉 BN 运行统计，支持 `carry`/`reset_each_step` 记忆对照和状态条件文本查询。
- `AerialClauseRouteNet`：`aerial_route_recurrent_clause_v3`，冻结 CLIP 子句特征与只读历史的子句指针。
- `AerialDinoRouteNet`：`aerial_route_dino_v5`，冻结 DINOv3 ViT-S/16，CLS 加 patch token，沿用 v2 文本/区域/GRU/动作头，checkpoint 格式 8。
- `AerialRGBDRecurrentRouteNet`：`aerial_route_recurrent_rgbd_v3`，增加深度编码。
- `AirVLNRGBAdapter`：`airvln_seq2seq_*` / `airvln_cma_*`，导入冻结的官方源码和 DDPPO 资产，checkpoint 格式 6/7。

checkpoint 格式与架构对应：旧 FOV 与 `aerial_route_v1` 为 4，路线循环 v2/v3 为 5，官方 RGB 基线为 6，RGB-D 模型为 7，DINOv3 v5 为 8。模型配置写入 checkpoint，加载时校验架构、词表、tokenizer、任务协议和来源，不按参数形状猜 forward。v5 还记录 DINOv3 variant、输入尺寸、patch size、embed dim、源码 SHA256 和权重 SHA256；DINOv3 源码目录可用 `UAVNAV_DINO_REPO` 覆盖，源码 SHA 不一致时拒绝加载。

### 训练与 run 产物

`fit_aerial()` 在训练前完成合同校验：数据覆盖、会话不重叠、词表只由训练部分构建、render pass 来源、多 pass 选择、损失协议、学习率分组和更新预算。优化器为 AdamW，视觉骨干学习率为其余参数的 0.1 倍，调度器为余弦退火。

每次实验写入 `runs/train/<experiment>/`：

- `hparams.yaml`、`split_manifest.json`、`task_config.json`
- `train_cache_manifest.json`、`validation_cache_manifest.json`、`source_snapshot/`
- `results.csv`、`results.png`
- `weights/last.pt`、`weights/best.pt`
- `metrics.json`、`audit/`、`launch.json` 等运行证据

`best.pt` 按无权重教师验证 CE 选取，不代表导航最优。训练未跑闭环时导航指标保持 `null`。目录已存在且非空时拒绝启动，必须换新的 `UAVNAV_NAME`。

### 推理与闭环

`uavnav/avln/inference.py::AerialActionPredictor` 是有状态的单步推理器，只接受当前图像（RGB-D 架构还需当前深度）、完整指令、已执行动作历史或等价 one-hot。每个 episode 必须调用 `reset_episode()`；跨指令复用记忆会被拒绝。

`closed_loop.py` 负责自主 rollout、教师回放、DAgger 采集和指标计算；`airsim_env.py` 负责 AirSim 八动作设位姿和观测；`geometry.py::aerial_pose_transition()` 是数据标签与仿真共用的动作转换。`rollout.py` 和 `simulator.py` 属于历史 FOV 路径。

闭环证据按 attempt 组织：`attempts/<scene>_<episode>/attempt_N/` 保存元数据、`journal.jsonl`、rollout 或 error；`attempt_ledger.jsonl` 冻结尝试顺序和内容 SHA。评分只读封口的 `episodes/`，未完成名单保持 `invalid/null`。

## 关键不变量

- 策略输入只能来自当前观测、指令、已执行动作和合法过去记忆。目标、参考路线、教师动作、未来帧不得进入决策。
- 训练与验证的 episode、几何路线和 capture session 不得重叠；官方 split 不得混入训练，正式 `val_unseen` 不用于调参或挑 checkpoint。
- 当前阶段固定 `seed=0`，未经用户授权不启动多 seed 队列。
- 循环模型单 episode 路径要求 `workers=0`；`episode_batch` 只支持特定 v2 组合。
- 旧架构、旧 checkpoint、旧 run 和旧指标保持原义。新增采样、损失、分组、模型或计分行为必须显式版本化。
- 教师准确率、学习率曲线和接口回归不构成导航成绩。未完成的 NE/SR/OSR/nDTW/sDTW/STOP 指标保持 `null`，不填估计值。
- 官方基线必须使用冻结的上游源码、完整来源 SHA 清单和真实 DDPPO 权重，不用近似网络替代。
- 已存在的研究输出、缓存、权重、失败证据和审核记录不覆盖、不删除。清理前核对引用、来源和进程占用。
- 测试使用合成数据与 fake SDK，验证的是接口和合同，不是真实场景或泛化结果。缺 `fastdtw` 等可选依赖时测试会明确跳过，不用其他算法替代。

## 依赖分层

`requirements.txt` 是核心依赖；`requirements-baseline.txt` 是官方 RGB 适配的可选包；`requirements-eval.txt` 是 fastdtw、AirSim/RPC 和 DAgger 教师图的可选包。三者都不是完整 lockfile，也不保证 Jetson 兼容。torch/torchvision 需按目标 CUDA 或 JetPack 选择匹配版本。
