# 轻量 AVLN 代码说明

当前主路径是 AerialVLN-S 长程语言路线导航。执行状态只更新项目根 [progress.md](../progress.md)，修改顺序见 [修改方案](plan/修改方案.md)。运行前读 [constraints.md](../constraints.md)；旧 FOV 原始数据、权重、合同和实验来源保留。

## LANI 独立兼容性验证

LANI 是独立验证分支，不使用 AerialVLN-S 的八动作、20 米半径或旧 checkpoint。官方 CIFF 源码保持原样，数据与模拟器来自作者 Cornell 发布包；持久数据根为 `/datasets/LANI/official_emnlp2018`，具体校验和当前运行结果见 `plan/lani_verification_20261021/`。

已有真实 Linux 模拟器和可用 X 显示时，从 `code/` 执行：

```bash
python -B scripts/verify_lani.py \
  --upstream-root ../idea/ciff-master \
  --asset-root <含data与simulators的LANI根> \
  --split train --episodes 1 --max-steps 40 --timeout 300 \
  --output <新的独占验证目录>
```

入口复用官方 Py3 server/parser，显式隐藏目标标记，先完整教师路线验证实际位姿和图像更新，再在同一批任务跑 STOP、Random（包含 STOP）、恒前进。每任务重置。128×128、四动作顺序 `Forward/TurnRight/TurnLeft/Stop`；最多 40 次移动加终止通信，区分自主和预算停止。CLI 有界清理本次自建进程组，失败日志与轨迹保留，不静默回退合成环境。

原生 SD/SR 使用 XZ 距离与严格 `<5` 场景单位；OSR 和精确二维 nDTW/sDTW 是另行记录的项目扩展，教师回放产生诊断参考，不能当论文原生 NED，也不与 Aerial 旧评测混报。SPL 缺可行最短路保持 `null`。任何 smoke 比较均非完整官方 dev/test。

2026-10-21 真实 Unity 已通过 train/dev 各三任务验收，具体短任务结果在 `plan/lani_verification_20261021/smoke_comparison_audit.json`。这不是完整 dev/test 或学习模型成绩。

用户已授权完整 LANI 训练与 dev/test 对照。独立模块 `uavnav/lani/` 提供全部有效 segment 的来源审核、只由 train 构建的词表、动作前 RGB 缓存、连续任务 BC 及自主闭环。四动作学生使用冻结 DINOv3/224；GA-LSTM 直接复用冻结 CIFF 原类，仅适配现代设备/GRU 接口，使用原生128 RGB。两者均重训，不加载 Aerial 八动作权重；GA 的 BC 配方属于适配对照，不称论文 A3C 训练复现。LINGUNet 的全景/位姿参考另列。

完整缓存采集不按教师长度过滤，`--limit 0` 为默认完整范围：

```bash
python -B scripts/verify_lani.py --mode collect --upstream-root ../idea/ciff-master \
  --asset-root <已核LANI根> --split train --resume --timeout 259200 --output <新train缓存目录>
```

对 dev/test 分别采集到独立目录。正式训练只接受完整 train/dev 缓存，固定 seed0，设备必须 CUDA：

```bash
export UAVNAV_DATA_ROOT=<已核LANI根>
export UAVNAV_CACHE_MANIFEST=<train缓存目录>/manifest.json
export UAVNAV_VALIDATION_CACHE_MANIFEST=<dev缓存目录>/manifest.json
export UAVNAV_ARCHITECTURE=lani_ga_lstm_v1
export UAVNAV_UPSTREAM_ROOT=../idea/ciff-master
export UAVNAV_NAME=<独立实验名>
python -B train.py --dataset lani_v1
```

学生设 `UAVNAV_ARCHITECTURE=lani_dino_recurrent_v1`，并提供 `UAVNAV_DINO_REPO`、真实 `UAVNAV_DINO_WEIGHTS`。训练配置只在 `train.py::lani_training_parameters()` 汇总。`UAVNAV_LANI_PROJECT` 可显式指定独立持久训练输出根。每个run保存配置、来源、曲线、last/best权重，best按完整dev无权重教师CE选择，导航指标在闭环前保持null。

自主评测使用 `scripts/verify_lani.py --mode evaluate --split dev|test --checkpoint <best.pt> --reference-manifest <对应split缓存>/manifest.json`，并填写相同上游、资产和新输出目录。40次移动预算包含所有官方有效任务，超预算难例保留。`--policy stop|random|forward` 可跑完整简单基线；`--mode pipeline --pipeline-spec <冻结合同>` 串行执行完整采集、两模型训练及dev/test比较，任一步失败停止并保日志。合同和未完成项见 [修改方案](plan/修改方案.md)及根目录进度。

## 当前主线与边界

- 主路径：`aerialvln_s_v1` + `aerial_route_recurrent_v2` + `set_pose_unpaused_rgbd_bounded_rerequest_v3` + `eval_adapter_v2`，checkpoint 格式 5，单 episode 连续分块，视觉默认冻结。
- 实验特性：`aerial_route_recurrent_clause_v3`（冻结 CLIP 子句指针，需要 `UAVNAV_VISION_FEATURE_CACHE`、`UAVNAV_TEXT_FEATURE_CACHE` 和可选依赖 `open_clip_torch`）、`aerial_route_recurrent_rgbd_v3`、`aerial_route_dino_v5`（冻结 DINOv3 ViT，checkpoint 格式 8，需要 `UAVNAV_DINO_REPO` 和 `UAVNAV_DINO_WEIGHTS`，不做 R18 特征缓存）、`UAVNAV_EPISODE_BATCH`、`UAVNAV_SAMPLE_INDEX`、`UAVNAV_LOSS_VERSION=episode_normalized_ce_v2`、`UAVNAV_HISTORY_DROPOUT`。实验特性在通过独立审核前不进入正式对照。
- 历史只读：FOV 对象接近、`aerial_route_v1`、checkpoint 格式 3/4、旧 render/capture 协议。保留加载和证据语义，不再扩展。

2026-10-19 审核基线与当前执行范围见 [严格审查与执行修改方案](plan/review_package/AVLN训练代码严格审查与执行修改方案_20261019.md)。报告附录记录审核时的源码 SHA；后续代码修改不自动继承该快照的测试结论。当前 AVLN 指空中视觉语言导航，输入不含音频。动作 2/3 是偏航转向，6/7 是侧移，不能统称为同一种“左右动作”。v3 子句模型与 v5 DINO 模型尚无真实训练结果；能够构建或重载不代表独立审核、真实训练和导航均已通过。v3 的长文本、reset、状态记录与审核问题，以及 episode_batch 独立审核缺口，按上述报告逐项验收，未验收前不进入正式对照。

最新完整来源五轮实验为 `full_rgb_frozen_bc_seed0_20261011_convergence5ep`，实际训练/开发分区为 8097/2010 个指令 episode，944269/226772 个状态；原始逐轮摘要见 [result_check_latest.json](plan/avln_code_comparison/gpu_launch_20261007/full_training_20261011_convergence5ep/result_check_latest.json)，配置与来源见同目录 `experiment_contract.json`。该摘要中的 train 指标是在各块更新参数期间累计的预测，不是固定末权重在 eval 模式的训练集复算，不能直接据此判定末权重欠拟合。第 5 轮 dev 教师准确率为 70.3504%，无权 CE 为 0.870044；不是自主导航成绩。本地同步摘要不等于已有完整原 run、缓存和权重副本，复算前需核实际资产与 SHA。

[三条独立 dev 路线诊断](plan/avln_code_comparison/gpu_launch_20261007/full_training_20261011_convergence5ep/navigation_gpu_20261014/startup_retry1/result_summary.json)使用 epoch3 权重、seed0、200 动作，三条均未成功；不能与 epoch5 教师统计混作同权重实验，也不能当完整官方验证。正式完整 val_seen/val_unseen 导航尚未完成，缺失指标保持 `null`。`best.pt` 仍仅按无权教师验证 CE 选取，导航候选保存及选模需另按冻结合同执行。

### 本轮修复与诊断入口

2026-10-19 按修订方案先落实 R01/R02/R03、R16 的候选留存和 R19 的最低训练记录。默认模型结构、损失与更新频率沿用原合同。Aerial 在线训练读取 RGB 时核本次字节 SHA，再从同一字节解码；内容变化即拒绝。视觉特征缓存载荷/精度认证仍按 R18 单独验收。

- `scripts/audit_training.py` 同一权重分别复算 train/dev，新增首步、动作切换邻域、侧移、STOP 及 STOP 前五步分层，输出帧微平均、episode 宏平均及存在冻结几何映射时的路线宏平均。DAgger 片段不冒完整 BC 教师前缀，总训练复算与分层范围分别记录。查表只拟合 BC train 的过去两动作，不作为语言/视觉贡献证明。
- `--mode loss-scale` 的 `actual_training_formula` 根据实际 v1/v2 协议选择分母，原固定块分母列仍只是诊断。合成 logits 导数不代表真实模型参数梯度或导航收益。
- `UAVNAV_CANDIDATE_EPOCHS` 接受训练开始前登记的升序、不重复、从 1 起的 epoch JSON 列表，默认 `[]`。候选在该轮验证完成后保存为 `weights/epoch_XXX.pt`，`candidate_inventory.json` 绑定 SHA、来源与实际累计更新数。审核时用 `--teacher-checkpoint <run>/weights/epoch_XXX.pt`。该清单只登记候选，不产生导航排名；开发名单、预算、排序及全部尝试仍需事前冻结，尚未自动生成 `navigation_best`。
- 新 run 的 `runtime.json` 记录软件、设备与精度设置；`training_diagnostics.jsonl` 明示 train 累计预测和 validation 末权重 eval 的区别。单 episode 路径记录裁剪前总梯度、裁剪比例及主机侧阶段耗时；CUDA 未同步的阶段耗时不能当 GPU 内核耗时。`UAVNAV_DIAGNOSTICS_INTERVAL` 默认每 128 次更新抽样分支梯度，0 关闭分支抽样。非有限梯度在更新前停止并保留 `training_failure*.json`；多 episode 路径尚未具备这套完整诊断。

这些是输入正确性与诊断能力的修改，未运行新的真实训练或闭环，不能据此声明 SR/sDTW 上升。v3 总审核入口分派已补齐，其长文本、状态与资产合同仍需后续独立修复验收。

### 编码器组合与 DINOv3 v5 试跑入口

每个架构只使用自己的视觉与文本路径：默认 v2 是 ImageNet ResNet18 + 词嵌入/LSTM；v5 是 DINOv3 + 同一 LSTM 文本结构；v3 是 ResNet18 + 冻结 CLIP 子句特征，策略中不构造 LSTM。v5 直接构造 DINO，不先创建再丢弃 ResNet，也不接入 CLIP。RGB-D 与官方对照保留各自明确的模态合同。

新训练在入口拒绝不属于所选架构的 DINO/CLIP 配置与缓存。切换架构前清除不再使用的 `UAVNAV_DINO_*`、`UAVNAV_TEXT_FEATURE_CACHE` 和 `UAVNAV_VISION_FEATURE_CACHE`；v5 不接受 R18 特征缓存。模型构建与 checkpoint 重载也核对这些组合，避免声明与实际前向不一致。

构造清理保持已有参数名称、注册顺序和旧权重前向语义。DINO/v3 不再消耗无用编码器的随机初始化，因此同 seed 的新建模型初值可能不同；新 run 记录 `model_construction_version=direct_selected_encoders_v1`、实际初值 SHA 和源码。配对实验仍须实际复制并核对共享参数，不能仅用 seed0 声称同初值。旧权重缺该字段可按原架构严格加载，不补造历史构造记录。

DINOv3 只替换视觉前端，文本、区域注意力、GRU 和八动作头沿用 v2。首轮对照保持冻结、224 输入、hidden=128；当前训练代码也接受 320，但应作为另一个分辨率实验。原生 224 缓存放大到 320 不会新增原始细节，若重渲染必须同步相机、缓存来源和在线输入：

```bash
export UAVNAV_ARCHITECTURE=aerial_route_dino_v5
export UAVNAV_DINO_REPO=../idea/DINOv3
export UAVNAV_DINO_WEIGHTS="$PWD/DINOv权重文件/checkpoints/dinov3_vits16_pretrain_lvd1689m-08c60483.pth"
export UAVNAV_DINO_VARIANT=vits16
export UAVNAV_IMGSZ=224
export UAVNAV_NAME=dino_v5_s16_224_frozen_seed0
unset UAVNAV_TEXT_FEATURE_CACHE UAVNAV_VISION_FEATURE_CACHE
python -B train.py
```

v5 的 `model_config.visual_encoder` 记录 variant、输入尺寸、patch size、embed dim、源码 SHA256 和权重 SHA256。推理时若 DINOv3 源码目录变化会被拒绝；可设置 `UAVNAV_DINO_REPO` 指向同一份只读源码。DINOv3 使用 DINOv3 License，论文和衍生发布需致谢并遵守其条款。
- Aerial 评测当前只接受 seed0；正式合同仍要求完整 val split、AirSim、`eval_adapter_v2` 和 500 动作预算。v3 与 `episode_batch` 的审计入口仍在收敛，未完成前不用于正式结果。

## 任务与已测边界

数据协议为 `aerialvln_s_v1`，当前训练默认 `aerial_route_recurrent_v2`、格式 5：前视 RGB、完整指令、过去执行动作、128 维跨步记忆，八动作中的 0 为自主 STOP。新 episode 清空记忆；完整 episode 连续分块，块间携带并 detach 状态。默认冻结整个视觉骨干，投影、文本、融合与 GRU 等下游参数继续学习；显式 `finetune` 时卷积及 BN affine 参数才学习。两种模式均固定视觉 BatchNorm 运行统计，避免当前动作受同块未来图像影响。格式 4 的 `aerial_route_v1` 保持原义。

2026-10-05，scene2 开发子集包含 16 条训练路线、36 条指令 episode、2486 个监督状态和 1076 张唯一 RGB；验证子集为 8 条路线、594 个状态。20 轮后 last 的教师准确率为 99.7989%、STOP 召回为 97.2222%，三条预冻结已训练路线中两条自主 STOP 成功，长路线在 200 动作预算结束时失败。best 按验证 CE 选在第 2 轮，验证准确率 52.3569%、STOP 召回 12.5%；后续 CE 上升，不能只报训练拟合或把 best 当作 SR 最优。

[原始训练证据](plan/aerialvln_dataset_20261005/v2_server_20261005/evidence/verification_summary.json)与[首次失败定位](plan/aerialvln_dataset_20261005/v2_server_20261005/evidence/failure_localization.json)保留。后续[三次长路线重复](plan/aerialvln_dataset_20261005/observation_repeat_20261005_1336/repeat_analysis.json)均失败；三首错的[图像/记忆干预](plan/aerialvln_dataset_20261005/observation_repeat_20261005_1336/image_memory_factorial.json)及[同位姿80图](plan/aerialvln_dataset_20261005/controlled_render_20261005_1430/analysis.json)支持这些位置的视觉输入变化足以触发动作错误。固定记忆独立重放一致，具体渲染因素仍未知，不能写成下载损坏或整个记忆模块错误。

这些2026-10-05结果只支持局部教师拟合与部分已训练路线完成。后续官方原网络RGB适配实跑已完成，见下方2026-10-06对照；正式未知路线泛化、语言因果收益、原论文完整配方和16GB Jetson成本仍待测。

## 模块与复用边界

- `train.py::aerial_training_parameters()`：唯一的路线默认配置；`train(dataset, overrides)` 统一正式训练和开发验收调用，默认选择 AerialVLN-S，旧 FOV 必须显式选择。
- `uavnav/avln/data.py`：官方标注、完整帧与源哈希审核、按 episode 分组、分词及批处理；`preprocess_rgb()` 统一训练与推理图像变换。
- `model.py`、`fit.py`、`inference.py`：模型、训练循环及版本化权重重载；历史格式不按参数形状推断 forward。
- `airsim_env.py`：上游八动作设位姿和实际观测；`closed_loop.py`：自主循环、教师回放及日志计分。
- `metadata.py`：任务合同、名单和目标权限；`geometry.py::aerial_pose_transition()` 是数据标签与 AirSim 共用的八动作转换，旧机体变换仍保留。`rollout.py`、`simulator.py` 保留历史 FOV 路径。
- `scripts/verify_stage2.py`：场景缓存与开发验收；`scripts/audit_training.py`：冻结训练结果复算；`scripts/audit_dataset.py`：历史 FOV 文件审核。
- `tests/`：持续 `unittest` 回归；`runs/train/<experiment>/`：模型、日志、配置、快照与结果；`plan/`：方案与证据摘要。

主要复用 [AirVLN 官方仓库](https://github.com/AirVLN/AirVLN)，本地原件在 [idea/AirVLN](../idea/AirVLN/README.md)：场景设置、八动作、原标注、XY20 米计分、深度终止代理，以及 Seq2Seq/CMA/教师采集参考。v2/v3 视觉骨干复用 torchvision；`aerial_route_dino_v5` 使用 [idea/DINOv3](../idea/DINOv3) 的冻结 DINOv3 骨干，不复制其源码。nDTW 使用 fastdtw。项目代码负责轻量策略、缓存来源绑定、版本兼容和可审计闭环，不新建仿真平台。GRU、空间注意力、损失加权是已有组件，不直接作为论文主创新。

下一项基线优先复用以下上游模块，先核固定版本和配置，再接现有场景及评测合同：

- [Model/seq2seq_policy.py](../idea/AirVLN/Model/seq2seq_policy.py)：指令、RGB、深度与导航状态编码器。
- [Model/cma_policy.py](../idea/AirVLN/Model/cma_policy.py)：跨模态注意力及两级导航状态。
- [Model/il_trainer.py](../idea/AirVLN/Model/il_trainer.py)：序列动作交叉熵和训练状态管理。
- [src/vlnce_src/util.py](../idea/AirVLN/src/vlnce_src/util.py)：官方词表和 `Tokenizer`；本项目的 `route_numeric_v1` 保留数值，不能冒充未改动的官方文本设置。
- [src/vlnce_src/train.py](../idea/AirVLN/src/vlnce_src/train.py) 与 [dagger_train.py](../idea/AirVLN/src/vlnce_src/dagger_train.py)：教师采集、LMDB/特征缓存与策略访问状态的训练参考。特征缓存仅在对应骨干参数冻结或版本完全一致时复用，当前可学习视觉骨干不能长期使用旧特征。

## 数据与场景

官方固定来源为 Kaggle `shuboliu/aerialvln-s` v3、`shuboliu/aerialvln-simulators` v2。服务器路径：

```text
/project-data/aerialvln/
  DATA/data/aerialvln-s/   train、val_seen、val_unseen、test 标注
  ENVs/                  官方场景
  cache/                 派生 RGB 缓存与清单
  runtime/python/        当前隔离 AirSim/RPC/fastdtw 依赖
```

5 份标注、275 份场景文件的 CRC、长度与 SHA 验收通过，见 [下载验收](plan/aerialvln_dataset_20261005/download_verification.json)。train/val_seen/val_unseen/test 为 10113/333/531/770 个 episode；test 目标、路径和动作由官方隐藏。标注不包含预录 RGB，图像需真实场景渲染，缺隐藏字段或无预录图不能判为下载失败。

6 条单点 STOP 训练候选已在派生读取时隔离，原标注不改。官方 val_seen 的 321/333 条 episode 复用训练路线，不能证明未知路线泛化；本次 8 条开发验证路线中 3 条也在所选训练子集。来源与内容核查见 [数据审核](plan/aerialvln_dataset_20261005/dataset_deep_audit.json)，未知场景 `val_unseen` 需单独验收。

执行场景前核 GPU/Vulkan、所需场景及有效设置。按上游 ComputerVision 配置使用 `front_0`、`Drone_1`，Unreal 由非 root 账户运行。既有 AirSim 依赖设置为：

```bash
export PYTHONPATH=/project-data/aerialvln/runtime/python:/project/code
```

使用 `/opt/conda/bin/python`；本轮验收场景已停止、专用账户与临时副本已收尾，不把历史路径当作当前服务已启动。

## 开发与训练命令

### 新合同的显式入口

执行分工和版本规则见根 `constraints.md` 第27至43条；已有 `AGENTS.md` 保留。新入口默认不开启，旧run及权重保持原义。

- 评价：`evaluate.py --metric-protocol eval_adapter_v2` 使用含初始位置的新计分合同，正式完整split要求500动作，开发子集可显式200；评分与名单各自版本化并核SHA。该开关不会升级教师回放为自主导航。
- 教师开发验证：设置 `UAVNAV_VALIDATION_SPLIT=development_train_grouped`，`UAVNAV_DEVELOPMENT_FRACTION=0.2`、`UAVNAV_DEVELOPMENT_SPLIT_SEED=0`，或通过 `train(overrides=...)` 显式覆盖。train缓存和validation缓存都来自官方train，后者需独立v2采集session，并包含完整原名单或完整dev分区；额外训练pass全部过滤掉dev几何组。设置 `UAVNAV_DEVELOPMENT_SPLIT_MANIFEST` 可复用已冻结run的split_manifest或独立route manifest；比例与seed须一致。
- 几何身份按场景、完整XYZ/朝向形成，同路线全部指令成组；量化精度为1e-4m和1e-6rad，属于版本化分组规则，不宣称误差范围内所有路径都等价。位姿只用于审计和拆分，不送入policy。
- CPU损失尺度：复用 `scripts/audit_training.py --mode loss-scale --run-dir <run> --output-json <已有证据目录的新JSON>`；可用 `--supervision-json` 指定已保存的完整动作或局部教师记录，缺全集标签时仅核清单长度/日志更新数。候选固定分母仅作诊断，不改变默认训练损失。

### 审核后工程整改入口

- `--require-formal-protocol`：只允许完整官方val划分、真实AirSim、显式 `eval_adapter_v2` 和500预算。该检查证明评测合同符合要求，不证明模型泛化或完整复现论文。默认v1保留用于历史比较。
- `--resume`：仅续评本轮新建的Aerial AirSim v2目录，原权重、源码、标注、名单、预算、输入/设备/连接配置须一致。完整结束的成功和策略失败均复用；基础设施错误仅从起点重置后新建attempt，不从未知仿真状态继续动作。未封口完整结果、终止后清理错误或损坏证据须先审核，不自动重试择优。
- 每次尝试在 `attempts/<scene>_<episode>/attempt_N/` 保留元数据、逐事件 `journal.jsonl`、rollout或error；`attempt_ledger.jsonl`冻结顺序与内容SHA。评分只读取已封口的canonical `episodes/`，但 `metrics.json::attempt_audit` 单列所有尝试与基础设施错误；未完成名单保持invalid/null。SHA用于内容一致性，不能替代独立来源认证。
- 日志在动作派发前写入，RPC未返回的动作明确标“执行未知”，不能算零动作；回调写失败立即停止。即使不保存RGB/GRU诊断图，仍保事件与已返回动作前缀。写日志会改变墙钟时序，时延边界排除journal写入，导航结果仍需新真实实验。
- Aerial指标说明明确：时延为逐决策，包含STOP、预处理/模型/同步/输出解析，不含取图和控制；NE/SR/OSR是XY，nDTW是XYZ。contact、深度代理、连续飞行碰撞不混用，旧原始成绩不重写。
- 新run记录 `model_selection_basis` 和 `training_precision`，旧checkpoint缺这些增量字段仍按原义加载。best仍按无权教师CE；新增 `chunk_objective_mean_diagnostic` 与全样本加权CE分开，二者不等同导航最优。模型前向只接五个合法输入键，教师标签仅留损失侧。

重复恢复时使用与首次运行相同参数，仅追加 `--resume`；旧目录没有 `evaluation_run.json` 不能通过恢复开关升级。缺失的canonical文件仅从已核SHA的封口原attempt补写，已有内容不同则拒绝，不重新运行该路线。新 `--scene-endpoints` 支持完整split名单及按scene续评，场景仍由执行者启动并保存实际启动进程证据。独立开发集自主导航/sDTW选模是后续工作。

本机检查使用现有 `/path/to/python`。接口回归及现有真实缓存的成组拆分检查不构成新训练或闭环成绩，实际验收记录见根progress.md；独立dev自主导航及sDTW选模入口仍待接入。本地缺fastdtw的实际数值测试会明确跳过，不用其他算法替代。

从 `code/` 执行。没有独立编译步骤，要求兼容 PyTorch/torchvision 环境；本机已有 GPU 环境为 `/path/to/python-env`，不要覆盖其他项目环境。

依赖清单分层：`requirements.txt`为核心，`requirements-baseline.txt`为官方RGB适配的可选包，`requirements-eval.txt`为fastdtw/AirSim-RPC可选包。新增清单仅声明依赖，本轮没有安装；它们不是全环境锁文件，也不保证Jetson兼容。torch/torchvision需按CUDA或JetPack选择匹配版本；上游适配要求 `torch.serialization.safe_globals` 能力，缺时拒绝不安全回退。AirSim旧RPC的msgpack/Tornado兼容需在隔离环境核查，已有服务器runtime不被覆盖。

`UAVNAV_DEVICE`是训练入口环境变量；评测使用 `--device`，直接推理调用显式传 `device`，未传时按其可用设备默认。源码已有overrides支持lr/imgsz/history/seed，无需为每项追加另一配置入口。

```bash
python -B -m unittest discover -s tests -v
python -B evaluate.py --help
python -B scripts/verify_stage2.py --dataset aerialvln_s_v1 --help
```

采集命令需要对应场景已启动；输出文件和缓存目录使用新名称，拒绝覆盖旧缓存：

```bash
python -B scripts/verify_stage2.py --dataset aerialvln_s_v1 --mode collect --annotation-root /project-data/aerialvln/DATA/data/aerialvln-s --scene-id 2 --split train --sampling representative --episodes 16 --scene-build-dir <实际已启动的scene2构建目录> --capture-session-id <本次场景启动身份> --output /project-data/aerialvln/cache/route_development_scene2/pass0/train.json
```

`--episodes` 为独立路线数，代表采样覆盖动作和长度；同路 RGB 可复用，但保留全部 episode 及其指令。`--sampling all` 覆盖当前场景有效路线，单场景仍不是官方全量；`integration_shortest` 只用于集成。验证另用 `--split val_seen` 与独立输出，`--save-depth` 按需保留深度数组。

默认采集使用来源协议 `aerialvln_s_pose_rgb_v2`：绑定实际 API settings、实测 FOV、相机外参、构建文件 SHA 和逐帧响应相机/时序。构建摘要明确排除 Unreal `Saved` 运行目录，其他资产仍逐文件校验；采集前后来源变化则拒绝完成清单。场景保持未暂停、零等待；若 `simSetVehiclePose` 后传感器时间戳未推进，最多用 3 次 `simContinueForFrames(1)` 重取，并把重试次数写入帧记录，仍严格拒绝重复时间戳。`--scene-build-dir` 与启动进程的对应关系、`--capture-session-id` 均由调用方明确声明，命名本身不证明独立重启；实验执行时须真实分组。旧接口需显式 `--render-protocol legacy-v1`，其缺失来源字段保持未知，不能进入多 pass 训练。

正式训练统一通过 `train.py`，默认任务为 `aerialvln_s_v1`。默认参数集中在 `aerial_training_parameters()`，环境变量或已校验的 overrides 负责显式覆盖。以下为既有开发缓存路径示例，新实验须换 `UAVNAV_NAME`：

```bash
export UAVNAV_DATASET=aerialvln_s_v1
export UAVNAV_DATA_ROOT=/project-data/aerialvln/DATA/data/aerialvln-s
export UAVNAV_CACHE_MANIFEST=/project-data/aerialvln/cache/route_v2_scene2_20261005/train.json
export UAVNAV_VALIDATION_CACHE_MANIFEST=/project-data/aerialvln/cache/route_v2_scene2_20261005/val_seen.json
export UAVNAV_VALIDATION_SPLIT=val_seen
export UAVNAV_DEVICE=cuda
export UAVNAV_WORKERS=0
export UAVNAV_NAME=aerial_route_recurrent_v2_scene2_new_run
python -B train.py
```

默认 chunk16、224 图像、hidden128，有效 batch 是单条 episode，显存随 chunk 调整。模型、日志和快照写 `runs/train/<experiment>/`。未知成绩保持 `null`，不要把 sample 数或教师准确率当导航分数。

v2 的视觉冻结和多次完整渲染选项：

```bash
export UAVNAV_VISION_TRAIN_POLICY=frozen
export UAVNAV_CACHE_MANIFEST=/project-data/aerialvln/cache/route_development_scene2/pass0/train.json
export UAVNAV_RENDER_PASS_MANIFESTS='["/project-data/aerialvln/cache/route_development_scene2/pass1/train.json"]'
export UAVNAV_RENDER_PASS_SEED=0
```

`frozen` 为路线模型默认策略，符合 AirVLN 官方冻结预训练视觉骨干的构建；`finetune` 只有显式设置 `UAVNAV_VISION_TRAIN_POLICY=finetune` 才启用，作为小规模数据的对照实验。`frozen` 冻结全部视觉骨干参数（含 BN affine），投影、融合及 GRU 继续训练，两组均固定视觉 BN 运行统计。冻结不减少在线骨干大小。额外清单仅放 pass1 及之后，不能重复 pass0；单 pass 用空列表 `[]`。多 pass 必须有相同完整 episode/指令/监督和构建/设置合同、不同采集会话与图像文件来源。每条 episode 每轮由独立随机源选一个完整 pass，跨 chunk 不换 pass，不增加监督帧数或更新次数。训练/验证会话重叠则拒绝。新 run 保存每 pass 来源快照、内容摘要及 `render_pass_selections.jsonl`；审核入口核全部来源、选择与更新预算，训练分类明确针对 pass0。新选项只支持路线 v2，历史权重保留原推理语义。

`verify_stage2.py --mode integration` 只验一轮保存重载；`--mode learnability` 验八类覆盖、教师准确率至少 95%、每类及 STOP 召回至少 90%且超过多数类。这些阈值属于小集合可学性验收，不是完整训练集的通用指标合同。两者调用 `train(dataset="aerialvln_s_v1", overrides=...)`，复用学习率等默认配置，但当前仍强制 `validation_split=val_seen`，且拒绝 `--development-split-manifest`，因此不能称为默认 grouped-dev 主路径验收。后处理当前重读整份 train 缓存做拟合诊断；若后续接入 grouped-dev，必须同时按该 run 冻结名单筛实际 train 成员并单列 dev，不能只改 validation 参数。本批仅澄清能力边界，不运行或改写这两个模式。

结果独立审核：

```bash
python -B scripts/audit_training.py --run-dir runs/train/<experiment> --output-dir runs/train/<experiment>/audit --device cuda --workers 0
```

审核核冻结输入、监督、快照与权重，按完整教师前缀重放循环模型，报告各类召回、STOP、多数先验和 OOV。验证 CE 无权重，best 仅按该 CE 选取；正式导航候选仍需固定验证闭环，不能据 best 文件名宣称最好导航。

## 2026-10-07 全量实验代码入口

所有实验固定seed0。2026-10-07 入口建立时，A100 一轮预检只证明接口，旧采集队列失败且完整优化尚未开始；这属于历史状态，后续五轮结果见本文顶部证据。当前资源与执行状态看根 `progress.md`，不得据历史运行状态重启队列。2026-10-08 用户确认先跑完整 AerialVLN-S，以下入口按完整训练来源准备，新的真实采集与训练仍须先通过 GPU/场景门。原 RGB 学生 v2/格式5 保持原义；新增学生 `aerial_route_recurrent_rgbd_v3`、官方 `airvln_seq2seq_rgbd_v1` / `airvln_cma_rgbd_v1` 使用格式7，要求真实归一化前视深度256×256，缺深度或来源 SHA 不符即拒绝。RGB-D 基线启用原深度编码器，仍是项目训练适配，不能称原论文完整复现。

### 先采集并核完整数据

按场景启动真实构建，保存进程命令与启动会话证据。每个scene、split、独立pass分别用新目录；首次就填写 `--resume-collection`，中断后同参数继续，封口路线核验后复用、未封口路线另建attempt。场景重启改变session，须登记新采集pass，不能假冒同一次会话。各模型共用已核的同一个RGB-D缓存，RGB-only策略忽略深度。

```bash
python -B scripts/verify_stage2.py --dataset aerialvln_s_v1 --mode collect \
  --annotation-root /project-data/aerialvln/DATA/data/aerialvln-s \
  --split train --scene-id 2 --sampling all --save-depth --depth-storage npy_gzip_float32_v1 --resume-collection \
  --scene-build-dir <当前scene2构建目录> --capture-session-id <实际启动身份> \
  --output /project-data/aerialvln/cache/full/pass0/scene2/train.json
```

对官方训练的12个场景逐场景完整采集，资源验收后可同时采两个不同场景。另采val_seen全部8场景；训练来源成组开发验证仅对冻结dev路线独立实采，不再次渲染整份train。合并清单必须位于各分片的共同父目录；合并只核证据，不连接场景。

当前最多六路调度合同为 `plan/avln_code_comparison/gpu_launch_20261007/gpu_gate_20261008/full_retry1/parallel_runtime6/restart1/full_parallel_contract.json`，此前 `parallel_runtime/`、`parallel_runtime3/`和原 `parallel_runtime6/` 保留接管、失败及重启前证据。合同包含冻结的共用、worker、owner源码及其SHA。真实启动身份、boot及六份已完成来源在同目录 `launch_spec.json`、`launch.json`；当前状态读取 `parallel_runtime6/restart1/full_collection_status.json`，各worker状态读取其 `spec.output_dir`。服务器重启后原进程身份失效，旧状态文件的running不能代表进程存活；保完整场景来源，部分缓存不能跨session拼接。此次六个剩余训练场景在原缓存根内的 `restart1_train_pass/` 新会话完整采集，原六个完整场景仍使用 `train_pass/`；合并为 `train_index_restart1.json`，开发名单、开发index和seen index也带 `_restart1`，不得套用旧路径。最终合并仍逐源执行完整数据审核。

这些属于一次正式采集队列的证据，不能直接重跑合同或重新启动旧控制器；失败时先核boot、状态和PID/PGID/start ticks，保活跃session及所有attempt。协调器从已冻结的配置文件读取启动参数，避免嵌套审计记录超过系统命令行限制；端口暂不能绑定时等待，不结束未知监听者。原进程退出时命令行可能先清空：此时必须继续核PID/PGID/start ticks，不能直接误报PID复用，也不能把进程消失当成功。历史同session恢复若无父进程可取得worker退出码，须绑定原源码/会话、完成状态、采集exit0、场景归档清理和严格缓存审核；本次重启恢复不继承旧worker。仿真未必生成额外Saved日志；审核实际保存的启动stdout日志与归档settings的SHA，并单列Saved日志是否存在，不编造文件。

六个slot分别使用41461至41466端口和独立账号home、build、userdir、settings、日志与场景输出，实际RPC设置和监听进程归属必须核验。同UID别名仅复用项目遍历ACL，不提供权限隔离；禁止按UID批量停止进程。启动前串行检查显存余量至少6144MiB、构建副本容量加8GiB根盘余量，采集前显存保4096MiB、逐帧数据盘保12GiB；同时读取容器cgroup内存，当前新派发软预算为已用不超过85GiB并保可用6GiB。这些是当前工程预算，后续场景按真实峰值复核，不能用宿主机内存替代容器配额。资源不足暂停新派发，仍保已启动任务，不保证全程六路。原在途collector和worker保原会话完整封口；暂停的旧父进程须保至继承子进程真实退出并核验退出码，随后仅由新owner精确终止。一个scene不跨session拼接；训练名单冻结和dev独立采集仍在完整train合并通过后进行。

```bash
python -B scripts/verify_stage2.py --dataset aerialvln_s_v1 --mode merge \
  --annotation-root /project-data/aerialvln/DATA/data/aerialvln-s --split train --save-depth \
  --merge-caches <同一pass的12个scene/train.json路径> \
  --output /project-data/aerialvln/cache/full/pass0/train_index.json
```

`scene_shards_v1`绑定各scene的独立构建/settings/session，不能把scene2的来源套到其他场景。认证原始官方train10113条；按已审核隔离规则采10107条有效任务，6条原件、理由和episodeSHA进入 `excluded_quarantine`。任意漏采、多采或新增隔离都拒绝标全量。val_seen仍333条，val_unseen仍531条。

全量train独立渲染预算441879状态，仅raw深度约108GiB；容量须重新实测并计入dev、seen、权重及场景副本，不能沿用历史剩余空间保证。使用 `npy_gzip_float32_v1`、`.npy.gz`无损保存原float32位模式，记录压缩文件SHA和逐帧storage协议，读入Tensor与raw相同；旧`.npy`保原义。train/dev/val_seen必须核实际独立session，不能只换session名字。旧控制器合同只作失败证据，新采集策略需新来源合同；不支持在新场景进程中伪造旧session恢复。

当前ComputerVision构建实测拒绝`simContinueForFrames`及`simContinueForTime`，旧推进候选保留失败证据。新来源采用`set_pose_unpaused_rgbd_bounded_rerequest_v3`：RGB与Depth同次请求、各自时间戳正值并推进、两相机位姿匹配请求；重复时最多重新请求3次，不调用时钟推进/暂停接口、不额外等待，超时或仍陈旧就拒绝。帧清单保存双时间戳、时差、双相机位姿、请求审计与暂停状态，失败保存原attempt的`failure.json`及journal。时差目前仅`measure_only`，不声称已通过所有场景同步容限验收。可恢复采集以`preflight_attempt_*.json`保存七动作实测/预检失败，默认`--min-free-gib 12`在逐帧落盘前保容量余量。旧策略缓存继续按各自旧合同读取，不改历史来源版本。

完整train index封口后，冻结训练来源开发名单；输出拒绝覆盖已有文件：

```bash
python -B scripts/verify_stage2.py --dataset aerialvln_s_v1 --mode plan-development \
  --annotation-root /project-data/aerialvln/DATA/data/aerialvln-s --split train --save-depth \
  --cache-manifest /project-data/aerialvln/cache/full/pass0/train_index.json \
  --development-fraction 0.2 --development-split-seed 0 \
  --output /project-data/aerialvln/cache/full/development_split.json
```

在名单包含dev任务的每个scene，启动独立真实session后沿用上述collect命令，增加`--development-split-manifest /project-data/aerialvln/cache/full/development_split.json`，输出`cache/full/dev_pass/scene<编号>/train.json`。仍用`--split train --sampling all --resume-collection --save-depth`，其`all`表示当前scene全部冻结dev成员，不是完整官方split。

```bash
python -B scripts/verify_stage2.py --dataset aerialvln_s_v1 --mode merge \
  --annotation-root /project-data/aerialvln/DATA/data/aerialvln-s --split train --save-depth \
  --development-split-manifest /project-data/aerialvln/cache/full/development_split.json \
  --merge-caches <全部dev场景的dev_pass/scene*/train.json路径> \
  --output /project-data/aerialvln/cache/full/development_index.json
```

开发index与冻结名单均置于`cache/full/`，所有分片在该共同父目录内。新index明确`aerial_development_subset_v1`和`train_source_development_partition_complete`；漏成员、来源/SHA变化或多成员即拒绝。它只能作为开发来源，不能冒完整训练index。

### BC、暖启动DAgger与训练恢复

```bash
export UAVNAV_DATASET=aerialvln_s_v1 UAVNAV_DEVICE=cuda
export UAVNAV_DATA_ROOT=/project-data/aerialvln/DATA/data/aerialvln-s
export UAVNAV_CACHE_MANIFEST=/project-data/aerialvln/cache/full/pass0/train_index.json
export UAVNAV_VALIDATION_CACHE_MANIFEST=/project-data/aerialvln/cache/full/development_index.json
export UAVNAV_DEVELOPMENT_SPLIT_MANIFEST=/project-data/aerialvln/cache/full/development_split.json
export UAVNAV_VALIDATION_SPLIT=development_train_grouped UAVNAV_REQUIRE_FULL_TRAIN=1
export UAVNAV_ARCHITECTURE=aerial_route_recurrent_v2 UAVNAV_STAGE=bc
export UAVNAV_NAME=student_rgb_bc_seed0
python -B train.py
```

默认开发拆分只来自train几何组，词表只用实际训练部分。`REQUIRE_FULL_TRAIN=1`核完整训练**来源缓存**；使用成组开发留出时，实际训练覆盖标记仍为false，不冒全部10107条都已训练。开发预算冻结后，全train重训须清除`UAVNAV_DEVELOPMENT_SPLIT_MANIFEST`，明确改为 `VALIDATION_SPLIT=val_seen` 和对应完整seen缓存；最终选预先冻结轮数的last，不用val_unseen挑checkpoint。`best.pt`仍为教师CE候选，不能当导航最优。

独立审核已有best或last使用原`audit_training.py`入口，选择实际教师权重：

```bash
python -B scripts/audit_training.py --run-dir <实际run目录> --output-dir <新的审核证据目录> \
  --device cpu --batch 1 --workers 0 --seed 0 --bootstrap 1 --teacher-checkpoint-choice last
```

`--teacher-checkpoint-choice`默认best，与实际观测重放用的`--checkpoint-choice`独立。它绑定所选epoch/CE/SHA并保留两权重完整性审核；教师动作结果不计导航SR。

更换 `ARCHITECTURE` 和独立 `NAME` 可跑RGB-D学生、官方RGB-D两基线；原网络还需上文的上游源码清单、DDPPO资产及隔离日志。先测真实吞吐/显存后再决定并行任务数。循环训练当前实际batch为一个episode的连续chunk，`UAVNAV_BATCH`不把它升级为多episode并行；不得据设置的64声称实际batch64。

DAgger需要先核真实导航图、节点字典及场景绑定教师审核合同，覆盖位姿/朝向、偏轨、路线顺序、STOP和图连通性；没有审核证据时拒采，不能用参考帧同索引动作充当偏轨标签。下面beta为配置示例，须事前登记实际配方。

```bash
python -B scripts/verify_stage2.py --dataset aerialvln_s_v1 --mode dagger \
  --annotation-root "$UAVNAV_DATA_ROOT" --split train --scene-id 2 --sampling all \
  --checkpoint runs/train/student_rgb_bc_seed0/weights/last.pt --device cuda \
  --beta 0.5 --max-steps 500 --collection-id rgb_dagger_round1_scene2 --resume-collection \
  --teacher-upstream-root <冻结AirVLN源码目录> --teacher-nav-graph <已审核图目录> \
  --teacher-token-dict <已审核节点目录> --teacher-review <scene2教师审核JSON> \
  --scene-build-dir <当前scene2构建目录> --capture-session-id <实际启动身份> \
  --output /project-data/aerialvln/cache/dagger/round1/scene2.json

export UAVNAV_STAGE=dagger UAVNAV_NAME=student_rgb_dagger_round1_seed0
export UAVNAV_WARM_START_CHECKPOINT=runs/train/student_rgb_bc_seed0/weights/last.pt
export UAVNAV_DAGGER_MANIFESTS='["/project-data/aerialvln/cache/dagger/round1/scene2.json"]'
python -B train.py
```

按同合同追加其他scene清单。DAgger只采当前checkpoint实际训练成员，排除dev；教师监督与实际执行history分别认证，失败尝试保留。教师同时走官方进度更新链；同XYZ但朝向冲突的快捷分支拒绝标签，拒绝任务不能算已完成偏轨覆盖。仅完整封口collection允许训练，partial只能恢复审核。混合随机源当前每episode重置seed0，相同长度任务共用混合前缀，配方中明确记录。

`warm_start`只加载同结构/词表的模型，优化器与时间表新建；`resume`恢复同run最近**已提交epoch**的模型、优化器、调度器、RNG与日志，未提交epoch重跑，旧checkpoint不能冒恢复状态。恢复时保持首次全部参数和epochs不变，清空暖启动变量后设置 `UAVNAV_RESUME_CHECKPOINT=<该run的weights/last.pt>`。禁止同时指定warm/resume；来源、名单或配置变化需新run。

### 完整split闭环

`--scene-endpoints` 的JSON为 `{"schema_version":1,"scenes":[...]}`，每项含 `scene_id,ip,port,build_dir,expected_provenance`；provenance必须是实际RPC采得的完整来源，不填空模板。端点配置覆盖且仅覆盖整个split，可先启动一个scene执行分片，停止后启动下一scene并 `--resume`；完整名单始终保持整个split，全部完成才计算指标。不同模型可以并行训练，但不能同时控制同一AirSim端点。

```bash
python -B evaluate.py --dataset aerialvln_s_v1 --backend airsim --data-root "$UAVNAV_DATA_ROOT" \
  --split val_unseen --scene-endpoints <实查全部5场景端点JSON> --scene-id 7 --scene-ready \
  --checkpoint <事先冻结的checkpoint> --device cuda --metric-protocol eval_adapter_v2 \
  --require-formal-protocol --max-steps 500 --output <独立正式评测目录>
```

将尖括号内容替换为实际路径；`--scene-ready` 仅声明场景已启动，不替代端点与进程/构建来源认证。下一scene使用同一目录及合同，只改变执行scene并追加 `--resume`。主指标SR/sDTW，辅助NE/OSR/nDTW及自主STOP；未完整split和隐藏test指标为null。当前CPU检查不证明真实图教师、完整RGB-D原网络设备运行或导航成绩；这些进入GPU实验前的实际验收。

## 闭环与同权限对照

量化指标与分阶段通过标准集中见[当前量化合同](plan/修改方案.md)：SR、sDTW为主，nDTW/NE/OSR为辅，自主STOP与16GB Jetson全链时延/统一内存另报。旧v1仍是动作后采样，显式v2已含初始位置，真实新闭环验收另记progress；SR项目结束语义与原eval调度边界分开。本文不据加载参数或教师准确率判研究通过。


已训练路线自主诊断需要 checkpoint 位于原 run 的 `weights/`，其邻接冻结名单确实包含 episode：

```bash
python -B evaluate.py --dataset aerialvln_s_v1 --backend airsim --data-root /project-data/aerialvln/DATA/data/aerialvln-s --split train --training-route-diagnostic --scene-id 2 --episode-id <已训练ID> --scene-ready --checkpoint runs/train/<experiment>/weights/last.pt --record-observations --max-steps 200 --output runs/train/<experiment>/training_route_<ID>
```

输出标记 `subset_diagnostic`、`seen_in_training=true`，不称泛化。独立验证使用 `--split val_seen` 或 `val_unseen`，去掉训练诊断开关，先固定 episode 名单、权重及预算；上游默认预算 500。回放使用 `--backend replay --cache-manifest <清单>`，只输出教师分类诊断。test 仅允许 `--preflight-only`，未取得合法官方评分时不补造真值或成绩。

`--record-observations` 在 episode 的 `observations/` 保存每次决策所用实际 RGB、哈希、历史动作、相机响应和推理前后记忆数组，包括 STOP 决策帧。真实环境拒绝未推进的 RGB 时间戳，并记录 RGB/深度时间与响应相机 pose；本轮三次长路线自主重复均失败，实际输入重放输出及记忆差为 0；当前图像/记忆替换诊断见 [证据](plan/aerialvln_dataset_20261005/observation_repeat_20261005_1336/image_memory_factorial.json)。记录改变墙钟时序，原无记录失败保留，不将替换诊断当导航修复。

历史项目v1的NE/SR/OSR使用XY20米，nDTW/sDTW使用fastdtw与动作后位置采样；上游reset也计初始位置，二者不能混称完整原evaluator。未来正式协议含初始位置、明示终止/预算边界，保持旧结果原义；自主STOP成功另列，SPL暂保持 `null`。官方 SR 可包含预算或深度终止后的近目标状态，不等同自主 STOP。直接设位姿且 `ignore_collision=True`，深度终止代理与 contact 分开记录，不能称连续动力学飞行。

官方 Seq2Seq/CMA 默认 RGBD，当前学生 RGB-only。本轮先接入官方原网络的同 RGB 权限适配 `airvln_seq2seq_rgb_v1`、`airvln_cma_rgb_v1`，完整 RGBD 原训练流程作为后续独立复现。RGB 对照只关闭策略深度分支，环境仍采集深度并执行同一终止代理；上游全局 `ablate_depth` 不用于配置本项目环境。原网络使用真实 ResNet50/512维GRU、固定视觉BN、FP32及项目数值词表，checkpoint格式6记录完整来源；共用项目20轮/TBPTT16/损失并不等于复现官方训练配方。实际验收见 [原网络对照](plan/avln_code_comparison/AVLN开源代码对照与修改路线.md)。

配置原网络需设 `UAVNAV_ARCHITECTURE`、`UAVNAV_UPSTREAM_ROOT`、`UAVNAV_UPSTREAM_PROJECT_PREFIX`、`UAVNAV_UPSTREAM_LOG_DIR`、`UAVNAV_UPSTREAM_SOURCE_SHA256` 和 `UAVNAV_DDPPO_CHECKPOINT_SHA256`，再使用上述训练/审核入口。源码清单由 `uavnav.avln.model.airvln_source_sha256(root)` 生成；资产为官方 `DATA/models/ddppo-models/gibson-2plus-resnet50.pth`。日志必须在上游目录外，一进程仅运行一种官方策略；重载仍核源码与资产，缺失时拒绝用近似网络替代。入口按架构自动选冻结骨干、单pass、512维及global/spatial，不接受在overrides中另传hidden。

同结构记忆对照用 `UAVNAV_MEMORY_MODE=carry/reset_each_step`，同词表文本对照用 `UAVNAV_TEXT_CONTROL=constant` 重训，当前这两项用于学生v2。`no_history` 只删动作窗口，仍保留视觉记忆；v1/v2 同时改变序列、分词和损失，其差值不能单独归因 GRU。

## 下一步与历史入口

2026-10-06 官方原网络对照已完成：[验收](plan/avln_code_comparison/baseline_run_20261006/verification_summary.json)、[60主诊断结果](plan/avln_code_comparison/baseline_run_20261006/comparison_summary.json)、[回传SHA](plan/avln_code_comparison/baseline_run_20261006/local_transfer_verification.json)。三条已训练路线各5次、200步，学生单/多pass均短4/5、中5/5、长0/5；Seq2Seq均0/5，CMA仅中1/5。CMA长路线NE/nDTW优于学生，不能只据完成次数称整体胜过开源。基线尚未充分拟合、路线顺序非均衡、第五轮GPU存在外部争用；本轮不是官方完整RGBD训练/未知路线/Jetson结果。61有效运行4595真实决策重放差0，额外有效失败及初始RPC执行错误另列。下一步先核基线收敛与关键状态、独立均衡评测，再分别检验视觉稳定和语言阶段机制。

全量标注校验现按episode批量计算，检查范围和旧动作语义保持。服务器单次train读取由72.20秒降15.71秒，138项服务器回归通过；这仅为标注校验提效，[证据](plan/aerialvln_dataset_20261005/observation_repeat_20261005_1336/annotation_validation_optimization.json)。

后续真实v2采集与四组20轮冻结/微调×单/多pass已经完成。固定候选微调多pass last20的5次独立重启结果为短5/5、中5/5、长0/5，长首错24/40/30/24/30；27实际观测重放一致，新权重6侧移首错仍可由当前图像变化触发，frame40另有缓存已见错误。来源/工程验收通过不等于导航修复，见 [当前验证](plan/aerialvln_dataset_20261005/render_pass_20261006/gpu/verification_summary.json)。旧 [80图](plan/aerialvln_dataset_20261005/controlled_render_20261005_1430/analysis.json) 与失败保留。下一步先核关键动作语义/收敛和真实外观鲁棒性，再做独立路线、Seq2Seq/CMA及语言/记忆对照，性能通过后进入压缩与16GB Jetson全在线测量。参数量、A100显存和推理时延不替代板上验收。

历史 FOV 训练显式使用 `python -B train.py --dataset uav_vln_fov` 或 `UAVNAV_DATASET=uav_vln_fov`，评测使用 `evaluate.py --dataset fov`，数据指向 `/project-data/uav_vln_fov/`；不把其对象 3D10 米合同及 3DG-VLN/DBFly 成绩混入新路线任务。历史说明保留于 [骨架](plan/骨架.md)、[数据修复报告](plan/数据重新审核与修复报告.md)、[基线审核](plan/基线训练结果与代码反查报告.md)、[开源代码对照](plan/avln_code_comparison/AVLN开源代码对照与修改路线.md) 与各 run 快照。OMC-RL 为可选参考，见 [任务对齐审查](plan/omc_alignment/OMC-RL与当前代码的任务对齐审查.md)。

清理逐项核来源、引用、版本状态与进程占用。持续回归、正式 rollout、失败证据、权重、原数据及来源哈希保留；清理实际执行结果只记录在根 `progress.md`，不新增同用途清理脚本或报告。
