"""FOV静态对象接近与AerialVLN-S长程八动作导航入口。"""

from __future__ import annotations

import argparse
import hashlib
import json
import os
import random
import sys
from importlib import metadata as package_metadata
from pathlib import Path

import numpy as np


def _parser() -> argparse.ArgumentParser:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--dataset", choices=("fov", "aerialvln_s_v1"), default="fov")
    parser.add_argument("--backend", choices=("replay", "airsim"), required=True)
    inputs = parser.add_mutually_exclusive_group(required=True)
    inputs.add_argument("--trajectory", type=Path)
    inputs.add_argument("--data-root", type=Path, help="FOV列表所在split目录，或AerialVLN官方标注目录")
    parser.add_argument("--list-json")
    parser.add_argument("--split", choices=("test", "unobject", "unscene", "unseen_scene", "unseen_object", "train", "val_seen", "val_unseen"), required=True)
    parser.add_argument("--episode-id", help="AerialVLN 场景内 episode ID，用于单场景诊断")
    parser.add_argument("--scene-id", type=int, help="当前真实场景 ID，AerialVLN 单场景闭环要求显式设置")
    parser.add_argument("--scene-endpoints", type=Path,
                        help="正式全split场景端点JSON；可顺序执行全部场景，scene-id仅选择执行分片")
    parser.add_argument("--cache-manifest", type=Path, help="AerialVLN 真实渲染缓存，replay 仅检查分类不计导航成绩")
    parser.add_argument("--record-observations", action="store_true", help="Aerial闭环保存实际RGB、相机响应和GRU状态，用于失败复现")
    parser.add_argument("--training-route-diagnostic", action="store_true",
                        help="仅AerialVLN单条已训练路线自主完成诊断，不作为泛化成绩")
    parser.add_argument("--development-route-diagnostic", action="store_true",
                        help="仅冻结几何开发名单中的单条未训练路线自主诊断，不作为官方验证")
    parser.add_argument("--development-split-manifest", type=Path,
                        help="开发闭环必须绑定训练时冻结的完整几何路线名单")
    parser.add_argument("--preflight-only", action="store_true",
                        help="只核验数据、名单和对象元数据；不连接仿真器、不生成导航指标")
    parser.add_argument("--evaluation-protocol", type=Path,
                        help="FOV静态合同仅支持预检；AerialVLN合同须与八动作checkpoint一致")
    parser.add_argument("--metric-protocol", choices=("airvln_xy20_fastdtw_v1", "eval_adapter_v2"),
                        default="airvln_xy20_fastdtw_v1",
                        help="Aerial评分版本；v2含初始位姿，正式范围固定500动作；默认保留历史v1")
    parser.add_argument("--resume", action="store_true",
                        help="仅Aerial AirSim v2：核冻结合同和全部尝试后，从起点重试基础设施错误；不重跑策略失败")
    parser.add_argument("--require-formal-protocol", action="store_true",
                        help="要求完整val划分、v2和500预算；只核合同，不认证真实导航或论文复现")
    parser.add_argument("--policy", choices=("model", "constant", "previous"), default="model")
    parser.add_argument("--aerial-baseline", choices=("random", "forward"),
                        help="AerialVLN下限策略：不读图像/指令/目标，不输出STOP，仅耗尽动作预算或触发环境终止")
    parser.add_argument("--checkpoint", type=Path)
    parser.add_argument("--device", default="cuda")
    parser.add_argument("--legacy-strip-direction", choices=("true", "false"))
    parser.add_argument("--output", type=Path, required=True)
    parser.add_argument("--max-steps", type=int, help="FOV默认64，AerialVLN默认500；正式评测前冻结")
    parser.add_argument("--stop-threshold", type=float, help="已监督STOP模型的动作前停止阈值，验证选定后冻结")
    parser.add_argument("--stop-mode", choices=("auto", "predicted", "fixed"), default="auto",
                        help="固定预算对照仍按同一对象/无碰撞口径评分，predicted要求训练过的STOP")
    parser.add_argument("--goal-source", choices=("reference_endpoint", "object"),
                        help="目标与停止头开关独立；STOP模型固定预算对照仍用对象目标")
    parser.add_argument("--seed", type=int, default=0)
    parser.add_argument("--constant-step", type=float,
                        help="米，默认来自既有训练扫描；previous 首步也使用该值")
    parser.add_argument("--success-distance", type=float,
                        help="米，TravelUAV 源码阈值，仅用于离线评测")
    parser.add_argument("--spl-definition", choices=("standard", "success_distance_adjusted"),
                        default=None)
    parser.add_argument("--ip", default="127.0.0.1")
    parser.add_argument("--port", type=int, default=41451)
    parser.add_argument("--vehicle-name")
    parser.add_argument("--camera-name")
    parser.add_argument("--rgb-order", choices=("RGB", "BGR"))
    parser.add_argument("--scene-map-name", help="AirSim 已启动场景的 Map 名，与轨迹目录核对")
    parser.add_argument("--spawnarea-json", type=Path,
                        help="对象生成点元数据，默认使用数据集 meta/map_spawnarea_info.json；仅核对配置")
    parser.add_argument("--scene-ready", action="store_true",
                        help="确认已按官方场景/对象配置布置此轨迹，当前入口不负责场景启动/对象生成")
    parser.add_argument("--action-duration", type=float, help="FOV固定仿真秒数，默认5")
    parser.add_argument("--speed-limit", type=float, help="FOV米/秒，默认1")
    parser.add_argument("--sample-interval", type=float, help="FOV执行期间采样间隔，默认0.1仿真秒")
    return parser


def _baseline_predictor(kind, seed, device):
    """下限策略适配：无权重，身份哈希由策略名与seed派生，评分合同沿用统一AerialVLN任务合同。"""
    import torch
    from uavnav.avln.closed_loop import AerialBaselinePolicy
    from uavnav.avln.metadata import aerial_task_protocol
    policy = AerialBaselinePolicy(kind, seed=seed)
    task = aerial_task_protocol()
    policy.checkpoint_sha256 = hashlib.sha256(f"aerial_baseline_v1:{kind}:{seed}".encode()).hexdigest()
    policy.device = torch.device("cpu")
    policy.config = {**AerialBaselinePolicy.config, "task_protocol": task, "stop_enabled": False,
                     "policy_kind": f"aerial_baseline_{kind}"}
    return policy


class BaselinePredictor:
    """仅使用训练先验或上一段实际运动，首步不读取未来位姿。"""

    def __init__(self, policy: str, constant_step: float):
        self.policy = policy
        self.constant_step = constant_step

    def predict(self, image, instruction, history):
        if self.policy == "previous" and len(history):
            # history 是相对当前观测的历史坐标，最近一项的负向量为上一段运动。
            return -np.asarray(history[-1], dtype=np.float32)
        return np.array([self.constant_step, 0, 0], dtype=np.float32)


def _reference(trajectory: Path, start_index: int | None = None) -> list[list[float]]:
    logs = sorted((trajectory / "log").glob("*.json"), key=lambda p: int(p.stem))
    if start_index is not None:
        logs = [path for path in logs if int(path.stem) >= start_index]
    if not logs:
        raise ValueError(f"轨迹 log 为空: {trajectory}")
    positions = [json.loads(p.read_text(encoding="utf-8"))["sensors"]["state"]["position"] for p in logs]
    array = np.asarray(positions, dtype=np.float64)
    if array.shape != (len(logs), 3) or not np.isfinite(array).all():
        raise ValueError(f"参考轨迹位置无效: {trajectory}")
    return array.tolist()


def _object_config(trajectory: Path, spawnarea_json: Path | None) -> dict:
    """核对目标元数据，不启动场景或生成对象。"""
    from uavnav.avln.metadata import resolve_object_metadata

    metadata_path = spawnarea_json or trajectory.parents[2] / "meta" / "map_spawnarea_info.json"
    mark_path = trajectory / "mark.json"
    config = resolve_object_metadata(
        json.loads(mark_path.read_text(encoding="utf-8")),
        json.loads(metadata_path.read_text(encoding="utf-8")), trajectory.parent.name,
    )
    config["metadata_path"] = str(metadata_path)
    config["metadata_sha256"] = hashlib.sha256(metadata_path.read_bytes()).hexdigest()
    config["mark_sha256"] = hashlib.sha256(mark_path.read_bytes()).hexdigest()
    return config


def _evaluation_manifest(args, paths, protocol_hash):
    from uavnav.avln.metadata import canonical_eval_split, validate_evaluation_manifest

    source_hash = None
    if args.data_root:
        list_path = Path(args.list_json)
        list_path = list_path if list_path.is_absolute() else args.data_root / list_path
        source_hash = hashlib.sha256(list_path.read_bytes()).hexdigest()
    return validate_evaluation_manifest({
        "schema_version": 1, "scope": "subset_diagnostic", "split": canonical_eval_split(args.split),
        "source_sha256": source_hash, "evaluation_protocol_sha256": protocol_hash,
        "episodes": [{"traj_id": f"{path.parent.name}/{path.name}", "split": canonical_eval_split(args.split)}
                     for path in paths],
    })


def _preflight_metadata(args, trajectories, manifest, evaluation_protocol):
    """只核文件事实；相机像素、实际资产和坐标映射留待真实场景核验。"""
    from uavnav.avln.data import _frames, _instruction_from_obj_des
    from uavnav.avln.metadata import evaluation_manifest_sha256

    results = []
    for trajectory in trajectories:
        rows = sorted((trajectory / "log").glob("*.json"), key=lambda path: int(path.stem))
        frames, _ = _frames(trajectory)
        # 上游提供 DownCamera；这里核存在性，不将未解码像素记为相机验收。
        down = next((trajectory / name for name in ("DownCamera", "downcamera")
                     if (trajectory / name).is_dir()), None)
        down_indices = set()
        for image in down.glob("*.png") if down is not None else []:
            number = int(image.stem)
            if number < 0 or number in down_indices:
                raise ValueError(f"下视相机出现无效或重复帧索引: {image}")
            down_indices.add(number)
        missing_down = [number for _, _, number in frames
                        if number not in down_indices]
        instruction = _instruction_from_obj_des(trajectory, strip_direction=False)
        if not instruction:
            raise ValueError(f"缺少评测指令 obj_des.json: {trajectory}")
        object_config = _object_config(trajectory, args.spawnarea_json)
        reference = _reference(trajectory, frames[0][2])
        results.append({
            "traj_id": f"{trajectory.parent.name}/{trajectory.name}",
            "object_config": object_config, "front_frames": len(frames),
            "missing_down_frame_indices": missing_down,
            "reference_log_sha256": hashlib.sha256(b"".join(
                path.name.encode("utf-8") + b"\0" + path.read_bytes() for path in rows)).hexdigest(),
            "instruction_sha256": hashlib.sha256((trajectory / "obj_des.json").read_bytes()).hexdigest(),
            "start_position": frames[0][0]["position"], "reference_endpoint": reference[-1],
            "scene_assets": "not_checked", "coordinate_mapping": "not_verified",
            "camera_pixel_validation": "not_checked",
        })
    report = {
        "status": "metadata_preflight_only", "real_simulator_executed": False,
        "ready_for_formal_evaluation": False,
        "evaluation_manifest_sha256": evaluation_manifest_sha256(manifest),
        "evaluation_protocol": evaluation_protocol, "episodes": results,
        "pending_checks": ["actual_scene_and_object_mesh", "world_to_vehicle_ned_mapping",
                           "dual_camera_calibration_and_pixels", "control_and_contact_collision",
                           "dual_view_policy_and_trained_stop"],
    }
    (args.output / "preflight.json").write_text(json.dumps(report, ensure_ascii=False, indent=2, allow_nan=False), encoding="utf-8")


def _json_sha256(value):
    return hashlib.sha256(json.dumps(value, sort_keys=True, separators=(",", ":"),
                                     ensure_ascii=False, allow_nan=False).encode()).hexdigest()


def _save_evaluation_json(path, value):
    """一次创建并同步落盘；已存在的证据绝不覆盖。"""
    with path.open("x", encoding="utf-8", newline="\n") as stream:
        stream.write(json.dumps(value, ensure_ascii=False, indent=2, allow_nan=False) + "\n")
        stream.flush()
        os.fsync(stream.fileno())


def _write_json_atomic(path, value):
    """同盘原子替换 metrics.json，进程中断不会留下截断文件。"""
    path = Path(path)
    path.parent.mkdir(parents=True, exist_ok=True)
    temporary = path.with_name(path.name + ".pending")
    try:
        with temporary.open("w", encoding="utf-8", newline="\n") as stream:
            stream.write(json.dumps(value, ensure_ascii=False, indent=2, allow_nan=False) + "\n")
            stream.flush()
            os.fsync(stream.fileno())
        os.replace(temporary, path)
    finally:
        temporary.unlink(missing_ok=True)


def _attempt_file_hashes(directory):
    if directory.is_symlink() or getattr(directory, "is_junction", lambda: False)():
        raise ValueError("评测尝试目录不能为链接")
    files = {}
    for path in sorted(directory.rglob("*")):
        if path.is_symlink() or getattr(path, "is_junction", lambda: False)() or not path.resolve().is_relative_to(directory.resolve()):
            raise ValueError("评测尝试内容含链接或越界来源")
        if path.is_file():
            files[path.relative_to(directory).as_posix()] = hashlib.sha256(path.read_bytes()).hexdigest()
    return files


def _append_attempt_ledger(root, rows, event):
    entry = {"schema_version": 1, "index": len(rows), "previous_sha256": rows[-1]["sha256"] if rows else None, **event}
    entry["sha256"] = _json_sha256(entry)
    with (root / "attempt_ledger.jsonl").open("a", encoding="utf-8", newline="\n") as stream:
        stream.write(json.dumps(entry, ensure_ascii=False, separators=(",", ":"), allow_nan=False) + "\n")
        stream.flush()
        os.fsync(stream.fileno())
    rows.append(entry)


def _journal_summary(path):
    """损坏/未封口尾部留痕；部分轨迹永不产生导航成绩。"""
    raw = path.read_bytes() if path.is_file() else b""
    events, state = [], "complete_lines"
    previous = None
    lines = raw.splitlines(keepends=True)
    for index, line in enumerate(lines):
        try:
            entry = json.loads(line)
        except (ValueError, UnicodeDecodeError):
            state = "truncated_last_line" if index == len(lines) - 1 and not line.endswith(b"\n") else "corrupt_content"
            break
        if (not isinstance(entry, dict) or entry.get("index") != index or entry.get("previous_sha256") != previous
                or entry.get("sha256") != _json_sha256({k: v for k, v in entry.items() if k != "sha256"})
                or not isinstance(entry.get("event"), dict)):
            state = "corrupt_content"
            break
        events.append(entry["event"])
        previous = entry["sha256"]
        if not line.endswith(b"\n"):
            state = "truncated_last_line"
    completed = sum(event.get("event") == "action_completed" for event in events)
    decisions = sum(event.get("event") == "policy_decision_validated" for event in events)
    pending = False
    for event in events:
        if event.get("event") == "action_dispatch":
            pending = True
        elif event.get("event") == "action_completed":
            pending = False
    return {"journal_status": state, "journal_sha256": hashlib.sha256(raw).hexdigest(),
            "valid_prefix_events": len(events), "known_completed_steps": completed,
            "validated_decisions": decisions, "pending_dispatch": pending,
            "pending_action_execution": "unknown" if pending or state != "complete_lines" else "no_unacknowledged_dispatch",
            "policy_terminal_recorded": any(event.get("event") == "terminal" for event in events),
            "valid_prefix_is_navigation_score": False,
            "last_error_category": next((event.get("error_category") for event in reversed(events)
                                          if event.get("event") == "error"), None)}


def _validate_attempts(root, run, metadata_by_id):
    """先核全部旧证据再触碰环境；不按成功率挑选旧尝试。"""
    ledger = root / "attempt_ledger.jsonl"
    rows, attempts, previous = [], {}, None
    if ledger.is_file():
        for index, line in enumerate(ledger.read_bytes().splitlines(keepends=True)):
            if not line.endswith(b"\n"):
                raise ValueError("尝试ledger末行截断，拒绝自动续评；保留原证据待审核")
            try:
                entry = json.loads(line)
            except (ValueError, UnicodeDecodeError) as error:
                raise ValueError("尝试ledger内容损坏") from error
            if (not isinstance(entry, dict) or entry.get("schema_version") != 1 or entry.get("index") != index
                    or entry.get("previous_sha256") != previous
                    or entry.get("sha256") != _json_sha256({k: v for k, v in entry.items() if k != "sha256"})):
                raise ValueError("尝试ledger顺序/内容摘要冲突")
            key = entry.get("attempt_path")
            if entry.get("event") == "started":
                traj = entry.get("traj_id")
                number = sum(item["traj_id"] == traj for item in attempts.values()) + 1
                if (traj not in metadata_by_id or key != f"attempts/{traj.replace('/', '_')}/attempt_{number:04d}"
                        or key in attempts or entry.get("run_sha256") != _json_sha256(run)
                        or entry.get("metadata_sha256") != _json_sha256(metadata_by_id[traj])
                        or any(item["traj_id"] == traj and item.get("status") == "completed" for item in attempts.values())):
                    raise ValueError("重复/未知尝试或已完成路线被重试")
                attempts[key] = {"traj_id": traj, "start": entry, "progress": [], "status": None}
            elif entry.get("event") in ("progress", "finished"):
                if key not in attempts or attempts[key]["status"] is not None:
                    raise ValueError("未登记尝试或终态后的ledger内容")
                item = attempts[key]
                if entry["event"] == "progress":
                    if entry.get("journal_index") != len(item["progress"]):
                        raise ValueError("journal事件序号与ledger冲突")
                    item["progress"].append(entry)
                else:
                    if entry.get("status") not in ("completed", "infrastructure_error", "interrupted", "policy_error", "unknown_error"):
                        raise ValueError("不支持的尝试终态")
                    item.update(status=entry["status"], terminal=entry)
            else:
                raise ValueError("不支持的ledger事件")
            rows.append(entry)
            previous = entry["sha256"]
    attempts_root = root / "attempts"
    actual = set()
    if attempts_root.exists():
        if not attempts_root.is_dir() or attempts_root.is_symlink():
            raise ValueError("attempts根目录非法")
        for parent in attempts_root.iterdir():
            if not parent.is_dir() or parent.is_symlink() or parent.name not in {traj.replace("/", "_") for traj in metadata_by_id}:
                raise ValueError("未知attempts父目录或文件")
            actual.update(path.relative_to(root).as_posix() for path in parent.iterdir())
    if actual - set(attempts) or any(not (root / key).is_dir() for key in actual):
        raise ValueError("存在未登记或未知尝试内容，拒绝续评")
    completed = {}
    for key, item in attempts.items():
        directory = root / key
        files = _attempt_file_hashes(directory) if directory.is_dir() else {}
        if "ori_info.json" in files:
            if json.loads((directory / "ori_info.json").read_text(encoding="utf-8")) != metadata_by_id[item["traj_id"]]:
                raise ValueError("尝试元数据与冻结输入不一致")
        elif item["status"] is not None:
            raise ValueError("封口尝试缺少元数据")
        if item["progress"]:
            raw = (directory / "journal.jsonl").read_bytes()
            for event in item["progress"]:
                length = event.get("journal_bytes")
                if (type(length) is not int or length <= 0 or length > len(raw)
                        or hashlib.sha256(raw[:length]).hexdigest() != event.get("journal_sha256")):
                    raise ValueError("已落盘journal与ledger摘要冲突")
        if item["status"] is not None:
            if item["terminal"].get("files_sha256") != files:
                raise ValueError("封口尝试内容被修改或缺失")
            terminal_file = "rollout.json" if item["status"] == "completed" else "error.json"
            if terminal_file not in files:
                raise ValueError("尝试终态证据缺失")
        if item["status"] == "completed":
            completed[item["traj_id"]] = key
        else:
            summary = _journal_summary(directory / "journal.jsonl")
            if summary["policy_terminal_recorded"]:
                raise ValueError("策略终止已记录但尝试未完成封口，禁止因清理错误重跑并择优；需人工审核原终态")
            if item["status"] is None and summary["journal_status"] == "corrupt_content":
                raise ValueError("未封口journal内容损坏，保留证据并拒绝自动重试")
            if item["status"] in ("policy_error", "unknown_error"):
                raise ValueError("策略异常/未知异常禁止自动续评，保留所有尝试并需人工审核")
            if summary["last_error_category"] in ("policy_error", "unknown_error"):
                raise ValueError("journal记录策略异常/未知异常，禁止自动重试")
            if item["status"] == "infrastructure_error" and summary["last_error_category"] != "infrastructure_error":
                error_payload = json.loads((directory / "error.json").read_text(encoding="utf-8"))
                if error_payload.get("error_category") != "infrastructure_error":
                    raise ValueError("旧基础设施异常缺可信类型认证，禁止自动重试并需人工审核")
            # 完整result却未封口，不能重跑并在多个结果中择优。
            if item["status"] is None and "rollout.json" in files:
                raise ValueError("存在未封口完整rollout，需审核同hash恢复，禁止自动重跑")
    episodes_root = root / "episodes"
    if episodes_root.exists():
        expected = {traj.replace("/", "_") for traj in completed}
        if {path.name for path in episodes_root.iterdir()} - expected:
            raise ValueError("canonical episodes存在未知/未封口轨迹")
    for traj, key in completed.items():
        canonical = root / "episodes" / traj.replace("/", "_")
        if canonical.exists():
            expected = {name: attempts[key]["terminal"]["files_sha256"][name] for name in ("ori_info.json", "rollout.json")}
            actual = _attempt_file_hashes(canonical)
            if any(name not in expected or digest != expected[name] for name, digest in actual.items()):
                raise ValueError("canonical轨迹与封口尝试摘要不一致")
    return rows, attempts, completed


def _publish_completed_attempt(root, traj, attempt):
    """由唯一封口结果复制canonical文件，不移动或覆盖尝试证据。"""
    directory = root / "episodes" / traj.replace("/", "_")
    directory.mkdir(parents=True, exist_ok=True)
    for name in ("ori_info.json", "rollout.json"):
        if (directory / name).exists():
            if (directory / name).read_bytes() != (attempt / name).read_bytes():
                raise ValueError("canonical现有内容与完成尝试不一致，禁止覆盖")
            continue
        with (directory / name).open("xb") as stream:
            stream.write((attempt / name).read_bytes())
            stream.flush()
            os.fsync(stream.fileno())


def _load_scene_endpoints(path, scene_ids):
    """端点不是场景启动器；调用方须预启动并声明真实来源，评测核RPC设置。"""
    from uavnav.avln.airsim_env import aerial_scene_build
    payload = json.loads(path.read_text(encoding="utf-8"))
    if (not isinstance(payload, dict) or set(payload) != {"schema_version", "scenes"}
            or type(payload["schema_version"]) is not int or payload["schema_version"] != 1):
        raise ValueError("scene-endpoints要求schema_version=1及scenes")
    if not isinstance(payload["scenes"], list):
        raise ValueError("scene-endpoints.scenes必须是列表")
    rows = {}
    addresses = set()
    for item in payload["scenes"]:
        if not isinstance(item, dict) or set(item) != {"scene_id", "ip", "port", "build_dir", "expected_provenance"}:
            raise ValueError("场景端点字段必须为scene_id/ip/port/build_dir/expected_provenance")
        scene, ip, port = item["scene_id"], item["ip"], item["port"]
        if (type(scene) is not int or scene <= 0 or scene in rows or not isinstance(ip, str) or not ip.strip() or ip != ip.strip()
                or type(port) is not int or not 1 <= port <= 65535 or (ip, port) in addresses):
            raise ValueError("场景端点身份/地址无效或重复")
        build = aerial_scene_build(item["build_dir"])
        provenance = item["expected_provenance"]
        if not isinstance(provenance, dict) or provenance.get("scene_build") != build:
            raise ValueError("场景构建与expected_provenance不一致")
        required = {"scene_build", "settings", "settings_sha256", "camera_fov_degrees", "camera_extrinsics", "capture_policy"}
        if set(provenance) != required or provenance["settings_sha256"] != _json_sha256(provenance["settings"]):
            raise ValueError("expected_provenance须完整绑定构建/设置/相机/采集协议")
        rows[scene] = item
        addresses.add((ip, port))
    if set(rows) != set(scene_ids):
        raise ValueError("scene-endpoints必须覆盖且仅覆盖完整split场景")
    return {scene: rows[scene] for scene in sorted(rows)}


def _run_aerial_attempts(args, episodes, predictor, metadata_by_id, run, env_factory, rollout, write_metrics, torch):
    """同run串行账本写入；进程退出由操作系统释放锁，不产生陈旧PID阻塞。"""
    with (args.output / ".evaluation.lock").open("a+b") as stream:
        stream.seek(0, 2)
        if stream.tell() == 0:
            stream.write(b"0")
            stream.flush()
        stream.seek(0)
        if os.name == "nt":
            import msvcrt
            acquire = lambda: msvcrt.locking(stream.fileno(), msvcrt.LK_NBLCK, 1)
            release = lambda: msvcrt.locking(stream.fileno(), msvcrt.LK_UNLCK, 1)
        else:
            import fcntl
            acquire = lambda: fcntl.flock(stream.fileno(), fcntl.LOCK_EX | fcntl.LOCK_NB)
            release = lambda: fcntl.flock(stream.fileno(), fcntl.LOCK_UN)
        try:
            acquire()
        except OSError as error:
            raise RuntimeError("同一评测run正在执行，不能并发写账本；并行模型须使用独立output") from error
        try:
            return _run_aerial_attempts_locked(args, episodes, predictor, metadata_by_id, run,
                                              env_factory, rollout, write_metrics, torch)
        finally:
            stream.seek(0)
            release()


def _run_aerial_attempts_locked(args, episodes, predictor, metadata_by_id, run, env_factory, rollout, write_metrics, torch):
    from uavnav.avln.closed_loop import read_rollout_metrics, METRIC_KEYS, AERIAL_METRIC_KEYS, PENDING_KEYS
    root = args.output
    rows, attempts, completed = _validate_attempts(root, run, metadata_by_id)
    for traj, key in completed.items():
        _publish_completed_attempt(root, traj, root / key)
        read_rollout_metrics(root / "episodes" / traj.replace("/", "_"))
    # Unsealed partial attempts are retained as infrastructure interruptions, never scored.
    for key, item in attempts.items():
        if item["status"] is None:
            directory = root / key
            directory.mkdir(parents=True, exist_ok=True)
            if not (directory / "ori_info.json").exists():
                _save_evaluation_json(directory / "ori_info.json", metadata_by_id[item["traj_id"]])
            if not (directory / "error.json").exists():
                _save_evaluation_json(directory / "error.json", {"status": "interrupted", "done": False,
                    "error": "previous_process_ended_before_attempt_seal", **_journal_summary(directory / "journal.jsonl")})
            event = {"event": "finished", "attempt_path": key, "status": "interrupted",
                     "files_sha256": _attempt_file_hashes(directory)}
            _append_attempt_ledger(root, rows, event)
            item.update(status="interrupted", terminal=rows[-1])
    (root / "episodes").mkdir(exist_ok=True)

    def report():
        peak = torch.cuda.max_memory_allocated(predictor.device) / 1024 ** 3 if predictor.device.type == "cuda" else None
        candidate_complete = set(completed) == set(metadata_by_id)
        # 全量渲染帧可达数十GB；不在每episode结束反复重hash所有历史图像。
        # 未封口全split只报进度与null，最终评分才运行全量审计。
        if candidate_complete:
            payload = write_metrics(root, eval_dir=root / "episodes", peak_vram_gb=peak)
        else:
            payload = {"status": "incomplete", "metrics": {name: None for name in
                       dict.fromkeys((*METRIC_KEYS, *AERIAL_METRIC_KEYS, *PENDING_KEYS))}}
            payload["metrics"]["peak_vram_gb"] = peak
        states = [entry for entry in rows if entry["event"] == "finished"]
        payload["attempt_audit"] = {
            "attempt_protocol": "aerial_attempt_journal_v1", "ledger_sha256": hashlib.sha256((root / "attempt_ledger.jsonl").read_bytes()).hexdigest() if rows else None,
            "total_attempts": sum(entry["event"] == "started" for entry in rows),
            "completed_attempts": sum(entry["status"] == "completed" for entry in states),
            "infrastructure_attempts": sum(entry["status"] in ("infrastructure_error", "interrupted") for entry in states),
            "policy_error_attempts": sum(entry["status"] == "policy_error" for entry in states),
            "unknown_error_attempts": sum(entry["status"] == "unknown_error" for entry in states),
            "policy_errors_require_review": True,
            "error_classification_protocol": "aerial_failure_classification_v2",
            "infrastructure_attempts_are_navigation_scores": False,
            "formal_navigation_verified": False,
            "attempts": [{"attempt_path": entry["attempt_path"], "status": entry["status"],
                **(_journal_summary(root / entry["attempt_path"] / "journal.jsonl")
                   if candidate_complete or entry["status"] != "completed" else {})} for entry in states]}
        # 除canonical评分外再审计尝试账本；失败/缺失不能被排除后平均。
        try:
            if candidate_complete:
                _, _, verified = _validate_attempts(root, run, metadata_by_id)
            else:
                verified = completed
            audit_error = None
        except ValueError as error:
            # 原执行异常优先保留；审计拒绝也落盘，不能升级成完成或允许重试。
            verified, audit_error = {}, str(error)
        full = audit_error is None and set(verified) == set(metadata_by_id)
        payload["completion"] = {"expected_episodes": len(metadata_by_id), "completed_episodes": len(verified),
                                 "missing_episode_ids": sorted(set(metadata_by_id) - set(verified)),
                                 "status": "complete" if full else "incomplete"}
        if audit_error is not None:
            payload["attempt_audit"]["validation_error"] = audit_error
        if not full:
            payload["status"] = "incomplete"
            for name in ("ne", "sr", "osr", "ndtw", "sdtw", "spl", "autonomous_stop_success"):
                payload["metrics"][name] = None
        payload["official_source_authentication"] = run.get("official_source_authentication")
        payload["evaluation_scope"] = next(iter(metadata_by_id.values()))["evaluation_scope"]
        _write_json_atomic(root / "metrics.json", payload)
        return payload

    for episode in episodes:
        traj = f"{episode['scene_id']}/{episode['episode_id']}"
        if traj in completed:
            continue
        number = sum(item["traj_id"] == traj for item in attempts.values()) + 1
        key = f"attempts/{traj.replace('/', '_')}/attempt_{number:04d}"
        _append_attempt_ledger(root, rows, {"event": "started", "attempt_path": key, "traj_id": traj,
            "run_sha256": _json_sha256(run), "metadata_sha256": _json_sha256(metadata_by_id[traj])})
        directory = root / key
        directory.mkdir(parents=True)
        _save_evaluation_json(directory / "ori_info.json", metadata_by_id[traj])
        journal = directory / "journal.jsonl"
        journal.touch(exist_ok=False)
        journal_index, journal_previous, journal_bytes = 0, None, 0
        journal_digest = hashlib.sha256()
        def progress(event):
            nonlocal journal_index, journal_previous, journal_bytes
            entry = {"index": journal_index, "previous_sha256": journal_previous, "event": event}
            entry["sha256"] = _json_sha256(entry)
            line = (json.dumps(entry, ensure_ascii=False, separators=(",", ":"), allow_nan=False) + "\n").encode("utf-8")
            with journal.open("ab") as stream:
                stream.write(line)
                stream.flush()
                os.fsync(stream.fileno())
            journal_digest.update(line)
            journal_bytes += len(line)
            _append_attempt_ledger(root, rows, {"event": "progress", "attempt_path": key,
                "journal_index": journal_index, "journal_bytes": journal_bytes, "journal_sha256": journal_digest.hexdigest()})
            journal_index += 1
            journal_previous = entry["sha256"]
        env, error, cleanup_error, result = None, None, None, None
        execution_stage = "environment_construct"
        try:
            rotation = episode["start_rotation"]
            endpoint = getattr(args, "_scene_endpoints", {}).get(episode["scene_id"])
            env = env_factory(episode["start_position"], rotation[1:] + rotation[:1], episode["scene_id"],
                              ip=endpoint["ip"] if endpoint else args.ip,
                              port=endpoint["port"] if endpoint else args.port, rgb_order=run["execution_config"]["rgb_order"])
            execution_stage = "environment_provenance"
            if endpoint is not None:
                actual = env.capture_provenance(endpoint["expected_provenance"]["scene_build"])
                if actual != endpoint["expected_provenance"]:
                    raise ValueError("实时场景设置/相机来源与冻结端点不一致")
                _save_evaluation_json(directory / "scene_provenance.json", actual)
            execution_stage = "rollout"
            result = rollout(env, predictor, episode["instruction"]["instruction_text"], args.max_steps,
                             run["execution_config"]["history_frames"],
                             observation_dir=directory / "observations" if args.record_observations else None,
                             metric_protocol=args.metric_protocol, progress_callback=progress)
        except BaseException as exception:
            error = exception
        finally:
            if env is not None:
                try:
                    env.finish()
                except BaseException as exception:
                    cleanup_error = exception
                    if error is None:
                        error = exception
                        execution_stage = "finish_request"
        if error is not None:
            summary = _journal_summary(journal)
            from uavnav.avln.closed_loop import aerial_error_category
            category = (summary["last_error_category"] if execution_stage == "rollout"
                        and summary["last_error_category"] is not None else aerial_error_category(error, execution_stage))
            _save_evaluation_json(directory / "error.json", {"status": category, "done": False, "error_category": category,
                "error_classification_protocol": "aerial_failure_classification_v2",
                "error": f"{type(error).__name__}: {error}",
                "cleanup_error": f"{type(cleanup_error).__name__}: {cleanup_error}" if cleanup_error is not None else None,
                "environment_constructed": env is not None, **summary})
            _append_attempt_ledger(root, rows, {"event": "finished", "attempt_path": key,
                "status": category, "error_classification_protocol": "aerial_failure_classification_v2",
                "files_sha256": _attempt_file_hashes(directory)})
            report()
            raise error
        result["execution_config"] = run["execution_config"]
        _save_evaluation_json(directory / "rollout.json", result)
        _append_attempt_ledger(root, rows, {"event": "finished", "attempt_path": key, "status": "completed",
            "files_sha256": _attempt_file_hashes(directory)})
        attempts[key] = {"traj_id": traj, "status": "completed"}
        completed[traj] = key
        _publish_completed_attempt(root, traj, directory)
        if set(completed) != set(metadata_by_id):
            report()
    report()


def _authenticate_development_route(checkpoint, config, official, selected, split_path):
    """Bind a held-out route to both the original release and its checkpoint split."""
    from uavnav.avln.data import load_aerial_development_split
    frozen, _ = load_aerial_development_split(split_path, official)
    run_manifest = checkpoint.resolve().parent.parent / "split_manifest.json"
    raw = run_manifest.read_bytes()
    digest = hashlib.sha256(raw).hexdigest()
    if digest != config.get("split_manifest_sha256"):
        raise ValueError("开发路线诊断的checkpoint邻接训练名单SHA不一致")
    training = json.loads(raw)
    train_keys = {f"{item['scene_id']}/{item['episode_id']}" for item in frozen["train_episode_keys"]}
    dev_keys = {f"{item['scene_id']}/{item['episode_id']}" for item in frozen["dev_episode_keys"]}
    if (training.get("data_protocol") != "aerialvln_s_v1"
            or training.get("validation_purpose") != "development_train_grouped"
            or training.get("validation_source_split") != "train"
            or training.get("development_route_split") != frozen
            or training.get("development_route_split_sha256") != frozen["manifest_sha256"]
            or config.get("development_route_split_sha256") != frozen["manifest_sha256"]
            or set(training.get("train_episode_ids", [])) != train_keys
            or set(training.get("validation_episode_ids", [])) != dev_keys
            or train_keys & dev_keys):
        raise ValueError("开发路线诊断的冻结几何名单与训练/开发成员不一致")
    if (len(selected) != 1 or f"{selected[0]['scene_id']}/{selected[0]['episode_id']}" not in dev_keys
            or training.get("train_annotation_sha256") != selected[0]["_annotation_sha256"]
            or training.get("validation_annotation_sha256") != selected[0]["_annotation_sha256"]):
        raise ValueError("所选路线不是该checkpoint冻结的独立开发路线")
    return digest, frozen["manifest_sha256"]


def _evaluate_aerial(args, parser):
    from uavnav.avln.data import load_aerial_episodes
    from uavnav.avln.metadata import (aerial_scoring_truth_sha256, aerial_task_protocol,
        evaluation_manifest_sha256, validate_evaluation_manifest, validate_aerial_task_protocol,
        authenticate_aerial_release)
    from uavnav.avln.closed_loop import aerial_evaluation_protocol, validate_aerial_evaluation_protocol
    if getattr(args, "seed", 0) != 0:
        parser.error("当前阶段Aerial评测只允许seed0，避免baseline随机源改变结果")
    if args.resume and (args.backend != "airsim" or args.metric_protocol != "eval_adapter_v2" or args.preflight_only):
        parser.error("resume仅用于Aerial真实AirSim、显式v2评分，不接受预检或回放")
    if args.require_formal_protocol and (args.backend != "airsim" or args.preflight_only
            or args.split not in ("val_seen", "val_unseen") or args.metric_protocol != "eval_adapter_v2"
            or args.max_steps != 500):
        parser.error("正式合同要求Aerial AirSim、完整val划分、显式v2与500动作")
    if args.data_root is None or args.trajectory is not None:
        parser.error("AerialVLN 需要 --data-root 指向官方标注目录")
    if args.split not in ("train", "val_seen", "val_unseen", "test"):
        parser.error("AerialVLN 使用 train/val_seen/val_unseen/test")
    if args.training_route_diagnostic and (args.split != "train" or args.backend != "airsim"
            or args.preflight_only or args.scene_id is None or args.episode_id is None):
        parser.error("训练路线诊断需要train/airsim、单scene-id和episode-id；不接受预检或回放")
    if args.development_route_diagnostic and (args.split != "train" or args.backend != "airsim"
            or args.preflight_only or args.scene_id is None or args.episode_id is None
            or args.development_split_manifest is None or args.metric_protocol != "eval_adapter_v2"
            or args.training_route_diagnostic or args.require_formal_protocol):
        parser.error("开发路线诊断要求train/AirSim、单scene/episode、冻结开发名单及v2；禁止训练诊断或正式合同")
    if args.development_split_manifest is not None and not args.development_route_diagnostic:
        parser.error("development-split-manifest仅用于显式开发路线诊断")
    if args.split == "train" and args.backend == "airsim" and not args.preflight_only and not (args.training_route_diagnostic or args.development_route_diagnostic):
        parser.error("train真实执行仅允许显式训练或独立开发路线诊断，不作正式验证")
    if args.camera_name not in (None, "front_0") or args.vehicle_name not in (None, "Drone_1"):
        parser.error("AerialVLN 固定官方 front_0/Drone_1，不能静默替换相机或载具")
    if args.success_distance not in (None, 20):
        parser.error("AerialVLN 官方成功使用XY20米，不能沿用FOV10米")
    if any(getattr(args, key) is not None for key in ("list_json", "constant_step", "spl_definition",
            "action_duration", "speed_limit", "sample_interval", "legacy_strip_direction", "spawnarea_json", "scene_map_name")):
        parser.error("AerialVLN 不接受FOV列表、运动步长、SPL、速度控制、方向删除或对象生成参数")
    supplied_protocol = json.loads(args.evaluation_protocol.read_text(encoding="utf-8")) if args.evaluation_protocol else None
    supplied_scoring = None
    if isinstance(supplied_protocol, dict) and supplied_protocol.get("schema_version") == 2:
        supplied_scoring = validate_aerial_evaluation_protocol(supplied_protocol)
        if args.metric_protocol != supplied_scoring["metric_protocol"]:
            parser.error("评分合同需要显式--metric-protocol eval_adapter_v2，不能混用旧默认")
        supplied_task = supplied_scoring["task_protocol"]
    else:
        supplied_task = validate_aerial_task_protocol(supplied_protocol) if supplied_protocol is not None else None
    episodes = load_aerial_episodes(args.data_root, args.split)
    official_episodes = episodes
    official_count = len(episodes)
    source_authentication = None
    try:
        source_authentication = authenticate_aerial_release(args.split, episodes)
    except ValueError as error:
        if args.require_formal_protocol:
            parser.error(str(error))
    if args.require_formal_protocol and args.episode_id is not None:
        parser.error("正式合同不能裁剪episode；scene-id仅选择完整split的执行分片")
    if args.scene_id is not None and not args.require_formal_protocol:
        episodes = [ep for ep in episodes if ep["scene_id"] == args.scene_id]
    if args.episode_id is not None:
        episodes = [ep for ep in episodes if str(ep["episode_id"]) == args.episode_id]
    if not episodes:
        parser.error("所选场景/episode 不属于官方划分")
    scope = ("official_split" if args.split in ("val_seen", "val_unseen", "test")
             and source_authentication is not None and len(episodes) == official_count else "subset_diagnostic")
    if args.require_formal_protocol and scope != "official_split":
        parser.error("正式合同必须完整官方val名单，子集不能声明正式")
    if args.metric_protocol == "eval_adapter_v2":
        try:
            aerial_evaluation_protocol(supplied_task or aerial_task_protocol(), args.max_steps, scope)
        except ValueError as error:
            parser.error(str(error))
    if args.output.exists() and any(args.output.iterdir()) and not args.resume:
        raise FileExistsError(f"拒绝复用非空评测目录: {args.output}")
    if args.resume and not (args.output / "evaluation_run.json").is_file():
        raise ValueError("resume要求已冻结的新评测run，不能复用旧目录或空目录")
    if not args.preflight_only:
        if args.aerial_baseline is not None:
            if args.checkpoint is not None or args.policy != "model":
                parser.error("--aerial-baseline 不能与 --checkpoint 或其他 --policy 同用")
        elif args.checkpoint is None or args.policy != "model":
            parser.error("AerialVLN 八动作入口需要 --policy model 和 --checkpoint")
        if args.split == "test":
            parser.error("官方 test 无 goals/actions/reference，当前不支持本地评分；可做 --preflight-only")
        if args.backend == "airsim" and not args.scene_ready:
            parser.error("AerialVLN 闭环需要已启动场景及 --scene-ready")
        if args.require_formal_protocol and args.scene_endpoints is None:
            parser.error("正式全split要求 --scene-endpoints 绑定全部场景来源和端点")
        if args.backend == "airsim" and args.scene_endpoints is None and args.scene_id is None:
            parser.error("AerialVLN闭环需要scene-id或完整scene-endpoints")
        if args.backend == "replay" and args.cache_manifest is None:
            parser.error("AerialVLN replay 需要 --cache-manifest")
        if type(args.max_steps) is not int or args.max_steps <= 0:
            parser.error("max_steps 必须是正整数；上游默认预算为500")
        if args.stop_threshold is not None or args.stop_mode == "fixed" or args.goal_source is not None:
            parser.error("AerialVLN 使用8类argmax STOP，不能沿用FOV停止阈值/对象目标")
    args._scene_endpoints = {}
    if args.scene_endpoints is not None:
        if args.backend != "airsim" or args.preflight_only:
            parser.error("scene-endpoints只用于真实AirSim执行")
        args._scene_endpoints = _load_scene_endpoints(args.scene_endpoints, {e["scene_id"] for e in episodes})
    execution_episodes = episodes
    if args.require_formal_protocol and args.scene_id is not None:
        execution_episodes = [ep for ep in episodes if ep["scene_id"] == args.scene_id]
        if not execution_episodes:
            parser.error("执行分片scene-id不属于完整split")
    args.output.mkdir(parents=True, exist_ok=True)
    task = supplied_task or aerial_task_protocol()
    task_hash = hashlib.sha256(json.dumps(task, sort_keys=True, separators=(",", ":"), ensure_ascii=False).encode()).hexdigest()
    scoring_protocol = aerial_evaluation_protocol(task, args.max_steps, scope) if args.metric_protocol == "eval_adapter_v2" else task
    if supplied_scoring is not None and supplied_scoring != scoring_protocol:
        parser.error("输入评分合同与所选预算/范围/任务不一致")
    scoring_hash = hashlib.sha256(json.dumps(scoring_protocol, sort_keys=True, separators=(",", ":"), ensure_ascii=False).encode()).hexdigest()
    if args.preflight_only:
        report = {"status": "aerial_metadata_preflight_only", "task_protocol": task,
                  "split": args.split, "official_episode_count": official_count,
                  "selected_episode_count": len(episodes), "annotation_sha256": episodes[0]["_annotation_sha256"],
                  "official_source_authentication": source_authentication,
                  "hidden_test_labels": args.split == "test", "real_simulator_executed": False,
                  "quarantine_candidates": [{"scene_id": e["scene_id"], "episode_id": e["episode_id"],
                                            "reason": e["_quarantine_reason"]} for e in episodes if e["_quarantine_reason"]],
                  "metrics": {key: None for key in ("ne", "sr", "osr", "ndtw", "sdtw", "spl")}}
        if args.metric_protocol == "eval_adapter_v2":
            report.update(evaluation_protocol=scoring_protocol, evaluation_protocol_sha256=scoring_hash)
        (args.output / "preflight.json").write_text(json.dumps(report, ensure_ascii=False, indent=2), encoding="utf-8")
        return
    import torch
    from uavnav.avln.inference import load_predictor, AERIAL_ARCHITECTURES
    from uavnav.avln.closed_loop import rollout_aerial_episode, replay_aerial_teacher_samples, write_metrics
    torch.manual_seed(args.seed)
    np.random.seed(args.seed)
    random.seed(args.seed)
    torch.set_float32_matmul_precision("highest")
    torch.backends.cudnn.allow_tf32 = False
    torch.backends.cudnn.benchmark = False
    predictor = load_predictor(args.checkpoint, device=args.device) if args.aerial_baseline is None else _baseline_predictor(args.aerial_baseline, args.seed, args.device)
    architecture = predictor.config["architecture"]
    if architecture not in AERIAL_ARCHITECTURES:
        raise ValueError("AerialVLN评测只接受路线八动作checkpoint")
    task = predictor.config["task_protocol"]
    if supplied_task is not None and task != supplied_task:
        raise ValueError("输入的AerialVLN任务合同与checkpoint任务合同不一致")
    task_hash = hashlib.sha256(json.dumps(task, sort_keys=True, separators=(",", ":"), ensure_ascii=False).encode()).hexdigest()
    scoring_protocol = aerial_evaluation_protocol(task, args.max_steps, scope) if args.metric_protocol == "eval_adapter_v2" else task
    if supplied_scoring is not None and supplied_scoring != scoring_protocol:
        raise ValueError("输入评分合同与checkpoint任务/预算/范围不一致")
    scoring_hash = hashlib.sha256(json.dumps(scoring_protocol, sort_keys=True, separators=(",", ":"), ensure_ascii=False).encode()).hexdigest()
    checkpoint_hash = predictor.checkpoint_sha256
    history_frames = predictor.config.get("history_frames", 8)
    training_manifest = None
    development_binding = None
    if args.development_route_diagnostic:
        development_binding = _authenticate_development_route(
            args.checkpoint, predictor.config, official_episodes, episodes, args.development_split_manifest)
    if args.training_route_diagnostic:
        run_manifest = args.checkpoint.resolve().parent.parent / "split_manifest.json"
        if not run_manifest.is_file() or hashlib.sha256(run_manifest.read_bytes()).hexdigest() != predictor.config["split_manifest_sha256"]:
            raise ValueError("训练路线诊断要求checkpoint邻接完整run及其已冻结训练名单")
        training_manifest = json.loads(run_manifest.read_text(encoding="utf-8"))
        key = f"{episodes[0]['scene_id']}/{episodes[0]['episode_id']}"
        if (len(episodes) != 1 or key not in training_manifest.get("train_episode_ids", [])
                or training_manifest.get("data_protocol") != "aerialvln_s_v1"):
            raise ValueError("所选路线不属于该checkpoint已训练episode，不能声称训练路线完成")
        if training_manifest.get("train_annotation_sha256") != episodes[0]["_annotation_sha256"]:
            raise ValueError("训练路线当前标注与checkpoint冻结训练来源不一致")
    if args.backend == "replay":
        from uavnav.avln.data import load_aerial_samples
        samples = load_aerial_samples(args.data_root, args.split, args.cache_manifest, history_frames,
                                      require_depth=predictor.config.get("input_modality") == "rgbd")
        selected_keys = {(e["scene_id"], str(e["episode_id"])) for e in episodes}
        selected_samples = [sample for sample in samples
                            if (sample["scene_id"], str(sample["episode_id"])) in selected_keys]
        diagnostics = replay_aerial_teacher_samples(predictor, selected_samples) if selected_samples else []
        if not diagnostics:
            raise ValueError("缓存未包含所选诊断episode")
        (args.output / "replay_predictions.json").write_text(json.dumps({"status": "replay_only", "checkpoint_sha256": checkpoint_hash,
            "architecture": architecture, "memory_protocol": predictor.config.get("memory_protocol", "none"),
            "memory_mode": predictor.config.get("memory_mode", "not_applicable"),
            "vision_batchnorm_protocol": predictor.config.get("vision_batchnorm_protocol", "legacy_batchnorm_v1"),
            "sequence_policy": predictor.config.get("sequence_policy", "frame_bc_v1"),
            "diagnostic_context": "complete_teacher_episode_prefixes_not_self_navigation",
            "cache_manifest_sha256": hashlib.sha256(args.cache_manifest.read_bytes()).hexdigest(),
            "diagnostics": diagnostics}, ensure_ascii=False, indent=2), encoding="utf-8")
        (args.output / "metrics.json").write_text(json.dumps({"status": "replay_only", "metrics": {
            key: None for key in ("ne", "sr", "osr", "ndtw", "sdtw", "spl", "autonomous_stop_success")}}, indent=2), encoding="utf-8")
        return
    from uavnav.avln.airsim_env import AerialRouteEnv
    # train 仅用于开发诊断，不能声明官方评测划分。
    manifest_rows = []
    for episode in episodes:
        row = {"traj_id": f"{episode['scene_id']}/{episode['episode_id']}", "split": args.split}
        if args.metric_protocol == "eval_adapter_v2":
            rotation = episode["start_rotation"]
            truth = {**row, "episode_sha256": episode["_episode_sha256"],
                     "annotation_sha256": episode["_annotation_sha256"],
                     "start_position": episode["start_position"], "start_orientation_xyzw": rotation[1:] + rotation[:1],
                     "goal_position": episode["goals"][0]["position"],
                     "reference_positions": [pose[:3] for pose in episode["reference_path"]]}
            row.update(episode_sha256=episode["_episode_sha256"], scoring_truth_sha256=aerial_scoring_truth_sha256(truth))
        manifest_rows.append(row)
    manifest = validate_evaluation_manifest({"schema_version": 2 if args.metric_protocol == "eval_adapter_v2" else 1,
        "scope": scope,
        "split": args.split, "source_sha256": episodes[0]["_annotation_sha256"],
        "evaluation_protocol_sha256": scoring_hash,
        "episodes": manifest_rows})
    manifest_hash = evaluation_manifest_sha256(manifest)
    config = {"checkpoint_sha256": checkpoint_hash,
              "policy": predictor.config.get("policy_kind", f"{architecture}_argmax"),
              "architecture": architecture, "memory_protocol": predictor.config.get("memory_protocol", "none"),
              "memory_mode": predictor.config.get("memory_mode", "not_applicable"),
              "vision_batchnorm_protocol": predictor.config.get("vision_batchnorm_protocol", "legacy_batchnorm_v1"),
              "observation_recording": "policy_sensor_state_v1" if args.record_observations else "disabled",
              "sequence_policy": predictor.config.get("sequence_policy", "frame_bc_v1"),
              "tokenizer_version": predictor.config.get("tokenizer_version", "legacy_word_v1"),
              "error_classification_protocol": "aerial_failure_classification_v2",
              "control_protocol": "airsim_set_pose_ignore_collision", "action_protocol": "aerial_action8_v1",
              "max_steps": args.max_steps, "camera_name": "front_0", "vehicle_name": "Drone_1",
              "rgb_order": args.rgb_order or "RGB", "depth_protocol": "scene1_7_depthvis255_else_depthperspective100_v1",
              "collision_termination": "depth_proxy", "history_frames": history_frames,
              "inference_precision": "fp32_tf32_disabled", "task_protocol_sha256": task_hash}
    if predictor.config.get("input_modality") == "rgbd":
        config.update(input_modality="rgbd", depth_input_protocol=predictor.config["depth_input_protocol"],
                      depth_size=predictor.config["depth_size"], depth_fusion=predictor.config.get("depth_fusion"))
    if predictor.config.get("architecture") == "aerial_route_dino_v5":
        config["visual_encoder"] = dict(predictor.config["visual_encoder"])
    if args.metric_protocol == "eval_adapter_v2":
        config.update(metric_protocol=args.metric_protocol, evaluation_protocol_sha256=scoring_hash)
    if predictor.config.get("checkpoint_format_version") in (6, 7) and "baseline_protocol" in predictor.config:
        config.update(baseline_protocol=predictor.config["baseline_protocol"],
                      memory_layers=predictor.config["memory_layers"], memory_hidden_size=512,
                      raw_rgb_adapter=predictor.config["raw_rgb_adapter"],
                      depth_policy=predictor.config["upstream_adapter"]["depth_policy"],
                      upstream_source_sha256=predictor.config["upstream_source_sha256"],
                      ddppo_checkpoint_sha256=predictor.config["ddppo_checkpoint_sha256"])
    if args.training_route_diagnostic:
        config.update(evaluation_purpose="training_route_completion", seen_in_training=True,
                      training_split_manifest_sha256=predictor.config["split_manifest_sha256"])
    if development_binding is not None:
        config.update(evaluation_purpose="development_route_completion", seen_in_training=False,
                      training_split_manifest_sha256=development_binding[0],
                      development_route_split_sha256=development_binding[1])
    metadata_by_id = {}
    for episode in episodes:
        metadata = {"task_version": "aerialvln_s_v1", "split": args.split,
                    "traj_id": f"{episode['scene_id']}/{episode['episode_id']}",
                    "episode_sha256": episode["_episode_sha256"], "annotation_sha256": episode["_annotation_sha256"],
                    "evaluation_manifest_sha256": manifest_hash, "evaluation_protocol_sha256": scoring_hash,
                    "evaluation_scope": manifest["scope"], "execution_config": config,
                    "goal_position": episode["goals"][0]["position"],
                    "reference_positions": [pose[:3] for pose in episode["reference_path"]]}
        if args.metric_protocol == "eval_adapter_v2":
            metadata["metric_protocol"] = args.metric_protocol
            metadata["start_position"] = episode["start_position"]
        if args.training_route_diagnostic:
            metadata.update(evaluation_purpose="training_route_completion", seen_in_training=True)
        if development_binding is not None:
            metadata.update(evaluation_purpose="development_route_completion", seen_in_training=False)
        rotation = episode["start_rotation"]
        metadata["start_orientation_xyzw"] = rotation[1:] + rotation[:1]
        metadata_by_id[metadata["traj_id"]] = metadata
    source_root = Path(__file__).resolve().parent
    sources = [source_root / "evaluate.py", source_root / "train.py", *sorted((source_root / "uavnav").rglob("*.py"))]
    run = {"schema_version": 1, "attempt_protocol": "aerial_attempt_journal_v1",
           "checkpoint_sha256": checkpoint_hash, "annotation_root": str(args.data_root.resolve()),
           "evaluation_manifest_sha256": manifest_hash, "evaluation_protocol_sha256": scoring_hash,
           "seed": args.seed, "device": str(predictor.device), "execution_config": config,
           "simulator_connection": ({"scene_endpoints": list(args._scene_endpoints.values())} if args._scene_endpoints
                                    else {"ip": args.ip, "port": args.port, "scene_id": args.scene_id}),
           "source_sha256": {path.relative_to(source_root).as_posix(): hashlib.sha256(path.read_bytes()).hexdigest() for path in sources},
           "runtime": {"python": sys.version, "torch": torch.__version__, "numpy": np.__version__,
                       "torchvision": package_metadata.version("torchvision"), "cuda_build": torch.version.cuda,
                       "cudnn": torch.backends.cudnn.version()},
           "journal_measurement_boundary": "synchronous_durable_events_outside_policy_inference_timer_v1",
           "formal_protocol_requested": args.require_formal_protocol,
           "formal_navigation_verified": False}
    if source_authentication is not None and scope == "official_split":
        run["official_source_authentication"] = source_authentication
    if args.resume:
        for name, expected in (("evaluation_run.json", run), ("evaluation_manifest.json", manifest),
                               ("evaluation_protocol.json", scoring_protocol)):
            if json.loads((args.output / name).read_text(encoding="utf-8")) != expected:
                raise ValueError(f"resume冻结合同/输入/源码发生变化: {name}")
    else:
        _save_evaluation_json(args.output / "evaluation_manifest.json", manifest)
        _save_evaluation_json(args.output / "evaluation_protocol.json", scoring_protocol)
        _save_evaluation_json(args.output / "evaluation_run.json", run)
    _run_aerial_attempts(args, execution_episodes, predictor, metadata_by_id, run, AerialRouteEnv,
                        rollout_aerial_episode, write_metrics, torch)


def main(argv: list[str] | None = None) -> None:
    parser = _parser()
    args = parser.parse_args(argv)
    if args.record_observations and (args.dataset != "aerialvln_s_v1" or args.backend != "airsim" or args.preflight_only):
        parser.error("record-observations仅用于Aerial真实闭环")
    args.max_steps = args.max_steps if args.max_steps is not None else (500 if args.dataset == "aerialvln_s_v1" else 64)
    if args.dataset == "aerialvln_s_v1":
        _evaluate_aerial(args, parser)
        return
    if args.training_route_diagnostic:
        parser.error("training-route-diagnostic只适用于AerialVLN")
    if args.resume or args.require_formal_protocol:
        parser.error("resume/require-formal-protocol只适用于AerialVLN真实AirSim")
    if args.metric_protocol != "airvln_xy20_fastdtw_v1":
        parser.error("metric-protocol eval_adapter_v2只适用于AerialVLN")
    if args.split not in ("test", "unobject", "unscene", "unseen_scene", "unseen_object"):
        parser.error("FOV不接受AerialVLN划分")
    args.list_json = args.list_json or "test.json"
    args.constant_step = args.constant_step if args.constant_step is not None else 4.94
    args.spl_definition = args.spl_definition or "success_distance_adjusted"
    args.camera_name = args.camera_name or "FrontCamera"
    args.vehicle_name = args.vehicle_name or ""
    args.action_duration = args.action_duration if args.action_duration is not None else 5.
    args.speed_limit = args.speed_limit if args.speed_limit is not None else 1.
    args.sample_interval = args.sample_interval if args.sample_interval is not None else .1
    if args.max_steps <= 0 or not np.isfinite(args.constant_step) or args.constant_step <= 0:
        parser.error("步数、步长和成功阈值必须是正数")
    if args.success_distance is not None and (not np.isfinite(args.success_distance) or args.success_distance <= 0):
        parser.error("成功阈值必须是有限正数")
    if not args.preflight_only and args.backend == "airsim" and (args.trajectory is None or not args.scene_ready or not args.rgb_order or not args.scene_map_name):
        parser.error("airsim 需要单条 --trajectory、--scene-ready、--scene-map-name 和 --rgb-order")
    if not args.preflight_only and args.policy == "model" and args.checkpoint is None:
        parser.error("model 需要 --checkpoint")
    from uavnav.avln.metadata import (
        canonical_eval_split, evaluation_manifest_sha256,
        evaluation_protocol_sha256, validate_evaluation_protocol,
    )
    evaluation_protocol = None
    if args.evaluation_protocol:
        evaluation_protocol = validate_evaluation_protocol(json.loads(args.evaluation_protocol.read_text(encoding="utf-8")))
        if not args.preflight_only:
            parser.error("fov_static_v1正式评测尚需双视角策略及真实场景/坐标预检，当前只接受--preflight-only")
    args.split = canonical_eval_split(args.split)
    # 只有 --help/参数检查完成后才导入 PyTorch，便于无 GPU 环境查看用法。
    from uavnav.avln.data import _frames, _instruction_from_obj_des, load_list
    from uavnav.avln.rollout import rollout_episode, write_rollout
    from uavnav.avln.closed_loop import write_metrics

    trajectories = [args.trajectory.resolve()] if args.trajectory else load_list(args.data_root, args.list_json)
    if args.data_root:
        list_path = Path(args.list_json)
        list_path = list_path if list_path.is_absolute() else args.data_root / list_path
        rows = json.loads(list_path.read_text(encoding="utf-8"))
        expected = {(args.data_root / (row["dir"] if isinstance(row, dict) else row)).resolve() for row in rows}
        omitted = expected - {path.resolve() for path in trajectories}
        if omitted:
            raise ValueError(f"评测列表有 {len(omitted)} 条轨迹缺少日志，拒绝静默排除后汇总")
    manifest = _evaluation_manifest(args, trajectories, evaluation_protocol_sha256(evaluation_protocol) if evaluation_protocol else None)
    manifest_digest = evaluation_manifest_sha256(manifest)
    def initialize_output():
        if args.output.exists() and any(args.output.iterdir()):
            raise FileExistsError(f"拒绝复用非空评测目录: {args.output}")
        args.output.mkdir(parents=True, exist_ok=True)
        (args.output / "evaluation_manifest.json").write_text(json.dumps(manifest, ensure_ascii=False, indent=2), encoding="utf-8")
    if args.preflight_only:
        initialize_output()
        _preflight_metadata(args, trajectories, manifest, evaluation_protocol)
        print(f"元数据预检已写入 {args.output.resolve()}；未连接真实场景，不产生导航指标")
        return

    random.seed(args.seed)
    np.random.seed(args.seed)
    if args.policy == "model":
        import torch
        from uavnav.avln.inference import WaypointPredictor

        torch.manual_seed(args.seed)
        torch.cuda.manual_seed_all(args.seed)
        # 各基线使用一致的推理数值口径，避免继承训练进程的 TF32 全局设置。
        torch.set_float32_matmul_precision("highest")
        torch.backends.cudnn.allow_tf32 = False
        torch.backends.cudnn.benchmark = False
        legacy_strip = None if args.legacy_strip_direction is None else args.legacy_strip_direction == "true"
        predictor = WaypointPredictor(args.checkpoint, device=args.device, strip_direction=legacy_strip)
        history_frames = predictor.config["history_frames"]
        checkpoint_hash = predictor.checkpoint_sha256
    else:
        predictor = BaselinePredictor(args.policy, args.constant_step)
        history_frames = 8
        checkpoint_hash = None
    explicit_success_distance = args.success_distance is not None
    stop_capable = args.policy == "model" and predictor.config["stop_enabled"]
    if args.stop_mode == "predicted" and not stop_capable:
        parser.error("predicted要求已监督STOP模型")
    stop_enabled = stop_capable and args.stop_mode != "fixed"
    goal_source = args.goal_source or ("object" if stop_capable else "reference_endpoint")
    if stop_capable:
        if goal_source != "object":
            parser.error("STOP模型及其固定预算对照必须遵守对象目标合同")
        protocol = predictor.config["task_protocol"]
        radius = protocol["success_distance_m"]
        if args.success_distance is not None and args.success_distance != radius:
            parser.error("成功阈值与checkpoint任务合同冲突")
        args.success_distance = radius
    if args.policy == "model" and args.backend == "airsim" and isinstance(predictor.config["task_protocol"], dict):
        if args.camera_name != predictor.config["task_protocol"]["camera"]:
            parser.error("相机名与checkpoint输入权限冲突")
    if stop_enabled:
        if args.stop_threshold is None or not np.isfinite(args.stop_threshold) or not 0 <= args.stop_threshold <= 1:
            parser.error("STOP模型要求显式--stop-threshold且范围为[0,1]")
    else:
        if args.stop_threshold is not None:
            parser.error("当前策略没有已监督STOP头，不可设置停止阈值")
        args.success_distance = args.success_distance or 20.0
    if goal_source == "object" and not stop_capable and not explicit_success_distance:
        parser.error("无STOP对象对照要求显式--success-distance")
    def execution_predictor(image, instruction, history):
        value = predictor.predict(image=image, instruction=instruction, history=history)
        if stop_capable and not stop_enabled:
            value = {**value, "stop_enabled": False, "stop_probability": None}
        return value
    initialize_output()
    for trajectory in trajectories:
        trajectory = trajectory.resolve()
        episode_dir = args.output / "episodes" / f"{trajectory.parent.name}_{trajectory.name}"
        if episode_dir.exists():
            raise FileExistsError(f"拒绝覆盖已有 episode: {episode_dir}")
        if args.backend == "airsim" and trajectory.parent.name != args.scene_map_name:
            raise ValueError("已声明的场景 Map 与参考轨迹不一致")
        instruction = _instruction_from_obj_des(trajectory, strip_direction=False)
        if not instruction:
            raise ValueError(f"缺少评测指令 obj_des.json: {trajectory}")
        first_frame = _frames(trajectory)[0][0]
        reference = _reference(trajectory, first_frame[2])
        object_config = _object_config(trajectory, args.spawnarea_json) if args.backend == "airsim" or goal_source == "object" else None
        goal = object_config["position"] if goal_source == "object" else reference[-1]
        if args.backend == "replay":
            from uavnav.avln.simulator import StaticTrajectoryEnv

            env = StaticTrajectoryEnv(trajectory)
        else:
            from uavnav.avln.airsim_env import AirSimEnv

            start, _, _ = first_frame
            env = AirSimEnv(
                start["position"], start["orientation"], ip=args.ip, port=args.port,
                vehicle_name=args.vehicle_name, camera_name=args.camera_name, rgb_order=args.rgb_order,
                action_duration=args.action_duration, speed_limit=args.speed_limit,
                sample_interval=args.sample_interval,
            )
        episode_dir.mkdir(parents=True)
        ori_info = {
            "ori_traj_dir": str(trajectory), "traj_id": f"{trajectory.parent.name}/{trajectory.name}",
            "split": args.split, "seed": args.seed, "policy": args.policy,
            "evaluation_manifest_sha256": manifest_digest,
            "evaluation_protocol_sha256": manifest["evaluation_protocol_sha256"],
            "evaluation_scope": manifest["scope"],
            "checkpoint_sha256": checkpoint_hash,
            "execution_config": {"checkpoint_sha256": checkpoint_hash, "policy": args.policy,
                "constant_step_m": args.constant_step if args.policy != "model" else None,
                "control_protocol": "paused_static_fixed_duration_world_velocity" if args.backend == "airsim" else "recorded_replay",
                "max_steps": args.max_steps, "action_duration_sim_s": args.action_duration,
                "speed_limit_m_s": args.speed_limit, "sample_interval_sim_s": args.sample_interval,
                "camera_name": args.camera_name, "rgb_order": args.rgb_order,
                "stop_mode": args.stop_mode, "stop_threshold": args.stop_threshold,
                "inference_precision": "fp32_tf32_disabled" if args.policy == "model" else None},
            "goal_position": goal, "goal_source": "object_metadata" if goal_source == "object" else "reference_trajectory_endpoint",
            "reference_positions": reference, "success_distance": args.success_distance,
            "spl_definition": args.spl_definition, "spl_reference": "reference_path_proxy",
            "success_basis": "final_within_success_distance_and_predicted_stop_and_no_collision" if stop_enabled else (
                "final_within_success_distance_and_no_collision" if goal_source == "object" else "final_within_success_distance"),
            "stop_protocol": "predicted_stop_before_action" if stop_enabled else (
                "fixed_horizon_stop_head_ignored" if stop_capable else "fixed_horizon_no_learned_stop"),
            "stop_threshold": args.stop_threshold,
            "max_steps": args.max_steps, "backend": args.backend,
            "model_config": predictor.config if args.policy == "model" else None,
            "inference_precision": "fp32_tf32_disabled" if args.policy == "model" else None,
            "seed_scope": "python_numpy_torch" if args.policy == "model" else "python_numpy",
            "simulator_seed_applied": False,
            "scene_setup": "caller_verified" if args.backend == "airsim" else None,
            "object_config": object_config,
            "control_protocol": "paused_static_fixed_duration_world_velocity" if args.backend == "airsim" else None,
        }
        (episode_dir / "ori_info.json").write_text(json.dumps(ori_info, ensure_ascii=False, indent=2), encoding="utf-8")
        try:
            result = rollout_episode(env, execution_predictor, instruction, history_frames, args.max_steps,
                                     seed=args.seed, stop_threshold=args.stop_threshold)
            result["goal_position"] = goal
            result["final_distance"] = float(np.linalg.norm(np.asarray(result["final_position"]) - goal))
            write_rollout(episode_dir / "rollout.json", result)
        except Exception as error:
            write_rollout(episode_dir / "rollout.json", {
                "status": "execution_error", "done": False, "termination_reason": "exception",
                "error": f"{type(error).__name__}: {error}", "seed": args.seed,
            })
            write_metrics(args.output, eval_dir=args.output / "episodes")
            raise
        finally:
            if hasattr(env, "finish"):
                env.finish()
    peak_vram = None
    if args.policy == "model" and predictor.device.type == "cuda":
        peak_vram = torch.cuda.max_memory_allocated(predictor.device) / 1024 ** 3
    write_metrics(args.output, eval_dir=args.output / "episodes", peak_vram_gb=peak_vram)
    print(f"结果已写入 {args.output.resolve()}")


if __name__ == "__main__":
    main()
