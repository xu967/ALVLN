"""UAV navigation package.

延迟导入训练入口，使几何、日志和仿真接口不要求安装 PyTorch。
"""


def fit(**kwargs):
    from uavnav.avln.fit import fit as train_fit

    return train_fit(**kwargs)

__all__ = ["fit"]
