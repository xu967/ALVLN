"""Official LANI segments and verified, causal teacher-render caches.

Annotation inspection uses only the standard library. NumPy and Pillow are
imported when reading RGB chunks; this module never imports PyTorch.
"""

from collections import Counter, defaultdict
from dataclasses import dataclass
import hashlib
from itertools import combinations
import json
import math
from pathlib import Path, PurePosixPath


SPLITS = ("train", "dev", "test")
ACTIONS = ("Forward", "TurnRight", "TurnLeft", "Stop")
STOP_ACTION = 3
CACHE_PROTOCOL = "lani_teacher_cache_v1"
DATA_PROTOCOL = "lani_segment_v1"
TOKENIZER = "lani_whitespace_train_vocab_v1"
IDENTITY_PROTOCOL = "lani_source_route_identity_v1"
SOURCE_KEYS = ("annotation", "config", "scene_config", "scene_path", "official_vocab")


def _json_bytes(value):
    return json.dumps(value, sort_keys=True, separators=(",", ":"),
                      ensure_ascii=False, allow_nan=False).encode("utf-8")


def _identity(value):
    return hashlib.sha256(_json_bytes(value)).hexdigest()


def _sha256(path):
    digest = hashlib.sha256()
    with Path(path).open("rb") as stream:
        for block in iter(lambda: stream.read(1024 * 1024), b""):
            digest.update(block)
    return digest.hexdigest()


def _valid_sha(value, label):
    if not isinstance(value, str) or len(value) != 64 or any(c not in "0123456789abcdef" for c in value):
        raise ValueError(f"{label}: expected lowercase SHA256")
    return value


def _relative_file(root, relative):
    if not isinstance(relative, str) or not relative or "\\" in relative:
        raise ValueError(f"Expected a relative POSIX file path: {relative!r}")
    pure = PurePosixPath(relative)
    if pure.is_absolute() or any(part in ("..", ".") for part in pure.parts) or ":" in relative:
        raise ValueError(f"Unsafe relative file path: {relative!r}")
    path = (root / relative).resolve()
    if not path.is_relative_to(root) or not path.is_file():
        raise FileNotFoundError(f"Missing file inside {root}: {relative}")
    return path


def _finite_numbers(values, count, label):
    if not isinstance(values, (list, tuple)) or len(values) != count:
        raise ValueError(f"{label}: expected {count} numeric entries")
    if any(isinstance(x, bool) or not isinstance(x, (int, float)) or not math.isfinite(x) for x in values):
        raise ValueError(f"{label}: values must be finite numbers")
    return tuple(float(x) for x in values)


@dataclass(frozen=True)
class LANIEpisode:
    task_id: str
    split: str
    paragraph_id: str
    segment_index: int
    instruction: str
    actions: tuple
    start_xzyaw: tuple
    goal_xz: tuple
    end_yaw: float
    config_file: str
    path_file: str
    scene_config: dict
    scene_path: dict
    source_shas: dict
    scene_identity: str
    reference_path_identity: str
    route_identity: str

    @property
    def movement_actions(self):
        return self.actions[:-1]

    @property
    def start_pos(self):
        return self.start_xzyaw

    def to_dict(self):
        """Small source/identity record, without duplicating full scene assets."""
        return {key: getattr(self, key) for key in (
            "task_id", "split", "paragraph_id", "segment_index", "instruction", "actions",
            "start_xzyaw", "goal_xz", "end_yaw", "config_file", "path_file", "source_shas",
            "scene_identity", "reference_path_identity", "route_identity")}


@dataclass
class OfficialLANIDataset:
    asset_root: Path
    data_root: Path
    splits: dict
    sources: dict
    invalid_counts: dict
    overlap_audit: dict

    @property
    def by_task_id(self):
        rows = [episode for episodes in self.splits.values() for episode in episodes]
        result = {episode.task_id: episode for episode in rows}
        if len(result) != len(rows):
            raise ValueError("Task IDs repeat across official splits; index each split separately")
        return result

    def to_dict(self):
        return {"protocol": DATA_PROTOCOL, "sources": self.sources,
                "invalid_counts": self.invalid_counts,
                "valid_segment_counts": {split: len(rows) for split, rows in self.splits.items()},
                "overlap_audit": self.overlap_audit}


def load_official_dataset(asset_root):
    """Read every valid official segment, including all over-budget routes.

    Invalid paragraphs are counted and their original source files are hashed.
    Their incomplete supervision is never silently converted into STOP examples.
    """
    root = Path(asset_root).resolve()
    data = root / "data/nav_drone"
    if not data.is_dir() and (root / "config_localmoves_6000.json").is_file():
        data = root
    if not data.is_dir():
        raise FileNotFoundError(f"Missing official data/nav_drone: {root}")
    config_path = data / "config_localmoves_6000.json"
    config = json.loads(config_path.read_text(encoding="utf-8"))
    if tuple(config.get("action_names", ())) != ACTIONS or config.get("stop_action") != "Stop" or config.get("use_paragraphs") is not False:
        raise ValueError("Expected official LANI single-segment four-action config")
    if (config.get("image_height"), config.get("image_width")) != (128, 128):
        raise ValueError("Expected native 128x128 LANI rendering")
    config_sha = _sha256(config_path)
    vocab_path = data / "vocab_6000.txt"
    vocab_sha = _sha256(vocab_path)
    resources = (data / "resources").resolve()
    source_records = {}
    parsed_resources = {}

    def resource(relative):
        if relative not in parsed_resources:
            path = _relative_file(resources, relative)
            content = json.loads(path.read_text(encoding="utf-8"))
            if not isinstance(content, dict):
                raise ValueError(f"Resource must be a JSON object: {path}")
            parsed_resources[relative] = content
            source_records[relative] = {"sha256": _sha256(path), "bytes": path.stat().st_size}
        return parsed_resources[relative], source_records[relative]["sha256"]

    splits, counts, annotation_sources = {}, {}, {}
    for split in SPLITS:
        annotation_path = data / f"{split}_annotations_6000.json"
        rows = json.loads(annotation_path.read_text(encoding="utf-8"))
        if not isinstance(rows, list):
            raise ValueError(f"Official annotations must be an array: {annotation_path}")
        annotation_sha = _sha256(annotation_path)
        annotation_sources[split] = {"sha256": annotation_sha, "bytes": annotation_path.stat().st_size}
        episodes, invalid_ids, split_ids = [], [], set()
        for row in rows:
            paragraph_id = str(row["id"])
            if paragraph_id in split_ids:
                raise ValueError(f"Duplicate official paragraph in {split}: {paragraph_id}")
            split_ids.add(paragraph_id)
            scene, scene_sha = resource(row["config_file"])
            path, path_sha = resource(row["path_file"])
            if not isinstance(row.get("valid"), bool):
                raise ValueError(f"{split}/{paragraph_id}: valid must be a boolean")
            if not row["valid"]:
                invalid_ids.append(paragraph_id)
                continue
            moves = row.get("moves")
            if not isinstance(moves, list) or not moves:
                raise ValueError(f"{split}/{paragraph_id}: valid paragraph lacks segments")
            for key in ("instructions", "start_x", "start_z", "start_rot", "end_x", "end_z", "end_rot"):
                if not isinstance(row.get(key), list) or len(row[key]) != len(moves):
                    raise ValueError(f"{split}/{paragraph_id}: inconsistent segment field {key}")
            normalized_scene = dict(scene)
            normalized_scene.setdefault("lakeCoords", [])
            scene_id = _identity(normalized_scene)
            path_id = _identity(path)
            for index, move_string in enumerate(moves):
                task_id = f"scene_{int(paragraph_id):04d}_{index:02d}"
                text = row["instructions"][index]
                if not isinstance(text, str) or not text.split():
                    raise ValueError(f"{task_id}: empty instruction")
                if not isinstance(move_string, str) or any(c not in "FRL" for c in move_string):
                    raise ValueError(f"{task_id}: unsupported movement labels")
                actions = tuple({"F": 0, "R": 1, "L": 2}[c] for c in move_string) + (STOP_ACTION,)
                start = _finite_numbers([row[k][index] for k in ("start_x", "start_z", "start_rot")], 3, task_id)
                goal = _finite_numbers([row[k][index] for k in ("end_x", "end_z")], 2, task_id)
                end_yaw = _finite_numbers([row["end_rot"][index]], 1, task_id)[0]
                route_id = _identity({"start_xzyaw": start, "goal_xz": goal,
                                      "end_yaw": end_yaw, "actions": actions})
                episodes.append(LANIEpisode(
                    task_id, split, paragraph_id, index, text, actions, start, goal, end_yaw,
                    row["config_file"], row["path_file"], normalized_scene, path,
                    dict(zip(SOURCE_KEYS, (annotation_sha, config_sha, scene_sha, path_sha, vocab_sha))),
                    scene_id, path_id, route_id))
        splits[split] = episodes
        counts[split] = {"raw_paragraphs": len(rows), "valid_paragraphs": len(rows) - len(invalid_ids),
                         "invalid_paragraphs": len(invalid_ids), "invalid_paragraph_ids": invalid_ids,
                         "all_paragraph_ids": sorted(split_ids), "valid_segments": len(episodes),
                         "segments_over_40_movement_actions": sum(len(e.movement_actions) > 40 for e in episodes),
                         "max_movement_actions": max((len(e.movement_actions) for e in episodes), default=0)}
    sources = {"config_sha256": config_sha, "official_vocab_sha256": vocab_sha,
               "annotations": annotation_sources, "resources": source_records,
               "resource_manifest_sha256": _identity(source_records),
               "identity_protocol": IDENTITY_PROTOCOL}
    result = OfficialLANIDataset(root, data, splits, sources, counts, {})
    result.overlap_audit = audit_official_splits(result)
    return result


def audit_official_splits(dataset):
    """Audit content identity without altering the official train/dev/test split.

    Route-program identity uses exact published start/goal/yaw/action content.
    Reference-path identity uses the complete published paragraph curve. These
    are exact-content checks, not a claim of approximate geometric disjointness.
    """
    kinds = ("paragraph_id", "scene_identity", "reference_path_identity", "route_identity")
    groups = {}
    for split, episodes in dataset.splits.items():
        groups[split] = {kind: defaultdict(list) for kind in kinds}
        for episode in episodes:
            for kind in kinds:
                groups[split][kind][getattr(episode, kind)].append(episode.task_id)
    comparisons = {}
    for left, right in combinations(SPLITS, 2):
        comparison = {}
        for kind in kinds:
            identities = sorted(set(groups[left][kind]) & set(groups[right][kind]))
            comparison[kind] = {"overlapping_identities": len(identities),
                                "left_tasks": sum(len(groups[left][kind][x]) for x in identities),
                                "right_tasks": sum(len(groups[right][kind][x]) for x in identities),
                                "examples": [{"identity": x, left: groups[left][kind][x],
                                              right: groups[right][kind][x]} for x in identities[:20]]}
        raw_overlap = sorted(set(dataset.invalid_counts[left]["all_paragraph_ids"]) &
                             set(dataset.invalid_counts[right]["all_paragraph_ids"]))
        comparison["all_raw_paragraph_ids"] = {"overlapping_ids": len(raw_overlap), "ids": raw_overlap}
        comparisons[f"{left}:{right}"] = comparison
    return {"protocol": IDENTITY_PROTOCOL,
            "scope": "exact semantic JSON scene/paragraph-curve and segment start-goal-yaw-action identities; no approximate geometry claim",
            "official_splits_modified": False, "comparisons": comparisons}


@dataclass(frozen=True)
class LANIVocabulary:
    token_to_id: dict
    training_tasks_sha256: str

    def __post_init__(self):
        mapping = self.token_to_id
        if mapping.get("<PAD>") != 0 or mapping.get("<UNK>") != 1 or set(mapping.values()) != set(range(len(mapping))):
            raise ValueError("LANI vocabulary requires contiguous IDs, PAD0 and UNK1")
        if any(not isinstance(token, str) or not isinstance(index, int) or isinstance(index, bool)
               for token, index in mapping.items()):
            raise ValueError("Invalid LANI vocabulary mapping")
        _valid_sha(self.training_tasks_sha256, "training_tasks_sha256")

    def __len__(self):
        return len(self.token_to_id)

    def encode(self, instruction):
        tokens = instruction.split()
        if not tokens:
            raise ValueError("Empty LANI instruction")
        return [self.token_to_id.get(token, 1) for token in tokens]

    def to_dict(self):
        return {"tokenizer": TOKENIZER, "token_to_id": self.token_to_id,
                "training_tasks_sha256": self.training_tasks_sha256, "pad_id": 0, "unk_id": 1}

    @classmethod
    def from_dict(cls, payload):
        if payload.get("tokenizer") != TOKENIZER or payload.get("pad_id") != 0 or payload.get("unk_id") != 1:
            raise ValueError("Unsupported LANI vocabulary contract")
        return cls(dict(payload["token_to_id"]), payload["training_tasks_sha256"])


def build_train_vocabulary(episodes):
    """Deterministic whitespace vocabulary, fitted exclusively on train text."""
    episodes = list(episodes)
    if not episodes or any(episode.split != "train" for episode in episodes):
        raise ValueError("Vocabulary must be built from nonempty train episodes only")
    records = sorted((e.task_id, e.instruction, e.source_shas["annotation"]) for e in episodes)
    if len({record[0] for record in records}) != len(records):
        raise ValueError("Vocabulary input contains duplicate train tasks")
    tokens = sorted({token for episode in episodes for token in episode.instruction.split()})
    if set(tokens) & {"<PAD>", "<UNK>"}:
        raise ValueError("Published tokens collide with reserved PAD/UNK labels")
    return LANIVocabulary({token: index for index, token in enumerate(["<PAD>", "<UNK>"] + tokens)},
                          _identity(records))


def vocabulary_coverage(vocabulary, episodes):
    counts = Counter(token for episode in episodes for token in episode.instruction.split())
    unknown = {token: count for token, count in counts.items() if token not in vocabulary.token_to_id}
    return {"tokens": sum(counts.values()), "unknown_tokens": sum(unknown.values()),
            "unknown_types": dict(sorted(unknown.items()))}


class LaniTeacherCache:
    """Validate complete causal RGB/action episodes and stream contiguous chunks.

    For formal training pass the official dataset: annotations, every task and
    full coverage are then checked before reading any image. SHA/image decoding
    checks happen on first use, or eagerly with verify_images=True.
    """
    def __init__(self, manifest_path, vocabulary, split=None, official_dataset=None,
                 require_complete=True, verify_images=False):
        self.manifest_path = Path(manifest_path).resolve()
        self.root = self.manifest_path.parent
        self.manifest_sha256 = _sha256(self.manifest_path)
        manifest = json.loads(self.manifest_path.read_text(encoding="utf-8"))
        if manifest.get("protocol") != CACHE_PROTOCOL:
            raise ValueError("Unsupported LANI teacher-cache protocol")
        self.split = manifest.get("split")
        if self.split not in SPLITS or split is not None and split != self.split:
            raise ValueError("LANI cache split mismatch")
        if manifest.get("native_size") != [128, 128]:
            raise ValueError("LANI cache requires native_size [128,128]")
        self.source_annotation_sha256 = _valid_sha(manifest.get("source_annotation_sha256"), "source_annotation_sha256")
        self.source_config_sha256 = _valid_sha(manifest.get("source_config_sha256"), "source_config_sha256")
        if not isinstance(vocabulary, LANIVocabulary):
            raise TypeError("Expected train-fitted LANIVocabulary")
        self.vocabulary = vocabulary
        rows = manifest.get("episodes")
        if not isinstance(rows, list) or not rows:
            raise ValueError("LANI cache requires nonempty episode array")
        self.episodes, self.by_task_id, self._checked_images = [], {}, set()
        official = ({episode.task_id: episode for episode in official_dataset.splits[self.split]}
                    if official_dataset is not None else None)
        if official_dataset is not None:
            if self.source_annotation_sha256 != official_dataset.sources["annotations"][self.split]["sha256"] or self.source_config_sha256 != official_dataset.sources["config_sha256"]:
                raise ValueError("LANI cache does not bind the supplied official annotation/config")
        for row in rows:
            self._validate_episode(row, official)
            task_id = row["task_id"]
            if task_id in self.by_task_id:
                raise ValueError(f"Duplicate cached task: {task_id}")
            self.episodes.append(row)
            self.by_task_id[task_id] = row
        expected = {e.task_id for e in official_dataset.splits[self.split]} if official_dataset is not None else None
        missing = sorted(expected - set(self.by_task_id)) if expected is not None else None
        self.coverage = {"official_source_checked": official is not None,
                         "complete": not missing if expected is not None else None,
                         "expected_episodes": len(expected) if expected is not None else None,
                         "cached_episodes": len(self.episodes), "missing_task_ids": missing}
        if require_complete and missing:
            raise ValueError(f"Incomplete {self.split} cache: missing {len(missing)} official tasks; first={missing[:5]}")
        if verify_images:
            for row in self.episodes:
                for index in range(len(row["images"])):
                    self._read_image(row, index)

    def _validate_episode(self, row, official):
        if not isinstance(row, dict) or not isinstance(row.get("task_id"), str) or not row["task_id"]:
            raise ValueError("Cache episode lacks task_id")
        task = row["task_id"]
        if row.get("split") != self.split or row.get("native_size") != [128, 128]:
            raise ValueError(f"{task}: split/native_size mismatch")
        text, actions = row.get("instruction"), row.get("actions")
        if not isinstance(text, str) or not text.split():
            raise ValueError(f"{task}: missing instruction")
        if not isinstance(actions, list) or not actions or any(type(x) is not int or x not in range(4) for x in actions):
            raise ValueError(f"{task}: expected four-action integer labels")
        if actions[-1] != STOP_ACTION or STOP_ACTION in actions[:-1]:
            raise ValueError(f"{task}: expected exactly one terminal STOP3")
        images, shas = row.get("images"), row.get("image_sha256")
        if not isinstance(images, list) or not isinstance(shas, list) or len(images) != len(actions) or len(shas) != len(actions):
            raise ValueError(f"{task}: complete before-action image/action/SHA lengths differ")
        source = row.get("source_shas")
        if not isinstance(source, dict) or any(key not in source for key in SOURCE_KEYS):
            raise ValueError(f"{task}: incomplete source_shas")
        for key in SOURCE_KEYS:
            _valid_sha(source[key], f"{task}/source_shas/{key}")
        if source["annotation"] != self.source_annotation_sha256 or source["config"] != self.source_config_sha256:
            raise ValueError(f"{task}: episode source disagrees with cache source")
        for relative, sha in zip(images, shas):
            _relative_file(self.root, relative)
            _valid_sha(sha, f"{task}/image_sha256")
        if official is not None:
            reference = official.get(task)
            if reference is None or reference.split != self.split:
                raise ValueError(f"{task}: not part of the supplied official split")
            if text != reference.instruction or tuple(actions) != reference.actions or source != reference.source_shas:
                raise ValueError(f"{task}: instruction/actions/source disagree with official segment")

    def __len__(self):
        return len(self.episodes)

    def _read_image(self, row, index):
        import io
        import numpy as np
        from PIL import Image

        path = _relative_file(self.root, row["images"][index])
        data = path.read_bytes()
        if hashlib.sha256(data).hexdigest() != row["image_sha256"][index]:
            raise ValueError(f"Cached image SHA256 mismatch: {path}")
        with Image.open(io.BytesIO(data)) as image:
            if image.mode != "RGB" or image.size != (128, 128):
                raise ValueError(f"Expected native RGB128 image: {path}, got {image.mode}/{image.size}")
            pixels = np.asarray(image, dtype=np.float32).copy()
        if pixels.shape != (128, 128, 3) or not np.isfinite(pixels).all():
            raise ValueError(f"Invalid RGB pixels: {path}")
        self._checked_images.add(row["images"][index])
        return np.moveaxis(pixels / 255.0, -1, 0)

    def iter_chunks(self, chunk_size, history_frames=8, episode_ids=None):
        """Yield full episodes in order; state reset/detach is the caller's duty.

        Current/future teacher actions never enter history. A chunk's first
        state retains only earlier executed actions from its own episode.
        """
        import numpy as np

        if type(chunk_size) is not int or chunk_size < 1 or type(history_frames) is not int or history_frames < 0:
            raise ValueError("chunk_size must be positive and history_frames nonnegative")
        rows = self.episodes if episode_ids is None else [self.by_task_id[key] for key in episode_ids]
        if len({row["task_id"] for row in rows}) != len(rows):
            raise ValueError("An episode may occur only once in a chunk traversal")
        for row in rows:
            actions = np.asarray(row["actions"], dtype=np.int64)
            encoded = np.asarray(self.vocabulary.encode(row["instruction"]), dtype=np.int64)
            for start in range(0, len(actions), chunk_size):
                stop = min(start + chunk_size, len(actions))
                length = stop - start
                history = np.zeros((length, history_frames, 4), dtype=np.float32)
                history_length = np.minimum(np.arange(start, stop), history_frames).astype(np.int64)
                if history_frames:
                    for offset, step in enumerate(range(start, stop)):
                        past = actions[max(0, step - history_frames):step]
                        if len(past):
                            history[offset, history_frames - len(past) + np.arange(len(past)), past] = 1.0
                tokens = np.broadcast_to(encoded, (length, len(encoded))).copy()
                yield {"image": np.stack([self._read_image(row, index) for index in range(start, stop)]),
                       "tokens": tokens, "token_mask": tokens != 0, "actions": actions[start:stop].copy(),
                       "history": history, "history_length": history_length,
                       "task_id": row["task_id"], "split": self.split, "instruction": row["instruction"],
                       "episode_start": start == 0, "episode_end": stop == len(actions),
                       "start_index": start, "stop_index": stop, "episode_length": len(actions)}
