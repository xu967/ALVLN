"""LANI-only behavior cloning; never loads an Aerial checkpoint."""

import csv
import hashlib
import json
from pathlib import Path
import random
import time


def prepare_batch(chunk, model, device):
    import torch
    import torch.nn.functional as F
    keys = ("image", "tokens", "token_mask", "history", "history_length", "actions")
    batch = {key: torch.as_tensor(chunk[key], device=device) for key in keys}
    if model.architecture == "lani_dino_recurrent_v1":
        image = F.interpolate(batch["image"], size=(224, 224), mode="bilinear", align_corners=False)
        mean = image.new_tensor([.485, .456, .406]).view(1, 3, 1, 1)
        std = image.new_tensor([.229, .224, .225]).view(1, 3, 1, 1)
        batch["image"] = (image - mean) / std
    return batch


def detach_state(state):
    if isinstance(state, tuple):
        return tuple(detach_state(x) for x in state)
    return state.detach() if hasattr(state, "detach") else state


def fit_lani(**config):
    import numpy as np
    import torch
    import matplotlib
    matplotlib.use("Agg")
    import matplotlib.pyplot as plt
    import yaml
    from tqdm import tqdm
    from .data import load_official_dataset, build_train_vocabulary, LaniTeacherCache
    from .model import build_model

    if config["seed"] != 0 or config["device"] != "cuda" or not torch.cuda.is_available():
        raise ValueError("LANI training requires registered seed0 and an available explicit CUDA device")
    if min(config["epochs"], config["sequence_chunk_size"]) < 1 or config["lr"] <= 0:
        raise ValueError("epochs, chunk size and learning rate must be positive")
    random.seed(0)
    np.random.seed(0)
    torch.manual_seed(0)
    torch.cuda.manual_seed_all(0)
    torch.cuda.set_per_process_memory_fraction(.25)
    torch.set_num_threads(2)
    torch.backends.cuda.matmul.allow_tf32 = False
    torch.backends.cudnn.allow_tf32 = False
    official = load_official_dataset(config["annotation_root"])
    full = config.get("require_full_train", True)
    if not full and "diagnostic" not in config["name"]:
        raise ValueError("Partial-cache runs require an explicit diagnostic name")
    vocab = build_train_vocabulary(official.splits["train"])
    caches = {split: LaniTeacherCache(config[key], vocab, split=split, official_dataset=official, require_complete=full)
              for split, key in (("train", "cache_manifest"), ("dev", "validation_cache_manifest"))}
    for split, cache in caches.items():
        actual = {episode["task_id"] for episode in cache.episodes}
        expected = {episode.task_id for episode in official.splits[split]}
        if full and actual != expected:
            raise ValueError(f"Full {split} coverage required, missing={len(expected-actual)}, extra={len(actual-expected)}")
    if any(item["route_identity"]["overlapping_identities"] or item["scene_identity"]["overlapping_identities"]
           for item in official.overlap_audit["comparisons"].values()):
        raise ValueError("Official source identity overlap needs explicit audit before training")
    run = Path(config["project"]) / config["name"]
    if run.exists():
        raise FileExistsError(f"New independent run required: {run}")
    model = build_model(config, len(vocab), pretrained=True).to("cuda")
    run.mkdir(parents=True)
    (run / "weights").mkdir()
    (run / "hparams.json").write_text(json.dumps(config, indent=2), encoding="utf-8")
    (run / "hparams.yaml").write_text(yaml.safe_dump(config, allow_unicode=True), encoding="utf-8")
    frozen = {"protocol": "lani_bc_full_seed0_v1" if full else "lani_bc_integration_seed0_v1", "seed": 0, "vocabulary": vocab.to_dict(),
              "checkpoint_selection": "unweighted full-dev teacher CE, not navigation best",
              "loss": "unweighted transition CE, one optimizer update per contiguous chunk",
              "history": "only previously executed four-action labels; reset per segment",
              "test_used_for_selection": False, "source_manifest": model.source_manifest,
              "cache_sha256": {split: hashlib.sha256(Path(config[key]).read_bytes()).hexdigest()
                               for split, key in (("train", "cache_manifest"), ("dev", "validation_cache_manifest"))}}
    (run / "task_config.json").write_text(json.dumps(frozen, indent=2), encoding="utf-8")
    source_dir = run / "source_snapshot"
    source_dir.mkdir()
    for path in [Path(__file__), Path(__file__).with_name("data.py"), Path(__file__).with_name("model.py"),
                 Path(__file__).parents[2] / "train.py"]:
        (source_dir / path.name).write_bytes(path.read_bytes())
    optimizer = torch.optim.AdamW((p for p in model.parameters() if p.requires_grad), lr=config["lr"], weight_decay=.01)
    scheduler = torch.optim.lr_scheduler.CosineAnnealingLR(optimizer, T_max=config["epochs"])
    best, updates, started = float("inf"), 0, time.monotonic()
    torch.cuda.reset_peak_memory_stats()
    fields = ["epoch", "train_ce", "dev_ce", "dev_accuracy", "dev_stop_recall", "dev_macro_recall", "updates", "lr", "elapsed_seconds"]
    with (run / "results.csv").open("x", newline="") as stream:
        writer = csv.DictWriter(stream, fieldnames=fields)
        writer.writeheader()
        for epoch in range(config["epochs"]):
            row = {"epoch": epoch + 1}
            for split, cache in caches.items():
                model.train(split == "train")
                loss_sum = count = correct = stop_count = stop_correct = 0
                confusion = torch.zeros((4,4),dtype=torch.long,device="cuda")
                state, previous_task = None, None
                context = torch.enable_grad() if split == "train" else torch.no_grad()
                with context:
                    for chunk in tqdm(cache.iter_chunks(config["sequence_chunk_size"], history_frames=8), desc=f"{epoch+1} {split}"):
                        if chunk["task_id"] != previous_task:
                            state = None
                            previous_task = chunk["task_id"]
                        batch = prepare_batch(chunk, model, "cuda")
                        policy_batch = {key: value for key, value in batch.items() if key != "actions"}
                        logits, state = model.forward_sequence(policy_batch, state)
                        loss = torch.nn.functional.cross_entropy(logits, batch["actions"])
                        if not torch.isfinite(loss):
                            raise FloatingPointError(f"Nonfinite {split} loss")
                        if split == "train":
                            optimizer.zero_grad(set_to_none=True)
                            loss.backward()
                            torch.nn.utils.clip_grad_norm_(model.parameters(), 1., error_if_nonfinite=True)
                            optimizer.step()
                            updates += 1
                        state = detach_state(state)
                        n = len(logits)
                        loss_sum += loss.item() * n
                        count += n
                        predicted = logits.argmax(-1)
                        correct += (predicted == batch["actions"]).sum().item()
                        stops = batch["actions"] == 3
                        stop_count += stops.sum().item()
                        stop_correct += ((predicted == 3) & stops).sum().item()
                        confusion += torch.bincount(4*batch["actions"]+predicted,minlength=16).reshape(4,4)
                row[split + "_ce"] = loss_sum / count
                if split == "dev":
                    recall = confusion.diag().float()/confusion.sum(1).clamp_min(1)
                    row.update(dev_accuracy=correct/count, dev_stop_recall=stop_correct/stop_count,
                               dev_macro_recall=recall.mean().item())
                    (run/"dev_action_confusion.json").write_text(json.dumps({"epoch":epoch+1,"confusion":confusion.tolist(),
                              "recall":recall.tolist(),"action_names":["Forward","TurnRight","TurnLeft","Stop"]},indent=2))
            row.update(updates=updates, lr=optimizer.param_groups[0]["lr"], elapsed_seconds=time.monotonic()-started)
            scheduler.step()
            writer.writerow(row)
            stream.flush()
            with (run / "results.csv").open(newline="") as source:
                curve = list(csv.DictReader(source))
            fig, ax = plt.subplots(figsize=(6,4))
            for split in ("train", "dev"):
                ax.plot([int(r["epoch"]) for r in curve], [float(r[split+"_ce"]) for r in curve], label=split)
            ax.set(xlabel="Epoch", ylabel="Unweighted teacher cross entropy")
            ax.legend()
            fig.tight_layout()
            fig.savefig(run / "results.png", dpi=140)
            plt.close(fig)
            checkpoint = {"format": "lani_checkpoint_v1", "config": config, "contract": frozen,
                          "epoch": epoch+1, "model": model.state_dict(), "optimizer": optimizer.state_dict(),
                          "scheduler": scheduler.state_dict(), "metrics": row}
            for target in (["last.pt", "best.pt"] if row["dev_ce"] < best else ["last.pt"]):
                temporary = run / "weights" / (target + ".pending")
                torch.save(checkpoint, temporary)
                temporary.replace(run / "weights" / target)
            best = min(best, row["dev_ce"])
            print(json.dumps(row), flush=True)
    metrics = {"scope": "full teacher train/dev, navigation unmeasured" if full else "partial integration, navigation unmeasured", "NE": None, "SR": None, "OSR": None,
               "nDTW": None, "sDTW": None, "SPL": None, "seed": 0,
               "peak_allocated_bytes": torch.cuda.max_memory_allocated(), "peak_reserved_bytes": torch.cuda.max_memory_reserved()}
    (run / "metrics.json").write_text(json.dumps(metrics, indent=2), encoding="utf-8")
    return run
