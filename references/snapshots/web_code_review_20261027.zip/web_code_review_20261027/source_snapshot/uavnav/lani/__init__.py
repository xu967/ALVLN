"""Independent LANI four-action data and training components."""
