"""LANI four-action policies; checkpoints never share AerialVLN semantics.

Images are prepared by the caller: GA uses the original 128 RGB input and
DINO uses the registered 224 preprocessing of that same observation.
"""

import hashlib
import importlib.util
from pathlib import Path
from types import SimpleNamespace

import torch
from torch import nn
from torch.nn import functional as F

from uavnav.avln.model import AerialDinoRouteNet


ACTION_NAMES = ("Forward", "TurnRight", "TurnLeft", "Stop")
ARCHITECTURES = ("lani_dino_recurrent_v1", "lani_ga_lstm_v1")
DINOV3_WEIGHTS_SHA256 = "08c60483bc63c04f533611e34bf70b120eedb7240f469bc16e9e20bf344b941d"
_GA_SOURCES = {}


def _sha(path):
    return hashlib.sha256(Path(path).read_bytes()).hexdigest()


def detach_state(state):
    """Detach a chunk boundary without changing the legal past-step count."""
    if isinstance(state, torch.Tensor):
        return state.detach()
    if isinstance(state, tuple):
        return tuple(detach_state(value) for value in state)
    return state


def _check_batch(batch, size, history_frames, vocab_size, sequence):
    required = {"image", "tokens", "token_mask", "history", "history_length"}
    if set(batch) != required:
        raise ValueError(f"LANI policy accepts only {sorted(required)}; labels/metadata stay outside")
    image, tokens, mask = batch["image"], batch["tokens"], batch["token_mask"]
    history, length = batch["history"], batch["history_length"]
    count = len(image)
    if image.shape != (count, 3, size, size) or count < 1 or (not sequence and count != 1):
        raise ValueError("LANI expects one nonempty episode sequence or one current observation")
    if not torch.isfinite(image).all():
        raise ValueError("LANI RGB must be finite")
    if (tokens.ndim != 2 or tokens.shape[0] != count or tokens.shape != mask.shape
            or tokens.dtype != torch.long or mask.dtype != torch.bool
            or not mask.any(dim=1).all() or tokens.min() < 0 or tokens.max() >= vocab_size):
        raise ValueError("Invalid LANI tokens/mask or vocabulary index")
    if not torch.equal(mask, tokens != 0):
        raise ValueError("LANI padding ID is 0 and must agree with token_mask")
    if count > 1 and (not torch.equal(tokens, tokens[:1].expand_as(tokens))
                      or not torch.equal(mask, mask[:1].expand_as(mask))):
        raise ValueError("A sequence must contain one fixed complete segment instruction")
    if history.shape != (count, history_frames, 4) or length.shape != (count,):
        raise ValueError("LANI history must have four-action one-hot entries")
    if (not torch.isfinite(history).all() or not torch.isfinite(length).all()
            or ((length < 0) | (length > history_frames) | (length != length.long())).any()
            or ((history != 0) & (history != 1)).any() or history[..., 3].any()):
        raise ValueError("History contains invalid actions, lengths, or a past terminal STOP")
    expected = torch.arange(history_frames, device=length.device)[None, :] >= history_frames - length[:, None]
    if not torch.equal(history.sum(-1), expected.to(history.dtype)):
        raise ValueError("History must be left-padded and contain only executed past actions")


class _LaniCheckpoint:
    def get_extra_state(self):
        return {"architecture": self.architecture, "action_names": list(ACTION_NAMES),
                "model_contract_version": "lani_four_action_model_v1",
                "source_manifest": dict(self.source_manifest)}

    def set_extra_state(self, state):
        if (not isinstance(state, dict) or state.get("architecture") != self.architecture
                or state.get("action_names") != list(ACTION_NAMES)
                or state.get("model_contract_version") != "lani_four_action_model_v1"):
            raise ValueError("Not a compatible LANI four-action checkpoint")
        saved = state.get("source_manifest")
        if not isinstance(saved, dict) or set(saved) != set(self.source_manifest):
            raise ValueError("LANI checkpoint lacks its exact source manifest")
        for key, value in self.source_manifest.items():
            if key == "dino_weights_sha256" and value is None:
                if saved[key] != DINOV3_WEIGHTS_SHA256:
                    raise ValueError("LANI DINO checkpoint lacks pretrained weight provenance")
            elif saved[key] != value:
                raise ValueError(f"LANI checkpoint source mismatch: {key}")
        self.source_manifest = dict(saved)
        if hasattr(self, "visual_encoder"):
            self.visual_encoder["weights_sha256"] = saved["dino_weights_sha256"]
            self.vision.weights_sha256 = saved["dino_weights_sha256"]
            self._lani_ready = True

    def load_state_dict(self, state_dict, strict=True, assign=False):
        if not strict:
            raise ValueError("LANI checkpoints require strict loading and explicit architecture metadata")
        return super().load_state_dict(state_dict, strict=True, assign=assign)

    def forward(self, *args, **kwargs):
        raise ValueError("Use forward_step or forward_sequence and reset state for each task")


class LaniDinoRouteNet(_LaniCheckpoint, AerialDinoRouteNet):
    """Existing frozen DINO/region/text/GRU components with a LANI action head."""

    def __init__(self, vocab_size, config, pretrained):
        weights = config.get("dino_weights")
        if pretrained and (not weights or not Path(weights).is_file()):
            raise FileNotFoundError("First LANI DINO training requires the real pretrained weights")
        super().__init__(vocab_size, dino_repo=config["dino_repo"], dino_variant="vits16",
                         dino_input_size=224, dino_frozen=True,
                         dino_weights=weights if pretrained else None,
                         history_frames=config.get("history_frames", 8), hidden=128,
                         pretrained=False, memory_mode="carry", text_query_mode="visual_history",
                         visual_fusion="spatial", fusion_mode="query_plus_text", stop_enabled=True)
        self.architecture = "lani_dino_recurrent_v1"
        self.vocab_size = vocab_size
        self.history_proj = nn.Linear(self.history_frames * 4 + 1, 128)
        self.head = nn.Linear(128, 4)
        if pretrained and self.vision.weights_sha256 != DINOV3_WEIGHTS_SHA256:
            raise ValueError("LANI v1 requires the frozen official ViT-S/16 LVD-1689M weights")
        self._lani_ready = pretrained
        self.source_manifest = {"adapter_sha256": _sha(__file__),
                                "aerial_components_sha256": _sha(Path(__file__).parents[1] / "avln/model.py"),
                                "dino_source_sha256": self.vision.repo_source_sha256,
                                "dino_weights_sha256": self.vision.weights_sha256}

    def forward_sequence(self, batch, state=None):
        if not self._lani_ready:
            raise ValueError("Reload-only DINO construction needs a strict LANI checkpoint before inference")
        _check_batch(batch, 224, self.history_frames, self.vocab_size, True)
        return super().forward_sequence(batch, state)

    def forward_step(self, batch, state=None):
        if not self._lani_ready:
            raise ValueError("Reload-only DINO construction needs a strict LANI checkpoint before inference")
        _check_batch(batch, 224, self.history_frames, self.vocab_size, False)
        return super().forward_step(batch, state)

    def forward_sequence_batch(self, *args, **kwargs):
        raise ValueError("LANI v1 accepts exactly one contiguous task, never Aerial episode batching")


def _ga_class(upstream_root):
    source = Path(upstream_root).resolve() / "src/baselines/chaplot_model_default.py"
    if not source.is_file():
        raise FileNotFoundError(f"Missing frozen CIFF GA-LSTM source: {source}")
    digest = _sha(source)
    if digest not in _GA_SOURCES:
        spec = importlib.util.spec_from_file_location("lani_frozen_ga_" + digest, source)
        module = importlib.util.module_from_spec(spec)
        spec.loader.exec_module(module)

        class CompatibleGA(module.a3c_lstm_ga_default):
            # Identical upstream modules/parameter names; modern device/GRU shapes only.
            def forward(self, inputs, cached_computation=None):
                image, tokens, (time, hx, cx) = inputs
                visual = F.relu(self.conv3(F.relu(self.conv2(F.relu(self.conv1(image))))))
                if cached_computation is None:
                    hidden = image.new_zeros((1, 1, self.gru_hidden_size))
                    for token in tokens[0]:
                        _, hidden = self.gru(self.embedding(token).view(1, 1, -1), hidden)
                    attention = torch.sigmoid(self.attn_linear(hidden.view(1, -1)))
                    attention = attention[:, :, None, None].expand_as(visual)
                    cached_computation = {"x_attention": attention}
                attention = cached_computation["x_attention"]
                if visual.shape != attention.shape:
                    raise ValueError("GA-LSTM attention and visual features disagree")
                fused = F.relu(self.linear((visual * attention).flatten(1)))
                hx, cx = self.lstm(fused, (hx, cx))
                output = torch.cat((hx, self.time_emb_layer(time).view(1, -1)), dim=1)
                return self.critic_linear(output), self.actor_linear(output), (hx, cx), cached_computation

        _GA_SOURCES[digest] = CompatibleGA
    return _GA_SOURCES[digest], digest


class LaniGALSTM(_LaniCheckpoint, nn.Module):
    """Direct subclass of the frozen CIFF GA-LSTM with its original 128 CNN."""

    def __init__(self, vocab_size, config):
        super().__init__()
        original, source_sha = _ga_class(config["upstream_root"])
        self.architecture = "lani_ga_lstm_v1"
        self.vocab_size = vocab_size
        self.history_frames = config.get("history_frames", 8)
        self.max_episode_length = config.get("max_episode_length", 512)
        if type(self.max_episode_length) is not int or self.max_episode_length < 199:
            raise ValueError("GA time capacity must cover all 199 official training states")
        self.network = original(SimpleNamespace(input_size=vocab_size,
                                               max_episode_length=self.max_episode_length),
                                config=None, final_image_height=6, final_image_width=6)
        self.source_manifest = {"adapter_sha256": _sha(__file__), "ga_upstream_sha256": source_sha}

    def forward_sequence(self, batch, state=None):
        _check_batch(batch, 128, self.history_frames, self.vocab_size, True)
        if state is None:
            hx = batch["image"].new_zeros((1, 256))
            cx, step = torch.zeros_like(hx), 1
        else:
            if not isinstance(state, tuple) or len(state) != 3:
                raise ValueError("GA state must be (hidden, cell, next_past_step_count)")
            hx, cx, step = state
            if (hx.shape != (1, 256) or cx.shape != (1, 256)
                    or not torch.isfinite(hx).all() or not torch.isfinite(cx).all()
                    or type(step) is not int or step < 1):
                raise ValueError("Invalid GA recurrent state")
        outputs, cache = [], None
        for index, image in enumerate(batch["image"]):
            if step >= self.network.time_emb_layer.num_embeddings:
                raise ValueError("GA legal past-step counter exceeds its registered time capacity")
            tokens = batch["tokens"][index][batch["token_mask"][index]].unsqueeze(0)
            time = torch.tensor([step], dtype=torch.long, device=image.device)
            _, logits, (hx, cx), cache = self.network((image.unsqueeze(0), tokens, (time, hx, cx)), cache)
            outputs.append(logits)
            step += 1
        return torch.cat(outputs), (hx, cx, step)

    def forward_step(self, batch, state=None):
        _check_batch(batch, 128, self.history_frames, self.vocab_size, False)
        return self.forward_sequence(batch, state)


def build_model(config, vocab_size, pretrained=True):
    """Build an explicit LANI model; pretrained=False is only for strict reload."""
    architecture = config.get("architecture")
    if architecture not in ARCHITECTURES:
        raise ValueError(f"LANI architecture must be one of {ARCHITECTURES}")
    if type(vocab_size) is not int or vocab_size < 2:
        raise ValueError("LANI vocabulary includes PAD=0 and UNK=1")
    if type(pretrained) is not bool or type(config.get("history_frames", 8)) is not int or config.get("history_frames", 8) < 1:
        raise ValueError("Invalid pretrained/history_frames setting")
    if config.get("action_names", list(ACTION_NAMES)) != list(ACTION_NAMES):
        raise ValueError("LANI action ordering must be Forward/TurnRight/TurnLeft/Stop")
    if config.get("num_actions", 4) != 4 or config.get("hidden", 128) != 128:
        raise ValueError("LANI v1 fixes four actions and student hidden=128")
    if config.get("memory_mode", "carry") != "carry":
        raise ValueError("LANI v1 requires causal carried task memory")
    if architecture == "lani_dino_recurrent_v1":
        if (config.get("imgsz", 224) != 224 or config.get("dino_variant", "vits16") != "vits16"
                or config.get("dino_frozen", True) is not True):
            raise ValueError("LANI student fixes frozen DINOv3 ViT-S/16 at 224")
        return LaniDinoRouteNet(vocab_size, config, pretrained)
    if config.get("imgsz", 128) != 128:
        raise ValueError("The original GA-LSTM CNN requires raw 128 RGB")
    return LaniGALSTM(vocab_size, config)
