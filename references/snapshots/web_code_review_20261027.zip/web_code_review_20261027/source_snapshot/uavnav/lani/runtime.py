"""Real official Unity collection and autonomous LANI evaluation."""

from contextlib import contextmanager
import hashlib
import json
import math
import os
from pathlib import Path
import random
import shutil
import socket
import subprocess
import sys
import time


def write_json(path, value):
    pending = path.with_suffix(path.suffix + ".pending")
    pending.write_text(json.dumps(value, indent=2, allow_nan=False) + "\n", encoding="utf-8")
    with pending.open("rb") as stream:
        os.fsync(stream.fileno())
    pending.replace(path)


def source_point(episode, vocabulary):
    from dataset_agreement_nav_drone.nav_drone_datapoint import NavDroneDataPoint
    tokens = [vocabulary.get(word, len(vocabulary)) for word in episode.instruction.split()]
    return NavDroneDataPoint(instruction=tokens, scene_name=episode.task_id,
                            trajectory=list(episode.movement_actions), sub_trajectory_list=[list(episode.movement_actions)],
                            scene_config=json.dumps(episode.scene_config), scene_path=json.dumps(episode.scene_path),
                            start_pos=episode.start_pos, start_pos_list=[episode.start_pos],
                            destination_list=[episode.goal_xz], paragraph_instruction=tokens,
                            instruction_auto_segmented=[tokens], instruction_oracle_segmented=[tokens],
                            instruction_indices=(0, len(tokens)))


@contextmanager
def real_server(args):
    sys.path.insert(0, str(args.upstream_root.resolve() / "src"))
    from dataset_agreement_nav_drone.action_space import ActionSpace
    from server_nav_drone.nav_drone_server_py3 import NavDroneServerPy3
    from dataset_agreement_nav_drone.nav_drone_dataset_parser import make_vocab_map
    config = json.loads((args.asset_root / "data/nav_drone/config_localmoves_6000.json").read_text())
    config["vocab_file"] = str(args.asset_root.resolve() / "data/nav_drone/vocab_6000.txt")
    config["resources_dir"] = str(args.asset_root.resolve() / "data/nav_drone/resources")
    with socket.socket() as probe:
        probe.bind(("127.0.0.1", 0))
        config.update(hostname="127.0.0.1", port=probe.getsockname()[1])
    server = NavDroneServerPy3(config, ActionSpace(config["action_names"], "Stop"))
    server.lani_official_vocab = make_vocab_map(config["vocab_file"])
    attempt = 1
    while (args.output / f"runtime_attempt_{attempt}").exists():
        attempt += 1
    runtime = args.output / f"runtime_attempt_{attempt}"
    runtime.mkdir()
    command = [str(args.asset_root.resolve() / "simulators/nav_drone/NavDroneLinuxBuild.x86_64"),
               "--height", "128", "--width", "128", "--goalmarker", "hide", "--rewardshaping", "goal",
               "--port", str(config["port"]), "-logFile", str(runtime / "unity.log")]
    env = os.environ.copy()
    for key, relative in (("XDG_CONFIG_HOME", "runtime_config"), ("XDG_CACHE_HOME", "runtime_cache"),
                          ("MESA_SHADER_CACHE_DIR", "runtime_cache/mesa")):
        target = runtime / relative
        target.mkdir(parents=True, exist_ok=True)
        env[key] = str(target)
    unity = None
    try:
        with (runtime / "unity_stdout.log").open("xb") as stream:
            unity = subprocess.Popen(command, cwd=args.asset_root, env=env, stdout=stream, stderr=subprocess.STDOUT)
        write_json(runtime / "environment.json", {"command": command, "pid": unity.pid,
                   "display": env.get("DISPLAY"), "software_rendering": env.get("LIBGL_ALWAYS_SOFTWARE"),
                   "goal_marker": "hide", "native_size": [128, 128]})
        yield server
    finally:
        if unity is not None and unity.poll() is None:
            unity.terminate()
            try:
                unity.wait(timeout=10)
            except subprocess.TimeoutExpired:
                unity.kill()
                unity.wait(timeout=10)
        server.kill()
        server.p.join(timeout=10)


def image_array(image):
    import numpy as np
    pixels = np.asarray(image)
    if pixels.shape != (3, 128, 128) or not np.isfinite(pixels).all() or pixels.min() < 0 or pixels.max() > 1.00001:
        raise ValueError("Official Unity must return finite CHW128 RGB in [0,1]")
    return np.clip(np.moveaxis(pixels, 0, -1) * 255, 0, 255).round().astype(np.uint8)


def collect(args):
    from PIL import Image
    from .data import load_official_dataset, build_train_vocabulary, LaniTeacherCache
    dataset = load_official_dataset(args.asset_root)
    vocab = build_train_vocabulary(dataset.splits["train"])
    selected = dataset.splits[args.split]
    if args.limit:
        selected = selected[:args.limit]
    session = args.output / "collection_contract.json"
    contract = {"protocol": "lani_teacher_cache_v1", "split": args.split, "native_size": [128, 128],
                "task_ids": [e.task_id for e in selected], "source_annotation_sha256": dataset.sources["annotations"][args.split]["sha256"],
                "source_config_sha256": dataset.sources["config_sha256"], "vocabulary": vocab.to_dict(),
                "scope": "full official split" if not args.limit else "bounded integration only",
                "goal_marker": "hide", "seed": 0, "endpoint_gate": "strict XZ distance < 5",
                "runtime_sha256": hashlib.sha256(Path(__file__).read_bytes()).hexdigest(),
                "reader_sha256": hashlib.sha256(Path(__file__).with_name("data.py").read_bytes()).hexdigest(),
                "upstream_sha256": {p.relative_to(args.upstream_root).as_posix():hashlib.sha256(p.read_bytes()).hexdigest()
                                    for p in sorted(args.upstream_root.rglob("*.py"))}}
    if session.exists():
        if json.loads(session.read_text()) != contract:
            raise ValueError("Resume source/selection contract changed")
    else:
        write_json(session, contract)
    records, started = [], time.monotonic()
    with real_server(args) as server:
        for index, episode in enumerate(selected):
            destination = args.output / "episodes" / episode.task_id
            sealed = destination / "episode.json"
            if sealed.exists():
                row = json.loads(sealed.read_text())
                if (row["source_shas"] != episode.source_shas or row["actions"] != list(episode.actions)
                        or row["instruction"] != episode.instruction or row["split"] != args.split
                        or not len(row["images"]) == len(row["image_sha256"]) == len(episode.actions)):
                    raise ValueError("Sealed collection source changed")
                for path, sha in zip(row["images"], row["image_sha256"]):
                    if hashlib.sha256((args.output / path).read_bytes()).hexdigest() != sha:
                        raise ValueError("Sealed image changed")
                records.append(row)
                continue
            if shutil.disk_usage(args.output).free < args.min_free_bytes:
                raise OSError("Collection stopped before exhausting registered disk reserve")
            destination.mkdir(parents=True, exist_ok=True)
            attempt = 1
            while (destination / f"attempt_{attempt}").exists():
                attempt += 1
            attempt_dir = destination / f"attempt_{attempt}"
            attempt_dir.mkdir()
            image, metadata = server.reset_receive_feedback(source_point(episode, server.lani_official_vocab))
            images, shas, poses = [], [], []
            for step, action in enumerate(episode.actions):
                rgb = image_array(image)
                frame = attempt_dir / f"{step:04d}.png"
                Image.fromarray(rgb).save(frame, compress_level=3)
                with frame.open("rb") as stream:
                    os.fsync(stream.fileno())
                content = frame.read_bytes()
                images.append(frame.relative_to(args.output).as_posix())
                shas.append(hashlib.sha256(content).hexdigest())
                poses.append([float(metadata[k]) for k in ("x_pos", "z_pos", "y_angle")])
                if action == 3:
                    _, _, metadata = server.halt_and_receive_feedback()
                else:
                    image, _, metadata = server.send_action_receive_feedback(action)
            sd = float(metadata["stop_dist_error"])
            row = {"task_id": episode.task_id, "split": args.split, "instruction": episode.instruction,
                   "actions": list(episode.actions), "images": images, "image_sha256": shas,
                   "native_size": [128, 128], "source_shas": episode.source_shas, "poses_xzyaw": poses,
                   "teacher_endpoint_SD": sd, "attempt": attempt,
                   "halt_position_xz": [float(metadata["x_pos"]),float(metadata["z_pos"])]}
            write_json(attempt_dir / "replay.json", row)
            if not math.isfinite(sd) or sd >= 5:
                raise ValueError(f"Teacher endpoint gate failed: {episode.task_id} SD={sd}; evidence retained")
            write_json(sealed, row)
            records.append(row)
            write_json(args.output / "status.json", {"status": "collecting", "completed": len(records),
                       "expected": len(selected), "last_task": episode.task_id, "elapsed_seconds": time.monotonic()-started,
                       "frames": sum(len(x["actions"]) for x in records)})
            if index % 10 == 0:
                print(f"{args.split}: {len(records)}/{len(selected)} complete episodes", flush=True)
    manifest = {key: contract[key] for key in ("protocol", "split", "native_size", "source_annotation_sha256", "source_config_sha256")}
    manifest.update(episodes=records, scope=contract["scope"])
    candidate = args.output / "manifest.pending.json"
    write_json(candidate, manifest)
    cache = LaniTeacherCache(candidate, vocab, official_dataset=dataset,
                             require_complete=not args.limit, verify_images=True)
    candidate.replace(args.output / "manifest.json")
    write_json(args.output / "status.json", {"status": "complete", "completed": len(records), "expected": len(selected),
               "coverage": cache.coverage, "elapsed_seconds": time.monotonic()-started})


def evaluate(args):
    import numpy as np
    import torch
    from .data import load_official_dataset, LANIVocabulary, build_train_vocabulary, LaniTeacherCache
    from .model import build_model
    from .fit import prepare_batch
    from scripts.verify_lani import ndtw
    dataset = load_official_dataset(args.asset_root)
    checkpoint = torch.load(args.checkpoint, map_location="cpu", weights_only=True) if args.policy == "model" else None
    if checkpoint is not None and checkpoint.get("format") != "lani_checkpoint_v1":
        raise ValueError("Only explicit LANI checkpoints are accepted")
    config = checkpoint["config"] if checkpoint else None
    vocab = (LANIVocabulary.from_dict(checkpoint["contract"]["vocabulary"]) if checkpoint
             else build_train_vocabulary(dataset.splits["train"]))
    if vocab.to_dict() != build_train_vocabulary(dataset.splits["train"]).to_dict():
        raise ValueError("Checkpoint training vocabulary/source differs")
    references = LaniTeacherCache(args.reference_manifest, vocab, split=args.split, official_dataset=dataset,
                                  require_complete=not args.limit)
    model = None
    if checkpoint:
        if args.device == "cuda" and not torch.cuda.is_available():
            raise RuntimeError("Requested CUDA is unavailable; no CPU fallback")
        if args.device == "cuda":
            torch.cuda.set_per_process_memory_fraction(.25)
            torch.backends.cuda.matmul.allow_tf32 = False
            torch.backends.cudnn.allow_tf32 = False
        model = build_model(config, len(vocab), pretrained=False).to(args.device)
        model.load_state_dict(checkpoint["model"], strict=True)
        model.eval()
        if args.device == "cuda":
            torch.cuda.reset_peak_memory_stats()
    selected = dataset.splits[args.split]
    if args.limit:
        selected = selected[:args.limit]
    contract = {"protocol": "lani_autonomous_eval_v1", "split": args.split, "max_movement_steps": 40,
                "checkpoint_sha256": hashlib.sha256(args.checkpoint.read_bytes()).hexdigest() if checkpoint else None,
                "policy": args.policy,
                "random_stream": "SHA256(seed0:task_id) per episode, independent of resume order",
                "reference_manifest_sha256": references.manifest_sha256, "seed": 0,
                "metrics": "native SD/SR plus project exact-XZ DTW, threshold5",
                "source": dataset.sources["annotations"][args.split], "task_ids": [e.task_id for e in selected],
                "scope": "full official split" if not args.limit else "bounded integration only"}
    path = args.output / "evaluation_contract.json"
    if path.exists() and json.loads(path.read_text()) != contract:
        raise ValueError("Frozen evaluation contract differs on resume")
    write_json(path, contract)
    results, latencies = [], []
    with real_server(args) as server, torch.inference_mode():
        for episode in selected:
            directory = args.output / "episodes" / episode.task_id
            sealed = directory / "result.json"
            if sealed.exists():
                results.append(json.loads(sealed.read_text()))
                continue
            directory.mkdir(parents=True, exist_ok=True)
            journal = directory / "journal.jsonl"
            if journal.exists():
                raise ValueError(f"Unsealed evaluation attempt requires audit; refusing an automatic policy rerun: {episode.task_id}")
            rng = random.Random(int(hashlib.sha256(("0:"+episode.task_id).encode()).hexdigest()[:16],16))
            image, metadata = server.reset_receive_feedback(source_point(episode, server.lani_official_vocab))
            state, actions, positions, task_latency = None, [], [], []
            for step in range(41):
                positions.append([float(metadata["x_pos"]), float(metadata["z_pos"])])
                history = np.zeros((1, 8, 4), dtype=np.float32)
                past = actions[-8:]
                for i, action in enumerate(past):
                    history[0, 8-len(past)+i, action] = 1
                tokens = np.array([vocab.encode(episode.instruction)], dtype=np.int64)
                chunk = {"image": np.moveaxis(image_array(image).astype(np.float32)/255, -1, 0)[None],
                         "tokens": tokens, "token_mask": tokens != 0, "history": history,
                         "history_length": np.array([len(past)]), "actions": np.array([0])}
                if model is not None and args.device == "cuda":
                    torch.cuda.synchronize()
                started = time.perf_counter()
                if model is not None:
                    batch = prepare_batch(chunk, model, args.device)
                    logits, state = model.forward_step({k:v for k,v in batch.items() if k != "actions"}, state)
                    action = int(logits.argmax(-1).item())
                else:
                    action = {"stop": lambda: 3, "random": lambda: rng.randrange(4), "forward": lambda: 0}[args.policy]()
                if model is not None and args.device == "cuda":
                    torch.cuda.synchronize()
                task_latency.append((time.perf_counter()-started)*1000)
                with journal.open("a",encoding="utf-8") as stream:
                    stream.write(json.dumps({"step":step,"xz":positions[-1],"action":action,
                                             "budget_stop":step==40 and action!=3})+"\n")
                    stream.flush()
                if action == 3 or step == 40:
                    _, _, metadata = server.halt_and_receive_feedback()
                    termination = "policy_stop" if action == 3 else "budget_stop"
                    final = [float(metadata["x_pos"]), float(metadata["z_pos"])]
                    if math.dist(final, positions[-1]) > 1e-4:
                        positions.append(final)
                    break
                actions.append(action)
                image, _, metadata = server.send_action_receive_feedback(action)
            reference = references.by_task_id[episode.task_id]["poses_xzyaw"]
            reference = [p[:2] for p in reference]
            halt = references.by_task_id[episode.task_id].get("halt_position_xz",reference[-1])
            if math.dist(halt,reference[-1]) > 1e-4:
                reference.append(halt)
            sr = float(metadata["stop_dist_error"] < 5)
            score = ndtw(positions, reference)
            row = {"task_id": episode.task_id, "SD": float(metadata["stop_dist_error"]),
                   "NE": float(metadata["stop_dist_error"]), "SR": sr,
                   "OSR": float(min(math.dist(p, episode.goal_xz) for p in positions) < 5),
                   "MCD": float(metadata["closest_dist_error"]), "NED": float(metadata["edit_dist_error"]),
                   "nDTW": score, "sDTW": sr*score, "SPL": None, "termination": termination,
                   "autonomous_stop_success": sr*float(termination == "policy_stop"),
                   "actual_path_xz": positions, "actions": actions, "latency_ms": task_latency}
            write_json(sealed, row)
            results.append(row)
            latencies.extend(task_latency)
            write_json(args.output / "status.json", {"status":"evaluating", "completed":len(results), "expected":len(selected)})
    summary = {key: sum(row[key] for row in results)/len(results)
               for key in ("SD", "NE", "SR", "OSR", "MCD", "NED", "nDTW", "sDTW", "autonomous_stop_success")}
    all_latency = [x for row in results for x in row["latency_ms"]]
    summary.update(SPL=None, episodes=len(results), policy_stop_rate=sum(r["termination"]=="policy_stop" for r in results)/len(results),
                   latency_p50_ms=float(np.percentile(all_latency,50)), latency_p95_ms=float(np.percentile(all_latency,95)),
                   latency_scope="RGB resize/normalize, device transfer, recurrent forward and action selection; excludes simulation/network")
    summary.update(loaded_model_parameters=sum(p.numel() for p in model.parameters()) if model else None,
                   peak_allocated_bytes=torch.cuda.max_memory_allocated() if model and args.device=="cuda" else None,
                   peak_reserved_bytes=torch.cuda.max_memory_reserved() if model and args.device=="cuda" else None,
                   precision="fp32_tf32_disabled" if model else None, native_rgb_size=[128,128],
                   model_rgb_size=[config["imgsz"],config["imgsz"]] if model else None)
    write_json(args.output / "metrics.json", {"status":"complete", "contract":contract, "summary":summary})


def pipeline(args):
    """Run a preregistered full seed0 queue; every failing stage stops the queue."""
    spec = json.loads(args.pipeline_spec.read_text())
    code = Path(spec["code_root"])
    script = code / "scripts/verify_lani.py"
    if spec.get("seed") != 0 or spec.get("protocol") != "lani_full_comparison_queue_v1":
        raise ValueError("Unsupported full comparison queue")
    frozen = args.output / "pipeline_contract.json"
    if frozen.exists() and json.loads(frozen.read_text()) != spec:
        raise ValueError("Queue contract changed")
    write_json(frozen, spec)

    def check_sources():
        for relative, sha in spec["source_sha256"].items():
            if hashlib.sha256((code/relative).read_bytes()).hexdigest() != sha:
                raise ValueError(f"Queue source changed: {relative}")

    def execute(stage, command, env=None):
        check_sources()
        log = args.output / (stage + ".log")
        write_json(args.output / "status.json", {"status":"running", "stage":stage, "command":command,
                   "started_at_unix":time.time()})
        with log.open("ab") as stream:
            process = subprocess.Popen(command, cwd=code, env=env, stdout=stream, stderr=subprocess.STDOUT)
            write_json(args.output / (stage+"_launch.json"), {"pid":process.pid,"pgid":os.getpgid(process.pid),
                       "command":command, "started_at_unix":time.time(),"log":str(log)})
            result = process.wait(timeout=604800)
        if result:
            write_json(args.output / "status.json", {"status":"failed", "stage":stage, "exit_code":result, "log":str(log)})
            raise RuntimeError(f"Full queue stopped at {stage}; original failure is retained")

    base = [sys.executable,"-B",str(script),"--upstream-root",str(args.upstream_root),
            "--asset-root",str(args.asset_root),"--max-steps","40","--timeout","604800","--worker"]
    for split in ("train","dev","test"):
        output = Path(spec["cache_root"])/split
        if not (output/"manifest.json").exists():
            execute("collect_"+split, base+["--mode","collect","--split",split,"--output",str(output),"--resume"])
    for architecture in ("lani_ga_lstm_v1","lani_dino_recurrent_v1"):
        run_name = architecture+"_full_seed0_"+spec["run_tag"]
        run = Path(spec["train_project"])/run_name
        env = os.environ.copy()
        env.update(UAVNAV_DATASET="lani_v1",UAVNAV_ARCHITECTURE=architecture,UAVNAV_DEVICE="cuda",
                   UAVNAV_DATA_ROOT=str(args.asset_root),UAVNAV_CACHE_MANIFEST=str(Path(spec["cache_root"])/"train/manifest.json"),
                   UAVNAV_VALIDATION_CACHE_MANIFEST=str(Path(spec["cache_root"])/"dev/manifest.json"),
                   UAVNAV_UPSTREAM_ROOT=str(args.upstream_root),UAVNAV_DINO_REPO=spec["dino_repo"],
                   UAVNAV_DINO_WEIGHTS=spec["dino_weights"],UAVNAV_EPOCHS=str(spec["epochs"]),UAVNAV_NAME=run_name,
                   UAVNAV_LANI_PROJECT=spec["train_project"],UAVNAV_LANI_DIAGNOSTIC="0")
        if not (run/"metrics.json").exists():
            import torch
            if not torch.cuda.is_available() or torch.cuda.mem_get_info()[0] < 6*1024**3:
                raise RuntimeError("Full training needs CUDA and at least 6GiB free; queue stops without CPU fallback")
            execute("train_"+architecture,[sys.executable,"-B",str(code/"train.py"),"--dataset","lani_v1"],env)
    checkpoints = {architecture:Path(spec["train_project"])/(architecture+"_full_seed0_"+spec["run_tag"])/"weights/best.pt"
                   for architecture in ("lani_ga_lstm_v1","lani_dino_recurrent_v1")}
    write_json(args.output / "frozen_checkpoints.json",{key:{"path":str(value),"sha256":hashlib.sha256(value.read_bytes()).hexdigest()}
                                                     for key,value in checkpoints.items()})
    for split in ("dev","test"):
        for policy,checkpoint in [("model",x) for x in checkpoints.values()]+[(x,None) for x in ("stop","random","forward")]:
            name = checkpoint.parents[1].name if checkpoint else policy
            output = Path(spec["eval_root"])/split/name
            if (output/"metrics.json").exists():
                continue
            command = base+["--mode","evaluate","--policy",policy,"--split",split,"--output",str(output),
                            "--reference-manifest",str(Path(spec["cache_root"])/split/"manifest.json"),"--resume"]
            if checkpoint:
                command += ["--checkpoint",str(checkpoint),"--device","cuda"]
            else:
                command += ["--device","cpu"]
            execute("eval_"+split+"_"+name,command)
    write_json(args.output / "status.json",{"status":"complete","seed":0,"split_coverage":"all official valid segments"})
