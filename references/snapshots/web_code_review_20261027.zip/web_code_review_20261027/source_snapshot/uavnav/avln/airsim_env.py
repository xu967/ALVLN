"""已启动的 TravelUAV/AirSim 场景的单机适配层。

API 来源是 idea/TravelUAV/airsim_plugin/AirVLNSimulatorClientTool.py
和 idea/AeroVLA/airsim_plugin/AirVLNSimulatorClientTool_AeroVLA.py。
不启动场景，不替换官方对象生成逻辑。调用方应先布置并核验目标对象。
该静态执行器在观测和推理期间暂停仿真，控制采用固定仿真时长的世界系
速度命令；与 TravelUAV 的多航点路径执行器不同，结果必须记录控制协议。
"""

from __future__ import annotations

import importlib
import hashlib
import io
import json
import os
from pathlib import Path
import stat
import time
from typing import Any

import numpy as np
from PIL import Image
from scipy.spatial.transform import Rotation

from uavnav.avln.rollout import Observation, _vector
from uavnav.avln.geometry import aerial_pose_transition


def aerial_scene_build(directory):
    """绑定调用方声明的已启动场景构建；不推断进程与目录的对应关系。"""
    root = Path(directory).absolute()
    def reject_link(path):
        attributes = path.lstat()
        if stat.S_ISLNK(attributes.st_mode) or getattr(attributes, "st_file_attributes", 0) & 0x400:
            raise ValueError(f"场景构建禁止符号链接或重解析点: {path}")
        return attributes
    for component in (root, *root.parents):
        reject_link(component)
    if not root.is_dir():
        raise ValueError("scene-build-dir 必须是场景构建目录")
    files = []
    def walking_error(error):
        raise error
    for directory_path, directories, filenames in os.walk(root, followlinks=False, onerror=walking_error):
        for name in directories:
            reject_link(Path(directory_path) / name)
        # Unreal运行中的Saved包含Logs/Config等；它不属于不可变场景构建。
        directories[:] = [name for name in directories if name != "Saved"]
        for name in filenames:
            path = Path(directory_path) / name
            attributes = reject_link(path)
            if not stat.S_ISREG(attributes.st_mode):
                raise ValueError(f"场景构建包含非普通文件: {path}")
            digest = hashlib.sha256()
            with path.open("rb") as stream:
                for block in iter(lambda: stream.read(1024 * 1024), b""):
                    digest.update(block)
            files.append({"path": path.relative_to(root).as_posix(), "sha256": digest.hexdigest(),
                          "size": attributes.st_size})
    files.sort(key=lambda row: row["path"])
    if not files:
        raise ValueError("scene-build-dir 没有普通构建文件")
    encoded = json.dumps(files, sort_keys=True, separators=(",", ":"), ensure_ascii=False, allow_nan=False)
    return {"sha256": hashlib.sha256(encoded.encode("utf-8")).hexdigest(), "files": files,
            "exclusion_policy": {"version": "unreal_saved_directories_v1", "directory_names": ["Saved"]}}


def aerial_action_pose(position, orientation_xyzw, action):
    """复现 AirVLN getPoseAfterMakeAction；平移只用 yaw，转向清零俯仰/滚转。"""
    if isinstance(action, (bool, np.bool_)) or not isinstance(action, (int, np.integer)) or not 0 <= action < 8:
        raise ValueError("AerialVLN action 必须是整数 0 至 7")
    p = _vector(position, "position", 3).copy()
    q = _vector(orientation_xyzw, "orientation_xyzw", 4).copy()
    rotation = Rotation.from_quat(q)
    matrix = rotation.as_matrix()
    yaw = np.arctan2(matrix[1, 0], matrix[0, 0])
    # 平移规则只使用yaw，非转向保留原四元数，避免Euler万向节消歧改变旧行为。
    state = aerial_pose_transition([*p, 0, 0, yaw], action)
    if action in (2, 3):
        q = Rotation.from_euler("z", state[5]).as_quat()
    return state[:3], q


class AerialRouteEnv:
    """官方离散 pose 控制，深度为终止代理；不是连续动力学飞行。"""

    replay = False
    actions_executed = True
    _MAX_IMAGE_REFRESH_ATTEMPTS = 3

    def __init__(self, start_position, start_orientation, scene_id, *, ip="127.0.0.1", port=41451,
                 vehicle_name="Drone_1", camera_name="front_0", rgb_order="RGB", timeout=60.,
                 detect_depth_collision=True, client=None, sdk=None):
        self.start_position = _vector(start_position, "start_position", 3)
        self.start_orientation = _vector(start_orientation, "start_orientation_xyzw", 4)
        Rotation.from_quat(self.start_orientation)
        if type(scene_id) is not int or scene_id <= 0 or rgb_order not in ("RGB", "BGR"):
            raise ValueError("scene_id 必须是正整数，rgb_order 必须是 RGB/BGR")
        self.scene_id = scene_id
        self.sdk = sdk or importlib.import_module("airsim")
        self.client = client or self.sdk.MultirotorClient(ip=ip, port=port, timeout_value=timeout)
        self.vehicle_name, self.camera_name, self.rgb_order = vehicle_name, camera_name, rgb_order
        self.detect_depth_collision = bool(detect_depth_collision)
        self.observation = None
        self._done = True
        self.collision_time_at_reset = 0
        self.last_image_timestamp_ns = None
        self.last_depth_timestamp_ns = None
        self.timeout = float(timeout)
        if not np.isfinite(self.timeout) or self.timeout <= 0:
            raise ValueError("timeout 必须为有限正数")
        self.capture_extrinsics = None
        self.capture_policy_version = None
        self.last_capture_audit = None

    def capture_provenance(self, scene_build):
        """v2采集专用来源读取；旧环境不要求设置/相机查询API。"""
        if self.client.simIsPause():
            raise RuntimeError("v2采集要求未暂停场景，拒绝静默改变暂停状态")
        read_settings = getattr(self.client, "getSettingsString", None)
        if not callable(read_settings):
            read_settings = getattr(self.client, "simGetSettingsString", None)
        if not callable(read_settings):
            raise RuntimeError("v2采集要求AirSim getSettingsString或兼容simGetSettingsString实际设置API")
        settings = json.loads(read_settings())
        try:
            camera = settings["Vehicles"][self.vehicle_name]["Cameras"][self.camera_name]
            position = [camera[key] for key in ("X", "Y", "Z")]
            angles = [camera[key] for key in ("Pitch", "Roll", "Yaw")]
        except (KeyError, TypeError) as error:
            raise ValueError("v2来源要求实际settings完整的车辆相机X/Y/Z/Pitch/Roll/Yaw外参") from error
        if any(type(value) not in (int, float) or not np.isfinite(value) for value in position + angles):
            raise ValueError("v2相机外参必须是有限数值")
        camera_info = self.client.simGetCameraInfo(self.camera_name, vehicle_name=self.vehicle_name)
        fov = getattr(camera_info, "fov", None)
        if type(fov) not in (int, float) or not np.isfinite(fov) or not 0 < fov < 180:
            raise ValueError("v2来源要求实际相机的有限FOV，范围(0,180)")
        encoded = json.dumps(settings, sort_keys=True, separators=(",", ":"), ensure_ascii=False, allow_nan=False)
        self.capture_extrinsics = {"position": position, "rotation_degrees": angles}
        self.capture_policy_version = "set_pose_unpaused_rgbd_bounded_rerequest_v3"
        return {"scene_build": scene_build, "settings": settings,
                "settings_sha256": hashlib.sha256(encoded.encode("utf-8")).hexdigest(),
                "camera_fov_degrees": float(fov),
                "camera_extrinsics": {"position": position, "rotation_degrees": angles},
                "capture_policy": {"version": self.capture_policy_version,
                                   "wait_seconds": 0.0, "pause": False,
                                   "max_refresh_attempts": self._MAX_IMAGE_REFRESH_ATTEMPTS,
                                   "clock_advance": "none",
                                   "timestamp_skew_policy": "measure_only"}}

    def _capture_error(self, message, audit):
        self.last_capture_audit = audit
        error = RuntimeError(message)
        error.capture_audit = audit
        return error

    def _refresh_capture_clock(self, audit):
        advance = getattr(self.client, "simContinueForFrames", None)
        if not callable(advance):
            raise self._capture_error("AerialVLN时间戳未推进，场景不支持simContinueForFrames", audit)
        deadline = time.perf_counter() + self.timeout
        failure = None
        try:
            advance(1)
            # AirSim推进API可能先返回，完成时才暂停。先等完成，不能提前
            # simPause(False)覆盖尚未完成的推进请求。
            while not self.client.simIsPause():
                if time.perf_counter() >= deadline:
                    raise TimeoutError("仿真帧推进未在timeout内完成并暂停")
                time.sleep(.002)
        except Exception as error:
            failure = error
        finally:
            audit["capture_paused_after"] = None
            try:
                self.client.simPause(False)
                audit["capture_paused_after"] = bool(self.client.simIsPause())
                if audit["capture_paused_after"]:
                    raise RuntimeError("simPause(False)后仿真仍暂停")
            except Exception as error:
                audit["pause_restore_error"] = str(error)
                failure = error if failure is None else RuntimeError(f"{failure}; 恢复失败: {error}")
        if failure is not None:
            audit["refresh_error"] = str(failure)
            raise self._capture_error(f"AerialVLN时间戳刷新失败: {failure}", audit) from failure

    def _response_camera(self, response):
        p, q = getattr(response, "camera_position", None), getattr(response, "camera_orientation", None)
        position = [float(p.x_val), float(p.y_val), float(p.z_val)] if p is not None else None
        orientation = [float(q.x_val), float(q.y_val), float(q.z_val), float(q.w_val)] if q is not None else None
        if self.capture_extrinsics is not None:
            p_array, q_array = np.asarray(position), np.asarray(orientation)
            if (p_array.shape != (3,) or q_array.shape != (4,)
                    or not np.isfinite(p_array).all() or not np.isfinite(q_array).all()
                    or abs(np.linalg.norm(q_array) - 1) > 1e-3):
                raise ValueError("v2 RGB-D响应相机必须含有限位置及单位xyzw")
            body = Rotation.from_quat(self.requested_orientation)
            expected_p = self.requested_position + body.apply(self.capture_extrinsics["position"])
            pitch, roll, yaw = self.capture_extrinsics["rotation_degrees"]
            expected_q = body * Rotation.from_euler("xyz", [roll, pitch, yaw], degrees=True)
            if (np.linalg.norm(p_array - expected_p) > .02
                    or (expected_q.inv() * Rotation.from_quat(q_array)).magnitude() > 1e-4):
                raise ValueError("v2 RGB-D响应相机与请求pose及实际外参不一致")
        return position, orientation

    @staticmethod
    def _camera_audit(response):
        # 保存拒绝响应的原始分量；无法表示为有限JSON数值的分量用null并
        # 逐项标明，不让NaN/Infinity使失败证据本身无法持久化。
        invalid = []
        def components(attribute, names):
            source = getattr(response, attribute, None)
            if source is None:
                invalid.append(attribute)
                return None
            values = []
            for name in names:
                value = getattr(source, name, None)
                try:
                    number = float(value)
                    if isinstance(value, (bool, np.bool_)) or not np.isfinite(number):
                        raise ValueError("invalid component")
                except (TypeError, ValueError, OverflowError):
                    number = None
                    invalid.append(f"{attribute}.{name}")
                values.append(number)
            return values
        position = components("camera_position", ("x_val", "y_val", "z_val"))
        orientation = components("camera_orientation", ("x_val", "y_val", "z_val", "w_val"))
        return position, orientation, invalid

    def _set_pose(self, position, orientation):
        pose = self.sdk.Pose(position_val=self.sdk.Vector3r(*position),
                             orientation_val=self.sdk.Quaternionr(*orientation))
        self.pose_requested_ns = time.time_ns()
        self.client.simSetVehiclePose(pose, ignore_collision=True, vehicle_name=self.vehicle_name)
        self.requested_position = np.asarray(position, dtype=float).copy()
        self.requested_orientation = np.asarray(orientation, dtype=float).copy()

    def _observe(self):
        try:
            return self._observe_capture()
        except Exception as error:
            if not hasattr(error, "capture_audit"):
                error.capture_audit = self.last_capture_audit
            raise

    def _observe_capture(self):
        special = self.scene_id in (1, 7)
        requests = [self.sdk.ImageRequest(self.camera_name, self.sdk.ImageType.Scene, False, False),
                    self.sdk.ImageRequest(self.camera_name,
                        self.sdk.ImageType.DepthVis if special else self.sdk.ImageType.DepthPerspective,
                        not special, special)]
        refresh_attempts = 0
        strict = self.capture_extrinsics is not None
        rerequest = strict and self.capture_policy_version == "set_pose_unpaused_rgbd_bounded_rerequest_v3"
        deadline = time.perf_counter() + self.timeout if rerequest else None
        audit = {"capture_paused_before": None, "capture_paused_after": None,
                 "image_refresh_attempts": 0, "image_refresh_audit": []}
        self.last_capture_audit = audit
        paused_before = bool(self.client.simIsPause())
        audit.update(capture_paused_before=paused_before, capture_paused_after=paused_before)
        if strict and paused_before:
            raise self._capture_error("v2 RGB-D采集开始时场景已暂停", audit)
        while True:
            if rerequest and time.perf_counter() >= deadline:
                audit["capture_timeout_seconds"] = self.timeout
                raise self._capture_error("AerialVLN RGB-D重请求超出总timeout", audit)
            request_started_ns = time.time_ns()
            try:
                responses = self.client.simGetImages(requests, vehicle_name=self.vehicle_name)
            except Exception as error:
                audit["rpc_error"] = str(error)
                raise self._capture_error(f"AerialVLN RGB-D请求失败: {error}", audit) from error
            response_received_ns = time.time_ns()
            if len(responses) != 2:
                raise self._capture_error("AerialVLN 前视 RGB/深度响应数量无效", audit)
            rgb, raw = responses
            image_stamp = getattr(rgb, "time_stamp", None)
            depth_stamp = getattr(raw, "time_stamp", None)
            image_stamp = int(image_stamp) if isinstance(image_stamp, (int, np.integer)) and not isinstance(image_stamp, bool) else 0
            depth_stamp = int(depth_stamp) if isinstance(depth_stamp, (int, np.integer)) and not isinstance(depth_stamp, bool) else None
            fresh = image_stamp > 0 and (self.last_image_timestamp_ns is None or image_stamp > self.last_image_timestamp_ns)
            depth_fresh = depth_stamp is not None and depth_stamp > 0 and (self.last_depth_timestamp_ns is None or depth_stamp > self.last_depth_timestamp_ns)
            reasons = ([] if fresh else ["rgb_timestamp_not_advanced"])
            if not depth_fresh and strict:
                reasons.append("depth_timestamp_not_advanced")
            attempt = {"attempt_index": refresh_attempts, "image_timestamp_ns": image_stamp,
                       "depth_timestamp_ns": depth_stamp, "rgb_fresh": fresh, "depth_fresh": depth_fresh,
                       "rejection_reasons": reasons, "request_started_ns": request_started_ns,
                       "response_received_ns": response_received_ns}
            for response, prefix in ((rgb, "response_camera"), (raw, "depth_response_camera")):
                camera_p, camera_q, invalid = self._camera_audit(response)
                attempt[f"{prefix}_position"] = camera_p
                attempt[f"{prefix}_orientation_xyzw"] = camera_q
                attempt[f"{prefix}_invalid_fields"] = invalid
            attempt["requested_position"] = self.requested_position.tolist()
            attempt["requested_orientation_xyzw"] = self.requested_orientation.tolist()
            audit["image_refresh_audit"].append(attempt)
            audit["capture_paused_after"] = bool(self.client.simIsPause())
            if rerequest and time.perf_counter() >= deadline:
                reasons.append("capture_timeout")
                audit["capture_timeout_seconds"] = self.timeout
                raise self._capture_error("AerialVLN RGB-D重请求超出总timeout，拒绝超时响应", audit)
            if strict and audit["capture_paused_after"]:
                reasons.append("capture_paused_after")
                raise self._capture_error("v2 RGB-D响应后场景意外暂停", audit)
            if not reasons:
                try:
                    camera_position, camera_orientation = self._response_camera(rgb)
                    depth_camera_position, depth_camera_orientation = self._response_camera(raw)
                except (ValueError, TypeError, AttributeError) as error:
                    reasons.append("response_camera_pose_invalid")
                    raise self._capture_error(str(error), audit) from error
                break
            if refresh_attempts >= self._MAX_IMAGE_REFRESH_ATTEMPTS:
                raise self._capture_error(
                    "AerialVLN图像时间戳未推进，拒绝将重复传感器帧作为新动作观测"
                    f"（已尝试{'重新请求' if rerequest else '仿真时钟推进'}{refresh_attempts}次）", audit
                )
            refresh_attempts += 1
            audit["image_refresh_attempts"] = refresh_attempts
            # 新采集合同仅重新请求；旧路径保留原推进/暂停恢复行为。
            if not rerequest:
                self._refresh_capture_clock(audit)
        pixels = np.frombuffer(rgb.image_data_uint8, dtype=np.uint8)
        if rgb.width <= 0 or rgb.height <= 0 or pixels.size != rgb.width * rgb.height * 3:
            raise RuntimeError("AerialVLN RGB 不是有效的未压缩三通道图像")
        array = pixels.reshape(rgb.height, rgb.width, 3)
        if self.rgb_order == "BGR":
            array = array[..., ::-1]
        if special:
            with Image.open(io.BytesIO(bytes(raw.image_data_uint8))) as image:
                depth = np.asarray(image.convert("RGB"), dtype=np.float32)[..., 1] / 255.
        else:
            depth = np.asarray(raw.image_data_float, dtype=np.float32)
            if raw.width <= 0 or raw.height <= 0 or depth.size != raw.width * raw.height:
                raise RuntimeError("AerialVLN DepthPerspective 数据尺寸无效")
            depth = np.clip(depth.reshape(raw.height, raw.width), 0, 100) / 100.
        if depth.shape != (raw.height, raw.width) or not np.isfinite(depth).all():
            raise RuntimeError("AerialVLN 深度包含无效像素")
        fraction = float(np.mean(depth < .004))
        proxy = fraction > .1
        pose = self.client.simGetVehiclePose(vehicle_name=self.vehicle_name)
        collision = self.client.simGetCollisionInfo(vehicle_name=self.vehicle_name)
        contact = bool(collision.has_collided and collision.time_stamp > self.collision_time_at_reset)
        p, q = pose.position, pose.orientation
        observed_p = np.array([p.x_val, p.y_val, p.z_val])
        observed_q = np.array([q.x_val, q.y_val, q.z_val, q.w_val])
        rotation_error = float((Rotation.from_quat(observed_q).inv() * Rotation.from_quat(self.requested_orientation)).magnitude())
        if np.linalg.norm(observed_p - self.requested_position) > .02 or rotation_error > 1e-4:
            raise RuntimeError("AerialVLN 返回pose与simSetVehiclePose请求不一致，拒绝错误坐标/延迟观测")
        # 上游用深度代理结束，contact 仅作额外证据，不改变官方 success。
        done = proxy and self.detect_depth_collision
        obs = Observation(
            Image.fromarray(np.ascontiguousarray(array)),
            observed_p, observed_q,
            timestamp=int(rgb.time_stamp) / 1e9, collision=contact, done=done,
            termination_reason="depth_collision_proxy" if done else None,
            info={"control_protocol": "airsim_set_pose_ignore_collision", "physical_continuous_flight": False,
                  "camera_name": self.camera_name, "vehicle_name": self.vehicle_name, "rgb_order": self.rgb_order,
                  "scene_id": self.scene_id, "depth_source": "DepthVis_green_uint8_div255" if special else "DepthPerspective_clip100_div100",
                  "depth_input_protocol": "front_0_scene_normalized_256_v1",
                  "depth_render_protocol": "scene1_7_depthvis255_else_depthperspective100_v1",
                  "depth_collision_fraction": fraction, "depth_collision_proxy": proxy,
                  "depth_collision_enabled": self.detect_depth_collision, "simulator_contact": contact,
                  "requested_position": self.requested_position.tolist(), "requested_orientation": self.requested_orientation.tolist(),
                  "pose_position_tolerance_m": .02, "pose_orientation_tolerance_rad": 1e-4,
                  "position_sampling": "discrete_pose_endpoints", "depth_normalized": depth[..., None]},
        )
        obs.info.update(image_timestamp_ns=image_stamp,
                        pose_requested_ns=self.pose_requested_ns,
                        request_started_ns=request_started_ns, response_received_ns=response_received_ns,
                        depth_timestamp_ns=depth_stamp,
                        response_camera_position=camera_position, response_camera_orientation_xyzw=camera_orientation,
                        depth_response_camera_position=depth_camera_position,
                        depth_response_camera_orientation_xyzw=depth_camera_orientation,
                        rgb_depth_timestamp_skew_ns=depth_stamp - image_stamp if depth_stamp is not None else None,
                        image_refresh_attempts=refresh_attempts,
                        image_refresh_audit=audit["image_refresh_audit"],
                        capture_paused_before=paused_before, capture_paused_after=audit["capture_paused_after"],
                        image_refresh_protocol=("bounded_rgbd_rerequest_v3" if rerequest else
                                                "simContinueForFrames_v1") if refresh_attempts else "none")
        self.observation = obs
        self.last_image_timestamp_ns = image_stamp
        self.last_depth_timestamp_ns = depth_stamp
        self._done = done
        return obs

    def reset(self):
        self.client.confirmConnection()
        self.last_image_timestamp_ns = None
        self.last_depth_timestamp_ns = None
        old = self.client.simGetCollisionInfo(vehicle_name=self.vehicle_name)
        self.collision_time_at_reset = int(old.time_stamp)
        self._set_pose(self.start_position, self.start_orientation)
        return self._observe()

    def step(self, action):
        if self._done or self.observation is None:
            raise RuntimeError("AerialVLN episode 未 reset 或已终止")
        if action == 0:
            raise ValueError("STOP 必须在动作执行前处理")
        position, orientation = aerial_action_pose(self.observation.position, self.observation.orientation, action)
        self._set_pose(position, orientation)
        return self._observe()

    def finish(self):
        self._done = True


class AirSimEnv:
    replay = False
    actions_executed = True

    def __init__(
        self,
        start_position: Any,
        start_orientation: Any,
        *,
        ip: str = "127.0.0.1",
        port: int = 41451,
        vehicle_name: str = "",
        camera_name: str = "FrontCamera",
        rgb_order: str,
        action_duration: float = 5.0,
        speed_limit: float = 1.0,
        timeout: float = 60.0,
        sample_interval: float = 0.1,
        client: Any = None,
        sdk: Any = None,
    ):
        self.start_position = _vector(start_position, "start_position", 3)
        self.start_orientation = _vector(start_orientation, "start_orientation", 4)
        Rotation.from_quat(self.start_orientation)
        if rgb_order not in ("RGB", "BGR"):
            raise ValueError("rgb_order 必须显式设置为 RGB 或 BGR，并在实景检查")
        values = [action_duration, speed_limit, timeout, sample_interval]
        if not np.isfinite(values).all() or min(values) <= 0:
            raise ValueError("action_duration、speed_limit、timeout、sample_interval 必须为有限正数")
        self.sdk = sdk or importlib.import_module("airsim")
        self.client = client if client is not None else self.sdk.MultirotorClient(
            ip=ip, port=port, timeout_value=timeout,
        )
        self.vehicle_name = vehicle_name
        self.camera_name = camera_name
        self.rgb_order = rgb_order
        self.action_duration = float(action_duration)
        self.speed_limit = float(speed_limit)
        self.sample_interval = float(sample_interval)
        self.timeout = float(timeout)
        self.observation: Observation | None = None
        self.collision_time_at_reset = 0
        self._done = True

    def _wait_until_paused(self) -> None:
        deadline = time.perf_counter() + self.timeout
        while not self.client.simIsPause():
            if time.perf_counter() >= deadline:
                self.client.simPause(True)
                raise TimeoutError("AirSim 未在超时前完成仿真推进并暂停")
            time.sleep(0.002)

    def _state_sample(self) -> dict[str, Any]:
        state = self.client.getMultirotorState(vehicle_name=self.vehicle_name)
        collision = self.client.simGetCollisionInfo(vehicle_name=self.vehicle_name)
        p, q = state.kinematics_estimated.position, state.kinematics_estimated.orientation
        return {
            "timestamp": int(state.timestamp) / 1e9,
            "position": [p.x_val, p.y_val, p.z_val],
            "orientation": [q.x_val, q.y_val, q.z_val, q.w_val],
            "collision": bool(collision.has_collided and collision.time_stamp > self.collision_time_at_reset),
        }

    def _observe(self, info: dict[str, Any] | None = None) -> Observation:
        response = self.client.simGetImages(
            [self.sdk.ImageRequest(self.camera_name, self.sdk.ImageType.Scene, False, False)],
            vehicle_name=self.vehicle_name,
        )[0]
        pixels = np.frombuffer(response.image_data_uint8, dtype=np.uint8)
        if response.width <= 0 or response.height <= 0 or pixels.size != response.width * response.height * 3:
            raise RuntimeError("AirSim 前视图不是有效的未压缩三通道图像")
        array = pixels.reshape(response.height, response.width, 3)
        if self.rgb_order == "BGR":
            array = array[..., ::-1]
        state = self.client.getMultirotorState(vehicle_name=self.vehicle_name)
        collision = self.client.simGetCollisionInfo(vehicle_name=self.vehicle_name)
        # AirSim 的碰撞状态可能保留上一个 episode，只记录 reset 后的新事件。
        collided = bool(collision.has_collided and collision.time_stamp > self.collision_time_at_reset)
        kinematics = state.kinematics_estimated
        p, q = kinematics.position, kinematics.orientation
        metadata = {
            "image_timestamp_ns": int(response.time_stamp),
            "state_timestamp_ns": int(state.timestamp),
            "wall_timestamp_unix_s": time.time(),
            "collision_timestamp_ns": int(collision.time_stamp),
            "collision_known": True,
            "control_protocol": "paused_static_fixed_duration_world_velocity",
            "position_sampling": "fixed_sim_step_pose_samples",
            "sample_interval_sim_s": self.sample_interval,
            "coordinate_frame": "airsim_local_ned_from_vehicle_spawn",
            "action_duration_sim_s": self.action_duration,
            "speed_limit_m_s": self.speed_limit,
            "camera_name": self.camera_name,
            "rgb_order": self.rgb_order,
        }
        metadata.update(info or {})
        obs = Observation(
            image=Image.fromarray(np.ascontiguousarray(array)),
            position=np.array([p.x_val, p.y_val, p.z_val]),
            orientation=np.array([q.x_val, q.y_val, q.z_val, q.w_val]),
            timestamp=int(state.timestamp) / 1e9,
            collision=collided,
            done=collided,
            termination_reason="collision" if collided else None,
            info=metadata,
        )
        self.observation = obs
        return obs

    def reset(self) -> Observation:
        self.client.confirmConnection()
        self.client.simPause(True)
        self.client.cancelLastTask(vehicle_name=self.vehicle_name)
        self.client.enableApiControl(True, vehicle_name=self.vehicle_name)
        self.client.armDisarm(True, vehicle_name=self.vehicle_name)
        # 在初始化帧推进之前记下旧碰撞，初始化期间的新碰撞必须可见。
        collision = self.client.simGetCollisionInfo(vehicle_name=self.vehicle_name)
        self.collision_time_at_reset = int(collision.time_stamp)
        kinematics = self.sdk.KinematicsState()
        kinematics.position = self.sdk.Vector3r(*self.start_position)
        kinematics.orientation = self.sdk.Quaternionr(*self.start_orientation)
        kinematics.linear_velocity = self.sdk.Vector3r(0, 0, 0)
        kinematics.angular_velocity = self.sdk.Vector3r(0, 0, 0)
        self.client.simSetKinematics(kinematics, ignore_collision=True, vehicle_name=self.vehicle_name)
        self.client.simContinueForFrames(1)
        self._wait_until_paused()
        self._done = False
        obs = self._observe()
        self._done = obs.done
        return obs

    def step(self, action_body: Any) -> Observation:
        if self._done or self.observation is None:
            raise RuntimeError("episode 尚未 reset 或已经终止")
        action = _vector(action_body, "action_body", 3)
        current = self.observation
        world_delta = Rotation.from_quat(current.orientation).apply(action)
        norm = float(np.linalg.norm(world_delta))
        scale = min(1.0, self.speed_limit * self.action_duration / max(norm, 1e-12))
        executed_delta = world_delta * scale
        velocity = executed_delta / self.action_duration
        yaw = np.degrees(np.arctan2(world_delta[1], world_delta[0]))
        if np.linalg.norm(world_delta[:2]) < 1e-9:
            forward = Rotation.from_quat(current.orientation).apply([1, 0, 0])
            yaw = np.degrees(np.arctan2(forward[1], forward[0]))
        started = time.perf_counter()
        samples = [{"timestamp": current.timestamp, "position": current.position.tolist(),
                    "orientation": current.orientation.tolist(), "collision": current.collision}]
        simulated = 0.0
        try:
            self.client.moveByVelocityAsync(
                *velocity, duration=self.action_duration,
                drivetrain=self.sdk.DrivetrainType.MaxDegreeOfFreedom,
                yaw_mode=self.sdk.YawMode(is_rate=False, yaw_or_rate=float(yaw)),
                vehicle_name=self.vehicle_name,
            )
            while simulated < self.action_duration - 1e-9:
                duration = min(self.sample_interval, self.action_duration - simulated)
                self.client.simContinueForTime(duration)
                self._wait_until_paused()
                sample = self._state_sample()
                if sample["timestamp"] <= samples[-1]["timestamp"]:
                    raise RuntimeError("AirSim 执行动作后传感器时间没有推进")
                samples.append(sample)
                simulated += duration
                if sample["collision"]:
                    break
        finally:
            self.client.simPause(True)
            self.client.cancelLastTask(vehicle_name=self.vehicle_name)
        obs = self._observe({
            "commanded_world_target": (current.position + world_delta).tolist(),
            "clipped_world_target": (current.position + executed_delta).tolist(),
            "velocity_world": velocity.tolist(),
            "action_clipped": scale < 1.0,
            "motion_samples": samples,
            "requested_sim_duration_s": simulated,
            "actual_sim_duration_s": samples[-1]["timestamp"] - samples[0]["timestamp"],
            "action_execution_ms": (time.perf_counter() - started) * 1000.0,
        })
        self._done = obs.done
        return obs

    def finish(self) -> None:
        self.client.simPause(True)
        self.client.cancelLastTask(vehicle_name=self.vehicle_name)
        self._done = True
