"""按checkpoint合同重建旧航点或八动作路线策略。

旧策略输出机体位移；路线v1无跨步状态，候选v2按episode维护合法观测记忆。
各版本使用训练时的图像归一化、文本编码和历史输入，不读取目标真值。
"""

from __future__ import annotations

import time
import hashlib
from io import BytesIO
from collections.abc import Mapping, Sequence
from numbers import Integral, Real
from pathlib import Path
from typing import Any

import numpy as np
import torch
from PIL import Image
from uavnav.avln.data import (IMAGENET_MEAN, IMAGENET_STD, Vocab, strip_direction_cue,
                             preprocess_rgb, preprocess_depth, validate_aerial_render_protocol)
from uavnav.avln.model import (DINOV3_VARIANTS, FUSION_MODES, TEXT_QUERY_MODES,
                             ARCHITECTURES, BACKBONES, FUSIONS, build_model,
                             AIRVLN_ARCHITECTURES, RGBD_ARCHITECTURES, validate_encoder_configuration)
from uavnav.avln.metadata import validate_task_protocol, task_protocol_sha256


ABLATIONS = ("none", "no_image", "no_history", "no_text")
AIRVLN_BASELINES = AIRVLN_ARCHITECTURES
AERIAL_ARCHITECTURES = ("aerial_route_v1", "aerial_route_recurrent_v2", "aerial_route_recurrent_clause_v3",
                        "aerial_route_recurrent_rgbd_v3", "aerial_route_dino_v5", *AIRVLN_BASELINES)
_MODEL_CONFIG_KEYS = (
    "history_frames",
    "hidden",
    "ablate",
    "imgsz",
    "image_mean",
    "image_std",
)


class CheckpointFormatError(ValueError):
    """checkpoint 缺少推理所需字段或字段类型不符合约定。"""


def _require_mapping(payload: Any, name: str) -> Mapping[str, Any]:
    if not isinstance(payload, Mapping):
        raise CheckpointFormatError(f"checkpoint 字段 {name!r} 必须是映射，实际为 {type(payload).__name__}")
    return payload


def _require_finite_positive(value: Any, name: str) -> float:
    if isinstance(value, bool):
        raise CheckpointFormatError(f"checkpoint 字段 {name!r} 必须是有限正数")
    try:
        result = float(value)
    except (TypeError, ValueError) as error:
        raise CheckpointFormatError(f"checkpoint 字段 {name!r} 必须是正数") from error
    if not np.isfinite(result) or result <= 0:
        raise CheckpointFormatError(f"checkpoint 字段 {name!r} 必须是有限正数，实际为 {value!r}")
    return result


def _require_int(value: Any, name: str) -> int:
    if isinstance(value, bool) or not isinstance(value, Integral):
        raise CheckpointFormatError(f"checkpoint 字段 {name!r} 必须是正整数")
    result = int(value)
    if result <= 0:
        raise CheckpointFormatError(f"checkpoint 字段 {name!r} 必须是正整数，实际为 {value!r}")
    return result


def _normalization(config: Mapping[str, Any]) -> tuple[np.ndarray, np.ndarray]:
    for name in ("image_mean", "image_std"):
        value = config[name]
        if not isinstance(value, Sequence) or isinstance(value, (str, bytes)) or len(value) != 3:
            raise CheckpointFormatError(f"model_config.{name} 必须包含 3 个数")
    try:
        mean = np.asarray(config["image_mean"], dtype=np.float32)
        std = np.asarray(config["image_std"], dtype=np.float32)
    except (TypeError, ValueError) as error:
        raise CheckpointFormatError("model_config.image_mean/std 必须包含数值") from error
    if not np.all(np.isfinite(mean)) or not np.all(np.isfinite(std)) or np.any(std <= 0):
        raise CheckpointFormatError("model_config.image_mean/std 必须是有限数，且 std 必须为正")
    if not np.allclose(mean, IMAGENET_MEAN) or not np.allclose(std, IMAGENET_STD):
        raise CheckpointFormatError("当前推理接口只接受训练约定的 ImageNet mean/std")
    return mean, std


def _load_checkpoint_snapshot(checkpoint: str | Path) -> tuple[Mapping[str, Any], str]:
    """同一次读取绑定权重内容与摘要，随后路径替换不影响本次加载。"""
    path = Path(checkpoint)
    if not path.is_file():
        raise FileNotFoundError(f"checkpoint 不存在: {path}")
    content = path.read_bytes()
    digest = hashlib.sha256(content).hexdigest()
    with BytesIO(content) as stream:
        del content
        try:
            payload = torch.load(stream, map_location="cpu", weights_only=True)
        except TypeError:
            # 旧版 torch.load 或包装器可能已消费流，回退前恢复起点。
            stream.seek(0)
            payload = torch.load(stream, map_location="cpu")
    return _require_mapping(payload, "root"), digest


def _build_without_download(vocab_size: int, config: Mapping[str, Any]) -> torch.nn.Module:
    """构造网络但禁止 torchvision 构造器下载 ImageNet 权重。

    checkpoint 已包含完整视觉骨干参数。推理构造显式关闭预训练权重，模型
    权重随后由 load_state_dict 严格加载。
    """

    return build_model(vocab_size, config, pretrained=False)


def _validate_checkpoint(payload: Mapping[str, Any]) -> tuple[dict[str, int], float, dict[str, Any]]:
    missing = [name for name in ("model", "vocab", "length_scale", "model_config") if name not in payload]
    if missing:
        raise CheckpointFormatError(f"checkpoint 缺少必需字段: {', '.join(missing)}")

    vocab_payload = _require_mapping(payload["vocab"], "vocab")
    vocab = dict(vocab_payload)
    if not vocab or any(not isinstance(key, str) for key in vocab):
        raise CheckpointFormatError("checkpoint.vocab 必须是非空的 {token: integer_id} 映射")
    if any(isinstance(value, bool) or not isinstance(value, Integral) for value in vocab.values()):
        raise CheckpointFormatError("checkpoint.vocab 的 id 必须是整数")
    ids = [int(value) for value in vocab.values()]
    if set(ids) != set(range(len(ids))) or vocab.get("<pad>") != 0 or vocab.get("<unk>") != 1:
        raise CheckpointFormatError("checkpoint.vocab 的 id 必须连续，且 <pad>=0、<unk>=1")

    length_scale = _require_finite_positive(payload["length_scale"], "length_scale")
    config_payload = _require_mapping(payload["model_config"], "model_config")
    missing_config = [name for name in _MODEL_CONFIG_KEYS if name not in config_payload]
    if missing_config:
        raise CheckpointFormatError(
            "checkpoint.model_config 缺少必需字段: " + ", ".join(missing_config)
        )
    config = dict(config_payload)
    version = config.get("checkpoint_format_version")
    if version is not None and (isinstance(version, bool) or not isinstance(version, Integral) or version not in (3, 4, 5, 6, 7, 8)):
        raise CheckpointFormatError("未知checkpoint_format_version")
    if version in (4, 5, 6, 7, 8):
        return _validate_aerial_checkpoint(payload, vocab, length_scale, config)
    if version == 3:
        required = ("architecture", "backbone", "visual_fusion", "grid_size", "stop_enabled",
                    "fusion_mode", "output_version", "task_protocol", "task_protocol_sha256", "text_control")
        if any(key not in config for key in required):
            raise CheckpointFormatError("新版checkpoint缺少架构/任务合同字段")
        try:
            protocol = validate_task_protocol(config["task_protocol"])
            digest = task_protocol_sha256(protocol)
        except (ValueError, TypeError) as error:
            raise CheckpointFormatError(str(error)) from error
        if (digest != config["task_protocol_sha256"] or protocol["image_size"] != config["imgsz"]
                or protocol["strip_direction"] != config.get("strip_direction")
                or (protocol["stop_source"] == "reviewed_annotations") != config["stop_enabled"]):
            raise CheckpointFormatError("checkpoint任务摘要或输入/STOP权限冲突")
    else:
        if config.get("architecture", "legacy_waypoint_v1") != "legacy_waypoint_v1":
            raise CheckpointFormatError("新架构必须声明checkpoint_format_version=3")
        config.setdefault("task_protocol", "legacy_unknown")
    config.setdefault("architecture", "legacy_waypoint_v1")
    config.setdefault("backbone", "resnet50")
    config.setdefault("visual_fusion", "global")
    config.setdefault("grid_size", 4)
    config.setdefault("stop_enabled", False)
    config.setdefault("text_control", "original")
    if (config["architecture"] not in ARCHITECTURES or config["backbone"] not in BACKBONES
            or config["visual_fusion"] not in FUSIONS or config["text_control"] not in ("original", "constant")
            or not isinstance(config["stop_enabled"], bool)):
        raise CheckpointFormatError("未知架构、骨干、空间融合、文本控制或STOP配置")
    if config["architecture"] in AERIAL_ARCHITECTURES:
        raise CheckpointFormatError("路线架构必须声明对应checkpoint_format_version=4或5")
    config["grid_size"] = _require_int(config["grid_size"], "model_config.grid_size")
    if config["architecture"] == "legacy_waypoint_v1" and (
            config["backbone"] != "resnet50" or config["visual_fusion"] != "global" or config["stop_enabled"]):
        raise CheckpointFormatError("历史架构不支持新骨干/空间/STOP")
    # 历史权重没有此字段，只能按原 forward 解释。张量形状不能区分两种融合。
    config.setdefault("fusion_mode", "text_context_only")
    if config["fusion_mode"] not in FUSION_MODES:
        raise CheckpointFormatError(f"model_config.fusion_mode 必须是 {FUSION_MODES} 之一")
    if config["architecture"] == "grounded_v1" and config["fusion_mode"] != "query_plus_text":
        raise CheckpointFormatError("新架构要求query_plus_text直接通路")
    if config["text_control"] == "constant" and (config.get("strip_direction") is not True or "<neutral>" not in vocab):
        raise CheckpointFormatError("恒定文本控制需要去方向协议及固定neutral token")
    if version == 3 and config["output_version"] != ("waypoint_stop_v1" if config["stop_enabled"] else "waypoint_v1"):
        raise CheckpointFormatError("output_version与STOP能力冲突")
    config["history_frames"] = _require_int(config["history_frames"], "model_config.history_frames")
    config["hidden"] = _require_int(config["hidden"], "model_config.hidden")
    config["imgsz"] = _require_int(config["imgsz"], "model_config.imgsz")
    if config["ablate"] not in ABLATIONS:
        raise CheckpointFormatError(f"model_config.ablate 必须是 {ABLATIONS} 之一")
    for name, expected in (
        ("coordinate_frame", "body"),
        ("quaternion_order", "xyzw"),
        ("length_unit", "meter"),
    ):
        if name in config and config[name] != expected:
            raise CheckpointFormatError(f"model_config.{name} 必须是 {expected!r}")
        config.setdefault(name, "legacy_unknown")
    _normalization(config)
    _require_mapping(payload["model"], "model")
    return {key: int(value) for key, value in vocab.items()}, length_scale, config


def _validate_aerial_checkpoint(payload, vocab, length_scale, config):
    from uavnav.avln.metadata import validate_aerial_task_protocol
    import hashlib
    import json
    required = ("architecture", "backbone", "visual_fusion", "grid_size", "stop_enabled",
                "fusion_mode", "output_version", "task_protocol", "task_protocol_sha256",
                "text_control", "history_policy", "strip_direction", "data_protocol",
                "split_manifest_sha256", "input_render_protocols", "input_render_protocols_sha256")
    if any(key not in config for key in required):
        raise CheckpointFormatError("路线checkpoint缺少架构、动作、历史、输入或来源合同")
    try:
        validate_encoder_configuration(config)
    except ValueError as error:
        raise CheckpointFormatError(str(error)) from error
    if ("model_construction_version" in config
            and config["model_construction_version"] != "direct_selected_encoders_v1"):
        raise CheckpointFormatError("未知模型构造版本；不能重解释初始化来源")
    rgbd = config["checkpoint_format_version"] == 7
    if rgbd:
        fixed_depth = {"input_modality": "rgbd", "depth_input_protocol": "front_0_scene_normalized_256_v1",
                       "depth_size": 256,
                       "depth_fusion": ("official_depth_encoder_v1" if config["architecture"] in AIRVLN_BASELINES
                                        else "conv32_64_128_add_fused_v1")}
        if (config["architecture"] not in RGBD_ARCHITECTURES
                or any(config.get(key) != value for key, value in fixed_depth.items())
                or type(config.get("depth_size")) is not int):
            raise CheckpointFormatError("格式7必须绑定RGB-D架构和真实256归一化深度合同")
    elif config["architecture"] in RGBD_ARCHITECTURES:
        raise CheckpointFormatError("RGB-D架构只接受格式7，禁止重解释旧RGB权重")
    if config["checkpoint_format_version"] == 8:
        if config["architecture"] != "aerial_route_dino_v5":
            raise CheckpointFormatError("格式8只对应aerial_route_dino_v5")
        visual = config.get("visual_encoder")
        if not isinstance(visual, Mapping):
            raise CheckpointFormatError("v5 checkpoint缺少visual_encoder合同")
        imgsz_value = config.get("imgsz")
        if type(imgsz_value) is not int or imgsz_value <= 0 or imgsz_value % 16:
            raise CheckpointFormatError("v5 imgsz必须是16的正整数倍")
        variant = visual.get("variant")
        if variant not in DINOV3_VARIANTS:
            raise CheckpointFormatError("v5 DINOv3 variant非法")
        if (visual.get("version") != "dinov3_backbone_v1"
                or visual.get("patch_size") != 16
                or visual.get("embed_dim") != DINOV3_VARIANTS[variant][1]
                or visual.get("frozen") is not True
                or visual.get("token_protocol") != "cls_plus_patch_tokens_v1"
                or visual.get("input_size") != imgsz_value
                or visual.get("grid_size") != imgsz_value // 16
                or config.get("grid_size") != imgsz_value // 16
                or config.get("backbone") != f"dinov3_{variant}"
                or config.get("vision_train_policy") != "frozen"
                or config.get("visual_fusion") != "spatial"
                or config.get("fusion_mode") != "query_plus_text"
                or config.get("stop_enabled") is not True):
            raise CheckpointFormatError("v5 DINOv3视觉/记忆/动作合同不一致")
        for field in ("repo_source_sha256", "weights_sha256"):
            value = visual.get(field)
            if (not isinstance(value, str) or len(value) != 64
                    or any(char not in "0123456789abcdef" for char in value)):
                raise CheckpointFormatError(f"v5 visual_encoder.{field}非法")
        repo_dir = visual.get("repo_dir")
        if not isinstance(repo_dir, str) or not repo_dir.strip():
            raise CheckpointFormatError("v5 visual_encoder.repo_dir非法")
    elif config["architecture"] == "aerial_route_dino_v5":
        raise CheckpointFormatError("v5只接受checkpoint格式8")
    baseline = config["checkpoint_format_version"] == 6 or rgbd and config["architecture"] in AIRVLN_BASELINES
    recurrent = config["checkpoint_format_version"] in (5, 6, 7, 8)
    text_query_mode = config.get("text_query_mode", "visual_history")
    if text_query_mode not in TEXT_QUERY_MODES:
        raise CheckpointFormatError(f"model_config.text_query_mode必须属于{TEXT_QUERY_MODES}")
    config["text_query_mode"] = text_query_mode
    if config["architecture"] not in ("aerial_route_recurrent_v2", "aerial_route_recurrent_clause_v3") and text_query_mode != "visual_history":
        raise CheckpointFormatError("状态条件文本查询仅支持轻量RGB循环路线模型")
    if config["architecture"] == "aerial_route_recurrent_clause_v3":
        encoder = config.get("text_encoder")
        if (not isinstance(encoder, Mapping) or encoder.get("version") != "frozen_clip_clause_cache_v1"
                or config.get("vision_train_policy") != "frozen" or config.get("text_control") != "original"):
            raise CheckpointFormatError("v3 checkpoint需记录冻结CLIP子句编码器、冻结视觉和原始指令")
    vision_train_policy = config.get("vision_train_policy", "finetune")
    if vision_train_policy not in ("finetune", "frozen") or (not recurrent and vision_train_policy != "finetune"):
        raise CheckpointFormatError("视觉训练策略仅支持v2 finetune/frozen，旧权重默认finetune")
    initial_fields = ("model_init_state_sha256", "vision_init_state_sha256")
    if any(field in config for field in initial_fields):
        for field in initial_fields:
            value = config.get(field)
            if (not isinstance(value, str) or len(value) != 64
                    or any(char not in "0123456789abcdef" for char in value)):
                raise CheckpointFormatError("配对训练初始化摘要缺失或非法")
    pass_fields = ("render_pass_policy", "render_pass_seed", "render_pass_count", "train_render_passes")
    if any(key in config for key in pass_fields):
        if not recurrent or any(key not in config for key in pass_fields):
            raise CheckpointFormatError("多次渲染checkpoint缺少完整pass训练合同")
        if (config["render_pass_policy"] != "episode_uniform_pass_v1"
                or type(config["render_pass_seed"]) is not int):
            raise CheckpointFormatError("未知完整episode渲染选择协议或seed类型")
        count = _require_int(config["render_pass_count"], "model_config.render_pass_count")
        passes = config["train_render_passes"]
        if not isinstance(passes, list) or len(passes) != count:
            raise CheckpointFormatError("render pass数量与来源记录不一致")
        sources, sessions, digests = set(), set(), set()
        for index, record in enumerate(passes):
            if (not isinstance(record, Mapping) or type(record.get("pass_index")) is not int
                    or record["pass_index"] != index
                    or not isinstance(record.get("source"), str) or not record["source"].strip()):
                raise CheckpointFormatError("render pass来源或顺序非法")
            for field in ("manifest_sha256", "sample_content_sha256"):
                value = record.get(field)
                if (not isinstance(value, str) or len(value) != 64
                        or any(char not in "0123456789abcdef" for char in value)):
                    raise CheckpointFormatError("render pass来源摘要非法")
            session = record.get("capture_session_id")
            if session is not None and (not isinstance(session, str) or not session.strip()):
                raise CheckpointFormatError("render pass采集会话非法")
            if (record["source"] in sources or record["manifest_sha256"] in digests
                    or count > 1 and (session is None or session in sessions)):
                raise CheckpointFormatError("render pass来源重复或缺少独立采集会话")
            sources.add(record["source"])
            digests.add(record["manifest_sha256"])
            sessions.add(session)
    if recurrent:
        visual_protocol = ("dinov3_layernorm_v1" if config["architecture"] == "aerial_route_dino_v5"
                           else "causal_fixed_bn_v1" if baseline else "frozen_running_stats_v1")
        fixed = {"memory_protocol": "airvln_recurrent_gru_v1" if baseline else "fused_gru_v1",
                 "sequence_policy": "episode_contiguous_tbptt_v1", "tokenizer_version": "route_numeric_v1",
                 "vision_batchnorm_protocol": visual_protocol}
        if any(config.get(key) != value for key, value in fixed.items()):
            raise CheckpointFormatError("路线状态checkpoint缺少或改变记忆/连续序列/数值文本协议")
        if config.get("memory_mode") not in ("carry", "reset_each_step"):
            raise CheckpointFormatError("路线状态checkpoint必须声明carry或reset_each_step记忆对照")
        config["sequence_chunk_size"] = _require_int(config.get("sequence_chunk_size"), "model_config.sequence_chunk_size")
        expected_constant = "<unk>" if config["text_control"] == "constant" else None
        if "constant_text_token" not in config or config["constant_text_token"] != expected_constant:
            raise CheckpointFormatError("路线状态checkpoint恒定文本编码与训练协议不一致")
        loss_protocol = config.get("loss_protocol")
        if (not isinstance(loss_protocol, Mapping)
                or set(loss_protocol) != {"version", "inflection_weight", "stop_weight", "normalization"}
                or {"transition_weighted_ce_v1": "sum_weights",
                    "episode_normalized_ce_v2": "episode_sum_weights"}.get(loss_protocol["version"]) != loss_protocol["normalization"]):
            raise CheckpointFormatError("路线状态checkpoint缺少完整转折/STOP损失协议")
        for key in ("inflection_weight", "stop_weight"):
            if isinstance(loss_protocol[key], bool) or not isinstance(loss_protocol[key], Real):
                raise CheckpointFormatError(f"loss_protocol.{key}必须是有限正数，不能隐式转换文本")
            _require_finite_positive(loss_protocol[key], f"loss_protocol.{key}")
    else:
        # 现有v1从未记录tokenizer_version，按训练时压数字的语义解释。
        if config.get("tokenizer_version", "fov_numeric_v1") != "fov_numeric_v1":
            raise CheckpointFormatError("旧route v1数字编码必须保持fov_numeric_v1")
        config.setdefault("tokenizer_version", "fov_numeric_v1")
    try:
        protocol = validate_aerial_task_protocol(config["task_protocol"])
        digest = hashlib.sha256(json.dumps(protocol, sort_keys=True, separators=(",", ":"),
                                          ensure_ascii=False, allow_nan=False).encode("utf-8")).hexdigest()
    except (ValueError, TypeError) as error:
        raise CheckpointFormatError(str(error)) from error
    expected_architectures = (("aerial_route_dino_v5",) if config["architecture"] == "aerial_route_dino_v5"
                             else (tuple(a for a in AIRVLN_BASELINES if (a in RGBD_ARCHITECTURES) == rgbd))
                             if baseline else (("aerial_route_recurrent_rgbd_v3",) if rgbd
                                               else (("aerial_route_recurrent_v2", "aerial_route_recurrent_clause_v3") if recurrent else ("aerial_route_v1",))))
    # New run annotations are optional for historical checkpoints, but never guessed when present.
    if ("model_selection_basis" in config and config["model_selection_basis"]
            != "lowest_unweighted_teacher_validation_ce_not_navigation"):
        raise CheckpointFormatError("路线checkpoint教师选模口径不支持，不能冒导航最优")
    if "training_precision" in config:
        precision = config["training_precision"]
        fields = {"version", "device_type", "forward", "memory", "loss", "inference"}
        if (not isinstance(precision, Mapping) or set(precision) != fields
                or precision["version"] != "aerial_training_precision_v1"
                or precision["device_type"] not in ("cpu", "cuda")):
            raise CheckpointFormatError("路线checkpoint训练精度合同缺失字段或版本不支持")
        expected_forward = "fp32" if baseline or precision["device_type"] == "cpu" else "bf16_autocast"
        if (precision["forward"] != expected_forward or precision["memory"] != ("fp32" if recurrent else "none")
                or precision["loss"] != "fp32" or precision["inference"] != "fp32"):
            raise CheckpointFormatError("路线checkpoint训练/记忆/损失/推理精度声明与架构不一致")
    if (config["architecture"] not in expected_architectures or config["output_version"] != "aerial_action8_v1"
            or config["history_policy"] != "action_onehot8_v1" or config["data_protocol"] != "aerialvln_s_v1"
            or config["stop_enabled"] is not True or config["strip_direction"] is not False
            or config["fusion_mode"] != ("official_policy" if baseline else "query_plus_text")
            or config["text_control"] not in (("original", "constant") if recurrent else ("original",))
            or digest != config["task_protocol_sha256"] or protocol["image_size"] != config["imgsz"]):
        raise CheckpointFormatError("路线checkpoint任务摘要或动作/历史/预处理冲突")
    if config["backbone"] not in BACKBONES or config["visual_fusion"] not in FUSIONS:
        raise CheckpointFormatError("未知路线骨干或融合配置")
    manifest_digest = config["split_manifest_sha256"]
    if (length_scale != 1. or not isinstance(manifest_digest, str) or len(manifest_digest) != 64
            or any(char not in "0123456789abcdef" for char in manifest_digest)):
        raise CheckpointFormatError("路线checkpoint需要有效冻结清单摘要和固定length_scale=1兼容占位")
    render = config["input_render_protocols"]
    if not isinstance(render, Mapping) or set(render) != {"train", "validation"}:
        raise CheckpointFormatError("路线checkpoint需记录训练/验证实际渲染协议")
    render_digest = hashlib.sha256(json.dumps(render, sort_keys=True, separators=(",", ":"),
                                             ensure_ascii=False, allow_nan=False).encode("utf-8")).hexdigest()
    if render_digest != config["input_render_protocols_sha256"]:
        raise CheckpointFormatError("路线checkpoint渲染摘要或前视相机/颜色协议冲突")
    try:
        for item in render.values():
            validate_aerial_render_protocol(item)
            if item["camera_name"] != protocol["camera"]:
                raise ValueError("路线checkpoint需要front_0相机")
            leaves = item["scenes"].values() if item.get("protocol_version") == "aerialvln_s_multiscene_rgb_v1" else [item]
            if rgbd and any(leaf.get("depth_protocol") != "scene1_7_depthvis255_else_depthperspective100_v1" for leaf in leaves):
                raise ValueError("RGB-D checkpoint必须记录场景差异深度来源协议")
        if (config.get("render_pass_count", 1) > 1
                and render["train"]["protocol_version"] != "aerialvln_s_pose_rgb_v2"):
            raise ValueError("多次渲染checkpoint需要带来源的v2采集协议")
    except (ValueError, TypeError) as error:
        raise CheckpointFormatError(str(error)) from error
    for key in ("history_frames", "hidden", "imgsz", "grid_size"):
        config[key] = _require_int(config[key], f"model_config.{key}")
    if baseline:
        for key in ("memory_layers", "memory_hidden_size"):
            config[key] = _require_int(config.get(key), f"model_config.{key}")
        fixed = {"baseline_protocol": "official_network_matched_training_adapter_v1",
                 "raw_rgb_adapter": "imagenet_denormalize_round_uint8_v1",
                 "prev_action_protocol": "last_executed_action_or_start_zero_v1",
                 "memory_hidden_size": 512, "hidden": 512,
                 "memory_layers": 2 if config["architecture"] in ("airvln_cma_rgb_v1", "airvln_cma_rgbd_v1") else 1,
                 "backbone": "resnet50", "vision_train_policy": "frozen", "memory_mode": "carry",
                 "imgsz": 224,
                 "visual_fusion": "spatial" if config["architecture"] in ("airvln_cma_rgb_v1", "airvln_cma_rgbd_v1") else "global",
                 "text_control": "original", "ablate": "none", "render_pass_count": 1}
        if any(config.get(key) != value or isinstance(config.get(key), bool) and isinstance(value, int)
               for key, value in fixed.items()):
            raise CheckpointFormatError("官方RGB网络checkpoint的结构、视觉适配或单pass合同冲突")
        adapter = config.get("upstream_adapter")
        fixed_adapter = {"baseline_protocol": fixed["baseline_protocol"], "memory_protocol": "airvln_recurrent_gru_v1",
                         "network_source": "direct_official_policy_import_v1", "raw_rgb_adapter": fixed["raw_rgb_adapter"],
                         "token_adapter": "project_route_numeric_vocab_full_instruction_v1",
                         "depth_policy": ("official_ablate_depth_false_normalized_nhwc_v1" if rgbd
                                          else "official_ablate_depth_true_environment_depth_retained_v1"),
                         "visual_bn": "causal_fixed_bn_v1", "prev_action_protocol": fixed["prev_action_protocol"],
                         "rnn_mask_protocol": "bool_valid_prefix_v1",
                         "progress_monitor": False, "rgb_pretraining": "imagenet1k_v1",
                         "recurrent_state_layers": fixed["memory_layers"], "memory_layers": fixed["memory_layers"],
                         "memory_hidden_size": 512}
        if (not isinstance(adapter, Mapping) or dict(adapter) != fixed_adapter or adapter.get("progress_monitor") is not False
                or config.get("network_precision") != "fp32_with_outer_autocast_disabled_v1"):
            raise CheckpointFormatError("官方RGB网络checkpoint缺少真实网络、语言、深度权限与精度适配记录")
        for key in ("upstream_root", "upstream_project_prefix", "upstream_log_dir"):
            if not isinstance(config.get(key), str) or not config[key].strip():
                raise CheckpointFormatError("官方RGB网络checkpoint缺少显式上游运行/资产路径")
        sources = config.get("upstream_source_sha256")
        if not isinstance(sources, Mapping) or not sources:
            raise CheckpointFormatError("官方RGB网络checkpoint缺少上游源码SHA清单")
        for relative, value in sources.items():
            if (not isinstance(relative, str) or Path(relative).is_absolute() or ".." in Path(relative).parts
                    or not relative.endswith(".py") or not isinstance(value, str) or len(value) != 64
                    or any(char not in "0123456789abcdef" for char in value)):
                raise CheckpointFormatError("官方RGB网络checkpoint上游源码清单非法")
        asset_digest = config.get("ddppo_checkpoint_sha256")
        if (not isinstance(asset_digest, str) or len(asset_digest) != 64
                or any(char not in "0123456789abcdef" for char in asset_digest)):
            raise CheckpointFormatError("官方RGB网络checkpoint缺少真实DDPPO资产SHA")
    if config["ablate"] not in ABLATIONS:
        raise CheckpointFormatError("未知路线消融配置")
    _normalization(config)
    _require_mapping(payload["model"], "model")
    return {key: int(value) for key, value in vocab.items()}, length_scale, config


def _as_rgb_image(image: Image.Image | np.ndarray | str | Path) -> Image.Image:
    if isinstance(image, (str, Path)):
        path = Path(image)
        if not path.is_file():
            raise FileNotFoundError(f"图像不存在: {path}")
        with Image.open(path) as opened:
            return opened.convert("RGB")
    if isinstance(image, Image.Image):
        return image.convert("RGB")
    if isinstance(image, np.ndarray):
        if image.dtype != np.uint8 or image.ndim != 3 or image.shape[2] != 3:
            raise ValueError("NumPy image 必须是 HWC 形状的 uint8 RGB 数组")
        return Image.fromarray(np.ascontiguousarray(image), mode="RGB")
    raise TypeError("image 必须是 PIL 图像、HWC uint8 RGB 数组、str 或 pathlib.Path")


def _as_history(history: Any, history_frames: int) -> tuple[torch.Tensor, torch.Tensor]:
    if history is None:
        values = np.zeros((0, 3), dtype=np.float32)
    elif isinstance(history, torch.Tensor):
        values = history.detach().float().cpu().numpy()
    else:
        try:
            values = np.asarray(history, dtype=np.float32)
        except (TypeError, ValueError) as error:
            raise ValueError("history 必须是形状为 (N, 3) 的有限数值序列") from error
    if values.size == 0:
        values = np.zeros((0, 3), dtype=np.float32)
    elif values.ndim == 1 and values.shape[0] == 3:
        values = values.reshape(1, 3)
    if values.ndim != 2 or values.shape[1] != 3:
        raise ValueError("history 必须是形状为 (N, 3) 的有限数值序列")
    if not np.all(np.isfinite(values)):
        raise ValueError("history 不能包含 NaN 或无穷值")
    values = values[-history_frames:]
    padded = np.zeros((history_frames, 3), dtype=np.float32)
    if len(values):
        padded[-len(values) :] = values
    return torch.from_numpy(padded).unsqueeze(0), torch.tensor([len(values)], dtype=torch.long)


class WaypointPredictor:
    """从训练 checkpoint 执行单张图像的机体坐标航点推理。"""

    def __init__(
        self,
        checkpoint: str | Path,
        device: str | torch.device | None = None,
        *,
        strip_direction: bool | None = None,
        _checkpoint_snapshot: tuple[Mapping[str, Any], str] | None = None,
    ):
        requested = torch.device(device or ("cuda" if torch.cuda.is_available() else "cpu"))
        if requested.type == "cuda" and not torch.cuda.is_available():
            raise RuntimeError(f"请求设备 {requested}，但当前 PyTorch 未检测到 CUDA")
        self.device = requested
        payload, self.checkpoint_sha256 = (
            _load_checkpoint_snapshot(checkpoint) if _checkpoint_snapshot is None else _checkpoint_snapshot
        )
        vocab, self.length_scale, config = _validate_checkpoint(payload)
        if config["architecture"] in AERIAL_ARCHITECTURES and self.__class__ is WaypointPredictor:
            raise CheckpointFormatError("八动作路线checkpoint需要AerialActionPredictor，不能解释为位移")
        stored_strip = config.get("strip_direction")
        if stored_strip is not None and not isinstance(stored_strip, bool):
            raise CheckpointFormatError("model_config.strip_direction 必须是布尔值")
        if strip_direction is not None and not isinstance(strip_direction, bool):
            raise ValueError("strip_direction 必须是布尔值或 None")
        if stored_strip is None and strip_direction is None:
            raise CheckpointFormatError(
                "历史 checkpoint 未记录 model_config.strip_direction；"
                "请按训练设置显式传入 strip_direction=True 或 False"
            )
        if stored_strip is not None and strip_direction is not None and stored_strip != strip_direction:
            raise ValueError("strip_direction 与 checkpoint 中的训练设置不一致")
        self.strip_direction = stored_strip if stored_strip is not None else strip_direction
        config["strip_direction"] = self.strip_direction
        self.vocab = Vocab([], tokenizer_version=config.get("tokenizer_version", "fov_numeric_v1"))
        self.vocab.words = vocab
        self.config = config
        self.image_mean, self.image_std = _normalization(config)
        self.model = _build_without_download(len(vocab), config)
        if config["architecture"] == "aerial_route_dino_v5":
            actual = self.model.visual_encoder
            expected = config["visual_encoder"]
            for field in ("version", "variant", "input_size", "patch_size", "embed_dim",
                          "grid_size", "frozen", "token_protocol"):
                if actual.get(field) != expected.get(field):
                    raise CheckpointFormatError(f"v5 DINOv3 {field}与checkpoint不一致")
            if actual.get("repo_source_sha256") != expected.get("repo_source_sha256"):
                raise CheckpointFormatError("v5 DINOv3源码SHA与checkpoint不一致")
        try:
            self.model.load_state_dict(payload["model"], strict=True)
        except (RuntimeError, TypeError) as error:
            raise CheckpointFormatError(f"checkpoint.model 与当前 WaypointNet 结构不匹配: {error}") from error
        self.model.to(self.device).eval()

    @classmethod
    def from_checkpoint(
        cls,
        checkpoint: str | Path,
        device: str | torch.device | None = None,
        *,
        strip_direction: bool | None = None,
    ) -> "WaypointPredictor":
        return cls(checkpoint, device=device, strip_direction=strip_direction)

    def _synchronize(self) -> None:
        if self.device.type == "cuda":
            torch.cuda.synchronize(self.device)

    def _batch(self, image: Image.Image | np.ndarray | str | Path, instruction: str, history: Any) -> dict[str, torch.Tensor]:
        if not isinstance(instruction, str) or not instruction.strip():
            raise ValueError("instruction 必须是非空字符串")
        instruction = (instruction.strip() if self.config["architecture"] in AERIAL_ARCHITECTURES
                       else instruction.replace("<image>", " ").strip())
        if self.strip_direction:
            instruction = strip_direction_cue(instruction)
        if not instruction:
            raise ValueError("instruction 预处理后不能为空")
        if self.config["text_control"] == "constant":
            instruction = "<unk>" if self.config["architecture"] in ("aerial_route_recurrent_v2", "aerial_route_recurrent_rgbd_v3", "aerial_route_dino_v5") else "<neutral>"
        image_tensor = preprocess_rgb(_as_rgb_image(image), self.config["imgsz"], self.image_mean, self.image_std)
        ids = self.vocab.encode(instruction)
        tokens = torch.tensor([ids], dtype=torch.long)
        token_mask = torch.ones_like(tokens, dtype=torch.bool)
        history_tensor, history_length = _as_history(history, self.config["history_frames"])
        if self.config["ablate"] == "no_history":
            history_tensor.zero_()
            history_length.zero_()
        return {
            "tokens": tokens.to(self.device),
            "token_mask": token_mask.to(self.device),
            "image": image_tensor.unsqueeze(0).to(self.device),
            "history": history_tensor.to(self.device),
            "history_length": history_length.to(self.device),
        }

    def predict(
        self,
        image: Image.Image | np.ndarray | str | Path,
        instruction: str,
        history: Any = None,
    ) -> dict[str, Any]:
        """预测下一步机体坐标位移，并返回端到端单步延迟（毫秒）。"""

        self._synchronize()
        started = time.perf_counter()
        batch = self._batch(image, instruction, history)
        self._synchronize()
        with torch.inference_mode():
            prediction = self.model(batch)
        self._synchronize()
        stop_probability = None
        if self.config["stop_enabled"]:
            if not isinstance(prediction, dict) or prediction["stop_logit"].shape != (1,):
                raise RuntimeError("启用STOP时模型必须输出位移和单个停止logit")
            logit = prediction["stop_logit"].float()
            if not torch.isfinite(logit).all():
                raise RuntimeError("停止logit包含非有限数")
            stop_probability = float(torch.sigmoid(logit)[0].cpu())
            prediction = prediction["body_displacement"]
        if prediction.shape != (1, 3):
            raise RuntimeError("模型输出必须是形状为 (1, 3) 的有限机体坐标位移")
        displacement = prediction[0].detach().float().cpu().tolist()
        if not np.all(np.isfinite(displacement)):
            raise RuntimeError("模型输出必须是形状为 (1, 3) 的有限机体坐标位移")
        return {
            "body_displacement": [float(value) for value in displacement],
            "latency_ms": (time.perf_counter() - started) * 1000.0,
            "device": str(self.device),
            "stop_enabled": self.config["stop_enabled"],
            "stop_probability": stop_probability,
        }


class AerialActionPredictor(WaypointPredictor):
    """路线动作推理；历史只接受已执行动作ID或等价的one-hot行。"""

    def __init__(self, checkpoint, device=None, *, _checkpoint_snapshot=None):
        super().__init__(checkpoint, device=device, strip_direction=False,
                         _checkpoint_snapshot=_checkpoint_snapshot)
        if self.config["architecture"] not in AERIAL_ARCHITECTURES:
            raise CheckpointFormatError("AerialActionPredictor只接受版本化八动作路线checkpoint")
        self.reset_episode()

    def reset_episode(self):
        """每个真实episode开始时调用；不允许沿用上条路线的记忆和文本绑定。"""
        self._state = None
        self._session_instruction = None

    def observation_state(self):
        """仅供显式诊断记录，不改变策略状态，也不访问目标或参考路线。"""
        if self._state is None:
            return None
        if isinstance(self._state, tuple):
            return tuple(part.detach().float().cpu().numpy().copy() for part in self._state)
        return self._state.detach().float().cpu().numpy().copy()

    @classmethod
    def from_checkpoint(cls, checkpoint, device=None, *, strip_direction=None):
        if strip_direction not in (None, False):
            raise ValueError("AerialVLN-S路线指令保持原文，strip_direction必须False")
        return cls(checkpoint, device=device)

    def _batch(self, image, instruction, history):
        batch = super()._batch(image, instruction, None)
        if history is None:
            values = np.zeros((0, 8), dtype=np.float32)
        else:
            raw = history.detach().cpu().numpy() if isinstance(history, torch.Tensor) else np.asarray(history)
            if raw.size == 0:
                values = np.zeros((0, 8), dtype=np.float32)
            elif raw.ndim == 1 and raw.dtype.kind in "iu" and not np.any((raw < 0) | (raw > 7)):
                values = np.eye(8, dtype=np.float32)[raw.astype(np.int64)]
            elif (raw.ndim == 2 and raw.shape[1] == 8 and raw.dtype.kind in "fiu" and np.all(np.isfinite(raw))
                  and np.all((raw == 0) | (raw == 1)) and np.all(raw.sum(axis=1) == 1)):
                values = raw.astype(np.float32)
            else:
                raise ValueError("history必须是0至7的已执行动作ID列表或Nx8 one-hot，不能包含当前位置/目标")
        values = values[-self.config["history_frames"]:]
        padded = np.zeros((self.config["history_frames"], 8), dtype=np.float32)
        if len(values):
            padded[-len(values):] = values
        batch["history"] = torch.from_numpy(padded).unsqueeze(0).to(self.device)
        batch["history_length"] = torch.tensor([len(values)], dtype=torch.long, device=self.device)
        if self.config["architecture"] == "aerial_route_recurrent_clause_v3":
            clauses = self._clause_features(instruction)
            batch["clause_features"] = clauses.unsqueeze(0).to(self.device)
            batch["clause_mask"] = torch.ones(1, len(clauses), dtype=torch.bool, device=self.device)
        if self.config["ablate"] == "no_history":
            batch["history"].zero_()
            batch["history_length"].zero_()
        return batch

    def _clause_features(self, instruction):
        """v3在线：与训练缓存相同的冻结CLIP子句编码，按指令缓存；不访问目标或参考路线。"""
        from uavnav.avln.data import build_text_feature_cache
        cache = getattr(self, "_clause_cache", None)
        if cache is None:
            cache = self._clause_cache = {}
        text = instruction.strip()
        if text not in cache:
            import tempfile
            with tempfile.TemporaryDirectory() as tmp:
                payload = build_text_feature_cache([text], Path(tmp) / "t.pt", self.device)
            cache[text] = next(iter(payload["clauses"].values())).float()
        return cache[text]

    def predict_action(self, image, instruction, history=None, depth=None):
        self._synchronize()
        started = time.perf_counter()
        batch = self._batch(image, instruction, history)
        if self.config["architecture"] in RGBD_ARCHITECTURES:
            if depth is None:
                raise ValueError("RGB-D在线策略缺少当前真实front_0归一化深度，禁止零填充")
            batch["depth"] = preprocess_depth(depth).unsqueeze(0).to(self.device)
        recurrent = self.config["architecture"] != "aerial_route_v1"
        if recurrent and self._session_instruction is not None and instruction.strip() != self._session_instruction:
            raise ValueError("路线状态已绑定另一条指令，新episode必须先reset_episode()")
        with torch.inference_mode():
            if recurrent:
                logits, state = self.model.forward_step(batch, self._state)
            else:
                logits, state = self.model(batch), None
            logits = logits.float()
        self._synchronize()
        if logits.shape != (1, 8) or not torch.isfinite(logits).all():
            raise RuntimeError("路线模型必须输出有限(1,8)动作logits")
        if recurrent:
            parts = state if isinstance(state, tuple) else (state,)
            if not all(torch.isfinite(part).all() for part in parts):
                raise RuntimeError("路线记忆包含非有限状态")
            if self.config["architecture"] in AIRVLN_BASELINES and tuple(state.shape) != (self.config["memory_layers"], 1, 512):
                raise RuntimeError("官方RGB网络在线记忆必须为[L,1,512]")
            self._state = tuple(part.detach() for part in state) if isinstance(state, tuple) else state.detach()
            self._session_instruction = instruction.strip()
        probabilities = logits.softmax(-1)[0].cpu().tolist()
        return {"action": int(logits.argmax(-1)[0].cpu()), "action_probabilities": probabilities,
                "stop_probability": probabilities[0], "stop_enabled": True,
                "latency_ms": (time.perf_counter() - started) * 1000.0, "device": str(self.device)}

    def predict_sequence(self, batch, state=None):
        """审核一个episode连续教师状态；外部传递chunk状态，不改在线会话记忆。"""
        if self.config["architecture"] == "aerial_route_v1":
            raise ValueError("连续记忆审核只适用于版本化循环路线策略")
        prepared = {key: value.to(self.device) for key, value in batch.items()}
        if self.config["text_control"] == "constant":
            prepared["tokens"] = torch.full((len(prepared["image"]), 1), self.vocab.words["<unk>"],
                                             dtype=torch.long, device=self.device)
            prepared["token_mask"] = torch.ones_like(prepared["tokens"], dtype=torch.bool)
        if state is not None:
            state = tuple(part.to(self.device) for part in state) if isinstance(state, tuple) else state.to(self.device)
        with torch.inference_mode():
            logits, following = self.model.forward_sequence(prepared, state)
        parts = following if isinstance(following, tuple) else (following,)
        if not torch.isfinite(logits).all() or not all(torch.isfinite(part).all() for part in parts):
            raise RuntimeError("连续路线审核产生非有限动作或记忆")
        return logits.float().cpu(), (tuple(part.detach() for part in following)
                                      if isinstance(following, tuple) else following.detach())

    def predict(self, image, instruction, history=None, depth=None):
        return self.predict_action(image, instruction, history, depth=depth)


def load_predictor(
    checkpoint: str | Path,
    device: str | torch.device | None = None,
    *,
    strip_direction: bool | None = None,
) -> WaypointPredictor:
    """加载 checkpoint 并返回可复用的单步推理器。"""

    snapshot = _load_checkpoint_snapshot(checkpoint)
    config = _require_mapping(snapshot[0].get("model_config", {}), "model_config")
    if config.get("architecture") in AERIAL_ARCHITECTURES:
        if strip_direction not in (None, False):
            raise ValueError("AerialVLN-S路线指令保持原文，strip_direction必须False")
        return AerialActionPredictor(checkpoint, device=device, _checkpoint_snapshot=snapshot)
    return WaypointPredictor(checkpoint, device=device, strip_direction=strip_direction,
                             _checkpoint_snapshot=snapshot)


def predict_single(
    checkpoint: str | Path,
    image: Image.Image | np.ndarray | str | Path,
    instruction: str,
    history: Any = None,
    device: str | torch.device | None = None,
    *,
    strip_direction: bool | None = None,
) -> dict[str, Any]:
    """一次性加载 checkpoint 并执行单步推理。"""

    return load_predictor(checkpoint, device=device, strip_direction=strip_direction).predict(image, instruction, history)


__all__ = [
    "CheckpointFormatError",
    "WaypointPredictor",
    "AerialActionPredictor",
    "load_predictor",
    "predict_single",
]
