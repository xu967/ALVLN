"""UAV-VLN-FOV 离线静态轨迹适配器。

只读取真实 ``log/*.json`` 和 ``FrontCamera``/``frontcamera`` 接口。
``reset()`` 和 ``step(action_body)`` 都返回 rollout.Observation。
action_body 是当前机体坐标系中的三维位移，单位米。每次 step 根据当前
记录姿态将它转换成 world_target 并记录，然后播放下一条记录中的图像、
位置与姿态。动作不会改变回放状态，因此该适配器只能验证数据流，不能
产生真实闭环导航指标。代码不调用或假定 AirSim API。
"""

from __future__ import annotations

import json
import time
from pathlib import Path
from typing import Any

import numpy as np
from scipy.spatial.transform import Rotation as R

from uavnav.avln.data import _frames
from uavnav.avln.rollout import Observation


def _action_vector(value: Any) -> np.ndarray:
    array = np.asarray(value, dtype=np.float64)
    if array.shape != (3,) or not np.isfinite(array).all():
        raise ValueError(f"action_body 必须是有限的形状 (3,) 向量，收到 shape={array.shape}")
    return array


def _source_timestamp(value: Any) -> int | float | None:
    """兼容原始数字字符串，保留整数精度，不推断或转换时间单位。"""
    if isinstance(value, bool):
        return None
    if isinstance(value, str):
        try:
            value = int(value.strip())
        except ValueError:
            try:
                value = float(value.strip())
            except ValueError:
                return None
    if isinstance(value, (int, float)) and np.isfinite(value):
        return value
    return None


class StaticTrajectoryEnv:
    """保留记录图像与位姿一致性的离线回放。

    日志中可选时间戳和碰撞字段的依据是 AeroVLA 客户端的 State.retrieve：
    ``sensors.state.timestamp`` 与 ``sensors.state.collision.has_collided``。
    不存在这些字段时返回 None，不能将未知碰撞状态解释为没有碰撞。
    原始 timestamp 保留原始数值与单位，不凭帧编号推算传感器时间。
    """

    replay = True
    replay_semantics = "recorded_observations; commanded_action_logged_only"

    def __init__(self, trajectory_dir: str | Path):
        self.trajectory_dir = Path(trajectory_dir)
        if not self.trajectory_dir.is_dir():
            raise FileNotFoundError(f"轨迹目录不存在: {self.trajectory_dir}")
        self._frames, self.frame_gap = _frames(self.trajectory_dir)
        # 与训练同样对齐 pose/image；元信息只从对应原始 log 读取。
        log_paths = {int(path.stem): path for path in (self.trajectory_dir / "log").glob("*.json")}
        self._raw_states = {
            index: json.loads(log_paths[index].read_text(encoding="utf-8"))["sensors"]["state"]
            for _, _, index in self._frames
        }
        self._cursor = 0
        self._started = False
        self._done = False
        self.events: list[dict[str, Any]] = []
        self._observation: Observation | None = None

    @property
    def observation(self) -> Observation:
        """取得当前记录帧；调用方必须先 reset。"""
        if self._observation is None:
            raise RuntimeError("请先调用 reset()")
        return self._observation

    def reset(self) -> Observation:
        self._cursor = 0
        self._started = True
        self._done = False
        self.events = []
        self._observation = self._make_observation(event="reset")
        self._record(self._observation)
        return self._observation

    def step(self, action_body: Any) -> Observation:
        """记录动作及世界目标，随后返回下一条真实记录帧。"""
        if not self._started:
            raise RuntimeError("请先调用 reset()")
        if self._done:
            raise RuntimeError("轨迹已经终止，请先调用 reset()")
        action = _action_vector(action_body)
        current = self.observation
        displacement_world = R.from_quat(current.orientation).apply(action)
        world_target = current.position + displacement_world
        self._cursor += 1
        self._done = self._cursor == len(self._frames) - 1
        self._observation = self._make_observation(
            event="step",
            commanded_action_body=action.tolist(),
            commanded_displacement_world=displacement_world.tolist(),
            world_target=world_target.tolist(),
            actual_frame_gap=self._frames[self._cursor][2] - self._frames[self._cursor - 1][2],
        )
        self._record(self._observation)
        return self._observation

    def _make_observation(self, *, event: str, **action_info: Any) -> Observation:
        state, image, index = self._frames[self._cursor]
        raw_state = self._raw_states[index]
        raw_timestamp = raw_state.get("timestamp")
        timestamp = _source_timestamp(raw_timestamp)
        timestamp_known = timestamp is not None
        raw_collision = raw_state.get("collision")
        collision = raw_collision.get("has_collided") if isinstance(raw_collision, dict) else None
        collision_known = isinstance(collision, bool)
        info = {
            "event": event,
            "frame_index": int(index),
            "wall_timestamp": time.time(),
            "timestamp_source": "sensors.state.timestamp" if timestamp_known else None,
            "timestamp_units": "source_native" if timestamp_known else None,
            "source_timestamp_raw": raw_timestamp,
            "collision_known": collision_known,
            "collision_source": "sensors.state.collision.has_collided" if collision_known else None,
            "replay": True,
            "replay_semantics": self.replay_semantics,
            "action_applied": False,
            "reference_frame_gap": self.frame_gap,
            **action_info,
        }
        return Observation(
            image=image,
            position=np.asarray(state["position"], dtype=np.float64).copy(),
            orientation=np.asarray(state["orientation"], dtype=np.float64).copy(),
            timestamp=timestamp,
            collision=collision if collision_known else None,
            done=self._done,
            termination_reason="trajectory_end" if self._done else None,
            info=info,
        )

    def _record(self, observation: Observation) -> None:
        self.events.append(
            {
                "timestamp": observation.timestamp,
                "position": observation.position.tolist(),
                "orientation": observation.orientation.tolist(),
                "collision": observation.collision,
                "done": observation.done,
                "termination_reason": observation.termination_reason,
                "info": dict(observation.info),
            }
        )
