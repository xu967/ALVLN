"""统一的单智能体导航 rollout 接口。

该模块只定义模型和环境之间的契约，不直接依赖 AirSim。环境负责提供当前
观测并执行机体坐标系位移，模型负责返回下一步机体坐标系位移。这样离线
轨迹回放和真实仿真器可以共享同一份日志格式，同时不会把离线回放误报为
真实闭环导航结果。
"""

from __future__ import annotations

import json
import time
from dataclasses import dataclass, field
from pathlib import Path
from typing import Any, Callable, Protocol, Sequence

import numpy as np

from uavnav.avln.geometry import body_offset


def _vector(value: Any, name: str, size: int) -> np.ndarray:
    array = np.asarray(value, dtype=np.float64)
    if array.shape != (size,) or not np.isfinite(array).all():
        raise ValueError(f"{name} 必须是有限的 shape=({size},) 向量，实际为 {array.shape}")
    return array


@dataclass
class Observation:
    """环境在一个时刻返回的观测。

    ``image`` 可以是图像路径或 HWC 的 RGB 数组。真实环境必须提供位置和
    ``(x, y, z, w)`` 四元数，便于统一计算机体坐标系的实际位移。
    """

    image: Any
    position: np.ndarray
    orientation: np.ndarray
    timestamp: float | None = None
    collision: bool | None = None
    done: bool = False
    termination_reason: str | None = None
    goal_position: np.ndarray | None = None
    reference_length: float | None = None
    info: dict[str, Any] = field(default_factory=dict)

    def __post_init__(self) -> None:
        if isinstance(self.collision, np.bool_):
            self.collision = bool(self.collision)
        if self.collision is not None and not isinstance(self.collision, bool):
            raise ValueError("collision 必须是 bool 或 None")
        if self.timestamp is not None and (isinstance(self.timestamp, bool) or not np.isfinite(self.timestamp)):
            raise ValueError("timestamp 必须是有限数或 None")
        self.position = _vector(self.position, "position", 3)
        self.orientation = _vector(self.orientation, "orientation", 4)
        if np.linalg.norm(self.orientation) < 1e-12:
            raise ValueError("orientation 四元数范数不能为 0")
        if self.goal_position is not None:
            self.goal_position = _vector(self.goal_position, "goal_position", 3)
        if self.reference_length is not None:
            self.reference_length = float(self.reference_length)
            if not np.isfinite(self.reference_length) or self.reference_length < 0:
                raise ValueError("reference_length 必须是非负有限数")


class NavigationEnv(Protocol):
    """单智能体环境的最小接口。"""

    replay: bool

    def reset(self) -> Observation:
        ...

    def step(self, action_body: Sequence[float]) -> Observation:
        ...


class Predictor(Protocol):
    def predict(
        self,
        image: Any,
        instruction: str,
        history: np.ndarray,
    ) -> Any:
        ...


def rollout_prediction(predictor: Predictor | Callable[..., Any], image: Any, instruction: str, history: np.ndarray) -> tuple[np.ndarray, bool, float | None]:
    if hasattr(predictor, "predict"):
        value = predictor.predict(image=image, instruction=instruction, history=history)
    else:
        value = predictor(image=image, instruction=instruction, history=history)
    stop_enabled = False
    probability = None
    if isinstance(value, dict):
        stop_enabled = value.get("stop_enabled", False)
        if not isinstance(stop_enabled, (bool, np.bool_)):
            raise ValueError("stop_enabled 必须为 bool")
        if stop_enabled:
            raw_probability = value.get("stop_probability")
            if isinstance(raw_probability, (bool, np.bool_)) or not isinstance(raw_probability, (int, float, np.number)):
                raise ValueError("stop_probability 必须是有限的 [0, 1] 数值")
            probability = float(raw_probability)
            if not np.isfinite(probability) or not 0 <= probability <= 1:
                raise ValueError("stop_probability 必须是有限的 [0, 1] 数值")
    if hasattr(value, "action_body"):
        value = value.action_body
    elif isinstance(value, dict):
        value = value.get("body_displacement", value.get("action_body", value.get("action", value.get("offset"))))
    action = _vector(value, "predictor output", 3)
    return action.astype(np.float32), bool(stop_enabled), probability


def _predict(predictor: Predictor | Callable[..., Any], image: Any, instruction: str, history: np.ndarray) -> np.ndarray:
    """兼容旧调用者；rollout 本身使用完整决策。"""
    return rollout_prediction(predictor, image, instruction, history)[0]


def _observation_evidence(observation: Observation) -> dict[str, Any]:
    return {
        "position": observation.position.tolist(),
        "orientation": observation.orientation.tolist(),
        "timestamp": observation.timestamp,
        "collision": observation.collision,
    }


def _history_for_observation(poses: list[Observation], current: Observation, limit: int) -> np.ndarray:
    if limit <= 0 or not poses:
        return np.zeros((0, 3), dtype=np.float32)
    recent = poses[-limit:]
    return np.stack(
        [
            body_offset(
                past.position,
                past.orientation,
                current.position,
                current.orientation,
            )
            for past in recent
        ],
        axis=0,
    ).astype(np.float32)


def _json_value(value: Any) -> Any:
    if isinstance(value, np.ndarray):
        return value.tolist()
    if isinstance(value, (np.floating, np.integer, np.bool_)):
        return value.item()
    if isinstance(value, dict):
        return {str(key): _json_value(item) for key, item in value.items()}
    if isinstance(value, (list, tuple)):
        return [_json_value(item) for item in value]
    return value


def rollout_episode(
    env: NavigationEnv,
    predictor: Predictor | Callable[..., Any],
    instruction: str,
    history_frames: int = 8,
    max_steps: int = 64,
    seed: int = 0,
    stop_threshold: float | None = None,
) -> dict[str, Any]:
    """执行一条 episode，并返回可序列化的审计日志。

    ``env.replay`` 为真时，日志状态来自记录轨迹，动作只被记录而不改变
    环境。该模式用于检查数据流，不产生闭环导航指标。
    """

    if not isinstance(instruction, str) or not instruction.strip() or max_steps <= 0 or history_frames < 0:
        raise ValueError("instruction 不能为空，max_steps 必须为正数，history_frames 不能为负数")
    replay = bool(getattr(env, "replay", False))
    if not replay and getattr(env, "actions_executed", None) is not True:
        raise ValueError("真实环境必须显式声明 actions_executed=True；回放环境必须声明 replay=True")
    observation = env.reset()
    initial_observation = _observation_evidence(observation)
    if observation.done or observation.collision:
        raise RuntimeError("reset 后环境已经终止或碰撞，拒绝执行 episode")
    previous: list[Observation] = []
    records: list[dict[str, Any]] = []
    started = time.perf_counter()
    termination_reason = "max_steps"
    stop_active = False
    terminal_decision = None

    for step in range(max_steps):
        step_started = time.perf_counter()
        history = _history_for_observation(previous, observation, history_frames)
        infer_started = time.perf_counter()
        action, stop_enabled, probability = rollout_prediction(predictor, observation.image, instruction, history)
        inference_ms = (time.perf_counter() - infer_started) * 1000.0
        if stop_enabled:
            if isinstance(stop_threshold, (bool, np.bool_)) or not isinstance(stop_threshold, (int, float, np.number)) or not np.isfinite(stop_threshold) or not 0 <= stop_threshold <= 1:
                raise ValueError("启用 STOP 必须配置有限的 [0, 1] stop_threshold")
            stop_active = True
            if probability >= stop_threshold:
                termination_reason = "model_stop"
                terminal_decision = {
                    "reason": "model_stop", "observation": _observation_evidence(observation),
                    "stop_enabled": True, "stop_probability": probability,
                    "stop_threshold": float(stop_threshold), "inference_ms": float(inference_ms),
                }
                break
        next_observation = env.step(action)
        end_to_end_ms = (time.perf_counter() - step_started) * 1000.0
        actual_body = body_offset(
            next_observation.position,
            next_observation.orientation,
            observation.position,
            observation.orientation,
        ).astype(np.float32)
        records.append(
            {
                "step": step,
                "timestamp": observation.timestamp,
                "next_timestamp": next_observation.timestamp,
                "position": observation.position.tolist(),
                "orientation": observation.orientation.tolist(),
                "commanded_action_body": action.tolist(),
                "actual_displacement_body": actual_body.tolist(),
                "next_position": next_observation.position.tolist(),
                "next_orientation": next_observation.orientation.tolist(),
                "collision": next_observation.collision,
                "action_executed": not replay,
                "done": bool(next_observation.done),
                "termination_reason": next_observation.termination_reason,
                "inference_ms": float(inference_ms),
                "end_to_end_ms": float(end_to_end_ms),
                "info": _json_value(next_observation.info),
            }
        )
        previous.append(observation)
        observation = next_observation
        if observation.collision:
            termination_reason = observation.termination_reason or "collision"
            break
        if observation.done:
            termination_reason = observation.termination_reason or "done"
            break

    if termination_reason in ("max_steps", "model_stop") and hasattr(env, "finish"):
        env.finish()
    if records and termination_reason != "model_stop":
        records[-1]["done"] = True
        records[-1]["termination_reason"] = termination_reason
    elapsed_ms = (time.perf_counter() - started) * 1000.0
    goal = observation.goal_position
    final_distance = None if goal is None else float(np.linalg.norm(observation.position - goal))
    result = {
        "status": "replay_only" if replay else "closed_loop",
        "replay": replay,
        "actions_executed": not replay,
        "done": True,
        "seed": int(seed),
        "instruction": instruction,
        "steps": len(records),
        "termination_reason": termination_reason,
        "collision": True if any(r["collision"] is True for r in records) else (False if all(r["collision"] is False for r in records) else None),
        "final_position": observation.position.tolist(),
        "goal_position": None if goal is None else goal.tolist(),
        "final_distance": final_distance,
        "reference_length": observation.reference_length,
        "elapsed_ms": elapsed_ms,
        "records": records,
    }
    if stop_active:
        result.update({
            "schema_version": 2, "stop_enabled": True,
            "termination_kind": "model_stop" if termination_reason == "model_stop" else ("collision" if observation.collision else ("horizon" if termination_reason == "max_steps" else "environment_done")),
            "stop_threshold": float(stop_threshold),
            "initial_observation": initial_observation,
            "terminal_observation": _observation_evidence(observation),
            "terminal_decision": terminal_decision,
            "actions_executed_count": 0 if replay else len(records),
            "collision": True if observation.collision is True or any(r["collision"] is True for r in records) else (False if initial_observation["collision"] is False and observation.collision is False and all(r["collision"] is False for r in records) else None),
        })
    return _json_value(result)


def write_rollout(path: str | Path, result: dict[str, Any]) -> None:
    """原子写入一条 rollout 日志，避免中断时留下半个 JSON。"""

    destination = Path(path)
    destination.parent.mkdir(parents=True, exist_ok=True)
    temporary = destination.with_suffix(destination.suffix + ".tmp")
    temporary.write_text(json.dumps(_json_value(result), ensure_ascii=False, indent=2, allow_nan=False), encoding="utf-8")
    temporary.replace(destination)
