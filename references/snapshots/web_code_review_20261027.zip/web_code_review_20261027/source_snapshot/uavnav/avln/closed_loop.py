"""读取实际 rollout 日志，审计后生成静态闭环指标。

没有 ``eval_dir`` 时保留训练阶段的 ``open_loop_only`` 和 null 指标。
回放、未执行动作、缺少终止证据的日志不会产生导航指标；只聚合实际
记录的碰撞与推理时延。SR、OSR、SPL 使用百分数，NE 使用米。
"""

import contextlib
import json
import hashlib
import os
import re
import time
from pathlib import Path

import numpy as np

from uavnav.avln.metadata import (
    aerial_scoring_truth_sha256, canonical_eval_split, evaluation_manifest_sha256, validate_evaluation_manifest,
)

METRIC_KEYS = ("ne", "sr", "osr", "spl")
PENDING_KEYS = (
    "success_rate_no_collision", "constraint_violation_rate", "collision_rate",
    "timeout_rate", "recovery_rate_after_dynamic", "min_clearance", "replan_count",
    "latency_p50", "latency_p95", "peak_vram_gb",
)


class ClosedLoopAuditError(ValueError):
    """日志缺少计算可靠指标所必需的字段。"""


class AerialPolicyError(ValueError):
    """策略执行或输出不合法；未完成轨迹不得伪造成导航失败成绩。"""


def _resource_failure(error):
    """沿异常链识别显存/内存失败，避免把基础设施问题计成策略错误。"""
    seen = set()
    while error is not None and id(error) not in seen:
        seen.add(id(error))
        kind = type(error)
        if isinstance(error, MemoryError) or (
                kind.__name__ == "OutOfMemoryError" and kind.__module__.startswith("torch")):
            return True
        error = getattr(error, "__cause__", None)
    return False


def aerial_error_category(error, stage):
    """只承认环境阶段的显式连接/超时类型，不据异常文本猜测RPC。"""
    if _resource_failure(error):
        return "infrastructure_error"
    if isinstance(error, AerialPolicyError):
        return "policy_error"
    if stage in ("reset_request", "action_dispatch", "finish_request", "environment_construct"):
        kind = type(error)
        typed_rpc = (kind.__module__.startswith("msgpackrpc.")
                     and kind.__name__ in ("TimeoutError", "TransportError", "RPCError"))
        if isinstance(error, (ConnectionError, TimeoutError)) or typed_rpc:
            return "infrastructure_error"
    return "unknown_error"


STOP_SUCCESS_BASIS = "final_within_success_distance_and_predicted_stop_and_no_collision"

AERIAL_METRIC_KEYS = ("ne", "sr", "osr", "ndtw", "sdtw", "autonomous_stop_success")
AERIAL_METRIC_PROTOCOLS = ("airvln_xy20_fastdtw_v1", "eval_adapter_v2")


def aerial_evaluation_protocol(task_protocol, max_steps, evaluation_scope):
    """新评分合同与策略任务合同分开绑定，不更改历史 checkpoint。"""
    return validate_aerial_evaluation_protocol({
        "schema_version": 2, "task_protocol": task_protocol,
        "metric_protocol": "eval_adapter_v2", "max_steps": max_steps,
        "evaluation_scope": evaluation_scope,
        "position_sampling": "initial_and_after_actions_exact_xyz_deduplicated",
        "termination_protocol": "terminal_reason_frozen_before_scoring_v2",
    })


def validate_aerial_evaluation_protocol(protocol):
    from uavnav.avln.metadata import validate_aerial_task_protocol
    fields = {"schema_version", "task_protocol", "metric_protocol", "max_steps",
              "evaluation_scope", "position_sampling", "termination_protocol"}
    if not isinstance(protocol, dict) or set(protocol) != fields:
        raise ValueError("eval_adapter_v2 评分合同字段缺失或不支持")
    result = dict(protocol)
    if (type(result["schema_version"]) is not int or result["schema_version"] != 2
            or result["metric_protocol"] != "eval_adapter_v2"
            or result["position_sampling"] != "initial_and_after_actions_exact_xyz_deduplicated"
            or result["termination_protocol"] != "terminal_reason_frozen_before_scoring_v2"):
        raise ValueError("eval_adapter_v2 评分合同版本/采样/终止时序不一致")
    result["task_protocol"] = validate_aerial_task_protocol(result["task_protocol"])
    budget, scope = result["max_steps"], result["evaluation_scope"]
    if (type(budget) is not int or not 1 <= budget <= 500
            or scope not in ("subset_diagnostic", "official_split")
            or (scope == "official_split" and budget != 500)):
        raise ValueError("eval_adapter_v2 正式范围必须500动作，开发范围为1至500动作")
    return result


def _reset_aerial_predictor(predictor):
    reset = getattr(predictor, "reset_episode", None)
    config = getattr(predictor, "config", {})
    if config.get("architecture") in ("aerial_route_recurrent_v2", "aerial_route_recurrent_clause_v3", "aerial_route_dino_v5", "airvln_seq2seq_rgb_v1", "airvln_cma_rgb_v1",
                                     "aerial_route_recurrent_rgbd_v3", "airvln_seq2seq_rgbd_v1", "airvln_cma_rgbd_v1") and not callable(reset):
        raise ValueError("循环路线策略必须提供reset_episode，不能跨episode保留hidden")
    if callable(reset):
        reset()
        return True
    return False


class AerialBaselinePolicy:
    """不读图像/指令/目标的下限策略；random 用独立种子，forward 恒前进，二者都不输出 STOP。"""

    config = {"architecture": "aerial_route_v1", "history_frames": 8}

    def __init__(self, kind, seed=0, stop_after=None):
        if kind not in ("random", "forward") or type(seed) is not int:
            raise ValueError("基线策略只支持random/forward及整数seed")
        if stop_after is not None and (type(stop_after) is not int or stop_after < 0):
            raise ValueError("stop_after必须是非负整数或None")
        self.kind, self.seed, self.stop_after = kind, seed, stop_after
        self.reset_episode()

    def reset_episode(self):
        self._rng = np.random.default_rng(self.seed)

    def predict_action(self, image, instruction, history=None):
        if self.stop_after is not None and len(history or []) >= self.stop_after:
            action = 0
        elif self.kind == "forward":
            action = 1
        else:
            action = int(self._rng.integers(1, 8))
        probabilities = np.zeros(8)
        probabilities[action] = 1.
        return {"action": action, "action_probabilities": probabilities.tolist()}


def _aerial_policy_action(predictor, image, instruction, past, depth=None):
    if getattr(predictor, "config", {}).get("input_modality") == "rgbd":
        if depth is None:
            raise ValueError("RGB-D策略缺少当前真实深度，拒绝用零图替代")
        return predictor.predict_action(image, instruction, past, depth=depth)
    return predictor.predict_action(image, instruction, past)


def collect_aerial_dagger_episode(env, predictor, teacher, episode, output, *, beta, seed=0,
                                 max_steps=500, history_frames=8, save_depth=False, depth_storage="npy_float_v1"):
    """训练期混合策略采集；教师读当前状态，部署策略仍只读传感器和合法历史。

    单attempt目录必须新建；调用方保留失败目录并续建新attempt，不覆盖失败。
    """
    from PIL import Image
    from uavnav.avln.data import AERIAL_CAPTURE_FRAME_FIELDS, AERIAL_RGBD_CAPTURE_FRAME_FIELDS, save_aerial_depth
    import random
    if (type(seed) is not int or seed != 0 or type(history_frames) is not int or history_frames < 0
            or type(max_steps) is not int or not 1 <= max_steps <= 500
            or isinstance(beta, bool) or not isinstance(beta, (int, float)) or not np.isfinite(beta) or not 0 <= beta < 1):
        raise ValueError("DAgger固定seed0/最多500动作且显式0<=beta<1；禁止全教师冒偏轨采集")
    if episode.get("source_split", "train") != "train" or not episode.get("actions"):
        raise ValueError("DAgger只能采有标签的训练episode")
    if bool(getattr(env, "replay", False)) or getattr(env, "actions_executed", None) is not True:
        raise ValueError("DAgger只能在实际执行动作的环境采集")
    directory = Path(output).resolve()
    directory.mkdir(parents=True, exist_ok=False)
    rows, history, pending, terminal = [], [], None, None
    rng = random.Random(seed)
    failure = None
    def save(name, value):
        destination = directory / name
        temporary = destination.with_suffix(destination.suffix + ".tmp")
        import os
        with temporary.open("w", encoding="utf-8") as stream:
            stream.write(json.dumps(value, ensure_ascii=False, indent=2, allow_nan=False))
            stream.flush()
            os.fsync(stream.fileno())
        temporary.replace(destination)
    def event(value):
        with (directory / "journal.jsonl").open("a", encoding="utf-8") as stream:
            stream.write(json.dumps(value, ensure_ascii=False, allow_nan=False) + "\n")
            stream.flush()
            import os
            os.fsync(stream.fileno())
    try:
        _reset_aerial_predictor(predictor)
        teacher.reset_episode(episode)
        event({"event": "reset_request"})
        obs = env.reset()
        if obs.done:
            raise RuntimeError("DAgger起点已终止，拒绝产生训练样本")
        for index in range(max_steps):
            past = history[-history_frames:] if history_frames else []
            depth = obs.info.get("depth_normalized")
            prediction = _aerial_policy_action(predictor, obs.image, episode["instruction"]["instruction_text"], past, depth)
            probs = np.asarray(prediction.get("action_probabilities"), dtype=float)
            policy = prediction.get("action")
            if (type(policy) is not int or not 0 <= policy < 8 or probs.shape != (8,)
                    or not np.isfinite(probs).all() or (probs < 0).any()
                    or not np.isclose(probs.sum(), 1., atol=1e-5) or policy != int(probs.argmax())):
                raise ValueError("DAgger学生动作或概率非法")
            label = teacher.label(obs, index, list(history))
            if (not isinstance(label, dict) or type(label.get("action")) is not int or not 0 <= label["action"] < 8
                    or label.get("teacher_protocol") != "airvln_upstream_pose_guard_v1"
                    or label.get("teacher_contract_sha256") != teacher.contract_sha256):
                raise ValueError("教师标签缺少当前状态审核来源")
            selected_teacher = rng.random() < beta
            action = label["action"] if selected_teacher else policy
            image_path = directory / f"{index:06d}.png"
            image = obs.image if isinstance(obs.image, Image.Image) else Image.fromarray(obs.image) if isinstance(obs.image, np.ndarray) else Image.open(obs.image)
            image.convert("RGB").save(image_path)
            frame = {"frame_index": index, "rgb": {"path": image_path.name, "sha256": hashlib.sha256(image_path.read_bytes()).hexdigest()},
                     "observed_position": obs.position.tolist(), "observed_orientation_xyzw": obs.orientation.tolist(),
                     "history_actions": list(past), "teacher_action": label["action"], "teacher_protocol": label["teacher_protocol"],
                     "reference_stage": label["reference_stage"], "predicted_action": policy, "selected_teacher": selected_teacher,
                     "executed_action": None if action == 0 else action}
            from scipy.spatial.transform import Rotation
            roll, pitch, yaw = Rotation.from_quat(obs.orientation).as_euler("xyz")
            frame["pose"] = [*obs.position.tolist(), float(pitch), float(roll), float(yaw)]
            frame["image_timestamp_s"] = obs.timestamp
            capture_fields = AERIAL_CAPTURE_FRAME_FIELDS
            if getattr(env, "capture_extrinsics", None) is not None:
                capture_fields += AERIAL_RGBD_CAPTURE_FRAME_FIELDS
            for key in capture_fields:
                frame[key] = obs.info[key]
            if save_depth or getattr(predictor, "config", {}).get("input_modality") == "rgbd":
                if depth is None:
                    raise ValueError("DAgger深度缓存缺实际传感器数据")
                depth_path = directory / (f"{index:06d}.npy.gz" if depth_storage == "npy_gzip_float32_v1" else f"{index:06d}.npy")
                frame["depth"] = save_aerial_depth(depth_path, depth, depth_storage)
            rows.append(frame)
            save("partial.json", {"status": "running", "frames": rows, "known_executed_actions": history})
            event({"event": "decision", "frame_index": index, "student_action": policy, "teacher_action": label["action"], "selected_action": action})
            if action == 0:
                terminal = "teacher_stop" if selected_teacher else "model_stop"
                break
            pending = {"frame_index": index, "action": action, "execution_state": "unknown_until_step_returns"}
            event({"event": "action_dispatch", **pending})
            following = env.step(action)
            frame["following_position"] = following.position.tolist()
            frame["following_orientation_xyzw"] = following.orientation.tolist()
            frame["following_done"] = bool(following.done)
            frame["following_termination_reason"] = following.termination_reason
            frame["following_depth_collision_fraction"] = following.info.get("depth_collision_fraction")
            history.append(action)
            pending = None
            save("partial.json", {"status": "running", "frames": rows, "known_executed_actions": history})
            event({"event": "action_completed", "frame_index": index, "action": action})
            obs = following
            if obs.done:
                if obs.termination_reason != "depth_collision_proxy":
                    raise ValueError("DAgger遇到未支持的环境终止原因")
                terminal = "depth_collision_proxy"
                break
        terminal = terminal or "max_steps"
        result = {"status": "completed", "sample_policy": "aerial_dagger_current_state_v1",
                  "termination_reason": terminal, "frames": rows, "beta": float(beta), "seed": seed,
                  "max_steps": max_steps, "history_frames": history_frames,
                  "checkpoint_sha256": getattr(predictor, "checkpoint_sha256", None),
                  "teacher_contract_sha256": teacher.contract_sha256,
                  "student_decisions": sum(not row["selected_teacher"] for row in rows)}
    except BaseException as error:
        failure = error
        save("error.json", {"status": "failed", "error": type(error).__name__ + ": " + str(error),
                            "frames": rows, "known_executed_actions": history, "pending_dispatch": pending})
        raise
    finally:
        try:
            env.finish()
        except BaseException as cleanup_error:
            save("cleanup_error.json", {"status": "failed", "error": type(cleanup_error).__name__ + ": " + str(cleanup_error),
                                        "original_error": None if failure is None else type(failure).__name__ + ": " + str(failure)})
            if failure is None:
                raise
    save("result.json", result)
    event({"event": "completed", "termination_reason": terminal})
    return result


def replay_aerial_teacher_samples(predictor, samples, *, rgb_context=None):
    """完整教师episode按帧顺序重放；模型STOP预测不截断教师诊断。"""
    from uavnav.avln.data import group_aerial_episodes, preprocess_depth
    diagnostics = []
    for episode in group_aerial_episodes(samples):
        _reset_aerial_predictor(predictor)
        for sample in episode:
            past = np.asarray(sample["history"]).argmax(axis=1).tolist() if len(sample["history"]) else []
            depth = sample.get("depth")
            if depth is not None:
                depth = preprocess_depth(depth, sample.get("depth_sha256"), sample.get("depth_storage_protocol")).squeeze(0).numpy()
            context = rgb_context(sample) if rgb_context is not None else contextlib.nullcontext(sample["image"])
            with context as image:
                prediction = _aerial_policy_action(predictor, image, sample["instruction"], past, depth)
            diagnostics.append({"scene_id": sample["scene_id"], "episode_id": sample["episode_id"],
                "frame_index": sample["frame_index"], "teacher_action": sample["action"], "prediction": prediction,
                "state_context": "teacher_observation_prefix_from_frame0",
                "teacher_history": past})
    return diagnostics


def replay_recorded_observations(predictor, manifest_path):
    """用原自主RGB/实际动作前缀重建记忆；不读取教师路线或目标。"""
    manifest_path = Path(manifest_path).resolve()
    payload = json.loads(manifest_path.read_text(encoding="utf-8"))
    if hashlib.sha256(payload["instruction"].encode()).hexdigest() != payload.get("instruction_sha256"):
        raise ValueError("实际观测指令摘要冲突")
    if (payload.get("checkpoint_sha256") is None
            or payload["checkpoint_sha256"] != getattr(predictor, "checkpoint_sha256", None)):
        raise ValueError("实际观测记录必须绑定同一checkpoint，不能重放另一模型")
    root = manifest_path.parent
    def source(name, expected):
        path = (root / name).resolve()
        if not path.is_relative_to(root) or not path.is_file() or hashlib.sha256(path.read_bytes()).hexdigest() != expected:
            raise ValueError("实际观测文件缺失、越界或摘要冲突")
        return path
    _reset_aerial_predictor(predictor)
    rows, history = [], []
    for index, frame in enumerate(payload["frames"]):
        past = history[-payload["history_frames"]:] if payload["history_frames"] else []
        if frame["decision_index"] != index or frame["history_actions"] != past:
            raise ValueError("实际观测决策时序或动作历史不连续")
        image_path = source(frame["rgb"], frame["rgb_sha256"])
        state = predictor.observation_state() if hasattr(predictor, "observation_state") else None
        state_error = None
        if frame.get("state_before") is not None:
            recorded = np.load(source(frame["state_before"], frame["state_before_sha256"]), allow_pickle=False)
            if state is None or state.shape != recorded.shape:
                raise ValueError("重放记忆的形状与原决策不符")
            state_error = float(np.max(np.abs(state - recorded)))
        depth = None
        if getattr(predictor, "config", {}).get("input_modality") == "rgbd":
            depth_path = source(frame.get("depth"), frame.get("depth_sha256"))
            depth = np.load(depth_path, allow_pickle=False)
        output = _aerial_policy_action(predictor, image_path, payload["instruction"], frame["history_actions"], depth)
        state_after_error = None
        if frame.get("state_after") is not None:
            recorded = np.load(source(frame["state_after"], frame["state_after_sha256"]), allow_pickle=False)
            state = predictor.observation_state() if hasattr(predictor, "observation_state") else None
            if state is None or state.shape != recorded.shape:
                raise ValueError("重放决策后记忆的形状与原决策不符")
            state_after_error = float(np.max(np.abs(state - recorded)))
        expected = frame["prediction"]
        error = float(np.max(np.abs(np.asarray(output["action_probabilities"]) - np.asarray(expected["action_probabilities"]))))
        rows.append({"decision_index": index, "original_action": expected["action"], "replayed_action": output["action"],
                     "probability_max_absolute_error": error, "memory_before_max_absolute_error": state_error,
                     "memory_after_max_absolute_error": state_after_error})
        if expected["action"] == 0 and index != len(payload["frames"]) - 1:
            raise ValueError("原自主STOP后不能继续重放动作")
        history.append(expected["action"])
    return {"scope": "same_actual_rgb_prefix_reproduction_not_navigation_score", "checkpoint_sha256": payload["checkpoint_sha256"],
            "decisions": rows, "changed_actions": sum(row["original_action"] != row["replayed_action"] for row in rows),
            "max_probability_error": max((row["probability_max_absolute_error"] for row in rows), default=None),
            "max_memory_error": max((row[key] for row in rows for key in
                ("memory_before_max_absolute_error", "memory_after_max_absolute_error") if row[key] is not None), default=None)}


def rollout_aerial_episode(env, predictor, instruction, max_steps=500, history_frames=8, observation_dir=None,
                           metric_protocol="airvln_xy20_fastdtw_v1", progress_callback=None):
    """Optional synchronous evidence callback; callback failures stop execution fail-closed.

    A dispatch without a returned step is unknown, not evidence that zero actions ran.
    No goals, reference route, teacher labels or raw depth enter the callback.
    """
    if progress_callback is not None and not callable(progress_callback):
        raise ValueError("progress_callback 必须是可调用函数或None")
    progress = {"stage": "validation", "known_completed_steps": 0, "validated_decisions": 0,
                "pending_dispatch": None}
    from copy import deepcopy
    callback_failed = False
    def emit(event, **fields):
        nonlocal callback_failed
        progress["stage"] = event
        if event == "policy_decision_validated":
            progress["validated_decisions"] += 1
        elif event == "action_dispatch":
            progress["pending_dispatch"] = {"decision_index": fields["decision_index"],
                                            "action": fields["action"], "execution_state": "unknown_until_step_returns"}
        elif event == "action_completed":
            progress["known_completed_steps"] += 1
            progress["pending_dispatch"] = None
        if progress_callback is not None:
            try:
                progress_callback(deepcopy({"event": event, **progress, **fields}))
            except Exception:
                callback_failed = True
                raise
    try:
        return _rollout_aerial_episode(env, predictor, instruction, max_steps, history_frames,
                                      observation_dir, metric_protocol, emit)
    except Exception as error:
        if progress_callback is not None and not callback_failed:
            # Preserve the operation exception even if the final error journal also fails.
            try:
                progress_callback({"event": "error", **progress,
                                   "error_type": type(error).__name__, "error": str(error),
                                   "error_category": aerial_error_category(error, progress["stage"])})
            except Exception:
                pass
        raise


def _rollout_aerial_episode(env, predictor, instruction, max_steps, history_frames, observation_dir,
                            metric_protocol, emit):
    """八动作闭环；STOP argmax 在执行前处理，策略不接收 goal/ref/teacher。"""
    if not isinstance(instruction, str) or not instruction.strip() or type(max_steps) is not int or max_steps <= 0:
        raise ValueError("instruction 非空且 max_steps 为正整数")
    if type(history_frames) is not int or history_frames < 0:
        raise ValueError("history_frames 必须是非负整数")
    if metric_protocol not in AERIAL_METRIC_PROTOCOLS:
        raise ValueError("不支持的AerialVLN评分协议")
    if metric_protocol == "eval_adapter_v2" and max_steps > 500:
        raise ValueError("eval_adapter_v2 不能超过500动作硬预算")
    replay = bool(getattr(env, "replay", False))
    if not replay and getattr(env, "actions_executed", None) is not True:
        raise ValueError("实际环境必须声明 actions_executed=True")
    emit("policy_reset_request")
    try:
        state_reset = _reset_aerial_predictor(predictor)
    except Exception as error:
        raise AerialPolicyError("策略reset失败: " + str(error)) from error
    if observation_dir is not None:
        observation_dir = Path(observation_dir).resolve()
        if observation_dir.exists():
            raise FileExistsError(f"诊断图像目录已存在，拒绝覆盖: {observation_dir}")
        observation_dir.mkdir(parents=True)
    emit("reset_request")
    obs = env.reset()
    def evidence(value):
        return {"position": value.position.tolist(), "orientation": value.orientation.tolist(),
                "timestamp": value.timestamp, "collision": value.collision,
                "depth_collision_proxy": value.info.get("depth_collision_proxy")}
    initial = evidence(obs)
    emit("reset_completed", observation=initial)
    if obs.done:
        raise RuntimeError("AerialVLN reset已触发环境终止，需先核验起点/传感器，不生成导航成绩")
    records, history, decision = [], [], None
    reason = obs.termination_reason if obs.done else "max_steps"
    observation_trace = []
    if not obs.done:
        for index in range(max_steps):
            emit("decision_request", decision_index=index)
            trace = None
            if observation_dir is not None:
                from PIL import Image
                image_path = observation_dir / f"{index:06d}.png"
                if isinstance(obs.image, np.ndarray):
                    Image.fromarray(obs.image).convert("RGB").save(image_path)
                elif isinstance(obs.image, Image.Image):
                    obs.image.convert("RGB").save(image_path)
                else:
                    with Image.open(obs.image) as image:
                        image.convert("RGB").save(image_path)
                trace = {"decision_index": index, "rgb": image_path.name,
                         "rgb_sha256": hashlib.sha256(image_path.read_bytes()).hexdigest(),
                         "history_actions": list(history[-history_frames:]) if history_frames else [],
                         "observation": evidence(obs),
                         "sensor": {key: obs.info.get(key) for key in ("image_timestamp_ns", "depth_timestamp_ns",
                             "response_camera_position", "response_camera_orientation_xyzw",
                             "depth_response_camera_position", "depth_response_camera_orientation_xyzw",
                             "rgb_depth_timestamp_skew_ns", "image_refresh_attempts", "image_refresh_audit",
                             "capture_paused_before", "capture_paused_after")}}
                if getattr(predictor, "config", {}).get("input_modality") == "rgbd":
                    if obs.info.get("depth_normalized") is None:
                        raise ValueError("RGB-D观测记录缺少真实深度")
                    depth_path = observation_dir / f"{index:06d}_depth.npy"
                    np.save(depth_path, obs.info["depth_normalized"], allow_pickle=False)
                    trace.update(depth=depth_path.name, depth_sha256=hashlib.sha256(depth_path.read_bytes()).hexdigest(),
                                 depth_input_protocol=predictor.config["depth_input_protocol"])
                state = predictor.observation_state() if hasattr(predictor, "observation_state") else None
                if state is not None:
                    state_path = observation_dir / f"{index:06d}_before.npy"
                    np.save(state_path, state, allow_pickle=False)
                    trace.update(state_before=state_path.name, state_before_sha256=hashlib.sha256(state_path.read_bytes()).hexdigest())
            start = time.perf_counter()
            past = history[-history_frames:] if history_frames else []
            try:
                prediction = _aerial_policy_action(predictor, obs.image, instruction, past, obs.info.get("depth_normalized"))
            except Exception as error:
                raise AerialPolicyError("策略predict_action失败: " + str(error)) from error
            latency = (time.perf_counter() - start) * 1000
            action = prediction.get("action") if isinstance(prediction, dict) else None
            try:
                probabilities = np.asarray(prediction.get("action_probabilities") if isinstance(prediction, dict) else None, dtype=float)
            except (TypeError, ValueError) as error:
                raise AerialPolicyError("predict_action概率不可转换为数值") from error
            if (type(action) is not int or not 0 <= action < 8 or probabilities.shape != (8,)
                    or not np.isfinite(probabilities).all() or (probabilities < 0).any()
                    or not np.isclose(probabilities.sum(), 1., atol=1e-5) or action != int(probabilities.argmax())):
                raise AerialPolicyError("predict_action 必须返回8类合法概率及其argmax整数动作")
            if trace is not None:
                state = predictor.observation_state() if hasattr(predictor, "observation_state") else None
                if state is not None:
                    state_path = observation_dir / f"{index:06d}_after.npy"
                    np.save(state_path, state, allow_pickle=False)
                    trace.update(state_after=state_path.name, state_after_sha256=hashlib.sha256(state_path.read_bytes()).hexdigest())
                trace["prediction"] = prediction
                observation_trace.append(trace)
                (observation_dir / "manifest.json").write_text(json.dumps({
                    "scope": "actual_policy_observations_and_recurrent_state_not_teacher_inputs",
                    "checkpoint_sha256": getattr(predictor, "checkpoint_sha256", None),
                    "instruction": instruction, "history_frames": history_frames,
                    "instruction_sha256": hashlib.sha256(instruction.encode()).hexdigest(),
                    "frames": observation_trace}, ensure_ascii=False, indent=2, allow_nan=False), encoding="utf-8")
            emit("policy_decision_validated", decision_index=index, action=action,
                 action_probabilities=probabilities.tolist(), current=evidence(obs),
                 history_actions=list(past), inference_ms=latency)
            if action == 0:
                reason = "model_stop"
                decision = {"action": 0, "action_probabilities": probabilities.tolist(),
                            "observation": evidence(obs), "inference_ms": latency}
                break
            emit("action_dispatch", decision_index=index, action=action)
            following = env.step(action)
            info = {key: value for key, value in following.info.items() if key != "depth_normalized"}
            records.append({"step": index, "action": action, "action_probabilities": probabilities.tolist(),
                            "current": evidence(obs), "following": evidence(following),
                            "inference_ms": latency, "action_executed": not replay, "info": info})
            emit("action_completed", record=records[-1])
            history.append(action)
            obs = following
            if obs.done:
                reason = obs.termination_reason or "environment_done"
                break
    emit("terminal", termination_reason=reason, terminal_observation=evidence(obs),
         terminal_decision=decision, steps=len(records))
    if hasattr(env, "finish"):
        emit("finish_request")
        env.finish()
    result = {"schema_version": 3, "task_version": "aerialvln_s_v1",
            "status": "replay_only" if replay else "closed_loop", "replay": replay,
            "actions_executed": not replay, "done": True, "steps": len(records),
            "policy_state_reset": state_reset,
            "observation_trace": str(observation_dir) if observation_dir is not None else None,
            "termination_reason": reason, "initial_observation": initial,
            "terminal_observation": evidence(obs), "terminal_decision": decision, "records": records}
    if metric_protocol == "eval_adapter_v2":
        result["metric_protocol"] = metric_protocol
    return result


def _aerial_pose_evidence(value, name):
    if not isinstance(value, dict):
        raise ClosedLoopAuditError(f"{name} 缺少观测")
    position = _vector(value.get("position"), f"{name}.position")
    try:
        q = np.asarray(value.get("orientation"), dtype=float)
    except (ValueError, TypeError) as exc:
        raise ClosedLoopAuditError(f"{name}.orientation 无效") from exc
    if q.shape != (4,) or not np.isfinite(q).all() or np.linalg.norm(q) < 1e-12:
        raise ClosedLoopAuditError(f"{name}.orientation 无效")
    _number(value.get("timestamp"), f"{name}.timestamp", nonnegative=True)
    if type(value.get("collision")) is not bool or type(value.get("depth_collision_proxy")) is not bool:
        raise ClosedLoopAuditError(f"{name} 缺少 contact/depth 代理布尔证据")
    return position


def _aerial_probabilities(value, action, field):
    try:
        probabilities = np.asarray(value, dtype=float)
    except (ValueError, TypeError) as exc:
        raise ClosedLoopAuditError(f"{field}不是数值概率列表") from exc
    if (probabilities.shape != (8,) or not np.isfinite(probabilities).all() or (probabilities < 0).any()
            or not np.isclose(probabilities.sum(), 1., atol=1e-5) or int(probabilities.argmax()) != action):
        raise ClosedLoopAuditError(f"{field}与合法8类argmax动作不一致")
    return probabilities


def _read_aerial_metrics(path, rollout):
    metadata = _metadata(path, rollout)
    config = metadata.get("execution_config")
    metric_protocol = config.get("metric_protocol", AERIAL_METRIC_PROTOCOLS[0]) if isinstance(config, dict) else AERIAL_METRIC_PROTOCOLS[0]
    if metric_protocol not in AERIAL_METRIC_PROTOCOLS:
        raise ClosedLoopAuditError("AerialVLN不支持的评分协议")
    if (rollout.get("metric_protocol", AERIAL_METRIC_PROTOCOLS[0]) != metric_protocol
            or metadata.get("metric_protocol", AERIAL_METRIC_PROTOCOLS[0]) != metric_protocol):
        raise ClosedLoopAuditError("AerialVLN rollout/元数据/执行配置评分协议不一致或缺失")
    if rollout.get("task_version") != "aerialvln_s_v1" or metadata.get("task_version") != "aerialvln_s_v1":
        raise ClosedLoopAuditError("AerialVLN task_version 无效")
    if metadata.get("split") not in ("train", "val_seen", "val_unseen", "test"):
        raise ClosedLoopAuditError("AerialVLN split 无效")
    if rollout.get("status") == "replay_only" and rollout.get("replay") is True:
        return {**{key: None for key in AERIAL_METRIC_KEYS}, "status": "replay_only",
                "split": metadata["split"], "source": str(path), "definition": {"task_version": "aerialvln_s_v1"}}
    if metadata["split"] == "test":
        raise ClosedLoopAuditError("AerialVLN test 隐藏真值，禁止本地导航评分")
    if (rollout.get("status") != "closed_loop" or rollout.get("replay") is not False
            or rollout.get("actions_executed") is not True or rollout.get("done") is not True):
        raise ClosedLoopAuditError("AerialVLN 缺少真实闭环执行声明")
    records = rollout.get("records")
    if not isinstance(records, list) or type(rollout.get("steps")) is not int or rollout["steps"] != len(records):
        raise ClosedLoopAuditError("AerialVLN 动作记录计数冲突")
    previous = rollout.get("initial_observation")
    initial_position = _aerial_pose_evidence(previous, "initial_observation")
    if previous["depth_collision_proxy"]:
        raise ClosedLoopAuditError("AerialVLN初始深度已触发代理，不能作为有效导航episode")
    positions = [initial_position] if metric_protocol == "eval_adapter_v2" else []
    latency, contacts, proxies = [], [previous["collision"]], [previous["depth_collision_proxy"]]
    for index, record in enumerate(records):
        if not isinstance(record, dict) or record.get("current") != previous:
            raise ClosedLoopAuditError("AerialVLN 动作观测不连续")
        action = record.get("action")
        if type(action) is not int or not 1 <= action < 8 or record.get("action_executed") is not True:
            raise ClosedLoopAuditError("AerialVLN 未真实执行合法非STOP动作")
        _aerial_probabilities(record.get("action_probabilities"), action, "record.action_probabilities")
        following = record.get("following")
        position = _aerial_pose_evidence(following, f"records[{index}].following")
        from uavnav.avln.airsim_env import aerial_action_pose
        from scipy.spatial.transform import Rotation
        expected_position, expected_q = aerial_action_pose(previous["position"], previous["orientation"], action)
        actual_q = np.asarray(following["orientation"])
        rotation_error = float((Rotation.from_quat(actual_q).inv() * Rotation.from_quat(expected_q)).magnitude())
        if np.linalg.norm(expected_position - position) > .02 or rotation_error > 1e-4:
            raise ClosedLoopAuditError("AerialVLN 实际动作端点与八动作控制协议不一致")
        if previous["depth_collision_proxy"]:
            raise ClosedLoopAuditError("AerialVLN 深度代理终止后继续执行动作")
        if following["timestamp"] < previous["timestamp"]:
            raise ClosedLoopAuditError("AerialVLN 时间倒退")
        positions.append(position)
        contacts.append(following["collision"])
        proxies.append(following["depth_collision_proxy"])
        latency.append(_number(record.get("inference_ms"), "inference_ms", nonnegative=True))
        previous = following
    terminal = rollout.get("terminal_observation")
    final = _aerial_pose_evidence(terminal, "terminal_observation")
    if terminal != previous:
        raise ClosedLoopAuditError("AerialVLN terminal 与实际末帧冲突")
    reason, decision = rollout.get("termination_reason"), rollout.get("terminal_decision")
    if reason == "model_stop":
        if not isinstance(decision, dict) or decision.get("action") != 0 or decision.get("observation") != terminal:
            raise ClosedLoopAuditError("AerialVLN STOP 决策证据缺失")
        _aerial_probabilities(decision.get("action_probabilities"), 0, "STOP.action_probabilities")
        latency.append(_number(decision.get("inference_ms"), "STOP.inference_ms", nonnegative=True))
        if any(proxies):
            raise ClosedLoopAuditError("AerialVLN 深度终止之后不能再STOP")
    elif decision is not None or reason not in ("max_steps", "depth_collision_proxy"):
        raise ClosedLoopAuditError("AerialVLN 终止原因或决策无效")
    if reason == "depth_collision_proxy" and terminal["depth_collision_proxy"] is not True:
        raise ClosedLoopAuditError("AerialVLN 深度代理终止缺证据")
    if not isinstance(config, dict) or type(config.get("max_steps")) is not int or config["max_steps"] <= 0:
        raise ClosedLoopAuditError("AerialVLN 缺少冻结执行配置")
    if metric_protocol == "eval_adapter_v2":
        declared_start = _vector(metadata.get("start_position"), "start_position")
        if np.linalg.norm(declared_start - initial_position) > .02:
            raise ClosedLoopAuditError("eval_adapter_v2官方初始位置与实际reset不一致")
        if (config["max_steps"] > 500 or metadata.get("evaluation_scope") not in ("subset_diagnostic", "official_split")
                or (metadata["evaluation_scope"] == "official_split" and config["max_steps"] != 500)):
            raise ClosedLoopAuditError("eval_adapter_v2正式预算必须500，开发预算必须1至500")
        if (terminal["depth_collision_proxy"] != (reason == "depth_collision_proxy")
                or (reason == "model_stop" and len(records) >= config["max_steps"])):
            raise ClosedLoopAuditError("eval_adapter_v2终止原因未按深度/STOP/预算时序冻结")
        if (re.fullmatch(r"[0-9a-f]{64}", str(metadata.get("evaluation_protocol_sha256"))) is None
                or metadata["evaluation_protocol_sha256"] != config.get("evaluation_protocol_sha256")):
            raise ClosedLoopAuditError("eval_adapter_v2必须绑定冻结评分合同SHA256")
        protocol_path = (path.parent.parent if path.parent.name == "episodes" else path.parent) / "evaluation_protocol.json"
        try:
            protocol = validate_aerial_evaluation_protocol(_load(protocol_path))
        except ValueError as exc:
            raise ClosedLoopAuditError(str(exc)) from exc
        protocol_hash = hashlib.sha256(json.dumps(protocol, sort_keys=True, separators=(",", ":"), ensure_ascii=False).encode()).hexdigest()
        task_hash = hashlib.sha256(json.dumps(protocol["task_protocol"], sort_keys=True, separators=(",", ":"), ensure_ascii=False).encode()).hexdigest()
        if (protocol_hash != config["evaluation_protocol_sha256"] or task_hash != config.get("task_protocol_sha256")
                or protocol["max_steps"] != config["max_steps"] or protocol["evaluation_scope"] != metadata["evaluation_scope"]):
            raise ClosedLoopAuditError("eval_adapter_v2评分合同内容与执行配置不一致")
        try:
            manifest = validate_evaluation_manifest(_load(protocol_path.with_name("evaluation_manifest.json")))
            row = next((item for item in manifest["episodes"] if item["traj_id"] == metadata.get("traj_id")), None)
            if (manifest["schema_version"] != 2 or row is None
                    or evaluation_manifest_sha256(manifest) != metadata.get("evaluation_manifest_sha256")
                    or manifest["evaluation_protocol_sha256"] != protocol_hash
                    or manifest["scope"] != metadata["evaluation_scope"] or manifest["split"] != metadata["split"]
                    or metadata.get("annotation_sha256") != manifest["source_sha256"]
                    or metadata.get("episode_sha256") != row["episode_sha256"]
                    or aerial_scoring_truth_sha256(metadata) != row["scoring_truth_sha256"]):
                raise ValueError("eval_adapter_v2源标注/评分真值与冻结schema2名单不一致")
        except ValueError as exc:
            raise ClosedLoopAuditError(str(exc)) from exc
    if (re.fullmatch(r"[0-9a-f]{64}", str(config.get("checkpoint_sha256"))) is None
            or not isinstance(config.get("policy"), str) or not config["policy"]
            or config.get("control_protocol") != "airsim_set_pose_ignore_collision"
            or config.get("action_protocol") != "aerial_action8_v1"):
        raise ClosedLoopAuditError("AerialVLN 执行配置必须绑定模型、策略和控制协议")
    if metadata["split"] == "train":
        purpose = metadata.get("evaluation_purpose")
        development = purpose == "development_route_completion"
        if (metadata.get("evaluation_scope") != "subset_diagnostic"
                or purpose not in ("training_route_completion", "development_route_completion")
                or metadata.get("seen_in_training") is not (not development)
                or config.get("evaluation_purpose") != purpose
                or config.get("seen_in_training") is not (not development)
                or re.fullmatch(r"[0-9a-f]{64}", str(config.get("training_split_manifest_sha256"))) is None
                or development and (metric_protocol != "eval_adapter_v2"
                    or re.fullmatch(r"[0-9a-f]{64}", str(config.get("development_route_split_sha256"))) is None)):
            raise ClosedLoopAuditError("train闭环要求明确已训练或独立开发路线诊断合同，不能当作官方成绩")
    architecture = config.get("architecture")
    baselines = ("airvln_seq2seq_rgb_v1", "airvln_cma_rgb_v1", "airvln_seq2seq_rgbd_v1", "airvln_cma_rgbd_v1")
    rgbd = architecture in ("aerial_route_recurrent_rgbd_v3", *baselines[2:])
    if rgbd and (config.get("input_modality") != "rgbd"
                 or config.get("depth_input_protocol") != "front_0_scene_normalized_256_v1"
                 or config.get("depth_size") != 256
                 or config.get("depth_fusion") != ("official_depth_encoder_v1" if architecture in baselines
                                                  else "conv32_64_128_add_fused_v1")):
        raise ClosedLoopAuditError("RGB-D执行缺少版本化实际深度合同")
    if architecture is not None and architecture not in ("aerial_route_v1", "aerial_route_recurrent_v2", "aerial_route_recurrent_clause_v3", "aerial_route_recurrent_rgbd_v3", "aerial_route_dino_v5", *baselines):
        raise ClosedLoopAuditError("AerialVLN执行配置记录了未知架构")
    if architecture in ("aerial_route_recurrent_v2", "aerial_route_recurrent_clause_v3", "aerial_route_recurrent_rgbd_v3", "aerial_route_dino_v5") and (
            config.get("policy") != f"{architecture}_argmax"
            or config.get("memory_protocol") != "fused_gru_v1"
            or config.get("memory_mode") not in ("carry", "reset_each_step")
            or config.get("vision_batchnorm_protocol") != ("dinov3_layernorm_v1" if architecture == "aerial_route_dino_v5" else "frozen_running_stats_v1")
            or config.get("sequence_policy") != "episode_contiguous_tbptt_v1"
            or config.get("tokenizer_version") != "route_numeric_v1"
            or rollout.get("policy_state_reset") is not True):
        raise ClosedLoopAuditError("循环路线执行缺少版本化记忆/序列协议或episode状态重置证据")
    if architecture in baselines:
        expected = {"policy": f"{architecture}_argmax", "memory_protocol": "airvln_recurrent_gru_v1",
                    "memory_mode": "carry", "vision_batchnorm_protocol": "causal_fixed_bn_v1",
                    "sequence_policy": "episode_contiguous_tbptt_v1", "tokenizer_version": "route_numeric_v1",
                    "baseline_protocol": "official_network_matched_training_adapter_v1",
                    "memory_layers": 1 if "seq2seq" in architecture else 2, "memory_hidden_size": 512,
                    "raw_rgb_adapter": "imagenet_denormalize_round_uint8_v1",
                    "depth_policy": ("official_ablate_depth_false_normalized_nhwc_v1" if rgbd
                                     else "official_ablate_depth_true_environment_depth_retained_v1")}
        if (any(config.get(key) != value for key, value in expected.items())
                or rollout.get("policy_state_reset") is not True
                or not isinstance(config.get("upstream_source_sha256"), dict) or not config["upstream_source_sha256"]
                or re.fullmatch(r"[0-9a-f]{64}", str(config.get("ddppo_checkpoint_sha256"))) is None):
            raise ClosedLoopAuditError("官方网络适配缺少真实来源、因果输入或记忆重置合同")
        for relative, digest in config["upstream_source_sha256"].items():
            if (not isinstance(relative, str) or Path(relative).is_absolute() or ".." in Path(relative).parts
                    or not relative.endswith(".py") or not isinstance(digest, str)
                    or re.fullmatch(r"[0-9a-f]{64}", digest) is None):
                raise ClosedLoopAuditError("官方网络适配上游源码路径或SHA256非法")
    if len(records) > config["max_steps"] or (reason == "max_steps" and len(records) != config["max_steps"]):
        raise ClosedLoopAuditError("AerialVLN 动作预算与终止记录不一致")
    goal = _vector(metadata.get("goal_position"), "goal_position")
    reference = _positions(metadata.get("reference_positions"), "reference_positions")
    if np.linalg.norm(np.asarray(reference[0]) - rollout["initial_observation"]["position"]) > .02:
        raise ClosedLoopAuditError("AerialVLN reset起点与官方参考首帧不一致")
    if metadata.get("start_orientation_xyzw") is not None:
        try:
            expected_q = np.asarray(metadata["start_orientation_xyzw"], dtype=float)
        except (ValueError, TypeError) as exc:
            raise ClosedLoopAuditError("AerialVLN官方起点四元数不是数字") from exc
        actual_q = np.asarray(rollout["initial_observation"]["orientation"], dtype=float)
        if expected_q.shape != (4,) or not np.isfinite(expected_q).all() or np.linalg.norm(expected_q) < 1e-12:
            raise ClosedLoopAuditError("AerialVLN官方起点四元数无效")
        from scipy.spatial.transform import Rotation
        if (Rotation.from_quat(expected_q).inv() * Rotation.from_quat(actual_q)).magnitude() > 1e-4:
            raise ClosedLoopAuditError("AerialVLN reset姿态与官方wxyz起点不一致")
    # v1 固定使用动作后观测，零步 STOP 用末观测；v2 包含初始位置。
    # 两版均保留相邻完全重复XYZ去重，不改历史采样或fastdtw算法。
    if not positions:
        positions = [final]
    unique = [positions[0]]
    for point in positions[1:]:
        if not np.array_equal(point, unique[-1]):
            unique.append(point)
    try:
        from fastdtw import fastdtw
    except ImportError as exc:
        raise ClosedLoopAuditError("官方 nDTW 需要 fastdtw；不能用另一种DTW冒充官方指标") from exc
    dtw = fastdtw(unique, reference, dist=lambda a, b: float(np.linalg.norm(np.asarray(a) - np.asarray(b))))[0]
    ndtw = float(np.exp(-dtw / (len(reference) * 20.)))
    ne = float(np.linalg.norm(final[:2] - goal[:2]))
    success = ne <= 20.
    result = {"ne": ne, "sr": 100. * success,
              "osr": 100. * any(np.linalg.norm(p[:2] - goal[:2]) <= 20. for p in positions),
              "ndtw": 100. * ndtw, "sdtw": 100. * success * ndtw,
              "autonomous_stop_success": 100. * (success and reason == "model_stop" and not any(proxies)),
              "spl": None, "status": "closed_loop", "split": metadata["split"], "source": str(path),
              "traj_id": metadata.get("traj_id"), "success": bool(success), "collision": None,
              "simulator_contact": any(contacts), "depth_collision_proxy": any(proxies),
              "latency_complete": True, "latency_samples_ms": latency,
              "termination_reason": reason,
              "definition": {"task_version": "aerialvln_s_v1", "metric_protocol": metric_protocol,
                  "success_basis": "is_end_and_xy_distance_le20_including_budget_and_depth_proxy",
                  "position_sampling": "discrete_pose_endpoints", "execution_config": config,
                  "ndtw_positions": ("initial_and_after_actions_exact_xyz_deduplicated" if metric_protocol == "eval_adapter_v2"
                                     else "deduplicated_measurements_after_actions_reset_excluded"),
                  "autonomous_stop_success_basis": "xy20_and_argmax_stop_and_no_depth_proxy",
                  "pose_position_tolerance_m": .02, "pose_orientation_tolerance_rad": 1e-4,
                  "spl": "not_reported_by_upstream", "physical_continuous_flight": False}}
    from uavnav.avln.metadata import aerial_metric_definition_contract
    result["definition"].update(aerial_metric_definition_contract())
    if metadata["split"] == "train":
        result.update(evaluation_purpose=metadata["evaluation_purpose"],
                      seen_in_training=metadata["seen_in_training"])
    if metric_protocol == "eval_adapter_v2":
        result["definition"]["termination_protocol"] = "terminal_reason_frozen_before_scoring_v2"
    return result


def _audit_stop_schema(rollout, replay=False):
    """核对动作前停止的实际观测与执行记录，不读取目标信息。"""
    records = rollout.get("records")
    if not isinstance(records, list):
        raise ClosedLoopAuditError("schema2 records 必须为列表")
    if rollout.get("stop_enabled") is not True:
        raise ClosedLoopAuditError("schema2 必须显式启用 STOP")
    threshold = _number(rollout.get("stop_threshold"), "stop_threshold")
    if not 0 <= threshold <= 1:
        raise ClosedLoopAuditError("stop_threshold 超出 [0, 1]")
    count = rollout.get("actions_executed_count")
    if isinstance(count, bool) or not isinstance(count, int) or count != (0 if replay else len(records)):
        raise ClosedLoopAuditError("actions_executed_count 与记录不一致")
    if type(rollout.get("steps")) is not int or rollout["steps"] != len(records):
        raise ClosedLoopAuditError("schema2 steps 与记录不一致")
    if not replay and (rollout.get("replay") is not False or rollout.get("actions_executed") is not True):
        raise ClosedLoopAuditError("schema2 缺少真实环境执行权限声明")

    def pose(value, field):
        if not isinstance(value, dict):
            raise ClosedLoopAuditError(f"{field} 缺少实际观测")
        position = _vector(value.get("position"), f"{field}.position")
        try:
            orientation = np.asarray(value.get("orientation"), dtype=np.float64)
        except (TypeError, ValueError) as exc:
            raise ClosedLoopAuditError(f"{field}.orientation 无效") from exc
        if orientation.shape != (4,) or not np.isfinite(orientation).all() or np.linalg.norm(orientation) < 1e-12:
            raise ClosedLoopAuditError(f"{field}.orientation 必须是有限非零四元数")
        timestamp = value.get("timestamp")
        if not replay or timestamp is not None:
            timestamp = _number(timestamp, f"{field}.timestamp", nonnegative=True)
        if not replay and not isinstance(value.get("collision"), bool):
            raise ClosedLoopAuditError(f"{field}.collision 缺少实际布尔记录")
        return position, orientation, timestamp

    def same_pose(left, right, field):
        a, b = pose(left, field), pose(right, field)
        if not np.allclose(a[0], b[0], rtol=0, atol=1e-5) or not np.allclose(a[1], b[1], rtol=0, atol=1e-6) or a[2] != b[2]:
            raise ClosedLoopAuditError(f"{field} 与实际端点观测不一致")

    initial, terminal = rollout.get("initial_observation"), rollout.get("terminal_observation")
    first_pose, final_pose = pose(initial, "initial_observation"), pose(terminal, "terminal_observation")
    if initial.get("collision") is True:
        raise ClosedLoopAuditError("初始观测已碰撞")
    previous = initial
    for index, record in enumerate(records):
        if not isinstance(record, dict):
            raise ClosedLoopAuditError("schema2 record 必须是对象")
        current = {key: record.get(key) for key in ("position", "orientation", "timestamp")}
        current["collision"] = previous.get("collision")
        same_pose(previous, current, f"records[{index}].current")
        following = {"position": record.get("next_position"), "orientation": record.get("next_orientation"),
                     "timestamp": record.get("next_timestamp"), "collision": record.get("collision")}
        next_pose = pose(following, f"records[{index}].next")
        if next_pose[2] is not None and current["timestamp"] is not None and next_pose[2] < current["timestamp"]:
            raise ClosedLoopAuditError("schema2 动作时间倒退")
        previous = following
    same_pose(previous, terminal, "terminal_observation")
    if previous.get("collision") != terminal.get("collision"):
        raise ClosedLoopAuditError("terminal_observation 碰撞记录不一致")
    if not np.allclose(_vector(rollout.get("final_position"), "final_position"), final_pose[0], rtol=0, atol=1e-5):
        raise ClosedLoopAuditError("final_position 与终止观测不一致")
    decision = rollout.get("terminal_decision")
    if rollout.get("termination_reason") == "model_stop":
        if rollout.get("collision") is True or any(record.get("done") is True or record.get("collision") is True for record in records):
            raise ClosedLoopAuditError("model_stop 之前环境已终止或碰撞")
        if not isinstance(decision, dict) or decision.get("reason") != "model_stop" or decision.get("stop_enabled") is not True:
            raise ClosedLoopAuditError("缺少 model_stop 决策证据")
        probability = _number(decision.get("stop_probability"), "terminal_decision.stop_probability")
        decision_threshold = _number(decision.get("stop_threshold"), "terminal_decision.stop_threshold")
        if not 0 <= probability <= 1 or decision_threshold != threshold or probability < threshold:
            raise ClosedLoopAuditError("停止概率/阈值与 model_stop 不一致")
        same_pose(decision.get("observation"), terminal, "terminal_decision.observation")
        if decision["observation"].get("collision") != terminal.get("collision") or terminal.get("collision") is True:
            raise ClosedLoopAuditError("model_stop 观测碰撞证据无效")
        _number(decision.get("inference_ms"), "terminal_decision.inference_ms", nonnegative=True)
    elif decision is not None or not records:
        raise ClosedLoopAuditError("无 model_stop 的 schema2 必须有真实动作且无停止决策")
    return first_pose[0]


def _load(path):
    path = Path(path)
    try:
        payload = json.loads(path.read_text(encoding="utf-8"))
    except (OSError, UnicodeError, json.JSONDecodeError) as exc:
        raise ClosedLoopAuditError(f"无法读取 JSON {path}: {exc}") from exc
    if not isinstance(payload, dict):
        raise ClosedLoopAuditError(f"{path} 顶层必须是 JSON 对象")
    return payload


def _number(value, field, nonnegative=False):
    if isinstance(value, bool):
        raise ClosedLoopAuditError(f"{field} 必须是有限数，不能是布尔值")
    try:
        value = float(value)
    except (TypeError, ValueError) as exc:
        raise ClosedLoopAuditError(f"{field} 缺失或不是数字") from exc
    if not np.isfinite(value) or (nonnegative and value < 0):
        raise ClosedLoopAuditError(f"{field} 必须是{'非负' if nonnegative else ''}有限数")
    return value


def _vector(value, field):
    try:
        array = np.asarray(value, dtype=np.float64)
    except (TypeError, ValueError) as exc:
        raise ClosedLoopAuditError(f"{field} 不是数值向量") from exc
    if array.shape != (3,) or not np.isfinite(array).all():
        raise ClosedLoopAuditError(f"{field} 必须是有限的三维向量")
    return array


def _positions(values, field):
    if not isinstance(values, list) or not values:
        raise ClosedLoopAuditError(f"{field} 为空或不是列表")
    return [_vector(value, f"{field}[{index}]") for index, value in enumerate(values)]


def _length(positions):
    return sum(float(np.linalg.norm(b - a)) for a, b in zip(positions, positions[1:]))


def _metadata(path, rollout):
    info_path = path / "ori_info.json"
    if not info_path.is_file():
        raise ClosedLoopAuditError(f"缺少 ori_info.json: {info_path}")
    info = _load(info_path)
    metadata = dict(info)
    # 元数据可以与 rollout 一同落盘，但两个文件冲突时拒绝算分。
    for key in ("goal_position", "reference_positions", "success_distance", "spl_definition", "split", "success_basis", "stop_protocol", "stop_threshold", "goal_source", "traj_id", "evaluation_manifest_sha256", "evaluation_protocol_sha256", "evaluation_scope", "execution_config", "task_version", "metric_protocol", "start_position", "start_orientation_xyzw", "episode_sha256", "annotation_sha256"):
        value = rollout.get(key)
        if value is not None:
            if key in metadata and metadata[key] != value:
                raise ClosedLoopAuditError(f"rollout.json 与 ori_info.json 的 {key} 不一致")
            metadata[key] = value
    return metadata


def _reference(metadata, path):
    values = metadata.get("reference_positions")
    if values is not None:
        return _positions(values, "reference_positions")
    origin = metadata.get("ori_traj_dir")
    if not isinstance(origin, str) or not origin:
        raise ClosedLoopAuditError("缺少 reference_positions 或 ori_traj_dir")
    origin = Path(origin)
    if not origin.is_absolute():
        origin = path / origin
    merged = _load(origin / "merged_data.json")
    frames = merged.get("trajectory_raw_detailed")
    if not isinstance(frames, list) or not frames:
        raise ClosedLoopAuditError("trajectory_raw_detailed 为空")
    return _positions([frame.get("position") if isinstance(frame, dict) else None for frame in frames], "trajectory_raw_detailed.position")


def _spl(is_success, reference_length, flown, distance, definition):
    if definition == "standard":
        length = reference_length
    elif definition == "success_distance_adjusted":
        length = max(reference_length - distance, 0.0)
    else:
        raise ClosedLoopAuditError("spl_definition 必须显式为 standard 或 success_distance_adjusted")
    if not is_success:
        return 0.0
    denominator = max(length, flown)
    # 起点即目标且未移动的标准成功任务按 1 记录；调整定义按 0 记录。
    if denominator == 0:
        return 100.0 if definition == "standard" else 0.0
    return 100.0 * length / denominator


def _recorded_scores(rollout, computed):
    """核对落盘指标，避免把不同口径的摘要混进平均值。"""
    recorded = rollout.get("metrics")
    if recorded is None:
        recorded = rollout if any(key in rollout for key in METRIC_KEYS) else {}
    if not isinstance(recorded, dict):
        raise ClosedLoopAuditError("rollout.metrics 必须是对象")
    result = dict(computed)
    for key in METRIC_KEYS:
        if key in recorded:
            value = _number(recorded[key], f"metrics.{key}", nonnegative=True)
            if not np.isclose(value, computed[key], rtol=1e-6, atol=1e-6):
                raise ClosedLoopAuditError(f"日志指标 {key}={value} 与轨迹计算值 {computed[key]} 不一致")
            result[key] = value
    return result


def _motion_samples(record, current, following, index):
    """读取实际执行期间位姿；缺采样时返回显式的端点模式。"""
    info = record.get("info")
    if not isinstance(info, dict) or "motion_samples" not in info:
        return None
    samples = info["motion_samples"]
    if not isinstance(samples, list) or len(samples) < 2:
        raise ClosedLoopAuditError(f"records[{index}].info.motion_samples 至少需要首末两帧")
    positions, timestamps, collisions = [], [], []
    for number, sample in enumerate(samples):
        field = f"records[{index}].info.motion_samples[{number}]"
        if not isinstance(sample, dict):
            raise ClosedLoopAuditError(f"{field} 必须是对象")
        positions.append(_vector(sample.get("position"), f"{field}.position"))
        timestamps.append(_number(sample.get("timestamp"), f"{field}.timestamp", nonnegative=True))
        try:
            orientation = np.asarray(sample.get("orientation"), dtype=np.float64)
        except (TypeError, ValueError) as exc:
            raise ClosedLoopAuditError(f"{field}.orientation 不是数值向量") from exc
        if orientation.shape != (4,) or not np.isfinite(orientation).all() or np.linalg.norm(orientation) < 1e-12:
            raise ClosedLoopAuditError(f"{field}.orientation 必须是有限的非零四元数")
        if not isinstance(sample.get("collision"), bool):
            raise ClosedLoopAuditError(f"{field}.collision 必须是实际布尔记录")
        collisions.append(sample["collision"])
    if any(right < left for left, right in zip(timestamps, timestamps[1:])):
        raise ClosedLoopAuditError(f"records[{index}].info.motion_samples 时间必须非减")
    if not np.allclose(positions[0], current, rtol=0, atol=1e-5) or not np.allclose(positions[-1], following, rtol=0, atol=1e-5):
        raise ClosedLoopAuditError(f"records[{index}].info.motion_samples 首末位置与实际动作端点不一致")
    return positions, timestamps, collisions


def read_rollout_metrics(path):
    """读取一个 episode 目录，返回静态指标、status 和指标定义。

    新格式为 ``rollout.json`` + ``ori_info.json``。旧的逐帧 ``log/*.json``
    可以读取，但必须提供动作已执行、终止状态、成功依据和 SPL 定义。
    不使用文件夹名推断 success/oracle，也不使用地图名推断测试划分。
    """
    path = Path(path)
    rollout_path = path / "rollout.json"
    legacy = not rollout_path.is_file()
    rollout = _load(path / "ori_info.json") if legacy else _load(rollout_path)
    schema = rollout.get("schema_version", 1)
    if type(schema) is int and schema == 3:
        return _read_aerial_metrics(path, rollout)
    if isinstance(schema, bool) or schema not in (1, 2):
        raise ClosedLoopAuditError("不支持的 rollout schema_version")
    status = rollout.get("status")
    if status == "replay_only" or rollout.get("replay") is True:
        if status != "replay_only" or rollout.get("replay") is not True:
            raise ClosedLoopAuditError("replay 与 status 不一致")
        if schema == 2:
            _audit_stop_schema(rollout, replay=True)
        elif not isinstance(rollout.get("records"), list) or not rollout["records"]:
            raise ClosedLoopAuditError("replay records 为空")
        metadata = _metadata(path, rollout)
        return {
            **{key: None for key in METRIC_KEYS}, "status": "replay_only",
            "source": str(path), "split": metadata.get("split"), "format": "replay",
            "definition": {"stop_protocol": metadata.get("stop_protocol", "not_recorded"), "goal_source": metadata.get("goal_source", "not_recorded")},
            "details": {"navigation_metrics": "not_applicable_to_replay"},
        }
    if status != "closed_loop":
        raise ClosedLoopAuditError("缺少 status=closed_loop 的真实 rollout 状态")
    initial_position = _audit_stop_schema(rollout) if schema == 2 else None
    metadata = _metadata(path, rollout)
    reason = rollout.get("termination_reason")
    if not isinstance(reason, str) or not reason.strip():
        raise ClosedLoopAuditError("缺少实际 termination_reason")
    if rollout.get("done") is not True:
        raise ClosedLoopAuditError("缺少 done=true，无法审计实际终止状态")
    split = metadata.get("split")
    if not isinstance(split, str) or not split.strip():
        raise ClosedLoopAuditError("缺少显式 split，不能由地图名推断测试划分")

    collided = None
    latency_samples = []
    latency_complete = False
    sampling = "action_endpoints"
    if legacy:
        logs = sorted((path / "log").glob("*.json"), key=lambda item: (int(re.search(r"\d+", item.name).group()) if re.search(r"\d+", item.name) else float("inf"), item.name))
        if not logs:
            raise ClosedLoopAuditError("legacy log 目录缺失或没有 JSON 日志")
        if rollout.get("actions_executed") is not True:
            raise ClosedLoopAuditError("legacy 日志缺少 actions_executed=true")
        positions = []
        for item in logs:
            payload = _load(item)
            try:
                position = payload["sensors"]["state"]["position"]
            except (KeyError, TypeError) as exc:
                raise ClosedLoopAuditError(f"{item} 缺少 sensors.state.position") from exc
            positions.append(_vector(position, str(item)))
        if not isinstance(rollout.get("success"), bool) or not isinstance(rollout.get("oracle_success"), bool):
            raise ClosedLoopAuditError("legacy 日志必须显式记录 success 和 oracle_success")
        if not isinstance(metadata.get("success_basis"), str) or not metadata["success_basis"].strip():
            raise ClosedLoopAuditError("legacy 日志必须声明 success_basis")
        is_success = rollout["success"]
        is_oracle = is_success or rollout["oracle_success"]
        if isinstance(rollout.get("collision"), bool):
            collided = rollout["collision"]
    else:
        records = rollout.get("records")
        if not isinstance(records, list) or (not records and schema != 2):
            raise ClosedLoopAuditError("records 为空，未记录实际执行步骤")
        all_executed = rollout.get("actions_executed") is True
        if rollout.get("actions_executed") is False:
            raise ClosedLoopAuditError("actions_executed=false，不允许生成导航指标")
        positions = [initial_position] if schema == 2 else []
        sampling_modes = set()
        last_sample_time = None
        sample_collisions = []
        latency_complete = True
        for index, record in enumerate(records):
            if not isinstance(record, dict):
                raise ClosedLoopAuditError(f"records[{index}] 必须是对象")
            if record.get("action_executed") is False or (not all_executed and record.get("action_executed") is not True):
                raise ClosedLoopAuditError(f"records[{index}] 未证明动作已执行")
            _number(record.get("timestamp"), f"records[{index}].timestamp", nonnegative=True)
            _vector(record.get("commanded_action_body"), f"records[{index}].commanded_action_body")
            _vector(record.get("actual_displacement_body"), f"records[{index}].actual_displacement_body")
            current = _vector(record.get("position"), f"records[{index}].position")
            following = _vector(record.get("next_position"), f"records[{index}].next_position")
            if positions and not np.allclose(positions[-1], current, rtol=0, atol=1e-5):
                raise ClosedLoopAuditError(f"records[{index}] 与上一帧位置不连续")
            if not positions:
                positions.append(current)
            motion = _motion_samples(record, current, following, index)
            if motion is None:
                sampling_modes.add("action_endpoints")
                positions.append(following)
            else:
                sampling_modes.add("sim_step_pose_samples")
                samples, timestamps, collisions = motion
                if last_sample_time is not None and timestamps[0] < last_sample_time:
                    raise ClosedLoopAuditError(f"records[{index}] 的采样时间早于上一动作末帧")
                last_sample_time = timestamps[-1]
                positions.extend(samples[1:])
                sample_collisions.extend(collisions)
            if "inference_ms" in record:
                latency_samples.append(_number(record["inference_ms"], f"records[{index}].inference_ms", nonnegative=True))
            else:
                latency_complete = False
        if not records and schema == 2:
            # schema2 审计已证明是同一实际观测上的零步 STOP，没有运动采样口径。
            sampling_modes.add("no_motion_stop")
        if len(sampling_modes) != 1:
            raise ClosedLoopAuditError("同一 episode 混用了执行采样和动作端点，无法统一路径指标")
        sampling = next(iter(sampling_modes))
        final = _vector(rollout.get("final_position"), "final_position")
        if not np.allclose(final, positions[-1], rtol=0, atol=1e-5):
            raise ClosedLoopAuditError("final_position 与最后实际 next_position 不一致")
        collision = rollout.get("collision")
        if not isinstance(collision, bool) or any(not isinstance(record.get("collision"), bool) for record in records):
            raise ClosedLoopAuditError("缺少实际 collision 布尔记录")
        collided = collision or any(record["collision"] for record in records) or any(sample_collisions)
        if schema == 2 and reason == "model_stop" and collided:
            raise ClosedLoopAuditError("model_stop 与实际碰撞采样矛盾")
        goal = _vector(metadata.get("goal_position"), "goal_position")
        distance = _number(metadata.get("success_distance"), "success_distance", nonnegative=True)
        basis = metadata.get("success_basis")
        if basis not in ("final_within_success_distance", "final_within_success_distance_and_no_collision", STOP_SUCCESS_BASIS):
            raise ClosedLoopAuditError("success_basis 必须显式为 final_within_success_distance 或 final_within_success_distance_and_no_collision")
        is_success = float(np.linalg.norm(final - goal)) <= distance
        if basis.endswith("and_no_collision"):
            is_success = is_success and not collided
        if basis == STOP_SUCCESS_BASIS:
            if schema != 2:
                raise ClosedLoopAuditError("预测停止成功协议要求 schema2 终止证据")
            is_success = is_success and reason == "model_stop"
        if schema == 2 and rollout.get("terminal_decision") is not None:
            latency_samples.append(float(rollout["terminal_decision"]["inference_ms"]))
        is_oracle = any(float(np.linalg.norm(position - goal)) <= distance for position in positions)

    goal = _vector(metadata.get("goal_position"), "goal_position")
    distance = _number(metadata.get("success_distance"), "success_distance", nonnegative=True)
    reference = _reference(metadata, path)
    if not legacy and not np.allclose(reference[0], positions[0], rtol=0, atol=1e-4):
        raise ClosedLoopAuditError("SPL参考路径起点与真实reset起点不一致")
    definition = metadata.get("spl_definition")
    computed = {
        "ne": float(np.linalg.norm(positions[-1] - goal)),
        "sr": 100.0 * float(is_success),
        "osr": 100.0 * float(is_oracle),
        "spl": _spl(is_success, _length(reference), _length(positions), distance, definition),
    }
    result = _recorded_scores(rollout, computed)
    result.update({
        "status": status, "split": split, "source": str(path),
        "traj_id": metadata.get("traj_id"),
        "termination_reason": reason, "format": "legacy" if legacy else "rollout",
        "collision": collided, "success": bool(is_success),
        "latency_samples_ms": latency_samples, "latency_complete": latency_complete,
        "definition": {
            "execution_config": metadata.get("execution_config", {
                "checkpoint_sha256": metadata.get("checkpoint_sha256"),
                "policy": metadata.get("policy", "legacy_not_recorded"),
                "control_protocol": metadata.get("control_protocol", "legacy_not_recorded"),
                "max_steps": metadata.get("max_steps"),
                "action_duration_sim_s": metadata.get("action_duration_sim_s"),
                "speed_limit_m_s": metadata.get("speed_limit_m_s"),
                "sample_interval_sim_s": metadata.get("sample_interval_sim_s"),
            }),
            "success_basis": metadata.get("success_basis"), "success_distance": distance,
            "spl_definition": definition, "spl_reference": "reference_path_proxy",
            "position_sampling": sampling, "stop_protocol": metadata.get("stop_protocol", "not_recorded"),
            "goal_source": metadata.get("goal_source", "not_recorded"),
            "latency_measurement": "model_inference_per_decision" if schema == 2 else "model_inference_per_action", "latency_percentile_method": "linear",
            "metric_units": {"ne": "m", "sr": "%", "osr": "%", "spl": "%", "collision_rate": "%", "success_rate_no_collision": "%", "latency_p50": "ms", "latency_p95": "ms"},
        },
        "details": {
            "stop_protocol": metadata.get("stop_protocol", "not_recorded"),
            "goal_source": metadata.get("goal_source", "not_recorded"),
            "position_sampling": sampling, "position_samples": len(positions),
            "latency_status": "complete" if latency_complete else "not_fully_recorded",
        },
    })
    return result


def _aggregate(results):
    keys = (*METRIC_KEYS, *(AERIAL_METRIC_KEYS[3:] if any("ndtw" in row for row in results) else ()))
    return {key: float(np.mean([result[key] for result in results]))
            if results and all(result.get(key) is not None for result in results) else None for key in keys}


def _measured_metrics(results):
    """仅用明确布尔碰撞证据和实际推理时间汇总，缺证据时保持 null。"""
    result = {key: None for key in ("collision_rate", "success_rate_no_collision", "latency_p50", "latency_p95")}
    if results and all(isinstance(item.get("collision"), bool) for item in results):
        result["collision_rate"] = 100.0 * float(np.mean([item["collision"] for item in results]))
        result["success_rate_no_collision"] = 100.0 * float(np.mean([item["success"] and not item["collision"] for item in results]))
    if results and all(item.get("latency_complete") is True for item in results):
        samples = [value for item in results for value in item["latency_samples_ms"]]
        if samples:
            result["latency_p50"], result["latency_p95"] = map(float, np.percentile(samples, [50, 95], method="linear"))
    return result


def _audit_evaluation_manifest(root, episodes, supplied_manifest):
    """核对冻结名单和所有 episode 身份，包括未完成及执行错误日志。"""
    issues = []
    single_episode = (root / "rollout.json").is_file()
    saved_path = (root.parent.parent if single_episode and root.parent.name == "episodes" else root.parent) / "evaluation_manifest.json"
    def episode_metadata(path):
        rollout_path = path / "rollout.json"
        return _metadata(path, _load(rollout_path) if rollout_path.is_file() else {})
    try:
        saved = validate_evaluation_manifest(_load(saved_path)) if saved_path.is_file() else None
        supplied = validate_evaluation_manifest(supplied_manifest) if supplied_manifest is not None else None
        if saved is not None and supplied is not None and saved != supplied:
            raise ValueError("传入名单与已保存 evaluation_manifest.json 不一致")
        manifest = supplied if supplied is not None else saved
        if manifest is None:
            # 历史日志仍可审计，但不能声明已核验正式划分完整性。
            if any(any(key in episode_metadata(path) for key in (
                    "evaluation_manifest_sha256", "evaluation_protocol_sha256", "evaluation_scope")) for path in episodes):
                raise ValueError("episode 声明了名单摘要，却缺少冻结评测名单")
            return None, issues
        aerial = bool(episodes) and all(episode_metadata(path).get("task_version") == "aerialvln_s_v1" for path in episodes)
        scoring_protocol = None
        if aerial:
            from uavnav.avln.metadata import validate_aerial_task_protocol
            protocol_path = saved_path.with_name("evaluation_protocol.json")
            protocol = _load(protocol_path)
            if isinstance(protocol, dict) and protocol.get("schema_version") == 2:
                protocol = validate_aerial_evaluation_protocol(protocol)
                scoring_protocol = protocol
                if manifest["schema_version"] != 2:
                    raise ValueError("eval_adapter_v2必须使用绑定逐episode评分真值的schema2名单")
                if protocol["evaluation_scope"] != manifest["scope"]:
                    raise ValueError("eval_adapter_v2评分范围与manifest不一致")
            else:
                if manifest["schema_version"] != 1:
                    raise ValueError("历史v1只能使用schema1评测名单")
                protocol = validate_aerial_task_protocol(protocol)
            actual_hash = hashlib.sha256(json.dumps(protocol, sort_keys=True, separators=(",", ":"), ensure_ascii=False).encode()).hexdigest()
            if manifest["evaluation_protocol_sha256"] != actual_hash:
                raise ValueError("AerialVLN冻结任务合同与manifest哈希不一致")
        elif manifest["scope"] == "official_split" or manifest["evaluation_protocol_sha256"] is not None:
            raise ValueError("正式FOV评测尚未接入真实场景/坐标证据与双视角合同，拒绝将诊断日志升级为正式结果")
        digest = evaluation_manifest_sha256(manifest)
        expected_rows = {row["traj_id"]: row for row in manifest["episodes"]}
        expected = set(expected_rows)
        seen = set()
        for episode in episodes:
            info = episode_metadata(episode)
            traj_id = info.get("traj_id")
            if not isinstance(traj_id, str) or traj_id not in expected:
                raise ValueError(f"名单之外或缺少身份的 episode: {episode.name}")
            if traj_id in seen:
                raise ValueError(f"重复 episode 身份: {traj_id}")
            seen.add(traj_id)
            actual_split = info.get("split") if aerial and manifest["split"] == "train" else canonical_eval_split(info.get("split"))
            if actual_split != manifest["split"]:
                raise ValueError(f"episode 划分与名单冲突: {traj_id}")
            if info.get("evaluation_manifest_sha256") != digest:
                raise ValueError(f"episode 名单摘要与冻结名单不一致: {traj_id}")
            if info.get("evaluation_protocol_sha256") != manifest["evaluation_protocol_sha256"]:
                raise ValueError(f"episode 评测合同摘要与名单不一致: {traj_id}")
            if "evaluation_scope" in info and info["evaluation_scope"] != manifest["scope"]:
                raise ValueError(f"episode 评测范围与名单不一致: {traj_id}")
            if aerial:
                config = info.get("execution_config", {})
                if not isinstance(config, dict):
                    raise ValueError(f"episode执行配置不是对象: {traj_id}")
                expected_metric = scoring_protocol["metric_protocol"] if scoring_protocol else AERIAL_METRIC_PROTOCOLS[0]
                if config.get("metric_protocol", AERIAL_METRIC_PROTOCOLS[0]) != expected_metric:
                    raise ValueError(f"episode评分版本与冻结合同不一致: {traj_id}")
                if scoring_protocol is not None:
                    row = expected_rows[traj_id]
                    if (info.get("annotation_sha256") != manifest["source_sha256"]
                            or info.get("episode_sha256") != row["episode_sha256"]
                            or aerial_scoring_truth_sha256(info) != row["scoring_truth_sha256"]):
                        raise ValueError(f"episode源标注/原episode/评分真值与冻结名单不一致: {traj_id}")
                    task_hash = hashlib.sha256(json.dumps(scoring_protocol["task_protocol"], sort_keys=True,
                        separators=(",", ":"), ensure_ascii=False).encode()).hexdigest()
                    if (config.get("max_steps") != scoring_protocol["max_steps"]
                            or config.get("evaluation_protocol_sha256") != actual_hash
                            or config.get("task_protocol_sha256") != task_hash):
                        raise ValueError(f"episode预算/评分/任务摘要与冻结合同不一致: {traj_id}")
        missing = sorted(expected - seen)
        if missing:
            raise ValueError(f"冻结名单有 {len(missing)} 个 episode 未产生记录: {missing}")
        return {"scope": manifest["scope"], "split": manifest["split"],
                "expected_episodes": len(expected), "manifest_sha256": digest,
                "evaluation_protocol_sha256": manifest["evaluation_protocol_sha256"],
                "identity_check": "complete"}, issues
    except (ClosedLoopAuditError, ValueError) as exc:
        issues.append({"path": str(saved_path), "code": "invalid_evaluation_manifest", "detail": str(exc)})
        return {"identity_check": "invalid"}, issues


def _write_json_atomic(path, payload):
    """同盘原子替换 metrics.json，reader 不会看到截断内容。"""
    path = Path(path)
    path.parent.mkdir(parents=True, exist_ok=True)
    temporary = path.with_name(path.name + ".pending")
    try:
        with temporary.open("w", encoding="utf-8", newline="\n") as stream:
            stream.write(json.dumps(payload, ensure_ascii=False, indent=2, allow_nan=False) + "\n")
            stream.flush()
            os.fsync(stream.fileno())
        os.replace(temporary, path)
    finally:
        temporary.unlink(missing_ok=True)


def write_metrics(run_dir, eval_dir=None, peak_vram_gb=None, evaluation_manifest=None):
    """写入 metrics.json，并返回同一份可审计 payload。"""
    metrics = {key: None for key in (*METRIC_KEYS, *AERIAL_METRIC_KEYS[3:], *PENDING_KEYS)}
    if peak_vram_gb is not None:
        metrics["peak_vram_gb"] = peak_vram_gb
    payload = {"status": "open_loop_only", "metrics": metrics}
    if eval_dir is not None:
        root = Path(eval_dir)
        issues, results, episodes = [], [], []
        if not root.is_dir():
            issues.append({"path": str(root), "code": "invalid_eval_dir", "detail": "eval_dir 不存在或不是目录"})
        else:
            # 每个 episode 都需留下通过或拒绝的审计记录。
            episodes = [root] if (root / "rollout.json").is_file() else sorted(path for path in root.iterdir() if path.is_dir())
            if not episodes:
                issues.append({"path": str(root), "code": "empty_eval_dir", "detail": "没有 episode 目录"})
            manifest_status, manifest_issues = _audit_evaluation_manifest(root, episodes, evaluation_manifest)
            issues.extend(manifest_issues)
            for episode in episodes:
                try:
                    results.append(read_rollout_metrics(episode))
                except ClosedLoopAuditError as exc:
                    issues.append({"path": str(episode), "code": "invalid_rollout", "detail": str(exc)})
        if not root.is_dir():
            manifest_status = None
        payload["evaluation_manifest"] = manifest_status
        payload["evaluation_scope"] = manifest_status["scope"] if manifest_status and "scope" in manifest_status else "legacy_unverified"
        replay_results = [result for result in results if result["status"] == "replay_only"]
        real_results = [result for result in results if result["status"] == "closed_loop"]
        if real_results and all(result.get("split") == "train" for result in real_results):
            purposes = {result.get("evaluation_purpose") for result in real_results}
            if len(purposes) != 1:
                issues.append({"path": str(root), "code": "mixed_training_and_development",
                               "detail": "已训练与独立开发路线不能混合汇总"})
            else:
                purpose = next(iter(purposes))
                payload.update(evaluation_purpose=purpose, seen_in_training=purpose == "training_route_completion",
                               generalization_evidence=purpose == "development_route_completion",
                               official_generalization_evidence=False)
        if replay_results and real_results:
            issues.append({"path": str(root), "code": "mixed_replay_and_closed_loop", "detail": "回放与实际闭环混杂，不能汇总导航指标"})
        # 零步停止无运动，不能冒称端点或仿真步采样。只对其采样方式豁免比较；
        # 所有其他定义保持相等，有运动 episode 之间仍严格检查采样方式。
        definitions = {json.dumps({key: value for key, value in result["definition"].items()
                                   if key != "position_sampling"}, sort_keys=True) for result in real_results}
        motion_sampling = {result["definition"]["position_sampling"] for result in real_results
                           if result["definition"]["position_sampling"] != "no_motion_stop"}
        if len(definitions) > 1 or len(motion_sampling) > 1:
            issues.append({"path": str(root), "code": "mixed_metric_definitions", "detail": "分数、目标来源、停止协议或位姿采样口径不一致，不能汇总"})
        # 无效/回放样本不静默移出分母，避免选择性成功率。
        full = _aggregate(real_results if not issues else [])
        aerial_scope = bool(real_results and all(
            result["definition"].get("task_version") == "aerialvln_s_v1" for result in real_results))
        if not real_results and isinstance(evaluation_manifest, dict):
            aerial_scope = evaluation_manifest.get("split") in ("train", "val_seen", "val_unseen")
        if aerial_scope:
            full = {key: full.get(key) for key in (*METRIC_KEYS, *AERIAL_METRIC_KEYS[3:])}
        metrics.update(full)
        if not issues and replay_results and not real_results:
            payload["status"] = "replay_only"
        else:
            payload["status"] = "closed_loop" if real_results and not issues else "closed_loop_invalid"
        if not issues and real_results:
            metrics.update(_measured_metrics(real_results))
            if all(result["definition"].get("task_version") == "aerialvln_s_v1" for result in real_results):
                metrics["simulator_contact_rate"] = 100. * float(np.mean([r["simulator_contact"] for r in real_results]))
                metrics["depth_collision_proxy_rate"] = 100. * float(np.mean([r["depth_collision_proxy"] for r in real_results]))
        payload["by_split"] = {"full": full}
        split_names = sorted({result["split"] for result in real_results if result["split"] != "full"})
        for split in split_names:
            payload["by_split"][split] = _aggregate([result for result in real_results if result["split"] == split] if not issues else [])
        payload["status_details"] = {
            "real_rollouts": len(real_results), "replay_rollouts": len(replay_results),
            "navigation_metric_units": {"ne": "m", "sr": "%", "osr": "%", "spl": "%", "ndtw": "%", "sdtw": "%", "autonomous_stop_success": "%"},
            "measured_metric_units": {"collision_rate": "%", "success_rate_no_collision": "%", "latency_p50": "ms", "latency_p95": "ms"},
            "latency_measurement": next(iter({result["definition"].get("latency_measurement", "model_inference_per_action")
                                              for result in real_results}), "not_measured") if not issues else "mixed_or_invalid",
        }
        payload["rollouts"] = results
        payload["audit"] = {
            "total_rollouts": len(episodes), "valid_rollouts": len(real_results),
            "valid_replays": len(replay_results),
            "rejected_rollouts": len(episodes) - len(results),
            "issue_count": len(issues), "issues": issues,
        }
    destination = Path(run_dir)
    destination.mkdir(parents=True, exist_ok=True)
    _write_json_atomic(destination / "metrics.json", payload)
    return payload
