"""读取显式版本的 FOV 航点样本或 AerialVLN-S 八动作样本。

位姿直接读轨迹目录下的 log/*.json，指令从 meta 的全量索引取，都不经过
merged_data.json。FOV 的 log 文件名就是 FrontCamera 里 png 的编号，逐一检查配对。
"""

import gzip
import hashlib
import io
import json
import os
import re
from pathlib import Path

import numpy as np
import torch
from PIL import Image
from scipy.spatial.transform import Rotation

from uavnav.avln.geometry import body_offset, aerial_pose_transition

# 数据集里是 FrontCamera，TravelUAV 的生成脚本产出小写，两种都认。
CAMERA_DIRS = ("frontcamera", "FrontCamera")
# 当前 FOV 数据的固定索引跨度，不代表秒。末尾额外图像仅保留用于回放。
FOV_FRAME_GAP = 5
SAMPLE_POLICY = "fov_fixed_index_gap_v1"
AERIAL_DATA_PROTOCOL = "aerialvln_s_v1"
AERIAL_SAMPLE_POLICY = "aerialvln_s_before_action_v1"
AERIAL_HISTORY_POLICY = "action_onehot8_v1"
AERIAL_GROUPED_SPLIT_PROTOCOL = "aerial_train_geometry_grouped_v1"
AERIAL_SPLITS = ("train", "val_seen", "val_unseen", "test")
AERIAL_ACTIONS = ("stop", "forward", "turn_left", "turn_right", "up", "down", "left", "right")
TOKENIZER_VERSIONS = ("fov_numeric_v1", "route_numeric_v1")
NUMBER = re.compile(r"^[+-]?\d+(\.\d+)?$")
# meta 里只有 instruction_with_initial_direction 一个字段，句末固定跟一句初始朝向线索
DIRECTION_CUE = re.compile(r"^it's\b", re.IGNORECASE)
# 与 model.py 的 ResNet50_Weights.IMAGENET1K_V2 配套。改权重必须改这里，反之亦然。
IMAGENET_MEAN = np.array([0.485, 0.456, 0.406], dtype=np.float32)
IMAGENET_STD = np.array([0.229, 0.224, 0.225], dtype=np.float32)


class InsufficientFramesError(RuntimeError):
    """真实记录不足以组成一对图像；不能凭空补帧。"""


def strip_direction_cue(text):
    """去掉句末的初始朝向线索，例如 "It's straight ahead."。

    这句描述初始相对方位。当前工程默认剥离，以统一单步指令处理；是否有助于
    导航或引入捷径需通过消融验证，不能仅据这项预处理推断。识别不到则原样返回。
    """
    parts = re.split(r"(?<=\.)\s+", text.strip())
    if len(parts) > 1 and DIRECTION_CUE.match(parts[-1]):
        return " ".join(parts[:-1]).strip()
    return text.strip()


def load_list(data_root, list_json):
    """读轨迹列表，返回轨迹目录。

    列表每项是相对 <split>/ 的轨迹目录（<Map>/<uuid>），也可以写成 {"dir": ...}。
    """
    root = Path(data_root).resolve()
    if not root.is_dir():
        raise FileNotFoundError(f"数据目录不存在: {root}")
    list_path = Path(list_json) if Path(list_json).is_absolute() else root / list_json
    if not list_path.is_file():
        raise FileNotFoundError(f"轨迹列表不存在: {list_path}")
    rows = json.loads(list_path.read_text(encoding="utf-8"))
    if not isinstance(rows, list):
        raise ValueError(f"{list_path} 必须是 FOV 轨迹列表，不能用 AerialVLN episodes 代替")
    paths = []
    seen = set()
    for row in rows:
        relative = row["dir"] if isinstance(row, dict) else row
        if not isinstance(relative, str) or not relative or Path(relative).is_absolute():
            raise ValueError(f"{list_path} 轨迹路径必须相对当前 split: {relative!r}")
        path = (root / relative).resolve()
        if not path.is_relative_to(root):
            raise ValueError(f"{list_path} 轨迹路径越出当前 split: {relative}")
        if path in seen:
            raise ValueError(f"{list_path} 含重复轨迹: {relative}")
        seen.add(path)
        if not (path / "log").is_dir():
            raise FileNotFoundError(f"列表轨迹缺 log/: {path}")
        paths.append(path)
    if not paths:
        raise RuntimeError(f"{list_path} 里没有可用的轨迹")
    return paths


def load_instructions(instruction_json, strip_direction=True):
    """读 meta 的全量指令索引，结构是 {Map: {uuid: {"instruction_with_initial_direction": ...}}}。

    键统一成 (Map, uuid)，这样 iter_samples 只要从轨迹目录反推两级就能查到。
    """
    payload = json.loads(Path(instruction_json).read_text(encoding="utf-8"))
    table = {}
    for map_name, entries in payload.items():
        for uuid, value in entries.items():
            if isinstance(value, dict):
                value = value.get("instruction_with_initial_direction") or value.get("instruction")
            if not value:
                continue
            text = value.replace("<image>", " ").strip()
            table[(map_name, uuid)] = strip_direction_cue(text) if strip_direction else text
    return table


def _camera_dir(traj_dir):
    for name in CAMERA_DIRS:
        path = traj_dir / name
        if path.is_dir():
            return path
    raise FileNotFoundError(f"{traj_dir} 下没有前视图像目录（找过 {CAMERA_DIRS}）")


def _frames(traj_dir):
    """返回 (frames, gap)。

    frames 是 [(state, image, index)] 按 index 升序，state 直接取自 log/*.json。
    log 文件名就是 FrontCamera 里 png 的编号，两边天然对齐，不需要推算。

    gap 是 FOV 固定的 5 个日志索引跨度。保留真实末尾图像供回放；训练只选
    跨度等于 5 的帧对。不能按每条短轨迹的众数推断：末尾残余可能并列，
    甚至只剩一个短跨度。索引跨度不等于传感器时间。
    """
    camera = _camera_dir(traj_dir)
    states = {}
    for path in (traj_dir / "log").glob("*.json"):
        state = json.loads(path.read_text(encoding="utf-8"))["sensors"]["state"]
        index = int(path.stem)
        if index in states:
            raise ValueError(f"{traj_dir} 含重复日志索引: {index}")
        position = np.asarray(state["position"], dtype=np.float64)
        orientation = np.asarray(state["orientation"], dtype=np.float64)
        if position.shape != (3,) or not np.isfinite(position).all():
            raise ValueError(f"日志位置非法: {path}")
        if (orientation.shape != (4,) or not np.isfinite(orientation).all()
                or np.linalg.norm(orientation) == 0):
            raise ValueError(f"日志 xyzw 非法: {path}")
        states[index] = {"position": state["position"], "orientation": state["orientation"]}
    usable = []
    image_indices = set()
    for image in sorted(camera.glob("*.png")):
        index = int(image.stem)
        if index in image_indices:
            raise ValueError(f"{camera} 含重复图像索引: {index}")
        image_indices.add(index)
        if index not in states:
            raise FileNotFoundError(f"前视图像缺对应日志: {image}")
        usable.append((states[index], image, index))
    usable.sort(key=lambda frame: frame[2])
    if len(usable) < 2:
        raise InsufficientFramesError(f"{traj_dir} 里可用的前视帧不足 2（前视目录 {camera}，log 帧 {len(states)}）")
    return usable, FOV_FRAME_GAP


def _instruction_from_obj_des(traj_dir, strip_direction):
    """退回轨迹自带的 obj_des.json（单元素列表）。剥离方向线索的规则与 meta 侧保持一致，
    否则训练侧剥了、评测侧没剥，同一个模型在两个口径下被评估。"""
    obj_des = traj_dir / "obj_des.json"
    if not obj_des.is_file():
        return None
    text = json.loads(obj_des.read_text(encoding="utf-8"))[0].strip()
    return strip_direction_cue(text) if strip_direction else text


def iter_samples(paths, history_frames, instructions=None, strip_direction=True):
    if history_frames < 0:
        raise ValueError("history_frames 必须非负")
    bad = 0
    missed = 0
    no_fixed_pair = 0
    for traj_dir in paths:
        traj_dir = Path(traj_dir)
        instruction = None
        instruction_source = "unknown"
        if instructions is not None:
            key = (traj_dir.parent.name, traj_dir.name)
            instruction = instructions.get(key)
            if instruction is None:
                # 当前训练指令表只覆盖 train，评测使用 obj_des。
                # 这里必须退回轨迹自带的 obj_des.json，否则整个 split 会悄悄变成空集。
                missed += 1
                instruction = _instruction_from_obj_des(traj_dir, strip_direction)
                instruction_source = "obj_des"
            else:
                instruction_source = "meta"
        else:
            instruction = _instruction_from_obj_des(traj_dir, strip_direction)
            instruction_source = "obj_des"
        if not instruction:
            raise ValueError(f"{traj_dir} 没有可用指令，已停止读取")
        try:
            frames, gap = _frames(traj_dir)
        except InsufficientFramesError as error:
            # 不足帧是已知记录限制；损坏日志和缺失配对必须报错。
            bad += 1
            if bad <= 10:
                print(f"[warn] 跳过轨迹 {traj_dir.name}: {error}")
            continue
        traj_id = f"{traj_dir.parent.name}/{traj_dir.name}"
        if not any(b[2] - a[2] == gap for a, b in zip(frames, frames[1:])):
            no_fixed_pair += 1
            print(f"[warn] 跳过轨迹 {traj_id}: 没有索引跨度为 {gap} 的前视帧对")
        for step in range(len(frames) - 1):
            # 固定索引跨度，排除末尾不足一步和缺帧后的长跨度。
            if frames[step + 1][2] - frames[step][2] != gap:
                continue
            current, image, _ = frames[step]
            nxt = frames[step + 1][0]
            offset = body_offset(
                nxt["position"],
                nxt["orientation"],
                current["position"],
                current["orientation"],
            )
            history = []
            begin = max(0, step - history_frames)
            for past, _, _ in frames[begin:step]:
                history.append(
                    body_offset(
                        past["position"],
                        past["orientation"],
                        current["position"],
                        current["orientation"],
                    )
                )
            yield {
                "traj_id": traj_id,
                "instruction": instruction,
                "instruction_source": instruction_source,
                "image": image,
                "frame_index": frames[step][2],
                "target_frame_index": frames[step + 1][2],
                "frame_gap": gap,
                "sample_policy": SAMPLE_POLICY,
                "history": np.stack(history, axis=0) if history else np.zeros((0, 3)),
                "offset": offset.astype(np.float32),
            }
    if missed:
        print(f"[warn] {missed} 条轨迹在指令表里没查到，已退回 obj_des.json")
    if bad:
        print(f"[warn] 共跳过 {bad} 条数据不完整的轨迹")
    if no_fixed_pair:
        print(f"[warn] 共跳过 {no_fixed_pair} 条没有固定跨度帧对的轨迹")


def _sha256(path):
    digest = hashlib.sha256()
    with Path(path).open("rb") as stream:
        for chunk in iter(lambda: stream.read(1024 * 1024), b""):
            digest.update(chunk)
    return digest.hexdigest()


def aerial_episode_sha256(episode):
    """哈希只覆盖官方原字段，忽略 reader 附加的下划线派生字段。"""
    original = {key: value for key, value in episode.items() if not key.startswith("_")}
    raw = json.dumps(original, sort_keys=True, separators=(",", ":"),
                     ensure_ascii=False, allow_nan=False).encode("utf-8")
    return hashlib.sha256(raw).hexdigest()


def _aerial_vector(value, length, label):
    if (not isinstance(value, list) or len(value) != length
            or any(isinstance(x, bool) or not isinstance(x, (int, float)) for x in value)):
        raise ValueError(f"{label} 必须是 {length} 维有限数值列表")
    array = np.asarray(value, dtype=np.float64)
    if not np.isfinite(array).all():
        raise ValueError(f"{label} 含非有限值")
    return array


def _wrapped_angle(delta):
    return (delta + np.pi) % (2 * np.pi) - np.pi


def aerial_next_pose(pose, action):
    """上游离散设位姿规则，NED 米和弧度，输入/输出 pitch,roll,yaw。"""
    current = _aerial_vector(list(pose), 6, "AerialVLN pose")
    if isinstance(action, bool) or not isinstance(action, int) or not 0 <= action < 8:
        raise ValueError("AerialVLN action 必须为 0 至 7 的整数")
    return aerial_pose_transition(current, action)


_EPISODE_MEMO = {}


def load_aerial_episodes(annotation_root, split):
    """进程内复用：键含标注文件SHA，内容变化即重读；返回深拷贝，调用方改动不污染缓存。"""
    import copy
    root = Path(annotation_root).resolve()
    for candidate in (root / f"{split}.json", root / f"{split}.json.gz",
                      root / split / f"{split}.json.gz", root / split / f"{split}.json"):
        if candidate.is_file():
            info = candidate.stat()
            key = (str(candidate), info.st_size, info.st_mtime_ns)
            if key not in _EPISODE_MEMO:
                _EPISODE_MEMO.clear()
                _EPISODE_MEMO[key] = _load_aerial_episodes_strict(annotation_root, split)
            return copy.deepcopy(_EPISODE_MEMO[key])
    return _load_aerial_episodes_strict(annotation_root, split)


def _load_aerial_episodes_strict(annotation_root, split):
    """读取官方 JSON/gzip，保留官方划分与原字段，附加可审计的派生状态。

    test 的隐藏监督保留为未知。train 单点 STOP 候选仅打隔离标记，原件不修改。
    """
    if split not in AERIAL_SPLITS:
        raise ValueError(f"AerialVLN-S split 必须属于 {AERIAL_SPLITS}")
    root = Path(annotation_root).resolve()
    candidates = [root / f"{split}.json", root / f"{split}.json.gz",
                  root / split / f"{split}.json.gz", root / split / f"{split}.json"]
    files = [path for path in candidates if path.is_file()]
    if len(files) != 1:
        raise FileNotFoundError(f"{root} 必须有且仅有一份 {split}.json 或 gzip，实际 {len(files)} 份")
    source = files[0]
    source_sha = _sha256(source)
    opener = gzip.open if source.suffix == ".gz" else open
    with opener(source, "rt", encoding="utf-8") as stream:
        payload = json.load(stream)
    if not isinstance(payload, dict) or not isinstance(payload.get("episodes"), list) or not payload["episodes"]:
        raise ValueError("AerialVLN-S 顶层必须有非空 episodes 列表")
    result = []
    seen = set()
    for row in payload["episodes"]:
        if not isinstance(row, dict) or any(str(key).startswith("_") for key in row):
            raise ValueError("AerialVLN-S episode 必须为官方 JSON 对象，不能含派生下划线字段")
        scene = row.get("scene_id")
        episode_id, trajectory_id = row.get("episode_id"), row.get("trajectory_id")
        if (isinstance(scene, bool) or not isinstance(scene, int) or scene <= 0
                or any(isinstance(value, bool) or not isinstance(value, (str, int))
                       or not str(value) for value in (episode_id, trajectory_id))):
            raise ValueError("AerialVLN-S scene_id/episode_id/trajectory_id 非法")
        key = (scene, str(episode_id))
        if key in seen:
            raise ValueError(f"AerialVLN-S episode 键重复: {key}")
        seen.add(key)
        instruction = row.get("instruction")
        if (not isinstance(instruction, dict) or not isinstance(instruction.get("instruction_text"), str)
                or not instruction["instruction_text"].strip()):
            raise ValueError(f"AerialVLN-S 指令为空: {key}")
        start = _aerial_vector(row.get("start_position"), 3, f"{key} start_position")
        quaternion = _aerial_vector(row.get("start_rotation"), 4, f"{key} start_rotation wxyz")
        if abs(np.linalg.norm(quaternion) - 1) > 1e-3:
            raise ValueError(f"AerialVLN-S start_rotation 必须是单位 wxyz: {key}")
        derived = dict(row)
        derived.update(_episode_sha256=aerial_episode_sha256(row), _annotation_sha256=source_sha,
                       _annotation_path=str(source), _data_protocol=AERIAL_DATA_PROTOCOL,
                       _quarantine_reason=None, _labels_available=split != "test")
        if split == "test":
            if any(row.get(field) is not None for field in ("reference_path", "actions", "goals")):
                raise ValueError("aerialvln_s_v1 test 真值应由官方隐藏，不能混入自行补造标签")
            result.append(derived)
            continue
        path, actions, goals = row.get("reference_path"), row.get("actions"), row.get("goals")
        if (not isinstance(path, list) or not path or not isinstance(actions, list)
                or len(actions) != len(path)):
            raise ValueError(f"AerialVLN-S reference_path/actions 必须非空且等长: {key}")
        poses = np.stack([_aerial_vector(pose, 6, f"{key} reference_path") for pose in path])
        if any(isinstance(action, bool) or not isinstance(action, int) or not 0 <= action < 8 for action in actions):
            raise ValueError(f"AerialVLN-S actions 必须是八动作整数: {key}")
        if actions[-1] != 0 or 0 in actions[:-1]:
            raise ValueError(f"AerialVLN-S 仅末动作可为 STOP: {key}")
        if not np.allclose(poses[0, :3], start, atol=1e-4, rtol=0):
            raise ValueError(f"AerialVLN-S 首参考位置与 start 不一致: {key}")
        w, x, y, z = quaternion / np.linalg.norm(quaternion)
        yaw = np.arctan2(2 * (w * z + x * y), 1 - 2 * (y * y + z * z))
        if abs(_wrapped_angle(poses[0, 5] - yaw)) > 1e-6:
            raise ValueError(f"AerialVLN-S 首参考 yaw 与 wxyz start 不一致: {key}")
        if not isinstance(goals, list) or not goals or any(not isinstance(goal, dict) for goal in goals):
            raise ValueError(f"AerialVLN-S goals 必须为非空对象列表: {key}")
        positions = [_aerial_vector(goal.get("position"), 3, f"{key} goal position") for goal in goals]
        if not any(np.allclose(poses[-1, :3], goal, atol=1e-4, rtol=0) for goal in positions):
            raise ValueError(f"AerialVLN-S 末参考位置与 goals 不一致: {key}")
        if len(poses) > 1:
            expected = aerial_pose_transition(poses[:-1], np.asarray(actions[:-1], dtype=np.int64))
            position_bad = np.any(np.abs(expected[:, :3] - poses[1:, :3]) > 1e-4, axis=1)
            rotation_bad = np.any(np.abs(_wrapped_angle(expected[:, 3:] - poses[1:, 3:])) > 1e-6, axis=1)
            bad = np.flatnonzero(position_bad | rotation_bad)
            if len(bad):
                raise ValueError(f"AerialVLN-S 动作/位置/yaw 标签冲突: {key} frame {int(bad[0])}")
        if split == "train" and len(path) == 1:
            derived["_quarantine_reason"] = "singleton_stop_requires_semantic_review"
        result.append(derived)
    if _sha256(source) != source_sha:
        raise RuntimeError("AerialVLN-S 标注在读取期间发生改变")
    return result


_VERIFIED_FILES = {}


def prefetch_verified_files(root, items, workers=32):
    """并行计算 SHA 并缓存；_aerial_cache_file 命中缓存时跳过重复读取，校验条件不变。"""
    from concurrent.futures import ThreadPoolExecutor
    root = Path(root).resolve()
    jobs = {}
    for item in items:
        if isinstance(item, dict) and isinstance(item.get("path"), str) and isinstance(item.get("sha256"), str):
            path = (root / item["path"]).resolve()
            if path.is_relative_to(root) and path.is_file():
                jobs[path] = item["sha256"]
    with ThreadPoolExecutor(max_workers=workers) as pool:
        for path, digest in zip(jobs, pool.map(_sha256, jobs)):
            _VERIFIED_FILES[(path, jobs[path])] = digest


def _aerial_cache_file(root, item, label):
    if not isinstance(item, dict) or not isinstance(item.get("path"), str):
        raise ValueError(f"{label} 必须包含相对 path 与 sha256")
    relative, expected = item["path"], item.get("sha256")
    if (not relative or Path(relative).is_absolute() or not isinstance(expected, str)
            or not re.fullmatch(r"[a-f0-9]{64}", expected)):
        raise ValueError(f"{label} path/sha256 非法")
    path = (root / relative).resolve()
    if not path.is_relative_to(root):
        raise ValueError(f"{label} path 越出缓存目录")
    if not path.is_file():
        raise FileNotFoundError(f"{label} 缺少渲染文件: {path}")
    actual = _VERIFIED_FILES.get((path, expected)) or _sha256(path)
    if actual != expected:
        raise ValueError(f"{label} SHA256 与渲染缓存不一致: {path}")
    return path


def _aerial_depth_storage(path, protocol=None):
    """压缩深度显式绑定无损存储；旧npy不补造新合同字段。"""
    if str(path).lower().endswith(".npy.gz"):
        if protocol != "npy_gzip_float32_v1":
            raise ValueError("压缩深度必须显式声明npy_gzip_float32_v1 storage_protocol")
    elif Path(path).suffix.lower() == ".npy":
        if protocol not in (None, "npy_float_v1"):
            raise ValueError("npy深度storage_protocol与文件后缀不一致")
    else:
        raise ValueError("深度缓存必须是.npy或声明协议的.npy.gz文件")
    return protocol


def _canonical_json_sha256(value):
    raw = json.dumps(value, sort_keys=True, separators=(",", ":"),
                     ensure_ascii=False, allow_nan=False).encode("utf-8")
    return hashlib.sha256(raw).hexdigest()


def validate_aerial_render_protocol(render):
    """Check historical v1 or source-bound v2 without inventing missing provenance."""
    if isinstance(render, dict) and render.get("protocol_version") == "aerialvln_s_multiscene_rgb_v1":
        if (set(render) != {"protocol_version", "camera_name", "scenes"}
                or render["camera_name"] != "front_0" or not isinstance(render["scenes"], dict)
                or not render["scenes"]):
            raise ValueError("多场景渲染合同缺少front_0与场景来源")
        for scene, child in render["scenes"].items():
            if (not isinstance(scene, str) or not scene.isdigit() or str(int(scene)) != scene or int(scene) <= 0
                    or not isinstance(child, dict) or child.get("protocol_version") != "aerialvln_s_pose_rgb_v2"
                    or child.get("camera_name") != render["camera_name"]):
                raise ValueError("多场景合同需要唯一合法scene_id与真实v2来源")
            validate_aerial_render_protocol(child)
        return
    if (not isinstance(render, dict)
            or render.get("protocol_version") not in ("aerialvln_s_pose_rgb_v1", "aerialvln_s_pose_rgb_v2")
            or render.get("pose_mode") != "simSetVehiclePose_ignore_collision"
            or render.get("pixel_order") != "RGB" or render.get("rgb_type") != "Scene"
            or not isinstance(render.get("camera_name"), str) or not render["camera_name"].strip()
            or any(isinstance(render.get(field), bool) or not isinstance(render.get(field), int)
                   or render[field] < 1 for field in ("width", "height"))):
        raise ValueError("AerialVLN-S render_protocol 不完整或不支持")
    if render["protocol_version"] == "aerialvln_s_pose_rgb_v1":
        return
    provenance = render.get("provenance")
    if not isinstance(provenance, dict):
        raise ValueError("AerialVLN-S v2 缺少 provenance")
    settings, build = provenance.get("settings"), provenance.get("scene_build")
    if not isinstance(settings, dict) or not settings or not isinstance(build, dict):
        raise ValueError("AerialVLN-S v2 settings/scene_build 必须为非空来源对象")
    files = build.get("files")
    if not isinstance(files, list) or not files:
        raise ValueError("AerialVLN-S v2 scene_build files 必须为非空列表")
    exclusions = build.get("exclusion_policy")
    if (exclusions is not None and exclusions != {
            "version": "unreal_saved_directories_v1", "directory_names": ["Saved"]}):
        raise ValueError("AerialVLN-S v2 scene_build 排除规则不支持")
    paths = set()
    for item in files:
        if (not isinstance(item, dict) or set(item) != {"path", "sha256", "size"}
                or not isinstance(item["path"], str) or not item["path"].strip()
                or Path(item["path"]).is_absolute() or ".." in Path(item["path"]).parts
                or item["path"] in paths
                or not isinstance(item["sha256"], str) or not re.fullmatch(r"[a-f0-9]{64}", item["sha256"])
                or isinstance(item["size"], bool) or not isinstance(item["size"], int) or item["size"] < 0):
            raise ValueError("AerialVLN-S v2 scene_build 文件来源非法或重复")
        paths.add(item["path"])
        if exclusions is not None and "Saved" in Path(item["path"]).parts[:-1]:
            raise ValueError("AerialVLN-S v2 scene_build 与已声明的Saved目录排除规则冲突")
    try:
        valid_hashes = (build.get("sha256") == _canonical_json_sha256(files)
                        and provenance.get("settings_sha256") == _canonical_json_sha256(settings))
    except (TypeError, ValueError) as error:
        raise ValueError("AerialVLN-S v2 settings/build 必须为有限 JSON") from error
    if not valid_hashes:
        raise ValueError("AerialVLN-S v2 settings/build SHA256 与内容不一致")
    fov = provenance.get("camera_fov_degrees")
    if (isinstance(fov, bool) or not isinstance(fov, (int, float))
            or not np.isfinite(fov) or not 0 < fov < 180):
        raise ValueError("AerialVLN-S v2 camera_fov_degrees 非法")
    extrinsics = provenance.get("camera_extrinsics")
    if not isinstance(extrinsics, dict):
        raise ValueError("AerialVLN-S v2 camera_extrinsics 不完整")
    _aerial_vector(extrinsics.get("position"), 3, "camera_extrinsics position")
    _aerial_vector(extrinsics.get("rotation_degrees"), 3, "camera_extrinsics rotation_degrees")
    try:
        camera = settings["Vehicles"][render.get("vehicle_name", "Drone_1")]["Cameras"][render["camera_name"]]
        source_position = _aerial_vector([camera[key] for key in ("X", "Y", "Z")], 3, "settings camera position")
        source_angles = _aerial_vector([camera[key] for key in ("Pitch", "Roll", "Yaw")], 3, "settings camera angles")
        captures = [item for item in camera["CaptureSettings"]
                    if isinstance(item, dict) and type(item.get("ImageType")) is int and item["ImageType"] == 0]
    except (KeyError, TypeError) as error:
        raise ValueError("AerialVLN-S v2 settings 缺少指定车辆/相机的显式来源") from error
    if (not np.array_equal(source_position, extrinsics["position"])
            or not np.array_equal(source_angles, extrinsics["rotation_degrees"])
            or len(captures) != 1 or captures[0].get("Width") != render["width"]
            or captures[0].get("Height") != render["height"]):
        raise ValueError("AerialVLN-S v2 settings 相机外参/尺寸与渲染合同不一致")
    policy = provenance.get("capture_policy")
    if (not isinstance(policy, dict)
            or policy.get("version") not in ("set_pose_unpaused_single_request_v1",
                                               "set_pose_unpaused_bounded_refresh_v1",
                                               "set_pose_unpaused_rgbd_bounded_refresh_v2",
                                               "set_pose_unpaused_rgbd_bounded_rerequest_v3")
            or isinstance(policy.get("wait_seconds"), bool) or policy.get("wait_seconds") != 0.0
            or policy.get("pause") is not False):
        raise ValueError("AerialVLN-S v2 capture_policy 不支持")
    if policy["version"] in ("set_pose_unpaused_bounded_refresh_v1",
                              "set_pose_unpaused_rgbd_bounded_refresh_v2"):
        if (policy.get("max_refresh_attempts") != 3
                or policy.get("clock_advance") != "simContinueForFrames"):
            raise ValueError("AerialVLN-S v2 bounded-refresh capture_policy 不完整")
    if (policy["version"] == "set_pose_unpaused_rgbd_bounded_refresh_v2"
            and (type(policy.get("max_refresh_attempts")) is not int
                 or policy.get("timestamp_skew_policy") != "measure_only")):
        raise ValueError("AerialVLN-S RGB-D v2必须显式记录时间差为measure_only")
    if policy["version"] == "set_pose_unpaused_rgbd_bounded_rerequest_v3":
        if (type(policy.get("max_refresh_attempts")) is not int
                or policy["max_refresh_attempts"] != 3 or policy.get("clock_advance") != "none"
                or policy.get("timestamp_skew_policy") != "measure_only"):
            raise ValueError("AerialVLN-S RGB-D v3要求有限重新请求且不推进时钟")


AERIAL_CAPTURE_FRAME_FIELDS = (
    "response_camera_position", "response_camera_orientation_xyzw", "image_timestamp_ns",
    "request_started_ns", "response_received_ns", "pose_requested_ns",
)
AERIAL_RGBD_CAPTURE_FRAME_FIELDS = (
    "depth_timestamp_ns", "depth_response_camera_position", "depth_response_camera_orientation_xyzw",
    "rgb_depth_timestamp_skew_ns", "image_refresh_attempts", "image_refresh_audit",
    "capture_paused_before", "capture_paused_after",
)


def _validate_aerial_capture_frame(frame, pose, render, previous):
    """Wall-clock request ordering and sensor ordering are separate clock domains."""
    fields = ("pose_requested_ns", "request_started_ns", "response_received_ns", "image_timestamp_ns")
    values = [frame.get(field) for field in fields]
    capture_policy = render["provenance"]["capture_policy"]["version"]
    rgbd = capture_policy in ("set_pose_unpaused_rgbd_bounded_refresh_v2",
                              "set_pose_unpaused_rgbd_bounded_rerequest_v3")
    if previous is not None:
        if rgbd:
            if not isinstance(previous, dict) or previous.get("capture_policy") != capture_policy:
                raise ValueError("AerialVLN-S RGB-D capture状态合同不一致")
            previous_times = previous["times"]
        else:
            previous_times = previous
    if any(isinstance(value, bool) or not isinstance(value, int) or value <= 0 for value in values):
        raise ValueError("AerialVLN-S v2 frame 时间必须为正整数纳秒")
    pose_ns, request_ns, response_ns, image_ns = values
    if (not pose_ns <= request_ns <= response_ns
            or (previous is not None and (image_ns <= previous_times[3] or pose_ns < previous_times[2]))):
        raise ValueError("AerialVLN-S v2 frame 时间顺序不一致")
    position = _aerial_vector(frame.get("response_camera_position"), 3, "response_camera_position")
    quaternion = _aerial_vector(frame.get("response_camera_orientation_xyzw"), 4,
                                "response_camera_orientation_xyzw")
    if abs(np.linalg.norm(quaternion) - 1) > 1e-3:
        raise ValueError("AerialVLN-S v2 response camera 必须为单位 xyzw")
    extrinsics = render["provenance"]["camera_extrinsics"]
    body = Rotation.from_euler("xyz", np.asarray(pose)[[4, 3, 5]])
    camera = Rotation.from_euler("xyz", np.asarray(extrinsics["rotation_degrees"])[[1, 0, 2]], degrees=True)
    expected_position = np.asarray(pose[:3]) + body.apply(extrinsics["position"])
    if (np.linalg.norm(position - expected_position) > .02
            or (Rotation.from_quat(quaternion).inv() * body * camera).magnitude() > 1e-4):
        raise ValueError("AerialVLN-S v2 response camera 与来源外参/请求 pose 不一致")
    if rgbd:
        depth_ns = frame.get("depth_timestamp_ns")
        skew = frame.get("rgb_depth_timestamp_skew_ns")
        if (type(depth_ns) is not int or depth_ns <= 0 or type(skew) is not int
                or skew != depth_ns - image_ns
                or (previous is not None and depth_ns <= previous["depth_timestamp_ns"])):
            raise ValueError("AerialVLN-S RGB-D深度时间戳/时间差不一致或未推进")
        depth_position = _aerial_vector(frame.get("depth_response_camera_position"), 3,
                                       "depth_response_camera_position")
        depth_quaternion = _aerial_vector(frame.get("depth_response_camera_orientation_xyzw"), 4,
                                         "depth_response_camera_orientation_xyzw")
        if (abs(np.linalg.norm(depth_quaternion) - 1) > 1e-3
                or np.linalg.norm(depth_position - expected_position) > .02
                or (Rotation.from_quat(depth_quaternion).inv() * body * camera).magnitude() > 1e-4):
            raise ValueError("AerialVLN-S RGB-D depth camera与请求pose/外参不一致")
        if frame.get("capture_paused_before") is not False or frame.get("capture_paused_after") is not False:
            raise ValueError("AerialVLN-S RGB-D采集前后必须实查未暂停")
        attempts, audit = frame.get("image_refresh_attempts"), frame.get("image_refresh_audit")
        if (type(attempts) is not int or not 0 <= attempts <= 3
                or not isinstance(audit, list) or len(audit) != attempts + 1):
            raise ValueError("AerialVLN-S RGB-D刷新次数/审计缺失或不一致")
        last_response = pose_ns
        for index, item in enumerate(audit):
            required = {"attempt_index", "image_timestamp_ns", "depth_timestamp_ns", "request_started_ns",
                        "response_received_ns", "rgb_fresh", "depth_fresh", "rejection_reasons"}
            if not isinstance(item, dict) or not required <= item.keys():
                raise ValueError("AerialVLN-S RGB-D刷新审计必须为对象")
            start, end = item.get("request_started_ns"), item.get("response_received_ns")
            if (type(item.get("attempt_index")) is not int or item["attempt_index"] != index
                    or any(type(item.get(name)) is not int or item[name] <= 0
                           for name in ("request_started_ns", "response_received_ns"))
                    or not last_response <= start <= end
                    or type(item.get("rgb_fresh")) is not bool or type(item.get("depth_fresh")) is not bool
                    or not isinstance(item.get("rejection_reasons"), list)
                    or any(not isinstance(reason, str) or not reason for reason in item["rejection_reasons"])
                    or (index < attempts and not item["rejection_reasons"])):
                raise ValueError("AerialVLN-S RGB-D刷新审计类型/时序/拒绝原因不一致")
            for name, fresh_name in (("image_timestamp_ns", "rgb_fresh"), ("depth_timestamp_ns", "depth_fresh")):
                stamp = item.get(name)
                if ((stamp is not None and (type(stamp) is not int or stamp < 0))
                        or (item[fresh_name] and (stamp is None or stamp == 0))):
                    raise ValueError("AerialVLN-S RGB-D拒绝帧时间必须为非负整数或显式缺测")
                reason = "rgb_timestamp_not_advanced" if fresh_name == "rgb_fresh" else "depth_timestamp_not_advanced"
                if not item[fresh_name] and reason not in item["rejection_reasons"]:
                    raise ValueError("AerialVLN-S RGB-D刷新传感器fresh标记与拒绝原因不一致")
            last_response = end
        final = audit[-1]
        if (final["image_timestamp_ns"] != image_ns or final["depth_timestamp_ns"] != depth_ns
                or final["request_started_ns"] != request_ns or final["response_received_ns"] != response_ns
                or final["rgb_fresh"] is not True or final["depth_fresh"] is not True
                or final["rejection_reasons"]):
            raise ValueError("AerialVLN-S RGB-D最终审计与接受帧不一致")
        return {"capture_policy": capture_policy, "times": values,
                "depth_timestamp_ns": depth_ns}
    return values


_PATH_FIELDS = ("image", "depth")


def _portable_sample(sample):
    """落盘用纯数据：Path→str，history→list；weights_only加载不放开任意类。"""
    result = {key: (str(value) if isinstance(value, Path) else value) for key, value in sample.items()}
    result["history"] = np.asarray(sample["history"]).tolist()
    result["_path_fields"] = [key for key in _PATH_FIELDS if isinstance(sample.get(key), Path)]
    return result


def _restore_sample(sample):
    result = dict(sample)
    for key in result.pop("_path_fields"):
        result[key] = Path(result[key])
    result["history"] = np.asarray(result["history"], dtype=np.float32).reshape(-1, 8)
    return result


def _sample_index_key(annotation_root, split, manifest_path, manifest_sha, episodes, history_frames,
                      include_route_metadata, require_depth):
    source = hashlib.sha256(Path(__file__).read_bytes()).hexdigest()
    return {"version": "verified_sample_index_v1", "source_sha256": source, "manifest_sha256": manifest_sha,
            "manifest_path": str(manifest_path), "annotation_sha256": episodes[0]["_annotation_sha256"],
            "split": split, "history_frames": history_frames,
            "include_route_metadata": include_route_metadata, "require_depth": require_depth}


def _file_stats(samples):
    stats = {}
    for sample in samples:
        for field in ("image", "depth"):
            path = sample.get(field)
            if isinstance(path, (str, Path)) and path not in stats:
                info = os.stat(path)
                stats[path] = (info.st_size, info.st_mtime_ns)
    return stats


def load_aerial_samples(annotation_root, split, cache_manifest, history_frames=8,
                        include_route_metadata=False, require_depth=False, index_mode="off", index_dir=None):
    """index_mode: off=严格逐帧重检(默认,旧行为);ram=进程内复用已验证结果;disk=已验证样本落盘复用。

    ram/disk 的键绑定源码SHA、清单SHA、标注SHA与参数,任一变化即作废并重建；
    命中后仍逐文件核对大小与mtime,变化则拒绝并重建,不信任陈旧旁路。
    """
    if index_mode not in ("off", "ram", "disk"):
        raise ValueError("index_mode只接受off/ram/disk")
    if index_mode == "off":
        return _load_aerial_samples_strict(annotation_root, split, cache_manifest, history_frames,
                                           include_route_metadata, require_depth)
    if index_mode == "disk" and not index_dir:
        raise ValueError("index_mode=disk需要index_dir")
    manifest_path = Path(cache_manifest).resolve()
    manifest_sha = _sha256(manifest_path)
    if json.loads(manifest_path.read_text(encoding="utf-8")).get("cache_kind") == "scene_shards_v1":
        return _load_aerial_samples_strict(annotation_root, split, cache_manifest, history_frames,
                                           include_route_metadata, require_depth, index_mode, index_dir)
    episodes = load_aerial_episodes(annotation_root, split)
    key = _sample_index_key(annotation_root, split, manifest_path, manifest_sha, episodes, history_frames,
                            include_route_metadata, require_depth)
    key_sha = _canonical_json_sha256(key)
    entry = _RAM_SAMPLE_INDEX.get(key_sha)
    sidecar = Path(index_dir) / f"{key_sha}.pt" if index_mode == "disk" else None
    if entry is None and sidecar is not None and sidecar.is_file():
        stored = torch.load(sidecar, map_location="cpu", weights_only=True)
        if stored.get("key") == key:
            stored["samples"] = [_restore_sample(sample) for sample in stored["samples"]]
            entry = stored
    if entry is not None:
        try:
            if all((os.stat(p).st_size, os.stat(p).st_mtime_ns) == tuple(v) for p, v in entry["files"].items()):
                _RAM_SAMPLE_INDEX[key_sha] = entry
                return [dict(sample) for sample in entry["samples"]]
        except OSError:
            pass
    samples = _load_aerial_samples_strict(annotation_root, split, cache_manifest, history_frames,
                                          include_route_metadata, require_depth)
    entry = {"key": key, "samples": samples, "files": _file_stats(samples)}
    _RAM_SAMPLE_INDEX[key_sha] = entry
    if sidecar is not None:
        sidecar.parent.mkdir(parents=True, exist_ok=True)
        temporary = sidecar.with_name(sidecar.name + ".pending")
        portable = [_portable_sample(sample) for sample in samples]
        torch.save({"key": key, "samples": portable, "files": {str(k): list(v) for k, v in entry["files"].items()}}, temporary)
        os.replace(temporary, sidecar)
    return [dict(sample) for sample in samples]


_RAM_SAMPLE_INDEX = {}


def _load_aerial_samples_strict(annotation_root, split, cache_manifest, history_frames=8,
                                include_route_metadata=False, require_depth=False, index_mode="off", index_dir=None):
    """由冻结的真实 RGB 缓存生成动作前监督；缺帧/改源/姿态错配均停止。

    manifest 允许显式 episode 子集，每个非隔离 episode 必须有所有参考状态。
    策略样本不包含目标位置或参考未来，history 仅包含过去已执行的动作。
    """
    if split == "test":
        raise ValueError("官方 test 无动作监督，不能进入训练/带标签采样")
    if isinstance(history_frames, bool) or not isinstance(history_frames, int) or history_frames < 0:
        raise ValueError("history_frames 必须是非负整数")
    if type(include_route_metadata) is not bool:
        raise ValueError("include_route_metadata 必须为bool")
    if type(require_depth) is not bool:
        raise ValueError("require_depth 必须为bool")
    episodes = load_aerial_episodes(annotation_root, split)
    by_key = {(episode["scene_id"], str(episode["episode_id"])): episode for episode in episodes}
    manifest_path = Path(cache_manifest).resolve()
    if not manifest_path.is_file():
        raise FileNotFoundError(f"AerialVLN-S 渲染缓存清单不存在: {manifest_path}")
    manifest_sha = _sha256(manifest_path)
    manifest = json.loads(manifest_path.read_text(encoding="utf-8"))
    if (not isinstance(manifest, dict) or manifest.get("schema_version") != 1
            or isinstance(manifest.get("schema_version"), bool)
            or manifest.get("data_protocol") != AERIAL_DATA_PROTOCOL or manifest.get("split") != split):
        raise ValueError("AerialVLN-S 缓存 schema/data_protocol/split 不一致")
    if manifest.get("annotation_sha256") != episodes[0]["_annotation_sha256"]:
        raise ValueError("AerialVLN-S 缓存 annotation_sha256 与当前官方标注不一致")
    render = manifest.get("render_protocol")
    validate_aerial_render_protocol(render)
    if manifest.get("cache_kind") == "scene_shards_v1":
        return _load_aerial_cache_index(annotation_root, split, manifest_path, manifest, manifest_sha,
                                        episodes, history_frames, include_route_metadata, require_depth,
                                        index_mode, index_dir)
    capture_session = manifest.get("capture_session_id")
    if (render["protocol_version"] == "aerialvln_s_pose_rgb_v2"
            and (not isinstance(capture_session, str) or not capture_session.strip())):
        raise ValueError("AerialVLN-S v2 缺少 capture_session_id")
    rows = manifest.get("episodes")
    if not isinstance(rows, list) or not rows:
        raise ValueError("AerialVLN-S 缓存 episodes 必须为非空列表")
    seen = set()
    samples = []
    prefetch_verified_files(manifest_path.parent, [frame.get("rgb") for row in rows if isinstance(row, dict)
                                                   for frame in (row.get("frames") or []) if isinstance(frame, dict)])
    for row in rows:
        if not isinstance(row, dict):
            raise ValueError("AerialVLN-S 缓存 episode 必须为对象")
        if (isinstance(row.get("scene_id"), bool) or not isinstance(row.get("scene_id"), int)
                or isinstance(row.get("episode_id"), bool)
                or not isinstance(row.get("episode_id"), (str, int))):
            raise ValueError("AerialVLN-S 缓存 episode 身份字段非法")
        key = (row.get("scene_id"), str(row.get("episode_id")))
        if key in seen or key not in by_key:
            raise ValueError(f"AerialVLN-S 缓存 episode 重复或不属于当前 split: {key}")
        seen.add(key)
        episode = by_key[key]
        if row.get("episode_sha256") != episode["_episode_sha256"]:
            raise ValueError(f"AerialVLN-S 缓存 episode_sha256 与原内容不一致: {key}")
        if episode["_quarantine_reason"]:
            print(f"[warn] 隔离训练单点 STOP 候选 {key}: {episode['_quarantine_reason']}")
            continue
        frames = row.get("frames")
        poses, actions = episode["reference_path"], episode["actions"]
        if not isinstance(frames, list) or len(frames) != len(poses):
            raise ValueError(f"AerialVLN-S 渲染缓存缺参考状态帧: {key}")
        previous_capture = None
        for index, (frame, pose, action) in enumerate(zip(frames, poses, actions)):
            if (not isinstance(frame, dict) or isinstance(frame.get("frame_index"), bool)
                    or not isinstance(frame.get("frame_index"), int)
                    or frame.get("frame_index") != index):
                raise ValueError(f"AerialVLN-S 缓存 frame_index 不连续: {key}")
            rendered_pose = _aerial_vector(frame.get("pose"), 6, f"{key} rendered pose")
            if (not np.allclose(rendered_pose[:3], pose[:3], atol=1e-4, rtol=0)
                    or np.max(np.abs(_wrapped_angle(rendered_pose[3:] - np.asarray(pose[3:])))) > 1e-6):
                raise ValueError(f"AerialVLN-S 渲染缓存源 pose 不一致: {key} frame {index}")
            if render["protocol_version"] == "aerialvln_s_pose_rgb_v2":
                previous_capture = _validate_aerial_capture_frame(frame, pose, render, previous_capture)
            image = _aerial_cache_file(manifest_path.parent, frame.get("rgb"), f"{key} RGB {index}")
            with Image.open(image) as raw:
                if raw.mode != "RGB" or raw.size != (render["width"], render["height"]):
                    raise ValueError(f"AerialVLN-S RGB 尺寸/通道与渲染协议不一致: {image}")
                raw.verify()
            depth_path = None
            if frame.get("depth") is not None:
                if render.get("depth_protocol") != "scene1_7_depthvis255_else_depthperspective100_v1":
                    raise ValueError("AerialVLN-S depth 缓存必须声明官方场景差异协议")
                depth_path = _aerial_cache_file(manifest_path.parent, frame["depth"], f"{key} depth {index}")
                storage = _aerial_depth_storage(depth_path, frame["depth"].get("storage_protocol"))
                if require_depth:
                    preprocess_depth(depth_path, frame["depth"]["sha256"], storage)
            elif require_depth:
                raise ValueError(f"RGB-D需要每个动作前状态的真实深度: {key} frame {index}")
            past = actions[max(0, index - history_frames):index] if history_frames else []
            history = np.eye(8, dtype=np.float32)[past] if past else np.zeros((0, 8), dtype=np.float32)
            samples.append({
                "image": image, "instruction": episode["instruction"]["instruction_text"],
                "instruction_source": "aerialvln_official", "history": history, "action": action,
                "traj_id": f"{episode['scene_id']}/{episode['trajectory_id']}",
                "episode_id": episode["episode_id"], "scene_id": episode["scene_id"], "frame_index": index,
                "sample_policy": AERIAL_SAMPLE_POLICY, "data_protocol": AERIAL_DATA_PROTOCOL,
                "history_policy": AERIAL_HISTORY_POLICY, "episode_sha256": episode["_episode_sha256"],
                "image_sha256": frame["rgb"]["sha256"], "annotation_sha256": episode["_annotation_sha256"],
                "cache_manifest_sha256": manifest_sha, "render_protocol": dict(render),
            })
            if include_route_metadata:
                # Explicit opt-in preserves the historical all-fields sample digest.
                samples[-1].update(source_split=split, reference_pose=list(pose),
                                   reference_length=len(poses))
            if require_depth:
                samples[-1].update(depth=depth_path, depth_sha256=frame["depth"]["sha256"],
                                   depth_input_protocol="front_0_scene_normalized_256_v1")
                if storage is not None:
                    samples[-1]["depth_storage_protocol"] = storage
            if render["protocol_version"] == "aerialvln_s_pose_rgb_v2":
                samples[-1]["capture_session_id"] = capture_session
    if not samples:
        raise RuntimeError("AerialVLN-S 缓存没有可训练样本，隔离候选不能充作训练数据")
    if _sha256(manifest_path) != manifest_sha:
        raise RuntimeError("AerialVLN-S 缓存清单在读取期间发生改变")
    return samples


def load_aerial_development_split(path, official):
    """Authenticate a frozen full-train geometric holdout against original release content."""
    from uavnav.avln.metadata import authenticate_aerial_release
    certificate = authenticate_aerial_release("train", official)
    path = Path(path).resolve()
    digest = _sha256(path)
    payload = json.loads(path.read_text(encoding="utf-8"))
    manifest = validate_aerial_route_split_manifest(payload.get("development_route_split", payload))
    if (manifest["annotation_sha256"] != certificate["annotation_sha256"]
            or manifest["split_seed"] != 0):
        raise ValueError("完整train开发名单标注来源不一致或非seed0")
    expected = {(ep["scene_id"], str(ep["episode_id"])): ep for ep in official if not ep["_quarantine_reason"]}
    found = set()
    for route in manifest["routes"]:
        for item in route["episodes"]:
            key = (item["scene_id"], item["episode_id"])
            episode = expected.get(key)
            if (episode is None or item["episode_sha256"] != episode["_episode_sha256"]
                    or route["identity"] != _aerial_geometry_identity(episode["scene_id"], episode["reference_path"])):
                raise ValueError("完整train开发名单episode/完整几何与官方内容不一致")
            found.add(key)
    if found != set(expected) or _sha256(path) != digest:
        raise ValueError("开发名单不覆盖完整有效train或读取期间被修改")
    return manifest, digest


def aerial_cache_index_children(manifest):
    """已冻结场景分片路径，仅当前目录之下，每场景唯一、逐内容SHA认证。"""
    path = Path(manifest).resolve()
    payload = json.loads(path.read_text(encoding="utf-8"))
    if payload.get("cache_kind") != "scene_shards_v1":
        return []
    shards = payload.get("shards")
    if not isinstance(shards, list) or not shards:
        raise ValueError("多场景缓存index缺少分片")
    paths, scenes, children = set(), set(), []
    for shard in shards:
        if (not isinstance(shard, dict) or set(shard) != {"path", "sha256", "scene_id"}
                or type(shard["scene_id"]) is not int or shard["scene_id"] <= 0
                or not isinstance(shard["path"], str) or ".." in Path(shard["path"]).parts
                or shard["scene_id"] in scenes):
            raise ValueError("多场景分片路径/场景非法或重复")
        child = _aerial_cache_file(path.parent, shard, "scene shard")
        if child == path or child in paths:
            raise ValueError("多场景分片不能循环或重复引用")
        child_payload = json.loads(child.read_text(encoding="utf-8"))
        if child_payload.get("cache_kind") is not None:
            raise ValueError("多场景分片必须是单场景直接缓存，禁止嵌套index")
        paths.add(child)
        scenes.add(shard["scene_id"])
        children.append(child)
    return children


def _load_aerial_cache_index(annotation_root, split, path, payload, digest, official,
                              history_frames, include_route_metadata, require_depth, index_mode="off", index_dir=None):
    from uavnav.avln.metadata import authenticate_aerial_release
    certificate = authenticate_aerial_release(split, official)
    development = payload.get("cache_index_protocol") == "aerial_development_subset_v1"
    scope = "train_source_development_partition_complete" if development else "official_split_complete"
    if (payload.get("status") != "complete" or payload.get("scope") != scope
            or payload.get("official_source_authentication") != certificate
            or payload["render_protocol"].get("protocol_version") != "aerialvln_s_multiscene_rgb_v1"
            or not development and payload.get("cache_index_protocol") is not None):
        raise ValueError("多场景全量缓存必须封口并绑定官方完整发布身份")
    excluded = sorted([{"scene_id": ep["scene_id"], "episode_id": ep["episode_id"],
                        "episode_sha256": ep["_episode_sha256"], "reason": ep["_quarantine_reason"]}
                       for ep in official if ep["_quarantine_reason"]],
                      key=lambda row: (row["scene_id"], str(row["episode_id"])))
    if (payload.get("excluded_quarantine") != excluded
            or payload.get("excluded_quarantine_sha256") != _canonical_json_sha256(excluded)):
        raise ValueError("多场景隔离名单必须逐内容绑定官方已审理由，禁止任意排除")
    expected = {(ep["scene_id"], str(ep["episode_id"])) for ep in official if not ep["_quarantine_reason"]}
    if development:
        if split != "train":
            raise ValueError("独立开发子集只能使用官方train来源")
        split_file = _aerial_cache_file(path.parent, payload.get("development_split_manifest"), "development split")
        route_split, split_digest = load_aerial_development_split(split_file, official)
        expected = {(item["scene_id"], item["episode_id"]) for item in route_split["dev_episode_keys"]}
        if payload.get("dev_episode_keys_sha256") != route_split["dev_episode_keys_sha256"]:
            raise ValueError("开发index冻结目标名单SHA不一致")
    index_rows = payload.get("episodes")
    if (not isinstance(index_rows, list) or any(not isinstance(row, dict) or type(row.get("scene_id")) is not int
            or isinstance(row.get("episode_id"), bool) or not isinstance(row.get("episode_id"), (str, int)) for row in index_rows)):
        raise ValueError("多场景缓存index缺完整episode身份清单")
    indexed = [(row["scene_id"], str(row["episode_id"])) for row in index_rows]
    if len(indexed) != len(expected) or set(indexed) != expected:
        raise ValueError("多场景index任务身份并非完整官方split")
    if development:
        episode_hashes = {(ep["scene_id"], str(ep["episode_id"])): ep["_episode_sha256"] for ep in official}
        if any(row.get("episode_sha256") != episode_hashes[key] for row, key in zip(index_rows, indexed)):
            raise ValueError("开发index任务内容SHA与官方源不一致")
    children = aerial_cache_index_children(path)
    samples, found = [], set()
    scene_protocols = payload["render_protocol"]["scenes"]
    if set(scene_protocols) != {str(shard["scene_id"]) for shard in payload["shards"]}:
        raise ValueError("多场景来源合同与分片场景集合不匹配")
    for child, shard in zip(children, payload["shards"]):
        child_payload = json.loads(child.read_text(encoding="utf-8"))
        if child_payload.get("render_protocol") != scene_protocols[str(shard["scene_id"])]:
            raise ValueError("多场景index与子缓存渲染来源不一致")
        if development and (child_payload.get("development_partition") != "dev"
                            or child_payload.get("development_split_manifest_sha256") != split_digest):
            raise ValueError("开发分片未绑定同一冻结开发名单")
        rows = child_payload.get("episodes")
        if not isinstance(rows, list) or not rows or any(not isinstance(row, dict) or row.get("scene_id") != shard["scene_id"] for row in rows):
            raise ValueError("单场景分片包含其他场景或空episode")
        keys = [(row["scene_id"], str(row["episode_id"])) for row in rows]
        if len(set(keys)) != len(keys) or found.intersection(keys):
            raise ValueError("多场景episode重复")
        found.update(keys)
        selected = load_aerial_samples(annotation_root, split, child, history_frames,
                                      include_route_metadata=include_route_metadata or development,
                                      require_depth=require_depth, index_mode=index_mode, index_dir=index_dir)
        for sample in selected:
            sample.update(child_cache_manifest_sha256=sample["cache_manifest_sha256"],
                          child_cache_manifest_source=str(child), cache_manifest_sha256=digest)
        samples.extend(selected)
        if _sha256(child) != shard["sha256"]:
            raise ValueError("单场景分片读取期间发生改变")
    if found != expected or _sha256(path) != digest:
        raise ValueError("多场景完整任务覆盖或读取期间来源发生改变")
    if development:
        samples = select_aerial_route_partition(samples, route_split, "dev")
        if _sha256(split_file) != split_digest:
            raise ValueError("开发名单在子分片审核期间改变")
        if not include_route_metadata:
            for sample in samples:
                for name in ("source_split", "reference_pose", "reference_length"):
                    sample.pop(name)
    return samples


def load_aerial_render_passes(annotation_root, split, cache_manifests, history_frames=8,
                              include_route_metadata=False, require_depth=False, index_mode="off", index_dir=None):
    """Read complete, matching passes without counting re-renders as new episodes."""
    if isinstance(cache_manifests, (str, Path)):
        cache_manifests = [cache_manifests]
    if not isinstance(cache_manifests, (list, tuple)) or not cache_manifests:
        raise ValueError("AerialVLN-S cache_manifests 必须为非空清单列表")
    manifests = [Path(path).resolve() for path in cache_manifests]
    if len(set(manifests)) != len(manifests):
        raise ValueError("AerialVLN-S render pass 来源清单重复")
    passes = [load_aerial_samples(annotation_root, split, path, history_frames,
                                 include_route_metadata=include_route_metadata,
                                 require_depth=require_depth, index_mode=index_mode, index_dir=index_dir) for path in manifests]
    groups = [group_aerial_episodes(samples, history_frames) for samples in passes]
    if len(passes) == 1:
        # Keep historical input order and vocabulary/sample digests exactly unchanged.
        return passes
    base_order = [(sample["scene_id"], str(sample["episode_id"]), sample["frame_index"])
                  for sample in passes[0]]
    # Canonical ordering makes input manifest row ordering immaterial to training pairing.
    passes = [[sample for episode in episodes for sample in episode] for episodes in groups]
    sessions, image_sources = set(), set()
    base = passes[0]
    for samples in passes:
        render, session = samples[0]["render_protocol"], samples[0].get("capture_session_id")
        if render["protocol_version"] != "aerialvln_s_pose_rgb_v2":
            raise ValueError("AerialVLN-S 多 render pass 必须全部使用 v2 来源协议")
        if session in sessions:
            raise ValueError("AerialVLN-S 多 render pass capture_session_id 重复")
        sessions.add(session)
        sources = {sample["image"].resolve() for sample in samples}
        if image_sources & sources:
            raise ValueError("AerialVLN-S 多 render pass 不得复用同一 RGB 文件来源")
        image_sources.update(sources)
        if render != base[0]["render_protocol"]:
            raise ValueError("AerialVLN-S 多 render pass render/build/settings 合同不一致")
        if len(samples) != len(base):
            raise ValueError("AerialVLN-S 多 render pass episode/完整帧数量不一致")
        identity = ("scene_id", "episode_id", "traj_id", "episode_sha256", "annotation_sha256",
                    "instruction", "frame_index", "action", "sample_policy", "history_policy")
        for first, other in zip(base, samples):
            if (any(first[field] != other[field] for field in identity)
                    or not np.array_equal(first["history"], other["history"])):
                raise ValueError("AerialVLN-S 多 render pass episode/指令/动作/合法历史不一致")
    # Validate with canonical episode ordering, then retain pass0's original order.
    # Word IDs and seeded initialization must match the single-pass control.
    aligned = []
    for samples in passes:
        by_key = {(sample["scene_id"], str(sample["episode_id"]), sample["frame_index"]): sample
                  for sample in samples}
        aligned.append([by_key[key] for key in base_order])
    return aligned


def load_aerial_dagger_samples(annotation_root, manifest, history_frames=8, require_depth=False,
                               allow_incomplete=False):
    """仅读取已审核真实学生状态，教师标签与实际执行历史分别认证。"""
    from uavnav.avln.geometry import validate_aerial_teacher_review
    from uavnav.avln.airsim_env import aerial_action_pose
    if (type(history_frames) is not int or history_frames < 0 or type(require_depth) is not bool
            or type(allow_incomplete) is not bool):
        raise ValueError("DAgger history_frames/require_depth非法")
    path = Path(manifest).resolve()
    source_sha = _sha256(path)
    payload = json.loads(path.read_text(encoding="utf-8"))
    if (not isinstance(payload, dict) or type(payload.get("schema_version")) is not int
            or payload["schema_version"] != 1 or payload.get("data_protocol") != AERIAL_DATA_PROTOCOL
            or payload.get("sample_policy") != "aerial_dagger_current_state_v1" or payload.get("split") != "train"):
        raise ValueError("DAgger只接受版本化train真实状态清单")
    collection = payload.get("collection_id")
    if not isinstance(collection, str) or not collection.strip():
        raise ValueError("DAgger collection_id不能为空")
    beta = payload.get("beta")
    if (type(payload.get("seed")) is not int or payload["seed"] != 0
            or isinstance(beta, bool) or not isinstance(beta, (int, float)) or not np.isfinite(beta) or not 0 <= beta < 1
            or type(payload.get("max_steps")) is not int or not 1 <= payload["max_steps"] <= 500
            or type(payload.get("history_frames")) is not int or payload["history_frames"] != history_frames
            or payload.get("teacher_protocol") != "airvln_upstream_pose_guard_v1"):
        raise ValueError("DAgger必须绑定seed0/非全教师beta/真实history和最多500决策合同")
    if not isinstance(payload.get("checkpoint_sha256"), str) or not re.fullmatch(r"[a-f0-9]{64}", payload["checkpoint_sha256"]):
        raise ValueError("DAgger必须绑定采集策略checkpoint摘要")
    render = payload.get("render_protocol")
    validate_aerial_render_protocol(render)
    if render["protocol_version"] != "aerialvln_s_pose_rgb_v2":
        raise ValueError("DAgger需要真实场景/相机来源v2")
    review = payload.get("teacher_contract")
    if not isinstance(review, dict):
        raise ValueError("DAgger缺教师审核合同")
    validate_aerial_teacher_review(review, review.get("scene_id"))
    if payload.get("teacher_contract_sha256") != _canonical_json_sha256(review):
        raise ValueError("DAgger教师审核合同SHA不匹配")
    official = load_aerial_episodes(annotation_root, "train")
    if payload.get("annotation_sha256") != official[0]["_annotation_sha256"]:
        raise ValueError("DAgger官方train标注来源不匹配")
    by_source = {(ep["scene_id"], str(ep["episode_id"])): ep for ep in official}
    rows = payload.get("episodes")
    if not isinstance(rows, list) or not rows:
        raise ValueError("DAgger清单没有完整采集episode")
    selected_ids, missing_ids = payload.get("selected_episode_ids"), payload.get("missing_episode_ids")
    if (not isinstance(selected_ids, list) or not selected_ids or any(not isinstance(key, str) or not key for key in selected_ids)
            or len(set(selected_ids)) != len(selected_ids) or not isinstance(missing_ids, list)
            or any(not isinstance(key, str) or not key for key in missing_ids) or len(set(missing_ids)) != len(missing_ids)
            or any(key not in {f"{scene}/{episode}" for scene, episode in by_source} for key in selected_ids)):
        raise ValueError("DAgger collection需要合法唯一完整训练源任务名单")
    if payload.get("collection_status") not in ("complete", "incomplete"):
        raise ValueError("DAgger collection缺显式封口状态")
    if not allow_incomplete and (payload["collection_status"] != "complete" or missing_ids):
        raise ValueError("DAgger训练不能读取未完成的partial collection")
    samples, seen = [], set()
    for row in rows:
        if (not isinstance(row, dict) or type(row.get("scene_id")) is not int
                or isinstance(row.get("source_episode_id"), bool)
                or not isinstance(row.get("source_episode_id"), (str, int))):
            raise ValueError("DAgger源episode身份非法")
        key = (row["scene_id"], str(row["source_episode_id"]))
        source = by_source.get(key)
        if source is None or key in seen or key[0] != review["scene_id"]:
            raise ValueError("DAgger源episode不属于当前已审核train场景或重复")
        seen.add(key)
        if (row.get("episode_id") != collection + "_" + key[1]
                or row.get("episode_sha256") != source["_episode_sha256"]
                or row.get("instruction") != source["instruction"]["instruction_text"]
                or source["_quarantine_reason"]):
            raise ValueError("DAgger源指令/episode内容/隔离状态不匹配")
        frames = row.get("frames")
        if not isinstance(frames, list) or not frames:
            raise ValueError("DAgger episode不能空或未封口")
        if len(frames) > payload["max_steps"] or row.get("termination_reason") == "max_steps" and len(frames) != payload["max_steps"]:
            raise ValueError("DAgger封口步数与决策预算不匹配")
        executed, previous_pose, previous_capture = [], None, None
        for index, frame in enumerate(frames):
            if (not isinstance(frame, dict) or type(frame.get("frame_index")) is not int
                    or frame["frame_index"] != index
                    or frame.get("teacher_protocol") != "airvln_upstream_pose_guard_v1"
                    or type(frame.get("reference_stage")) is not int or frame["reference_stage"] < 0
                    or type(frame.get("teacher_action")) is not int or not 0 <= frame["teacher_action"] < 8
                    or type(frame.get("predicted_action")) is not int or not 0 <= frame["predicted_action"] < 8
                    or type(frame.get("selected_teacher")) is not bool):
                raise ValueError("DAgger当前状态教师标签/阶段/策略动作非法")
            if beta == 0 and frame["selected_teacher"]:
                raise ValueError("DAgger beta0不能选择教师执行动作")
            position = _aerial_vector(frame.get("observed_position"), 3, "DAgger observed position")
            quat = _aerial_vector(frame.get("observed_orientation_xyzw"), 4, "DAgger observed orientation")
            if not np.isclose(np.linalg.norm(quat), 1., atol=1e-4):
                raise ValueError("DAgger实际姿态四元数必须单位化")
            if previous_pose is None:
                start = source["reference_path"][0]
                expected_position = np.asarray(start[:3], dtype=float)
                expected_orientation = Rotation.from_euler("xyz", [start[4], start[3], start[5]]).as_quat()
            else:
                expected_position, expected_orientation = aerial_action_pose(*previous_pose, executed[-1])
            if (np.linalg.norm(position - expected_position) > .02
                    or (Rotation.from_quat(expected_orientation).inv() * Rotation.from_quat(quat)).magnitude() > 1e-4):
                raise ValueError("DAgger实际pose不匹配起始姿态/上一已执行官方动作")
            previous_pose = (position, quat)
            pose = _aerial_vector(frame.get("pose"), 6, "DAgger capture pose")
            if (np.linalg.norm(pose[:3] - position) > .02 or (Rotation.from_euler("xyz", [pose[4], pose[3], pose[5]]).inv()
                    * Rotation.from_quat(quat)).magnitude() > 1e-4):
                raise ValueError("DAgger相机采集pose与实际观测姿态不一致")
            previous_capture = _validate_aerial_capture_frame(frame, pose, render, previous_capture)
            past = executed[-history_frames:] if history_frames else []
            if (not isinstance(frame.get("history_actions"), list)
                    or any(type(action) is not int for action in frame["history_actions"])
                    or frame["history_actions"] != past):
                raise ValueError("DAgger历史必须匹配过去实际执行动作，不能换成教师历史")
            image = _aerial_cache_file(path.parent, frame.get("rgb"), "DAgger RGB")
            with Image.open(image) as raw:
                if raw.mode != "RGB" or raw.size != (render["width"], render["height"]):
                    raise ValueError("DAgger RGB与相机协议不匹配")
                raw.verify()
            sample = dict(image=image, image_sha256=frame["rgb"]["sha256"], instruction=row["instruction"],
                          instruction_source="aerialvln_official", history=np.eye(8, dtype=np.float32)[past]
                          if past else np.zeros((0, 8), dtype=np.float32), action=frame["teacher_action"],
                          executed_action=frame.get("executed_action"), traj_id=f"{key[0]}/{source['trajectory_id']}",
                          episode_id=row["episode_id"], source_episode_id=row["source_episode_id"], scene_id=key[0],
                          frame_index=index, collection_id=collection, source_split="train",
                          sample_policy="aerial_dagger_current_state_v1", data_protocol=AERIAL_DATA_PROTOCOL,
                          history_policy=AERIAL_HISTORY_POLICY, episode_sha256=source["_episode_sha256"],
                          annotation_sha256=payload["annotation_sha256"], cache_manifest_sha256=source_sha,
                          teacher_contract_sha256=payload["teacher_contract_sha256"], render_protocol=dict(render),
                          termination_reason=row.get("termination_reason"))
            depth = frame.get("depth")
            if require_depth:
                if render.get("depth_protocol") != "scene1_7_depthvis255_else_depthperspective100_v1":
                    raise ValueError("DAgger RGB-D缺官方深度协议")
                depth_path = _aerial_cache_file(path.parent, depth, "DAgger depth")
                storage = _aerial_depth_storage(depth_path, depth.get("storage_protocol"))
                preprocess_depth(depth_path, depth["sha256"], storage)
                sample.update(depth=depth_path, depth_sha256=depth["sha256"],
                              depth_input_protocol="front_0_scene_normalized_256_v1")
                if storage is not None:
                    sample["depth_storage_protocol"] = storage
            actual = frame.get("executed_action")
            if actual is not None:
                chosen = frame["teacher_action"] if frame["selected_teacher"] else frame["predicted_action"]
                if type(actual) is not int or not 0 < actual < 8 or actual != chosen:
                    raise ValueError("DAgger执行动作与实际选择的教师/策略动作不一致")
                following_p = _aerial_vector(frame.get("following_position"), 3, "DAgger following position")
                following_q = _aerial_vector(frame.get("following_orientation_xyzw"), 4, "DAgger following orientation")
                expected_p, expected_q = aerial_action_pose(position, quat, actual)
                if (abs(np.linalg.norm(following_q) - 1) > 1e-4 or np.linalg.norm(following_p - expected_p) > .02
                        or (Rotation.from_quat(expected_q).inv() * Rotation.from_quat(following_q)).magnitude() > 1e-4):
                    raise ValueError("DAgger动作后实际pose与官方动作不匹配")
                if index + 1 < len(frames):
                    next_p = _aerial_vector(frames[index + 1].get("observed_position"), 3, "DAgger next position")
                    next_q = _aerial_vector(frames[index + 1].get("observed_orientation_xyzw"), 4, "DAgger next orientation")
                    if (np.linalg.norm(following_p - next_p) > .02 or (Rotation.from_quat(following_q).inv()
                            * Rotation.from_quat(next_q)).magnitude() > 1e-4):
                        raise ValueError("DAgger下一采集状态不等于上一动作后状态")
                executed.append(actual)
            elif index != len(frames) - 1:
                raise ValueError("DAgger只有封口末状态允许没有执行动作")
            else:
                chosen = frame["teacher_action"] if frame["selected_teacher"] else frame["predicted_action"]
                expected_reason = "teacher_stop" if frame["selected_teacher"] else "model_stop"
                if chosen != 0 or row.get("termination_reason") != expected_reason:
                    raise ValueError("DAgger无执行动作的末帧必须匹配实际选中的STOP及封口原因")
            samples.append(sample)
        if row.get("termination_reason") == "depth_collision_proxy":
            last = frames[-1]
            if (last.get("following_done") is not True or last.get("following_termination_reason") != "depth_collision_proxy"
                    or not isinstance(last.get("following_depth_collision_fraction"), (int, float))
                    or isinstance(last.get("following_depth_collision_fraction"), bool)
                    or not .1 < last["following_depth_collision_fraction"] <= 1):
                raise ValueError("DAgger深度碰撞封口缺动作后真实终止证据")
        elif row.get("termination_reason") == "max_steps" and frames[-1].get("executed_action") is None:
            raise ValueError("DAgger预算终止末决策应已执行真实运动")
    group_aerial_dagger_episodes(samples, history_frames)
    actual_ids = {f"{scene}/{episode}" for scene, episode in seen}
    if (actual_ids - set(selected_ids) or missing_ids != sorted(set(selected_ids) - actual_ids)
            or payload["collection_status"] == "complete" and (actual_ids != set(selected_ids) or missing_ids)):
        raise ValueError("DAgger实际封口episode与冻结任务名单/缺失名单不一致")
    if _sha256(path) != source_sha:
        raise ValueError("DAgger清单读取期间发生改变")
    return samples


def group_aerial_dagger_episodes(samples, history_frames):
    """完整学生rollout分组；不要求教师末STOP，不把实际历史重写成教师历史。"""
    if type(history_frames) is not int or history_frames < 0:
        raise ValueError("DAgger history_frames必须非负整数")
    groups = {}
    for sample in samples:
        if (sample.get("sample_policy") != "aerial_dagger_current_state_v1"
                or type(sample.get("scene_id")) is not int or not sample.get("collection_id")
                or not sample.get("episode_id")):
            raise ValueError("DAgger分组需要明确采集/episode/场景身份")
        groups.setdefault((sample["collection_id"], sample["scene_id"], str(sample["episode_id"])), []).append(sample)
    if not groups:
        raise ValueError("DAgger样本不能为空")
    result = []
    for key in sorted(groups):
        episode = groups[key]
        if any(type(sample.get("frame_index")) is not int for sample in episode):
            raise ValueError("DAgger frame_index必须整数")
        episode = sorted(episode, key=lambda sample: sample["frame_index"])
        if [sample["frame_index"] for sample in episode] != list(range(len(episode))):
            raise ValueError("DAgger episode必须从0连续至封口状态")
        for field in ("instruction", "source_episode_id", "episode_sha256", "teacher_contract_sha256", "termination_reason"):
            if len({sample.get(field) for sample in episode}) != 1:
                raise ValueError(f"DAgger单episode {field}不一致")
        if episode[-1].get("termination_reason") not in ("max_steps", "depth_collision_proxy", "model_stop", "teacher_stop"):
            raise ValueError("DAgger episode没有合法封口原因")
        executed = []
        for index, sample in enumerate(episode):
            if type(sample.get("action")) is not int or not 0 <= sample["action"] < 8:
                raise ValueError("DAgger教师动作非法")
            past = executed[-history_frames:] if history_frames else []
            expected = np.eye(8, dtype=np.float32)[past] if past else np.zeros((0, 8), dtype=np.float32)
            if not np.array_equal(sample["history"], expected):
                raise ValueError("DAgger历史与实际执行动作不一致")
            action = sample.get("executed_action")
            if action is None:
                if index != len(episode) - 1:
                    raise ValueError("DAgger中间帧不能缺执行动作")
            elif type(action) is not int or not 0 < action < 8:
                raise ValueError("DAgger实际运动动作非法")
            else:
                executed.append(action)
        result.append(episode)
    return result


def add_stop_annotations(samples, paths, label_path, task_protocol):
    """Attach reviewed STOP labels without deriving completion from trajectory data.

    Annotation rows may address an existing motion sample or the final observed frame
    of an otherwise eligible trajectory. A final-frame sample has no motion target;
    its zero offset is only a tensor placeholder and is masked by ``motion_valid``.
    """
    if not isinstance(task_protocol, dict):
        raise ValueError("task_protocol 必须是 JSON 对象")
    if (task_protocol.get("stop_source") != "reviewed_annotations"
            or task_protocol.get("stop_timing") != "before_action"):
        raise ValueError("STOP 协议必须使用 reviewed_annotations 和 before_action")

    label_path = Path(label_path)
    if not label_path.is_file():
        raise FileNotFoundError(f"STOP 标注不存在: {label_path}")
    payload = json.loads(label_path.read_text(encoding="utf-8"))
    if not isinstance(payload, dict) or set(payload) != {"schema_version", "task_protocol", "rows"}:
        raise ValueError("STOP 标注顶层字段必须是 schema_version、task_protocol、rows")
    if isinstance(payload["schema_version"], bool) or not isinstance(payload["schema_version"], int) or payload["schema_version"] != 1:
        raise ValueError("STOP 标注 schema_version 必须为 1")
    if payload["task_protocol"] != task_protocol:
        raise ValueError("STOP 标注 task_protocol 与当前任务协议不一致")
    rows = payload["rows"]
    if not isinstance(rows, list) or not rows:
        raise ValueError("STOP 标注 rows 必须是非空列表")

    source_samples = list(samples)
    eligible_ids = {sample.get("traj_id") for sample in source_samples}
    if None in eligible_ids or not eligible_ids:
        raise ValueError("没有可附加 STOP 标注的运动样本")
    motion_by_key = {}
    templates = {}
    for sample in source_samples:
        frame_index = sample.get("frame_index")
        if isinstance(frame_index, bool) or not isinstance(frame_index, int):
            raise ValueError("运动样本 frame_index 必须是整数")
        key = (sample["traj_id"], frame_index)
        if key in motion_by_key:
            raise ValueError(f"运动样本键重复: {key}")
        motion_by_key[key] = sample
        template = templates.setdefault(sample["traj_id"], sample)
        if (sample.get("instruction") != template.get("instruction")
                or sample.get("instruction_source") != template.get("instruction_source")):
            raise ValueError(f"同一轨迹的指令不一致: {sample['traj_id']}")

    path_by_id = {}
    for raw_path in paths:
        path = Path(raw_path)
        traj_id = f"{path.parent.name}/{path.name}"
        if traj_id in path_by_id:
            raise ValueError(f"轨迹路径重复: {traj_id}")
        path_by_id[traj_id] = path
    missing_paths = eligible_ids - set(path_by_id)
    if missing_paths:
        raise ValueError(f"有效运动轨迹缺少源路径: {sorted(missing_paths)}")

    required = {
        "traj_id", "frame_index", "stop_target", "reviewed", "reviewer",
        "evidence", "image_sha256", "log_sha256",
    }
    annotations = {}
    frame_cache = {}
    log_cache = {}
    for row_number, row in enumerate(rows, start=1):
        if not isinstance(row, dict) or set(row) != required:
            raise ValueError(f"STOP 标注第 {row_number} 行字段不符合 schema")
        traj_id = row["traj_id"]
        frame_index = row["frame_index"]
        stop_target = row["stop_target"]
        if not isinstance(traj_id, str) or not traj_id:
            raise ValueError(f"STOP 标注第 {row_number} 行 traj_id 非法")
        if isinstance(frame_index, bool) or not isinstance(frame_index, int):
            raise ValueError(f"STOP 标注第 {row_number} 行 frame_index 必须是整数")
        if isinstance(stop_target, bool) or not isinstance(stop_target, int) or stop_target not in (0, 1):
            raise ValueError(f"STOP 标注第 {row_number} 行 stop_target 必须是 0 或 1")
        if row["reviewed"] is not True:
            raise ValueError(f"STOP 标注第 {row_number} 行未经人工复核")
        if not isinstance(row["reviewer"], str) or not row["reviewer"].strip():
            raise ValueError(f"STOP 标注第 {row_number} 行 reviewer 为空")
        if not isinstance(row["evidence"], str) or not row["evidence"].strip():
            raise ValueError(f"STOP 标注第 {row_number} 行 evidence 为空")
        if traj_id not in eligible_ids:
            raise ValueError(f"STOP 标注引用非有效运动轨迹: {traj_id}")
        key = (traj_id, frame_index)
        if key in annotations:
            raise ValueError(f"STOP 标注键重复: {key}")

        if traj_id not in frame_cache:
            frames, _ = _frames(path_by_id[traj_id])
            frame_cache[traj_id] = {frame[2]: frame for frame in frames}
            logs = {}
            for log_path in (path_by_id[traj_id] / "log").glob("*.json"):
                index = int(log_path.stem)
                if index in logs:
                    raise ValueError(f"{path_by_id[traj_id]} 含重复日志索引: {index}")
                logs[index] = log_path
            log_cache[traj_id] = logs
        frame = frame_cache[traj_id].get(frame_index)
        log_path = log_cache[traj_id].get(frame_index)
        if frame is None or log_path is None:
            raise FileNotFoundError(f"STOP 标注缺少对应前视图或日志: {key}")
        for field, actual_path in (("image_sha256", frame[1]), ("log_sha256", log_path)):
            expected = row[field]
            if not isinstance(expected, str) or not re.fullmatch(r"[0-9a-fA-F]{64}", expected):
                raise ValueError(f"STOP 标注第 {row_number} 行 {field} 不是 SHA256")
            if _sha256(actual_path) != expected.lower():
                raise ValueError(f"STOP 标注第 {row_number} 行 {field} 与源文件不一致")
        if key not in motion_by_key and frame_index != max(frame_cache[traj_id]):
            raise ValueError(f"非运动样本的 STOP 标注只允许轨迹末帧: {key}")
        annotations[key] = stop_target

    if {row["stop_target"] for row in rows} != {0, 1}:
        raise ValueError("STOP 标注整体必须同时包含 0 和 1")

    output = []
    for sample in source_samples:
        annotated = dict(sample)
        key = (sample["traj_id"], sample["frame_index"])
        annotated["motion_valid"] = True
        annotated["stop_valid"] = key in annotations
        annotated["stop_target"] = float(annotations.get(key, 0))
        output.append(annotated)

    for key, stop_target in annotations.items():
        if key in motion_by_key:
            continue
        traj_id, frame_index = key
        ordered = sorted(frame_cache[traj_id].values(), key=lambda frame: frame[2])
        step = next(index for index, frame in enumerate(ordered) if frame[2] == frame_index)
        current, image, _ = ordered[step]
        history = [
            body_offset(past["position"], past["orientation"], current["position"], current["orientation"])
            for past, _, _ in ordered[:step]
        ]
        template = templates[traj_id]
        output.append({
            "traj_id": traj_id,
            "instruction": template["instruction"],
            "instruction_source": template.get("instruction_source", "unknown"),
            "image": image,
            "frame_index": frame_index,
            "target_frame_index": None,
            "frame_gap": FOV_FRAME_GAP,
            "sample_policy": SAMPLE_POLICY,
            "history": np.stack(history, axis=0) if history else np.zeros((0, 3)),
            "offset": np.zeros(3, dtype=np.float32),
            "motion_valid": False,
            "stop_valid": True,
            "stop_target": float(stop_target),
        })
    return output


def group_aerial_episodes(samples, history_frames=None):
    """按场景/episode 保留各指令的完整时序，拒绝缺帧及教师历史错配。"""
    if history_frames is not None and (type(history_frames) is not int or history_frames < 0):
        raise ValueError("history_frames 必须为非负整数")
    groups = {}
    for sample in samples:
        scene, episode_id = sample.get("scene_id"), sample.get("episode_id")
        if type(scene) is not int or isinstance(episode_id, bool) or not isinstance(episode_id, (str, int)):
            raise ValueError("时序样本需要合法 scene_id/episode_id")
        groups.setdefault((scene, str(episode_id)), []).append(sample)
    if not groups:
        raise ValueError("路线时序样本不能为空")
    result = []
    for key in sorted(groups):
        episode = groups[key]
        if any(type(sample.get("frame_index")) is not int for sample in episode):
            raise ValueError(f"路线 frame_index 必须是整数: {key}")
        episode = sorted(episode, key=lambda sample: sample["frame_index"])
        if [sample["frame_index"] for sample in episode] != list(range(len(episode))):
            raise ValueError(f"路线时序必须从 frame0 连续至末STOP，不能缺帧或重复: {key}")
        if (any(type(sample.get("action")) is not int or not 0 <= sample["action"] < 8 for sample in episode)
                or episode[-1]["action"] != 0 or any(sample["action"] == 0 for sample in episode[:-1])):
            raise ValueError(f"路线时序必须有且仅有末STOP: {key}")
        for field in ("instruction", "traj_id", "episode_sha256"):
            if len({sample.get(field) for sample in episode}) != 1:
                raise ValueError(f"单个 episode 的 {field} 不一致: {key}")
        if history_frames is not None:
            actions = [sample["action"] for sample in episode]
            for index, sample in enumerate(episode):
                past = actions[max(0, index - history_frames):index] if history_frames else []
                expected = np.eye(8, dtype=np.float32)[past] if past else np.zeros((0, 8), dtype=np.float32)
                actual = np.asarray(sample["history"])
                if actual.shape != expected.shape or not np.array_equal(actual, expected):
                    raise ValueError(f"教师历史必须仅含已执行动作，不得含当前或未来标签: {key} frame {index}")
        result.append(episode)
    return result


def _aerial_geometry_identity(scene_id, poses):
    poses = np.asarray(poses, dtype=np.float64)
    return {"scene_id": scene_id,
            "positions_1e4_m": np.rint(poses[:, :3] / 1e-4).astype(np.int64).tolist(),
            "pitch_roll_yaw_1e6_rad": np.rint(_wrapped_angle(poses[:, 3:]) / 1e-6).astype(np.int64).tolist()}


def _aerial_geometry_groups(samples):
    """Validate train-only full episodes and derive content identities, not trajectory IDs."""
    groups, episodes = {}, {}
    for episode in group_aerial_episodes(samples):
        first = episode[0]
        key = (first["scene_id"], str(first["episode_id"]))
        if (key[0] <= 0 or not key[1] or not isinstance(first.get("instruction"), str)
                or not first["instruction"].strip()):
            raise ValueError(f"成组开发拆分scene/episode/指令来源非法: {key}")
        for sample in episode:
            if (sample.get("source_split") != "train"
                    or sample.get("data_protocol") != AERIAL_DATA_PROTOCOL
                    or sample.get("sample_policy") != AERIAL_SAMPLE_POLICY
                    or sample.get("history_policy") != AERIAL_HISTORY_POLICY
                    or sample.get("instruction_source") != "aerialvln_official"):
                raise ValueError(f"成组开发拆分仅接受已核来源的官方train样本: {key}")
            if type(sample.get("reference_length")) is not int or sample["reference_length"] != len(episode):
                raise ValueError(f"成组开发拆分必须保留官方完整reference_length: {key}")
            for field in ("annotation_sha256", "episode_sha256", "cache_manifest_sha256"):
                if (not isinstance(sample.get(field), str)
                        or not re.fullmatch(r"[a-f0-9]{64}", sample[field])
                        or sample[field] != first[field]):
                    raise ValueError(f"成组开发拆分{field}来源缺失或不一致: {key}")
            if "child_cache_manifest_sha256" in first:
                if (sample.get("child_cache_manifest_sha256") != first["child_cache_manifest_sha256"]
                        or not isinstance(sample.get("child_cache_manifest_sha256"), str)
                        or re.fullmatch(r"[a-f0-9]{64}", sample["child_cache_manifest_sha256"]) is None
                        or sample.get("child_cache_manifest_source") != first["child_cache_manifest_source"]):
                    raise ValueError(f"多场景episode内分片来源不一致: {key}")
            validate_aerial_render_protocol(sample.get("render_protocol"))
            if (sample["render_protocol"]["protocol_version"] == "aerialvln_s_pose_rgb_v2"
                    and (not isinstance(sample.get("capture_session_id"), str)
                         or not sample["capture_session_id"].strip())):
                raise ValueError(f"成组开发拆分v2采集session来源缺失: {key}")
            if (sample["render_protocol"] != first["render_protocol"]
                    or sample.get("capture_session_id") != first.get("capture_session_id")):
                raise ValueError(f"成组开发拆分渲染来源在episode内不一致: {key}")
        poses = np.stack([_aerial_vector(sample.get("reference_pose"), 6,
                                         f"{key} frame {sample['frame_index']} reference_pose")
                          for sample in episode])
        if len(episode) > 1:
            expected = aerial_pose_transition(poses[:-1], np.asarray(
                [sample["action"] for sample in episode[:-1]], dtype=np.int64))
            if (np.any(np.abs(expected[:, :3] - poses[1:, :3]) > 1e-4)
                    or np.any(np.abs(_wrapped_angle(expected[:, 3:] - poses[1:, 3:])) > 1e-6)):
                raise ValueError(f"成组开发拆分位姿与动作不一致: {key}")
        if (np.any(np.abs(poses[:, :3] / 1e-4) >= np.iinfo(np.int64).max)):
            raise ValueError(f"成组开发拆分位姿超出安全量化范围: {key}")
        identity = _aerial_geometry_identity(key[0], poses)
        route_sha = _canonical_json_sha256(identity)
        group = groups.setdefault(route_sha, {"route_sha256": route_sha,
                                              "identity": identity, "episodes": []})
        group["episodes"].append({"scene_id": key[0], "episode_id": key[1],
                                  "episode_sha256": first["episode_sha256"]})
        episodes[key] = (episode, route_sha)
    if len({episode[0][0]["annotation_sha256"] for episode in episodes.values()}) != 1:
        raise ValueError("成组开发拆分不能混合不同官方train标注来源")
    return groups, episodes


def split_aerial_route_groups(samples, dev_fraction=0.2, split_seed=0):
    """Deterministic train-derived geometric holdout; synthetic inputs only verify contract.

    Route positions round to 1e-4 m and wrapped Euler angles to 1e-6 rad (ties-to-even).
    Re-render passes must be selected separately with select_aerial_route_partition.
    Official validation splits and historical ungrouped callers are unchanged.
    """
    if (isinstance(dev_fraction, bool) or not isinstance(dev_fraction, (int, float))
            or not np.isfinite(dev_fraction) or not 0 < dev_fraction < 1):
        raise ValueError("dev_fraction必须为0到1之间的有限数值")
    if type(split_seed) is not int:
        raise ValueError("split_seed必须为独立整数seed")
    groups, episodes = _aerial_geometry_groups(samples)
    if len(groups) < 2:
        raise ValueError(f"独立开发拆分几何路线不足: {len(groups)}，至少需要2条完整路线")
    count = max(1, min(len(groups) - 1, int(np.floor(len(groups) * dev_fraction + 0.5))))
    ranked = sorted(groups, key=lambda route: (
        _canonical_json_sha256({"split_seed": split_seed, "route_sha256": route}), route))
    dev_routes = set(ranked[:count])
    manifest = {
        "schema_version": 1, "split_protocol": AERIAL_GROUPED_SPLIT_PROTOCOL,
        "source_split": "train", "split_seed": split_seed, "dev_fraction": float(dev_fraction),
        "algorithm": "seeded_sha256_rank_round_half_up_clamp_nonempty_v1",
        "geometry_precision": {"position_m": 1e-4, "angle_rad": 1e-6,
                               "angle_wrap": "[-pi,pi)", "rounding": "numpy_rint_ties_to_even"},
        "route_count": len(groups), "dev_route_count": count,
        "annotation_sha256": next(iter(episodes.values()))[0][0]["annotation_sha256"],
        "routes": [dict(groups[route], partition="dev" if route in dev_routes else "train")
                   for route in sorted(groups)],
        "train_episode_keys": [], "dev_episode_keys": [], "sources": [],
        "coverage": {},
        "scope": "train_source_geometry_holdout_not_official_validation",
        "render_independence": "geometric_holdout_only; shared_capture_sessions_allowed_and_reported",
    }
    partitions = {"train": [], "dev": []}
    source_rows = {}
    for key, (episode, route) in sorted(episodes.items()):
        partition = "dev" if route in dev_routes else "train"
        partitions[partition].extend(episode)
        manifest[f"{partition}_episode_keys"].append({"scene_id": key[0], "episode_id": key[1]})
        first = episode[0]
        source = {"cache_manifest_sha256": first.get("child_cache_manifest_sha256", first["cache_manifest_sha256"]),
                  "render_protocol_sha256": _canonical_json_sha256(first["render_protocol"]),
                  "render_protocol": first["render_protocol"],
                  "capture_session_id": first.get("capture_session_id"),
                  "partitions": []}
        if "child_cache_manifest_sha256" in first:
            source["cache_index_sha256"] = first["cache_manifest_sha256"]
        record = source_rows.setdefault(source["cache_manifest_sha256"], source)
        if (record["render_protocol_sha256"] != source["render_protocol_sha256"]
                or record["capture_session_id"] != source["capture_session_id"]):
            raise ValueError("相同缓存SHA的渲染来源不一致")
        if partition not in record["partitions"]:
            record["partitions"].append(partition)
    manifest["sources"] = [dict(source_rows[key], partitions=sorted(source_rows[key]["partitions"]))
                           for key in sorted(source_rows)]
    train_tokens = {token for group in group_aerial_episodes(partitions["train"])
                    for token in tokenize(group[0]["instruction"], "route_numeric_v1")}
    for partition, selected in partitions.items():
        episode_groups = group_aerial_episodes(selected)
        tokens = [token for group in episode_groups
                  for token in tokenize(group[0]["instruction"], "route_numeric_v1")]
        counts = [sum(sample["action"] == action for sample in selected) for action in range(8)]
        manifest["coverage"][partition] = {
            "episodes": len(episode_groups), "states": len(selected), "action_counts": counts,
            "missing_actions": [action for action, n in enumerate(counts) if not n],
            "stop_states": counts[0], "instruction_token_occurrences": len(tokens),
            "oov_token_occurrences_against_train": sum(token not in train_tokens for token in tokens),
            "oov_fraction_against_train": (sum(token not in train_tokens for token in tokens)
                                           / len(tokens)) if tokens else None,
        }
        manifest[f"{partition}_episode_keys_sha256"] = _canonical_json_sha256(
            manifest[f"{partition}_episode_keys"])
    manifest["manifest_sha256"] = _canonical_json_sha256(manifest)
    return partitions["train"], partitions["dev"], manifest


def validate_aerial_route_split_manifest(manifest):
    """Validate versioned route grouping without requiring RGB or original annotations."""
    fields = {"schema_version", "split_protocol", "source_split", "split_seed", "dev_fraction",
              "algorithm", "geometry_precision", "route_count", "dev_route_count", "annotation_sha256",
              "routes", "train_episode_keys", "dev_episode_keys", "sources", "coverage", "scope",
              "render_independence", "train_episode_keys_sha256", "dev_episode_keys_sha256", "manifest_sha256"}
    if (not isinstance(manifest, dict)
            or set(manifest) != fields
            or manifest.get("split_protocol") != AERIAL_GROUPED_SPLIT_PROTOCOL
            or type(manifest.get("schema_version")) is not int
            or manifest.get("schema_version") != 1 or manifest.get("source_split") != "train"
            or manifest.get("manifest_sha256") != _canonical_json_sha256(
                {key: value for key, value in manifest.items() if key != "manifest_sha256"})):
        raise ValueError("成组开发拆分manifest版本/内容SHA不一致")
    if (not isinstance(manifest["annotation_sha256"], str)
            or re.fullmatch(r"[a-f0-9]{64}", manifest["annotation_sha256"]) is None
            or manifest["scope"] != "train_source_geometry_holdout_not_official_validation"
            or manifest["render_independence"] != "geometric_holdout_only; shared_capture_sessions_allowed_and_reported"
            or not isinstance(manifest["sources"], list) or not manifest["sources"]
            or not isinstance(manifest["coverage"], dict) or set(manifest["coverage"]) != {"train", "dev"}):
        raise ValueError("成组开发拆分manifest来源/范围声明非法")
    precision = {"position_m": 1e-4, "angle_rad": 1e-6,
                 "angle_wrap": "[-pi,pi)", "rounding": "numpy_rint_ties_to_even"}
    fraction, seed, routes = manifest.get("dev_fraction"), manifest.get("split_seed"), manifest.get("routes")
    if (manifest.get("geometry_precision") != precision
            or manifest.get("algorithm") != "seeded_sha256_rank_round_half_up_clamp_nonempty_v1"
            or type(seed) is not int or isinstance(fraction, bool)
            or not isinstance(fraction, (int, float)) or not np.isfinite(fraction) or not 0 < fraction < 1
            or not isinstance(routes, list) or len(routes) < 2
            or type(manifest.get("route_count")) is not int or manifest["route_count"] != len(routes)):
        raise ValueError("成组开发拆分manifest精度/算法/seed/比例/路线数与版本不一致")
    expected, seen_routes = {}, set()
    for row in routes:
        if (not isinstance(row, dict) or set(row) != {"route_sha256", "identity", "episodes", "partition"}
                or row["route_sha256"] != _canonical_json_sha256(row["identity"])
                or row["partition"] not in ("train", "dev")):
            raise ValueError("成组开发拆分manifest路线身份/分区不一致")
        if row["route_sha256"] in seen_routes:
            raise ValueError("成组开发拆分manifest重复几何路线，不能同route跨分区")
        seen_routes.add(row["route_sha256"])
        identity = row["identity"]
        if (not isinstance(identity, dict)
                or set(identity) != {"scene_id", "positions_1e4_m", "pitch_roll_yaw_1e6_rad"}
                or type(identity["scene_id"]) is not int or identity["scene_id"] <= 0):
            raise ValueError("成组开发拆分manifest canonical几何身份非法")
        positions, angles = identity["positions_1e4_m"], identity["pitch_roll_yaw_1e6_rad"]
        if (not isinstance(positions, list) or not isinstance(angles, list) or not positions
                or len(positions) != len(angles)
                or any(not isinstance(vector, list) or len(vector) != 3
                       or any(type(value) is not int for value in vector) for vector in positions + angles)):
            raise ValueError("成组开发拆分manifest canonical完整位置/朝向非法")
        if not isinstance(row["episodes"], list) or not row["episodes"]:
            raise ValueError("成组开发拆分manifest路线episode为空")
        for item in row["episodes"]:
            if (not isinstance(item, dict) or set(item) != {"scene_id", "episode_id", "episode_sha256"}
                    or type(item["scene_id"]) is not int or item["scene_id"] != identity["scene_id"]
                    or not isinstance(item["episode_id"], str) or not item["episode_id"]
                    or not isinstance(item["episode_sha256"], str)
                    or re.fullmatch(r"[a-f0-9]{64}", item["episode_sha256"]) is None):
                raise ValueError("成组开发拆分manifest episode身份非法")
            key = (item["scene_id"], item["episode_id"])
            if key in expected:
                raise ValueError("成组开发拆分manifest episode重复")
            expected[key] = (row["route_sha256"], item["episode_sha256"], row["partition"])
    count = max(1, min(len(routes) - 1, int(np.floor(len(routes) * fraction + 0.5))))
    ranked = sorted(seen_routes, key=lambda route: (
        _canonical_json_sha256({"split_seed": seed, "route_sha256": route}), route))
    dev_routes = set(ranked[:count])
    if (type(manifest.get("dev_route_count")) is not int or manifest["dev_route_count"] != count
            or any(row["partition"] != ("dev" if row["route_sha256"] in dev_routes else "train")
                   for row in routes)):
        raise ValueError("成组开发拆分manifest分区与冻结seed/比例算法不一致")
    for split in ("train", "dev"):
        keys = [{"scene_id": key[0], "episode_id": key[1]}
                for key, value in sorted(expected.items()) if value[2] == split]
        if (manifest.get(f"{split}_episode_keys") != keys
                or manifest.get(f"{split}_episode_keys_sha256") != _canonical_json_sha256(keys)):
            raise ValueError("成组开发拆分manifest分区episode名单/名单SHA与路线成员不一致")
    return manifest


def select_aerial_route_partition(samples, manifest, partition):
    """Apply the frozen episode and full-route identity to another verified render pass."""
    if partition not in ("train", "dev"):
        raise ValueError("partition必须为train或dev")
    manifest = validate_aerial_route_split_manifest(manifest)
    expected = {(item["scene_id"], item["episode_id"]):
                (row["route_sha256"], item["episode_sha256"], row["partition"])
                for row in manifest["routes"] for item in row["episodes"]}
    groups, episodes = _aerial_geometry_groups(samples)
    if next(iter(episodes.values()))[0][0]["annotation_sha256"] != manifest.get("annotation_sha256"):
        raise ValueError("成组开发拆分标注来源与冻结manifest不一致")
    partition_keys = {key for key, value in expected.items() if value[2] == partition}
    if set(episodes) not in (set(expected), partition_keys):
        raise ValueError("成组开发拆分输入必须含完整原episode名单或完整目标分区")
    selected = []
    for key, (episode, route) in sorted(episodes.items()):
        frozen_route, episode_sha, frozen_partition = expected[key]
        if route != frozen_route or episode[0]["episode_sha256"] != episode_sha:
            raise ValueError(f"成组开发拆分几何/指令原内容改变: {key}")
        if frozen_partition == partition:
            selected.extend(episode)
    return selected


def tokenize(text, tokenizer_version="fov_numeric_v1"):
    """旧FOV归一数字为<num>；路线v2保留块数、角度及距离的实际数值token。"""
    if tokenizer_version not in TOKENIZER_VERSIONS:
        raise ValueError(f"tokenizer_version 必须属于 {TOKENIZER_VERSIONS}")
    out = []
    for word in text.lower().split():
        word = word.strip(".,;:!?\"'")
        if not word:
            continue
        out.append("<num>" if tokenizer_version == "fov_numeric_v1" and NUMBER.match(word) else word)
    return out


def clause_split(text):
    """按句号/分号切子句，保留全部非空子句；无标点时整条指令为一个子句。"""
    parts = [part.strip() for part in re.split(r"[.;]+", text) if part.strip()]
    return parts or [text.strip() or "<unk>"]


TEXT_FEATURE_CACHE_VERSION = "frozen_clip_clause_cache_v1"


def text_cache_key(model_name="ViT-B-32-quickgelu", pretrained="openai"):
    return {"version": TEXT_FEATURE_CACHE_VERSION, "model": model_name, "pretrained": pretrained,
            "clause_split": "period_semicolon_v1", "pooling": "masked_mean_ln_final_v1", "max_clauses": 32}


@torch.no_grad()
def build_text_feature_cache(instructions, path, device, model_name="ViT-B-32-quickgelu", pretrained="openai", batch_size=256):
    """冻结CLIP文本塔，逐子句均值池化；缓存键为指令文本SHA，超出32子句的尾部并入最后一个子句。"""
    import open_clip
    key = text_cache_key(model_name, pretrained)
    model, _, _ = open_clip.create_model_and_transforms(model_name, pretrained=pretrained)
    model = model.to(device).eval()
    tokenizer = open_clip.get_tokenizer(model_name)
    features = {}
    pending = {}
    for text in instructions:
        digest = hashlib.sha256(text.encode("utf-8")).hexdigest()
        if digest not in features and digest not in pending:
            clauses = clause_split(text)
            if len(clauses) > key["max_clauses"]:
                clauses = clauses[:key["max_clauses"] - 1] + [" ".join(clauses[key["max_clauses"] - 1:])]
            pending[digest] = clauses
    flat = [(digest, clause) for digest, clauses in pending.items() for clause in clauses]
    out = {digest: [] for digest in pending}
    for begin in range(0, len(flat), batch_size):
        chunk = flat[begin:begin + batch_size]
        tokens = tokenizer([clause for _, clause in chunk]).to(device)
        x = model.token_embedding(tokens) + model.positional_embedding
        x = model.ln_final(model.transformer(x, attn_mask=model.attn_mask))
        valid = (tokens != 0).unsqueeze(-1).to(x.dtype)
        pooled = ((x * valid).sum(1) / valid.sum(1).clamp_min(1)).float().cpu()
        for (digest, _), vector in zip(chunk, pooled):
            out[digest].append(vector)
    payload = {"key": key, "clauses": {digest: torch.stack(rows).to(torch.float16) for digest, rows in out.items()}}
    path = Path(path)
    temporary = path.with_name(path.name + ".pending")
    torch.save(payload, temporary)
    os.replace(temporary, path)
    return payload


def load_text_feature_cache(path):
    payload = torch.load(path, map_location="cpu", weights_only=True)
    if payload.get("key") != text_cache_key():
        raise ValueError("文本特征缓存的编码器/子句协议与当前配置不一致，拒绝使用")
    return payload


def attach_text_features(episodes, payload):
    """给样本挂载子句特征；缺任意指令即拒绝，不静默回退。"""
    for episode in episodes:
        for sample in episode:
            digest = hashlib.sha256(sample["instruction"].encode("utf-8")).hexdigest()
            if digest not in payload["clauses"]:
                raise ValueError("文本特征缓存缺少指令")
            sample["clause_features"] = payload["clauses"][digest]
    return episodes


class Vocab:
    def __init__(self, texts, tokenizer_version="fov_numeric_v1"):
        if tokenizer_version not in TOKENIZER_VERSIONS:
            raise ValueError(f"tokenizer_version 必须属于 {TOKENIZER_VERSIONS}")
        self.tokenizer_version = tokenizer_version
        words = {"<pad>": 0, "<unk>": 1}
        for text in texts:
            for word in tokenize(text, tokenizer_version):
                if word not in words:
                    words[word] = len(words)
        self.words = words

    def encode(self, text):
        return [self.words.get(word, 1) for word in tokenize(text, self.tokenizer_version)] or [1]


def preprocess_rgb(image, imgsz, mean=IMAGENET_MEAN, std=IMAGENET_STD):
    """训练与在线推理共用的RGB张量变换，保持历史双三次缩放语义。"""
    image = image.convert("RGB").resize((imgsz, imgsz), Image.BICUBIC)
    array = np.asarray(image, dtype=np.float32) / 255.0
    array = (array - mean) / std
    return torch.from_numpy(np.ascontiguousarray(array)).permute(2, 0, 1)


def save_aerial_depth(path, depth, storage_protocol="npy_float_v1"):
    """写入新深度帧且拒覆盖；gzip保留原float32位模式，raw保留旧dtype。"""
    path = Path(path)
    if storage_protocol not in ("npy_float_v1", "npy_float32_v1", "npy_gzip_float32_v1"):
        raise ValueError("未知深度storage_protocol")
    compressed = storage_protocol == "npy_gzip_float32_v1"
    _aerial_depth_storage(path, storage_protocol if compressed else None)
    array = depth.detach().cpu().numpy() if isinstance(depth, torch.Tensor) else np.asarray(depth)
    preprocess_depth(array)
    if compressed and array.dtype != np.dtype("float32"):
        raise ValueError("npy_gzip_float32_v1只写真实float32深度，不转换dtype")
    with path.open("xb") as output:
        if compressed:
            with gzip.GzipFile(filename="", fileobj=output, mode="wb", compresslevel=6, mtime=0) as stream:
                np.save(stream, array, allow_pickle=False)
        else:
            np.save(output, array, allow_pickle=False)
    result = {"path": path.name, "sha256": _sha256(path)}
    if compressed:
        result["storage_protocol"] = storage_protocol
    return result


def preprocess_depth(depth, expected_sha256=None, storage_protocol=None):
    """真实front_0场景归一化深度，固定256，无估计、重缩放或填充。"""
    if isinstance(depth, (str, Path)):
        path = Path(depth)
        _aerial_depth_storage(path, storage_protocol)
        if not path.is_file():
            raise ValueError("深度缓存必须是存在的.npy或.npy.gz文件")
        if expected_sha256 is None or _sha256(path) != expected_sha256:
            raise ValueError("深度缓存缺少或不匹配SHA256")
        if storage_protocol == "npy_gzip_float32_v1":
            # 固定256浮点帧不允许无限解压；读完gzip同时校验CRC与尾部。
            with gzip.open(path, "rb") as stream:
                raw = stream.read(1024 * 1024 + 1)
            if len(raw) > 1024 * 1024:
                raise ValueError("压缩深度解压内容超过单帧预算")
            stream = io.BytesIO(raw)
            depth = np.load(stream, allow_pickle=False)
            if stream.read(1) or depth.dtype != np.dtype("float32"):
                raise ValueError("npy_gzip_float32_v1要求单个float32数组，不接受尾随内容")
        else:
            depth = np.load(path, allow_pickle=False)
        if _sha256(path) != expected_sha256:
            raise ValueError("深度缓存读取期间发生改变")
    elif storage_protocol is not None:
        raise ValueError("inline深度数组不声明文件storage_protocol")
    if isinstance(depth, torch.Tensor):
        depth = depth.detach().cpu().numpy()
    array = np.asarray(depth)
    if array.shape == (256, 256, 1):
        array = array[..., 0]
    if (array.shape != (256, 256) or array.dtype.kind != "f"
            or not np.isfinite(array).all() or np.any((array < 0) | (array > 1))):
        raise ValueError("深度必须为有限浮点256x256或256x256x1，值域[0,1]")
    return torch.from_numpy(np.array(array, dtype=np.float32, order="C", copy=True)).unsqueeze(0)


VISION_FEATURE_CACHE_VERSION = "frozen_vision_feature_cache_v1"


def vision_cache_key(model, imgsz, storage_dtype="float32"):
    """缓存键：预处理、骨干结构与权重一并绑定，任何一项改变都使缓存失效。"""
    digest = hashlib.sha256()
    for name, tensor in sorted(model.vision.state_dict().items()):
        digest.update(name.encode("utf-8") + str(tensor.dtype).encode("ascii") + str(list(tensor.shape)).encode("ascii"))
        digest.update(tensor.detach().cpu().contiguous().reshape(-1).view(torch.uint8).numpy().tobytes())
    return {"version": VISION_FEATURE_CACHE_VERSION, "backbone": model.backbone, "grid_size": model.grid_size,
            "imgsz": imgsz, "mean": [float(v) for v in IMAGENET_MEAN], "std": [float(v) for v in IMAGENET_STD],
            "bn": model.vision_batchnorm_protocol,
            "vision_state_sha256": digest.hexdigest(),
            **({"storage_dtype": storage_dtype} if storage_dtype != "float32" else {})}


@torch.no_grad()
def build_vision_feature_cache(model, episodes, imgsz, device, path, batch_size=64, storage_dtype="float32"):
    """一次性提取冻结骨干特征（fp32，eval），按 image_sha256 去重落盘；仅限完全冻结的路线模型。"""
    if getattr(model, "vision_train_policy", None) != "frozen" or any(p.requires_grad for p in model.vision.parameters()):
        raise ValueError("特征缓存只适用于完全冻结的视觉骨干")
    if storage_dtype not in ("float32", "float16"):
        raise ValueError("storage_dtype只接受float32或float16")
    store = torch.float16 if storage_dtype == "float16" else torch.float32
    key = vision_cache_key(model, imgsz, storage_dtype)
    unique = {}
    for episode in episodes:
        for sample in episode:
            digest = sample.get("image_sha256")
            if not isinstance(digest, str) or len(digest) != 64:
                raise ValueError("特征缓存要求每帧有image_sha256")
            unique.setdefault(digest, sample["image"])
    was_training = model.training
    model.eval()
    mean, regions = {}, {}
    digests = sorted(unique)
    from concurrent.futures import ThreadPoolExecutor
    from tqdm import tqdm

    def decode(digest):
        raw_bytes = Path(unique[digest]).read_bytes()
        if hashlib.sha256(raw_bytes).hexdigest() != digest:
            raise ValueError(f"图像内容与清单image_sha256不符，拒绝写入缓存: {unique[digest]}")
        with Image.open(io.BytesIO(raw_bytes)) as raw:
            return preprocess_rgb(raw, imgsz)

    with ThreadPoolExecutor(max_workers=16) as pool:
        for begin in tqdm(range(0, len(digests), batch_size), desc="vision feature cache", unit="batch"):
            chunk = digests[begin:begin + batch_size]
            images = list(pool.map(decode, chunk))
            pooled, grid = model.vision_summary(torch.stack(images).to(device))
            for row, digest in enumerate(chunk):
                mean[digest], regions[digest] = pooled[row].float().cpu().to(store), grid[row].float().cpu().to(store)
    model.train(was_training)
    payload = {"key": key, "mean": mean, "regions": regions}
    path = Path(path)
    temporary = path.with_name(path.name + ".pending")
    torch.save(payload, temporary)
    os.replace(temporary, path)
    return payload


def load_vision_feature_cache(path, model, imgsz, storage_dtype="float32"):
    payload = torch.load(path, map_location="cpu", weights_only=True)
    if payload.get("key") != vision_cache_key(model, imgsz, storage_dtype):
        raise ValueError("特征缓存的预处理/骨干权重与当前模型不一致，拒绝使用")
    return payload


def attach_vision_features(episodes, payload):
    """给样本挂载缓存特征；缺任意一帧即拒绝，不静默回退到在线前向。"""
    for episode in episodes:
        for sample in episode:
            digest = sample.get("image_sha256")
            if digest not in payload["mean"]:
                raise ValueError(f"特征缓存缺少帧 {digest}")
            sample["vision_mean"], sample["vision_regions"] = payload["mean"][digest], payload["regions"][digest]
    return episodes


def collate(samples, vocab, imgsz, history_frames):
    if not samples:
        raise ValueError("collate 不能使用空样本批次")
    cached = ["vision_mean" in sample for sample in samples]
    if any(cached) and not all(cached):
        raise ValueError("同一批次不能混合缓存特征与在线图像样本")
    if isinstance(history_frames, bool) or not isinstance(history_frames, int) or history_frames < 0:
        raise ValueError("history_frames 必须是非负整数")
    action_mode = any("action" in sample for sample in samples)
    if action_mode and any("action" not in sample or "offset" in sample for sample in samples):
        raise ValueError("八动作样本不能与旧位移监督混在同一批次")
    if action_mode and any(sample.get("history_policy") != AERIAL_HISTORY_POLICY for sample in samples):
        raise ValueError("八动作样本必须显式声明 action_onehot8_v1 历史协议")
    # 真实词在左、pad 在右。instruction 是单向 LSTM，句尾的 pad 不会污染前面 token 的隐状态。
    tokens = [vocab.encode(sample["instruction"]) for sample in samples]
    width = max(len(row) for row in tokens)
    token_ids = torch.zeros(len(samples), width, dtype=torch.long)
    token_mask = torch.zeros(len(samples), width, dtype=torch.bool)
    for row, ids in enumerate(tokens):
        token_ids[row, : len(ids)] = torch.tensor(ids)
        token_mask[row, : len(ids)] = True
    # 不做水平翻转：offset 是机体坐标，翻图会把 y 分量取反而标签不会跟着翻。
    images = []
    for sample in samples:
        if cached[0]:
            break
        try:
            image_source = sample["image"]
            if action_mode:
                raw_bytes = Path(image_source).read_bytes()
                if hashlib.sha256(raw_bytes).hexdigest() != sample.get("image_sha256"):
                    raise ValueError(f"图像内容与清单image_sha256不符，已停止训练: {image_source}")
                # 摘要和解码绑定同一次读取，避免核验后再打开路径时内容已变化。
                image_source = io.BytesIO(raw_bytes)
            with Image.open(image_source) as raw:
                images.append(preprocess_rgb(raw, imgsz))
        except OSError as error:
            raise RuntimeError(f"图像读取失败，已停止训练: {sample['image']}") from error
    history_width = 8 if action_mode else 3
    history = torch.zeros(len(samples), history_frames, history_width)
    history_length = torch.zeros(len(samples), dtype=torch.long)
    offsets = []
    for row, sample in enumerate(samples):
        past = np.asarray(sample["history"], dtype=np.float32)
        if past.ndim != 2 or past.shape[1] != history_width or not np.isfinite(past).all():
            raise ValueError("样本历史的形状/数值与当前协议不一致")
        past = past[-history_frames:] if history_frames else past[:0]
        history_length[row] = len(past)
        if len(past):
            history[row, -len(past) :] = torch.from_numpy(np.ascontiguousarray(past, dtype=np.float32))
        if not action_mode:
            offsets.append(torch.from_numpy(sample["offset"]))
    batch = {
        "tokens": token_ids,
        "token_mask": token_mask,
        "history": history,
        "history_length": history_length,
    }
    if cached[0]:
        batch["vision_mean"] = torch.stack([sample["vision_mean"] for sample in samples]).float()
        batch["vision_regions"] = torch.stack([sample["vision_regions"] for sample in samples]).float()
        batch["image"] = torch.empty(len(samples), 0)
    else:
        batch["image"] = torch.stack(images)
    if any("clause_features" in sample for sample in samples):
        if any("clause_features" not in sample for sample in samples):
            raise ValueError("同一批次不能混合子句特征与词表样本")
        width = max(len(sample["clause_features"]) for sample in samples)
        clauses = torch.zeros(len(samples), width, samples[0]["clause_features"].shape[-1])
        clause_mask = torch.zeros(len(samples), width, dtype=torch.bool)
        for row, sample in enumerate(samples):
            count = len(sample["clause_features"])
            clauses[row, :count] = sample["clause_features"].float()
            clause_mask[row, :count] = True
        batch["clause_features"], batch["clause_mask"] = clauses, clause_mask
    if any("depth" in sample for sample in samples):
        if any("depth" not in sample or sample.get("depth_input_protocol")
               != "front_0_scene_normalized_256_v1" for sample in samples):
            raise ValueError("RGB-D批次不能混入无深度样本或未知深度协议")
        batch["depth"] = torch.stack([preprocess_depth(sample["depth"], sample.get("depth_sha256"),
                                                     sample.get("depth_storage_protocol"))
                                      for sample in samples])
    if action_mode:
        actions = [sample["action"] for sample in samples]
        if any(isinstance(action, bool) or not isinstance(action, int) or not 0 <= action < 8 for action in actions):
            raise ValueError("八动作 action_target 必须为 0 至 7 的整数")
        batch["action_target"] = torch.tensor(actions, dtype=torch.long)
    else:
        batch["offset"] = torch.stack(offsets)
    stop_fields = ("motion_valid", "stop_valid", "stop_target")
    if any(field in sample for sample in samples for field in stop_fields):
        if any(field not in sample for sample in samples for field in stop_fields):
            raise ValueError("STOP 扩展样本必须同时包含 motion_valid、stop_valid 和 stop_target")
        batch["motion_valid"] = torch.tensor([sample["motion_valid"] for sample in samples], dtype=torch.bool)
        batch["stop_valid"] = torch.tensor([sample["stop_valid"] for sample in samples], dtype=torch.bool)
        batch["stop_target"] = torch.tensor([sample["stop_target"] for sample in samples], dtype=torch.float32)
    return batch
