"""严格解析 TravelUAV 对象元数据，不读取或改写原始 dataset。

官方生成点条目的实际位置为 ``entry[9:12]``，四元数为
``[entry[13], entry[14], entry[15], entry[12]]``，资产和尺度为
``entry[16]``、``entry[17]``。``entry[0:3]`` 是官方最近区域查询使用的
锚点，不能据它替换 mark 指定的对象。解析结果只证明元数据所指的配置，
不证明对应场景已经包含或渲染了该 mesh。
"""

import math
import hashlib
import json
import re
from collections.abc import Mapping, Sequence
from numbers import Real


POSITION_TOLERANCE_M = 1e-6

# 已核 Kaggle AerialVLN v3 压缩包原文件，证据见
# plan/aerialvln_dataset_20261005/aerialvln-s-file-manifest.json。
# 来源只读注册，禁止从用户提供的裁剪清单动态建立“官方”身份。
AERIALVLN_S_RELEASE = {
    "release": "kaggle_aerialvln_v3",
    "train": {"sha256": "64a06ef2228579e6e19f688d1eaa3fd3a407d8913fad38ce74e133e0b9336dee", "episodes": 10113},
    "val_seen": {"sha256": "29b52c9b7a5554376410f5d1d0631f563b29df730c20fb1b7adc23f36c004ac3", "episodes": 333},
    "val_unseen": {"sha256": "e364ca423fa27422857e101ad3705f6b14dbdac5c7e49bbeafee3d5ab2ed7504", "episodes": 531},
    "test": {"sha256": "a0658d366b67cebcf49b1e5a02cb6009491861edb3064fa721ce7e392994c3ca", "episodes": 770},
}


def authenticate_aerial_release(split, episodes):
    """认证未裁剪来源与唯一任务集合；文件SHA绑定发布内容而非数量推断。"""
    expected = AERIALVLN_S_RELEASE.get(split)
    if not isinstance(expected, dict) or not isinstance(episodes, list):
        raise ValueError("未知AerialVLN-S官方发布划分")
    identities = [f"{row['scene_id']}/{row['episode_id']}" for row in episodes]
    if (len(episodes) != expected["episodes"] or len(set(identities)) != len(identities)
            or any(row.get("_annotation_sha256") != expected["sha256"] for row in episodes)):
        raise ValueError("AerialVLN-S源SHA/完整任务数/唯一任务集合与已核Kaggle v3发布不一致")
    digest = hashlib.sha256(json.dumps(sorted(identities), separators=(",", ":"),
                                      ensure_ascii=False).encode("utf-8")).hexdigest()
    return {"release": AERIALVLN_S_RELEASE["release"], "split": split,
            "annotation_sha256": expected["sha256"], "episode_count": len(episodes),
            "episode_ids_sha256": digest}


def validate_official_aerial_split(annotation_root, split):
    """从原标注文件解析并认证发布来源，供训练/采集使用。"""
    from uavnav.avln.data import load_aerial_episodes
    episodes = load_aerial_episodes(annotation_root, split)
    certificate = authenticate_aerial_release(split, episodes)
    return {**certificate, "source_sha256": certificate["annotation_sha256"],
            "episode_ids": sorted(f"{row['scene_id']}/{row['episode_id']}" for row in episodes)}


def aerial_metric_definition_contract():
    """Reporting semantics only; leaves checkpoint task and numerical scoring unchanged."""
    return {
        "measurement_definition_version": "aerial_metric_reporting_v2",
        "latency_measurement": "model_inference_per_decision",
        "latency_boundary": {
            "start": "immediately_before_predict_action",
            "end": "predict_action_return",
            "includes": ["local_rgb_preprocessing", "instruction_encoding", "model_inference",
                         "device_synchronization_in_predictor", "output_action_parsing", "stop_decision"],
            "excludes": ["sensor_acquisition", "controller_step", "observation_recording", "journal_writes"],
        },
        "latency_percentile_method": "linear",
        "ndtw_distance_dimensions": 3,
        "ne_distance_dimensions": 2,
        "sr_distance_dimensions": 2,
        "osr_distance_dimensions": 2,
        "initial_contact_policy": "record_only_not_a_depth_proxy_or_success_veto",
        "initial_depth_proxy_policy": "reject_episode_before_policy_decisions",
        "depth_proxy_source": {
            "scene_1_7": "DepthVis_green_uint8_div255_not_metric_distance",
            "other_scenes": "DepthPerspective_float_m_clipped_0_100_div100",
            "termination": "normalized_depth_lt_0.004_fraction_gt_0.1",
            "physical_contact_equivalence": False,
        },
    }


def aerial_task_protocol(image_size=224):
    """AirVLN 上游八动作任务，前视 RGB 学生与深度终止代理分开记录。"""
    return validate_aerial_task_protocol({
        "version": "aerialvln_s_v1", "benchmark": "AerialVLN-S", "camera": "front_0",
        "image_size": image_size, "instruction_source": "instruction.instruction_text",
        "goal_access": "training_labels_and_offline_scoring_only",
        "action_protocol": "aerial_action8_v1", "history_protocol": "action_onehot8_v1",
        "stop_source": "teacher_action_0", "stop_timing": "before_action",
        "success_distance_m": 20.0, "distance_dimensions": 2,
        "control_protocol": "airsim_set_pose_ignore_collision",
        "collision_source": "normalized_depth_lt_0.004_fraction_gt_0.1_proxy",
    })


def validate_aerial_task_protocol(protocol):
    if not isinstance(protocol, Mapping):
        raise ValueError("AerialVLN task_protocol 必须是对象")
    fixed = {
        "version": "aerialvln_s_v1", "benchmark": "AerialVLN-S", "camera": "front_0",
        "instruction_source": "instruction.instruction_text",
        "goal_access": "training_labels_and_offline_scoring_only",
        "action_protocol": "aerial_action8_v1", "history_protocol": "action_onehot8_v1",
        "stop_source": "teacher_action_0", "stop_timing": "before_action",
        "success_distance_m": 20.0, "distance_dimensions": 2,
        "control_protocol": "airsim_set_pose_ignore_collision",
        "collision_source": "normalized_depth_lt_0.004_fraction_gt_0.1_proxy",
    }
    result = _exact_fields(protocol, {*fixed, "image_size"}, "aerial_task_protocol")
    for key, value in fixed.items():
        if result[key] != value or (key == "distance_dimensions" and type(result[key]) is not int):
            raise ValueError(f"aerial_task_protocol.{key} 必须为 {value!r}")
    if type(result["image_size"]) is not int or result["image_size"] <= 0:
        raise ValueError("aerial_task_protocol.image_size 必须是正整数")
    return result


def validate_task_protocol(protocol):
    """核验单前视任务合同，真值权限不属于学生输入。"""
    if not isinstance(protocol, Mapping):
        raise ValueError("task_protocol 必须是对象")
    protocol = dict(protocol)
    if (not isinstance(protocol.get("version"), str) or not protocol["version"]
            or protocol.get("camera") != "FrontCamera"
            or protocol.get("goal_access") != "training_labels_and_offline_scoring_only"):
        raise ValueError("task_protocol 需要版本、FrontCamera 和仅训练标签/评分的目标权限")
    if not isinstance(protocol.get("strip_direction"), bool):
        raise ValueError("task_protocol.strip_direction 必须是布尔值")
    size = protocol.get("image_size")
    if isinstance(size, bool) or not isinstance(size, int) or size <= 0:
        raise ValueError("task_protocol.image_size 必须是正整数")
    source, timing = protocol.get("stop_source"), protocol.get("stop_timing")
    if source == "disabled":
        if timing != "disabled":
            raise ValueError("禁用STOP时 stop_timing 也必须disabled")
    elif source == "reviewed_annotations":
        radius = protocol.get("success_distance_m")
        if (timing != "before_action" or protocol.get("goal_source") != "object_metadata"
                or isinstance(radius, bool) or not isinstance(radius, Real)
                or not math.isfinite(radius) or radius <= 0):
            raise ValueError("STOP合同需要动作前停止、对象目标和有限正完成距离")
    else:
        raise ValueError("未知的STOP标签来源")
    return protocol


def task_protocol_sha256(protocol):
    validated = validate_task_protocol(protocol)
    return hashlib.sha256(json.dumps(validated, sort_keys=True, separators=(",", ":"),
                                     ensure_ascii=False, allow_nan=False).encode("utf-8")).hexdigest()


def _exact_fields(value, fields, name):
    if not isinstance(value, Mapping) or set(value) != set(fields):
        raise ValueError(f"{name} 字段必须恰好为 {sorted(fields)}")
    return dict(value)


def validate_evaluation_protocol(protocol):
    """核验最终静态对象接近评测合同，不改变旧模型的训练合同。

    coordinate_frame 是待场景证据核验的声明，本函数不转换对象或参考坐标。
    allowed_observations 定义允许权限，不声称当前策略使用了所有权限。
    """
    fixed = {
        "version": "fov_static_v1", "benchmark": "UAV-VLN-FOV", "environment": "static",
        "goal_source": "object_metadata", "goal_access": "training_labels_and_offline_scoring_only",
        "stop_protocol": "predicted_stop_before_action", "collision_source": "simulator_contact",
        "oracle_termination": "disabled", "instruction_source": "obj_des.json",
        "target_description_source": "instruction_only",
        "coordinate_frame": "airsim_local_ned_from_vehicle_spawn",
    }
    result = _exact_fields(protocol, {*fixed, "success_distance_m", "distance_dimensions",
                                      "allowed_observations", "control", "spl"}, "evaluation_protocol")
    for key, expected in fixed.items():
        if result[key] != expected:
            raise ValueError(f"evaluation_protocol.{key} 必须是 {expected!r}")
    radius, dimensions = result["success_distance_m"], result["distance_dimensions"]
    if isinstance(radius, bool) or not isinstance(radius, Real) or not math.isfinite(radius) or radius != 10:
        raise ValueError("evaluation_protocol.success_distance_m 必须是 10 米")
    if isinstance(dimensions, bool) or not isinstance(dimensions, int) or dimensions != 3:
        raise ValueError("evaluation_protocol.distance_dimensions 必须是整数 3")
    result["success_distance_m"] = 10.0
    required = ("front_rgb", "down_rgb", "instruction", "initial_direction", "vehicle_pose")
    observations = result["allowed_observations"]
    if (not isinstance(observations, list) or any(not isinstance(item, str) for item in observations)
            or len(observations) != len(set(observations))
            or not set(required).issubset(observations) or not set(observations).issubset((*required, "depth"))):
        raise ValueError("allowed_observations 需要双RGB、指令、初始方向和机载位姿，只能额外允许 depth")
    result["allowed_observations"] = list(required) + (["depth"] if "depth" in observations else [])
    control = _exact_fields(result["control"], {"protocol", "max_steps", "action_duration_sim_s",
                                               "speed_limit_m_s", "sample_interval_sim_s"}, "control")
    if control["protocol"] != "paused_static_fixed_duration_world_velocity":
        raise ValueError("control.protocol 不支持")
    if isinstance(control["max_steps"], bool) or not isinstance(control["max_steps"], int) or control["max_steps"] <= 0:
        raise ValueError("control.max_steps 必须是正整数")
    for key in ("action_duration_sim_s", "speed_limit_m_s", "sample_interval_sim_s"):
        value = control[key]
        if isinstance(value, bool) or not isinstance(value, Real) or not math.isfinite(value) or value <= 0:
            raise ValueError(f"control.{key} 必须是有限正数")
        control[key] = float(value)
    if control["sample_interval_sim_s"] > control["action_duration_sim_s"]:
        raise ValueError("采样间隔不能超过动作推进时长")
    result["control"] = control
    expected_spl = {"definition": "success_distance_adjusted", "reference": "reference_path_proxy",
                    "sampling": "sim_step_pose_samples",
                    "zero_length_success": "one_if_denominator_le_1e-8"}
    spl = _exact_fields(result["spl"], expected_spl, "spl")
    if spl != expected_spl:
        raise ValueError("spl 定义、参考路径或位姿采样不符合 fov_static_v1")
    result["spl"] = spl
    return result


def evaluation_protocol_sha256(protocol):
    validated = validate_evaluation_protocol(protocol)
    return hashlib.sha256(json.dumps(validated, sort_keys=True, separators=(",", ":"),
                                     ensure_ascii=False, allow_nan=False).encode("utf-8")).hexdigest()


def canonical_eval_split(split):
    aliases = {"test": "test", "unobject": "unobject", "unscene": "unscene",
               "unseen_object": "unobject", "unseen_scene": "unscene",
               "val_seen": "val_seen", "val_unseen": "val_unseen"}
    if not isinstance(split, str) or split not in aliases:
        raise ValueError("评测划分必须是 test、unobject 或 unscene（兼容 unseen 别名）")
    return aliases[split]


def validate_evaluation_manifest(manifest):
    """冻结预期 episode 集合；未知、重复、跨划分或不安全轨迹 ID 拒绝。"""
    result = _exact_fields(manifest, {"schema_version", "scope", "split", "source_sha256",
                                     "evaluation_protocol_sha256", "episodes"}, "evaluation_manifest")
    if type(result["schema_version"]) is not int or result["schema_version"] not in (1, 2):
        raise ValueError("evaluation_manifest.schema_version 必须是整数 1 或 2")
    aerial_truth = result["schema_version"] == 2
    if aerial_truth and (result["split"] not in ("train", "val_seen", "val_unseen")
            or result["source_sha256"] is None or result["evaluation_protocol_sha256"] is None):
        raise ValueError("schema2只支持有源标注/评分合同摘要的AerialVLN带真值划分")
    if result["scope"] not in ("subset_diagnostic", "official_split"):
        raise ValueError("evaluation_manifest.scope 不支持")
    training_diagnostic = result["split"] == "train" and result["scope"] == "subset_diagnostic"
    if training_diagnostic:
        if result["source_sha256"] is None or result["evaluation_protocol_sha256"] is None:
            raise ValueError("训练路线诊断需要源标注和评测合同SHA256，不能声明正式划分")
    else:
        result["split"] = canonical_eval_split(result["split"])
    for key in ("source_sha256", "evaluation_protocol_sha256"):
        digest = result[key]
        if digest is not None and (not isinstance(digest, str) or re.fullmatch(r"[0-9a-fA-F]{64}", digest) is None):
            raise ValueError(f"evaluation_manifest.{key} 必须是 SHA256 或 None")
        result[key] = digest.lower() if digest is not None else None
    if result["scope"] == "official_split" and result["source_sha256"] is None:
        raise ValueError("official_split 必须绑定源列表 SHA256")
    episodes = result["episodes"]
    if not isinstance(episodes, list) or not episodes:
        raise ValueError("evaluation_manifest.episodes 必须是非空列表")
    if result["source_sha256"] is None and len(episodes) != 1:
        raise ValueError("仅单轨迹诊断允许 source_sha256=None")
    rows, seen = [], set()
    for row in episodes:
        fields = {"traj_id", "split", "episode_sha256", "scoring_truth_sha256"} if aerial_truth else {"traj_id", "split"}
        row = _exact_fields(row, fields, "episode")
        if aerial_truth:
            for field in ("episode_sha256", "scoring_truth_sha256"):
                if not isinstance(row[field], str) or re.fullmatch(r"[a-f0-9]{64}", row[field]) is None:
                    raise ValueError(f"episode.{field}必须是小写SHA256")
        traj_id = row["traj_id"]
        if (not isinstance(traj_id, str) or "\\" in traj_id or ":" in traj_id
                or len(traj_id.split("/")) != 2
                or any(part in ("", ".", "..") or part != part.strip() for part in traj_id.split("/"))):
            raise ValueError("episode.traj_id 必须是安全的 Map/UUID 相对路径")
        if traj_id in seen:
            raise ValueError(f"重复 episode: {traj_id}")
        seen.add(traj_id)
        if not training_diagnostic:
            row["split"] = canonical_eval_split(row["split"])
        if row["split"] != result["split"]:
            raise ValueError("episode.split 与评测名单划分不一致")
        rows.append(row)
    result["episodes"] = rows
    return result


def evaluation_manifest_sha256(manifest):
    validated = validate_evaluation_manifest(manifest)
    return hashlib.sha256(json.dumps(validated, sort_keys=True, separators=(",", ":"),
                                     ensure_ascii=False, allow_nan=False).encode("utf-8")).hexdigest()


def aerial_scoring_truth_sha256(metadata):
    """绑定离线真值，不向策略传入目标或参考路径。

    按字段名排序的UTF-8 JSON计算SHA256，分隔符为逗号/冒号，无空白。
    所有位姿数值转有限float，保留位置、路径顺序及原xyzw，不量化或归一化。
    额外元数据不入摘要；下列所有绑定字段必须显式存在。
    """
    if not isinstance(metadata, Mapping):
        raise ValueError("AerialVLN评分真值必须是对象")
    fields = ("traj_id", "split", "episode_sha256", "annotation_sha256")
    truth = {field: metadata.get(field) for field in fields}
    if (truth["split"] not in ("train", "val_seen", "val_unseen")
            or not isinstance(truth["traj_id"], str) or "\\" in truth["traj_id"]
            or ":" in truth["traj_id"] or len(truth["traj_id"].split("/")) != 2
            or any(part in ("", ".", "..") or part != part.strip() for part in truth["traj_id"].split("/"))):
        raise ValueError("AerialVLN评分真值traj_id/split无效")
    for field in ("episode_sha256", "annotation_sha256"):
        if not isinstance(truth[field], str) or re.fullmatch(r"[a-f0-9]{64}", truth[field]) is None:
            raise ValueError(f"AerialVLN评分真值{field}缺失或无效")
    for field, size in (("goal_position", 3), ("start_position", 3), ("start_orientation_xyzw", 4)):
        truth[field] = _vector(metadata.get(field), field, size)
    if sum(value * value for value in truth["start_orientation_xyzw"]) < 1e-24:
        raise ValueError("AerialVLN评分真值起始朝向不能为空四元数")
    reference = metadata.get("reference_positions")
    if not isinstance(reference, list) or not reference:
        raise ValueError("AerialVLN评分真值必须有完整参考位置列表")
    truth["reference_positions"] = [_vector(point, f"reference_positions[{index}]", 3)
                                    for index, point in enumerate(reference)]
    return hashlib.sha256(json.dumps(truth, sort_keys=True, separators=(",", ":"),
                                     ensure_ascii=False, allow_nan=False).encode("utf-8")).hexdigest()


class ObjectMetadataError(ValueError):
    """对象意图缺失、无匹配或存在多种配置。"""


def _vector(value, name, size):
    if not isinstance(value, Sequence) or isinstance(value, (str, bytes)) or len(value) != size:
        raise ObjectMetadataError(f"{name} 必须是长度为 {size} 的数值序列")
    result = []
    for number in value:
        if isinstance(number, bool) or not isinstance(number, Real) or not math.isfinite(number):
            raise ObjectMetadataError(f"{name} 必须仅包含有限数")
        result.append(float(number))
    return result


def resolve_object_metadata(mark, map_spawnarea_info, map_name):
    """用同 Map、同资产名和实际生成位置恢复唯一对象配置。

    位置匹配逐坐标使用固定绝对容差 ``1e-6`` 米，不使用相对容差。
    只有资产、位置、原始 xyzw 和尺度数值全部相同的条目才可折叠。
    无匹配或存在多种配置时抛出 ``ObjectMetadataError``，不回退到区域
    锚点最近查询，不修改 mark 或生成点列表，不归一化原始四元数。
    """
    if not isinstance(mark, Mapping) or not isinstance(map_spawnarea_info, Mapping):
        raise ObjectMetadataError("mark 和 map_spawnarea_info 必须是对象")
    if not isinstance(map_name, str) or not map_name:
        raise ObjectMetadataError("map_name 必须是非空字符串")
    if map_name not in map_spawnarea_info:
        raise ObjectMetadataError(f"Map 不存在: {map_name}")
    asset = mark.get("object_name")
    if not isinstance(asset, str) or not asset:
        raise ObjectMetadataError("mark.object_name 必须是非空资产名")
    target = mark.get("target")
    if not isinstance(target, Mapping):
        raise ObjectMetadataError("缺少 mark.target")
    target_position = _vector(target.get("position"), "mark.target.position", 3)
    entries = map_spawnarea_info[map_name]
    if not isinstance(entries, Sequence) or isinstance(entries, (str, bytes)):
        raise ObjectMetadataError(f"Map {map_name} 的生成点必须是列表")

    configurations = {}
    for index, entry in enumerate(entries):
        # 与官方格式一致，长度不足 18 的区域条目没有对象尺度等完整字段。
        if not isinstance(entry, Sequence) or isinstance(entry, (str, bytes)):
            raise ObjectMetadataError(f"Map {map_name} 的 entry[{index}] 不是序列")
        if len(entry) < 18 or entry[16] != asset:
            continue
        prefix = f"Map {map_name} entry[{index}]"
        position = _vector(entry[9:12], f"{prefix}.position", 3)
        if not all(abs(actual - intended) <= POSITION_TOLERANCE_M for actual, intended in zip(position, target_position)):
            continue
        orientation = _vector([entry[13], entry[14], entry[15], entry[12]], f"{prefix}.orientation_xyzw", 4)
        if math.hypot(*orientation) == 0:
            raise ObjectMetadataError(f"{prefix}.orientation_xyzw 不能是零四元数")
        scale = entry[17]
        if isinstance(scale, bool) or not isinstance(scale, Real) or not math.isfinite(scale) or scale <= 0:
            raise ObjectMetadataError(f"{prefix}.scale 必须是有限正数")
        scale = float(scale)
        key = (asset, *position, *orientation, scale)
        configurations.setdefault(key, {"asset": asset, "position": position, "orientation_xyzw": orientation, "scale": scale, "source_entry_indices": []})["source_entry_indices"].append(index)

    if not configurations:
        raise ObjectMetadataError(
            f"Map {map_name} 未找到资产 {asset} 在 mark.target.position={target_position} 的匹配生成点；"
            f"绝对容差 {POSITION_TOLERANCE_M} 米，禁止锚点最近兜底"
        )
    if len(configurations) != 1:
        indices = [item["source_entry_indices"] for item in configurations.values()]
        raise ObjectMetadataError(f"Map {map_name} 资产 {asset} 存在 {len(configurations)} 种匹配配置，entry indices={indices}")
    result = next(iter(configurations.values()))
    return {
        **result,
        "tolerance": {"absolute_m": POSITION_TOLERANCE_M, "relative": 0.0},
        "map_name": map_name,
        "resolution_rule": "exact_asset_and_actual_spawn_position",
        "validation_status": "metadata_intent_only_mesh_unverified",
    }
