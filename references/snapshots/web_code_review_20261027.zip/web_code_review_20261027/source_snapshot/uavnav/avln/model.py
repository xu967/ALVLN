"""版本化AVLN策略：旧机体位移、八动作反应基线与候选路线循环状态。

各架构复用逐词语言和视觉融合；旧checkpoint的输出及forward保持原语义。
路线v2的导航记忆与文本LSTM分开，只有连续episode训练能建立跨步监督。
"""

import hashlib
import argparse
import importlib
import json
import os
import sys
from contextlib import nullcontext
from pathlib import Path
from unittest.mock import patch

import torch
import numpy as np
from torch import nn
from torchvision.models import ResNet18_Weights, ResNet50_Weights, resnet18, resnet50


FUSION_MODES = ("text_context_only", "query_plus_text")
TEXT_QUERY_MODES = ("visual_history", "state_conditioned_v1")
DINOV3_VARIANTS = {
    "vits16": ("dinov3_vits16", 384),
    "vits16plus": ("dinov3_vits16plus", 384),
    "vitb16": ("dinov3_vitb16", 768),
    "vitl16": ("dinov3_vitl16", 1024),
}
DINOV3_BACKBONES = tuple(name for name, _ in DINOV3_VARIANTS.values())
DINOV3_ARCHITECTURES = ("aerial_route_dino_v5",)
AIRVLN_RGBD_ARCHITECTURES = ("airvln_seq2seq_rgbd_v1", "airvln_cma_rgbd_v1")
AIRVLN_ARCHITECTURES = ("airvln_seq2seq_rgb_v1", "airvln_cma_rgb_v1") + AIRVLN_RGBD_ARCHITECTURES
RGBD_ARCHITECTURES = ("aerial_route_recurrent_rgbd_v3",) + AIRVLN_RGBD_ARCHITECTURES
ARCHITECTURES = ("legacy_waypoint_v1", "grounded_v1", "aerial_route_v1", "aerial_route_recurrent_v2", "aerial_route_recurrent_clause_v3") + RGBD_ARCHITECTURES[:1] + DINOV3_ARCHITECTURES + AIRVLN_ARCHITECTURES
BACKBONES = ("resnet18", "resnet50") + DINOV3_BACKBONES
FUSIONS = ("global", "spatial")
ABLATIONS = ("none", "no_image", "no_history", "no_text")

_DINOV3_SOURCE_OWNER = None


def sha256_file(path):
    digest = hashlib.sha256()
    with Path(path).open("rb") as stream:
        for chunk in iter(lambda: stream.read(1024 * 1024), b""):
            digest.update(chunk)
    return digest.hexdigest()


def dinov3_source_manifest(root):
    """DINOv3 Python源码清单；权重文件不进入源码SHA。"""
    root = Path(root).resolve()
    if not (root / "dinov3" / "hub" / "backbones.py").is_file():
        raise FileNotFoundError(f"缺DINOv3源码目录: {root}")
    manifest = {
        path.relative_to(root).as_posix(): hashlib.sha256(path.read_bytes()).hexdigest()
        for path in sorted((root / "dinov3").rglob("*.py"))
        if ".git" not in path.relative_to(root).parts
    }
    if not manifest:
        raise ValueError("DINOv3源码清单为空")
    return manifest


def dinov3_source_sha256(root):
    raw = json.dumps(dinov3_source_manifest(root), sort_keys=True,
                     separators=(",", ":")).encode("utf-8")
    return hashlib.sha256(raw).hexdigest()


def _load_dinov3_backbone(repo_dir, variant):
    """按显式源码目录导入官方backbone；禁止跨目录或进程静默复用。"""
    global _DINOV3_SOURCE_OWNER
    if variant not in DINOV3_VARIANTS:
        raise ValueError(f"DINOv3 variant必须属于{tuple(DINOV3_VARIANTS)}")
    root = Path(repo_dir).resolve()
    if not (root / "dinov3" / "hub" / "backbones.py").is_file():
        raise FileNotFoundError(f"缺DINOv3源码目录: {root}")
    owner = str(root)
    if _DINOV3_SOURCE_OWNER is not None and _DINOV3_SOURCE_OWNER != owner:
        raise RuntimeError("一个进程只允许一个DINOv3源码目录")
    for module_name in ("dinov3", "dinov3.hub.backbones"):
        existing = sys.modules.get(module_name)
        if existing is not None and getattr(existing, "__file__", None):
            if root not in Path(existing.__file__).resolve().parents:
                raise RuntimeError("dinov3模块与当前源码目录冲突，请使用独立进程")
    if owner not in sys.path:
        sys.path.insert(0, owner)
    module = importlib.import_module("dinov3.hub.backbones")
    constructor = getattr(module, DINOV3_VARIANTS[variant][0])
    _DINOV3_SOURCE_OWNER = owner
    return constructor(pretrained=False)


class Dinov3VisionEncoder(nn.Module):
    """冻结或微调的DINOv3 ViT骨干，只输出CLS与patch token。

    输入必须与登记的input_size一致；输出形状由patch size和输入尺寸决定。
    权重只加载到本模块，不下发给文本、GRU或动作头。
    """

    def __init__(self, repo_dir, variant="vits16", input_size=224, frozen=True, weights=None):
        super().__init__()
        if variant not in DINOV3_VARIANTS:
            raise ValueError(f"DINOv3 variant必须属于{tuple(DINOV3_VARIANTS)}")
        if (isinstance(input_size, bool) or not isinstance(input_size, int)
                or input_size <= 0 or input_size % 16):
            raise ValueError("DINOv3 input_size必须是16的正整数倍")
        if not isinstance(frozen, bool):
            raise ValueError("DINOv3 frozen必须是布尔值")
        self.variant = variant
        self.input_size = input_size
        self.patch_size = 16
        self.grid_size = input_size // 16
        self.embed_dim = DINOV3_VARIANTS[variant][1]
        self.frozen = frozen
        self.repo_dir = str(Path(repo_dir).resolve())
        self.repo_source_sha256 = dinov3_source_sha256(self.repo_dir)
        self.model = _load_dinov3_backbone(self.repo_dir, variant)
        self.weights_sha256 = None
        if weights is not None:
            weights = Path(weights)
            if not weights.is_file():
                raise FileNotFoundError(f"DINOv3权重不存在: {weights}")
            digest = sha256_file(weights)
            state = torch.load(weights, map_location="cpu", mmap=True, weights_only=True)
            if not isinstance(state, dict):
                raise ValueError("DINOv3检查点必须是state_dict映射")
            self.model.load_state_dict(state, strict=True)
            self.weights_sha256 = digest
        if self.frozen:
            self.model.requires_grad_(False)
            self.model.eval()

    def train(self, mode=True):
        super().train(mode)
        if self.frozen:
            self.model.eval()
        return self

    def forward(self, image):
        if image.ndim != 4 or tuple(image.shape[-2:]) != (self.input_size, self.input_size):
            raise ValueError(f"DINOv3需要Nx3x{self.input_size}x{self.input_size}输入")
        output = self.model.forward(image, is_training=True)
        if (not isinstance(output, dict) or "x_norm_clstoken" not in output
                or "x_norm_patchtokens" not in output):
            raise RuntimeError("DINOv3 forward未返回CLS/patch token")
        cls, patches = output["x_norm_clstoken"], output["x_norm_patchtokens"]
        expected_patches = (len(image), self.grid_size * self.grid_size, self.embed_dim)
        expected_cls = (len(image), self.embed_dim)
        if tuple(patches.shape) != expected_patches or tuple(cls.shape) != expected_cls:
            raise RuntimeError(
                f"DINOv3输出形状异常: cls={tuple(cls.shape)} patch={tuple(patches.shape)}，"
                f"期望{expected_cls}/{expected_patches}")
        return cls, patches


class WaypointNet(nn.Module):
    """视觉 + 历史 + 指令的航点回归网络。

    输入 batch 各键的形状（由 data.collate 产生）：
        image:       (B, 3, imgsz, imgsz)  当前帧前视 RGB，值域 [0, 1]
        tokens:      (B, L)                指令词 id，0 为 <pad>
        token_mask:  (B, L)                True 表示真实词，False 表示 padding
        history:     (B, history_frames, 3) 机体坐标系下的历史航点，不足处左填 0
        history_length: (B,)               历史真实长度，0 表示这是轨迹第一帧
    输出：
        (B, 3)  机体坐标系下的下一步航点（方向 × 步长）
    """

    def __init__(self, vocab_size, history_frames=8, hidden=128, ablate="none", pretrained=True,
                 fusion_mode="text_context_only"):
        super().__init__()
        if fusion_mode not in FUSION_MODES:
            raise ValueError(f"fusion_mode={fusion_mode!r} 只能是 {FUSION_MODES}")
        self.fusion_mode = fusion_mode
        self.ablate = ablate
        self.hidden_size = hidden
        # 指令编码：词 id -> 50 维向量，padding_idx=0 使 <pad> 恒为零向量
        self.embed = nn.Embedding(vocab_size, 50, padding_idx=0)
        # 单层 LSTM 编码指令，输出 (B, L, hidden)，每个时间步保留隐状态
        self.instruction = nn.LSTM(50, hidden, batch_first=True)
        # ResNet-50 去掉 fc，保留 avgpool，输出 (B, 2048, 1, 1)。
        # 使用 ImageNet 预训练权重；各输入的实际贡献由对照实验检验。
        # 配套要求 collate 按 ImageNet 的 mean/std 归一化，两处必须一起改。
        weights = ResNet50_Weights.IMAGENET1K_V2
        backbone = resnet50(weights=None if not pretrained or ablate == "no_image" else weights)
        self.vision = nn.Sequential(*list(backbone.children())[:-1])
        self.vision_proj = nn.Linear(2048, hidden)   # 2048 -> hidden
        # 历史航点拍平后投影；末尾拼一列有效长度，否则"没有历史"和"历史点恰好在原点"张量一样
        self.history_proj = nn.Linear(history_frames * 3 + 1, hidden)
        self.history_frames = history_frames
        # query 由 [视觉; 历史] 拼接过线性层得到；(1, 2*hidden) -> hidden
        self.query = nn.Linear(hidden * 2, hidden)
        self.key = nn.Linear(hidden, hidden)        # 指令隐状态 -> key
        self.value = nn.Linear(hidden, hidden)      # 指令隐状态 -> value
        # 4 维回归头：raw[:, :3] 为方向，raw[:, 3:] 为步长
        self.head = nn.Linear(hidden, 4)

    def forward(self, batch):
        # 1) 指令：词嵌入 + LSTM，states 为 (B, L, hidden) 的逐词隐状态
        if self.ablate == "no_text":
            states = None
        else:
            tokens = self.embed(batch["tokens"])
            states, _ = self.instruction(tokens)
        # 2) 视觉：ResNet 全局特征展平并投影到 hidden
        # no_image 消融直接跳过骨干。喂零图不行：ResNet 的 BatchNorm 会在零图上把
        # running_var 累积向 0，验证时除以 sqrt(0+eps) 把特征放大几百倍，读出来的数没意义。
        if self.ablate == "no_image":
            visual = torch.zeros(
                batch["image"].shape[0], self.vision_proj.out_features,
                device=batch["image"].device, dtype=batch["history"].dtype,
            )
        else:
            image = self.vision(batch["image"]).flatten(1)
            visual = self.vision_proj(image)
        # 3) 历史：(B, history_frames, 3) + 有效长度 -> (B, hidden)
        fill = (batch["history_length"].to(batch["history"].dtype) / self.history_frames).unsqueeze(1)
        past = self.history_proj(torch.cat([batch["history"].flatten(1), fill], dim=-1))
        # 4) 拼接过路成 query，并在时间维插入一维以便与 states 做注意力
        query = self.query(torch.cat([visual, past], dim=-1)).unsqueeze(1)  # (B, 1, hidden)
        if self.ablate == "no_text":
            # 无文本消融直接使用视觉和历史 query，避免 token 数量、padding
            # 或 batch 内最大句长影响输出。
            context = query.squeeze(1)
        else:
            key = self.key(states)                                            # (B, L, hidden)
            # 5) 缩放点积注意力 (B, 1, hidden) @ (B, hidden, L) -> (B, 1, L)
            score = torch.matmul(query, key.transpose(1, 2)) / (key.shape[-1] ** 0.5)
            # padding 位置先置为最小值再做 softmax，避免注意力落到 <pad> 上
            score = score.masked_fill(~batch["token_mask"].unsqueeze(1), torch.finfo(score.dtype).min)
            weight = torch.softmax(score, dim=-1)
            # 加权求和 value 后去掉长度为 1 的时间维，得到 (B, hidden)
            context = torch.matmul(weight, self.value(states)).squeeze(1)
            if self.fusion_mode == "query_plus_text":
                # 恢复视觉/历史到动作头的直接通路，不增加参数。
                # no_text 分支已经使用 query，不能在该分支重复相加。
                context = query.squeeze(1) + context
        # 6) 回归头：切分方向与步长
        raw = self.head(context)                        # (B, 4)
        direction = raw[:, :3]
        # L2 归一化得到单位方向。下界取 1e-3 而非 1e-6：归一化雅可比含 1/‖r‖，
        # 下界太小会在反向把梯度放大上万倍，一次 NaN step 就毁掉整个 run。
        direction = direction / direction.norm(dim=-1, keepdim=True).clamp_min(1e-3)
        # softplus 保证步长为正，替代不可导的 abs/raw 截断
        length = torch.nn.functional.softplus(raw[:, 3:4])  # (B, 1)
        return direction * length


class GroundedWaypointNet(nn.Module):
    """版本化的文字查询视觉区域策略；全局对照仅替换区域聚合方式。

    stop_enabled=False 返回 (B, 3)，开启时返回位移与 (B,) 停止 logit。
    停止阈值与执行时机属于任务协议，不由本模块决定。
    """

    def __init__(self, vocab_size, history_frames=8, hidden=128, ablate="none",
                 pretrained=True, backbone="resnet18", visual_fusion="spatial",
                 grid_size=4, fusion_mode="query_plus_text", stop_enabled=False,
                 *, _vision_factory=None, _token_text=True):
        super().__init__()
        if backbone not in BACKBONES or visual_fusion not in FUSIONS:
            raise ValueError(f"backbone/visual_fusion 必须属于 {BACKBONES}/{FUSIONS}")
        if fusion_mode != "query_plus_text":
            raise ValueError("grounded_v1 仅接受 fusion_mode='query_plus_text'")
        if ablate not in ABLATIONS:
            raise ValueError(f"ablate 必须属于 {ABLATIONS}")
        for name, value in (("vocab_size", vocab_size), ("history_frames", history_frames),
                            ("hidden", hidden), ("grid_size", grid_size)):
            if isinstance(value, bool) or not isinstance(value, int) or value <= 0:
                raise ValueError(f"{name} 必须是正整数")
        if not isinstance(stop_enabled, bool):
            raise ValueError("stop_enabled 必须是布尔值")
        if not isinstance(_token_text, bool) or (_vision_factory is not None and not callable(_vision_factory)):
            raise ValueError("内部编码器构造选项非法")
        if _vision_factory is None and backbone in DINOV3_BACKBONES:
            raise ValueError("DINOv3 backbone必须由aerial_route_dino_v5构造")
        self.architecture = "grounded_v1"
        self.backbone = backbone
        self.visual_fusion = visual_fusion
        self.grid_size = grid_size
        self.hidden_size = hidden
        self.history_frames = history_frames
        self.ablate = ablate
        self.fusion_mode = fusion_mode
        self.stop_enabled = stop_enabled
        if _token_text:
            self.embed = nn.Embedding(vocab_size, 50, padding_idx=0)
            self.instruction = nn.LSTM(50, hidden, batch_first=True)
        if _vision_factory is None:
            if backbone == "resnet18":
                constructor, weights, channels = resnet18, ResNet18_Weights.IMAGENET1K_V1, 512
            else:
                constructor, weights, channels = resnet50, ResNet50_Weights.IMAGENET1K_V2, 2048
            network = constructor(weights=weights if pretrained and ablate != "no_image" else None)
            self.vision = nn.Sequential(*list(network.children())[:-2])
        else:
            self.vision, channels = _vision_factory()
            if not isinstance(self.vision, nn.Module) or type(channels) is not int or channels <= 0:
                raise ValueError("视觉构造器必须返回模块与正整数通道数")
        self.vision_proj = nn.Linear(channels, hidden)
        self.region_pool = nn.AdaptiveAvgPool2d((grid_size, grid_size))
        axis = torch.linspace(-1.0, 1.0, grid_size) if grid_size > 1 else torch.zeros(1)
        rows, columns = torch.meshgrid(axis, axis, indexing="ij")
        self.register_buffer("region_coordinates", torch.stack((columns, rows), dim=-1).reshape(1, -1, 2))
        self.position_proj = nn.Linear(2, hidden, bias=False)
        self.history_proj = nn.Linear(history_frames * 3 + 1, hidden)
        self.query = nn.Linear(hidden * 2, hidden)
        self.key = nn.Linear(hidden, hidden)
        self.value = nn.Linear(hidden, hidden)
        # 两种融合保留相同参数；global 对区域 value 均匀聚合，spatial 用文本查询。
        self.region_key = nn.Linear(hidden, hidden)
        self.region_value = nn.Linear(hidden, hidden)
        self.head = nn.Linear(hidden, 4)
        if stop_enabled:
            self.stop_head = nn.Linear(hidden, 1)

    def vision_summary(self, image):
        features = self.vision(image)
        return features.mean(dim=(-2, -1)), self.region_pool(features).flatten(2).transpose(1, 2)

    def _encode_observation(self, batch):
        if self.ablate == "no_image":
            visual = batch["history"].new_zeros((batch["image"].shape[0], self.hidden_size))
            regions = None
        else:
            if "vision_mean" in batch:
                pooled, regions = batch["vision_mean"], batch["vision_regions"]
            else:
                pooled, regions = self.vision_summary(batch["image"])
            visual = self.vision_proj(pooled)
            regions = self.vision_proj(regions) + self.position_proj(self.region_coordinates)
        history, history_length = batch["history"], batch["history_length"]
        if self.ablate == "no_history":
            history, history_length = torch.zeros_like(history), torch.zeros_like(history_length)
        fill = (history_length.to(history.dtype) / self.history_frames).unsqueeze(1)
        past = self.history_proj(torch.cat((history.flatten(1), fill), dim=-1))
        query = self.query(torch.cat((visual, past), dim=-1))
        return (query, *self._encode_text(batch), regions)

    def _encode_text(self, batch):
        if "clause_features" in batch or "clause_mask" in batch:
            raise ValueError("LSTM文本路径不接受CLIP子句特征")
        if self.ablate == "no_text":
            return None, batch.get("token_mask")
        states, _ = self.instruction(self.embed(batch["tokens"]))
        return states, batch.get("token_mask")

    def _fuse_observation(self, encoded, query_state=None):
        query, states, mask, regions = encoded
        if self.ablate == "no_text":
            context = torch.zeros_like(query)
            region_query = query
        else:
            if not mask.any(dim=1).all():
                raise ValueError("每个文本样本至少需要一个有效 token")
            attention_query = query
            if query_state is not None:
                if query_state.ndim == 3:
                    if query_state.shape[0] != 1:
                        raise ValueError("路线GRU查询状态必须是单层(1,B,hidden)")
                    query_state = query_state.squeeze(0)
                if query_state.shape != query.shape or not torch.isfinite(query_state).all():
                    raise ValueError("状态条件文本查询需要有限(B,hidden)路线状态")
                if not hasattr(self, "state_query"):
                    raise ValueError("当前模型未启用状态条件文本查询")
                # 状态只参与指令词注意力查询，不直接残差注入融合特征。
                attention_query = query + self.state_query(query_state)
            scores = torch.matmul(attention_query.unsqueeze(1), self.key(states).transpose(1, 2)) / self.hidden_size ** 0.5
            scores = scores.masked_fill(~mask.unsqueeze(1), torch.finfo(scores.dtype).min)
            context = torch.matmul(scores.softmax(dim=-1), self.value(states)).squeeze(1)
            region_query = context
        if regions is None:
            region_context = torch.zeros_like(query)
        elif self.visual_fusion == "global":
            region_context = self.region_value(regions).mean(dim=1)
        else:
            scores = torch.matmul(region_query.unsqueeze(1), self.region_key(regions).transpose(1, 2)) / self.hidden_size ** 0.5
            region_context = torch.matmul(scores.softmax(dim=-1), self.region_value(regions)).squeeze(1)
        return query + context + region_context

    def encode_fused(self, batch, query_state=None):
        return self._fuse_observation(self._encode_observation(batch), query_state=query_state)

    def forward(self, batch):
        fused = self.encode_fused(batch)
        raw = self.head(fused)
        direction = raw[:, :3] / raw[:, :3].norm(dim=-1, keepdim=True).clamp_min(1e-3)
        displacement = direction * torch.nn.functional.softplus(raw[:, 3:4])
        if self.stop_enabled:
            return {"body_displacement": displacement, "stop_logit": self.stop_head(fused).squeeze(-1)}
        return displacement


class AerialRouteNet(GroundedWaypointNet):
    """AerialVLN-S动作前状态预测八类动作；0为STOP，转向独立监督。"""

    def __init__(self, vocab_size, **kwargs):
        if kwargs.get("stop_enabled", True) is not True:
            raise ValueError("aerial_route_v1 的动作集合必须包含STOP")
        kwargs["stop_enabled"] = False
        super().__init__(vocab_size, **kwargs)
        self.architecture = "aerial_route_v1"
        self.stop_enabled = True
        self.history_proj = nn.Linear(self.history_frames * 8 + 1, self.hidden_size)
        self.head = nn.Linear(self.hidden_size, 8)

    def forward(self, batch):
        return self.head(self.encode_fused(batch))


class AerialRecurrentRouteNet(AerialRouteNet):
    """候选路线状态基线：连续合法观测进入小GRU，不读取真值路线进度。

    ``visual_history`` 保持原始查询语义；``state_conditioned_v1`` 只让上一
    步GRU状态参与指令词注意力查询，视觉/LSTM特征仍按chunk共享编码。
    """

    def __init__(self, vocab_size, memory_mode="carry", vision_train_policy="finetune",
                 text_query_mode="visual_history", **kwargs):
        if memory_mode not in ("carry", "reset_each_step"):
            raise ValueError("memory_mode只能为carry或reset_each_step")
        if vision_train_policy not in ("finetune", "frozen"):
            raise ValueError("vision_train_policy只能为finetune或frozen")
        if text_query_mode not in TEXT_QUERY_MODES:
            raise ValueError(f"text_query_mode只能为{TEXT_QUERY_MODES}")
        super().__init__(vocab_size, **kwargs)
        self.architecture = "aerial_route_recurrent_v2"
        self.memory_mode = memory_mode
        self.text_query_mode = text_query_mode
        self.vision_batchnorm_protocol = "frozen_running_stats_v1"
        self.vision_train_policy = vision_train_policy
        if vision_train_policy == "frozen":
            self.vision.requires_grad_(False)
        self.memory = nn.GRU(self.hidden_size, self.hidden_size, batch_first=True)
        if text_query_mode == "state_conditioned_v1":
            # 只为候选模型增加参数。旧默认模型不创建该层，旧checkpoint可严格加载。
            self.state_query = nn.Linear(self.hidden_size, self.hidden_size, bias=False)
            nn.init.zeros_(self.state_query.weight)
        self.train(self.training)

    def train(self, mode=True):
        super().train(mode)
        # 连续路线的T帧同时送视觉骨干；训练BN聚合会让早期特征看到未来帧。
        # 两组固定running统计；frozen组另冻结卷积及BN affine参数。
        for module in self.vision.modules():
            if isinstance(module, nn.modules.batchnorm._BatchNorm):
                module.eval()
        return self

    def _memory(self, fused, state, batch_size):
        if state is not None and (state.shape != (1, batch_size, self.hidden_size)
                                  or not torch.isfinite(state).all()):
            raise ValueError("路线GRU状态必须是有限(1,B,hidden)，跨episode由调用方清零")
        # 融合可用BF16；小循环状态用FP32避免混合精度GRU后端/隐藏状态不一致。
        with torch.autocast(device_type=fused.device.type, enabled=False):
            return self.memory(fused.float(), None if state is None else state.float())

    def forward_sequence(self, batch, state=None):
        """batch的首维T只允许同一episode的连续帧；调用方跨chunk detach状态。"""
        if self.text_query_mode == "state_conditioned_v1":
            encoded = self._encode_recurrent_observation(batch)
            outputs, following = [], state
            for index in range(len(batch["image"])):
                step_encoded = tuple(value[index:index + 1] if value is not None else None for value in encoded)
                if self.memory_mode == "reset_each_step":
                    following = None
                fused = self._fuse_recurrent_observation(step_encoded, following)
                output, following = self._memory(fused.unsqueeze(1), following, 1)
                logits = self.head(output.squeeze(1))
                outputs.append(logits)
            if not outputs:
                raise ValueError("路线序列不能为空")
            return torch.cat(outputs, dim=0), following
        fused = self.encode_fused(batch)
        if self.memory_mode == "reset_each_step":
            output, independent_states = self._memory(fused.unsqueeze(1), None, len(fused))
            return self.head(output.squeeze(1)), independent_states[:, -1:].contiguous()
        output, state = self._memory(fused.unsqueeze(0), state, 1)
        return self.head(output.squeeze(0)), state

    def forward_sequence_batch(self, batch, state, episodes, steps):
        """episode_batch_tbptt_v2：batch按(episode, step)行主序展平，状态为(1,E,hidden)。"""
        if self.text_query_mode != "visual_history" or self.memory_mode != "carry":
            raise ValueError("多episode并行仅支持visual_history与carry记忆")
        fused = self.encode_fused(batch)
        if fused.shape[0] != episodes * steps:
            raise ValueError("多episode批次帧数与(episodes, steps)不一致")
        output, state = self._memory(fused.reshape(episodes, steps, -1), state, episodes)
        return self.head(output).reshape(episodes * steps, 8), state

    def forward_step(self, batch, state=None):
        if self.memory_mode == "reset_each_step":
            state = None
        if self.text_query_mode == "state_conditioned_v1":
            encoded = self._encode_recurrent_observation(batch)
            fused = self._fuse_recurrent_observation(encoded, state)
        else:
            fused = self.encode_fused(batch)
        output, state = self._memory(fused.unsqueeze(1), state, len(fused))
        return self.head(output.squeeze(1)), state

    def _encode_recurrent_observation(self, batch):
        return self._encode_observation(batch)

    def _fuse_recurrent_observation(self, encoded, state):
        return self._fuse_observation(encoded, query_state=state)

    def forward(self, batch):
        logits, _ = self.forward_step(batch)
        return logits


class AerialDinoRouteNet(AerialRecurrentRouteNet):
    """v5候选：DINOv3密集视觉token，保留v2的文本、区域注意力、GRU与八动作头。"""

    def __init__(self, vocab_size, dino_repo, dino_variant="vits16", dino_input_size=224,
                 dino_frozen=True, dino_weights=None, **kwargs):
        if kwargs.get("text_query_mode", "visual_history") != "visual_history":
            raise ValueError("v5只支持visual_history文本查询")
        if not isinstance(dino_frozen, bool):
            raise ValueError("dino_frozen必须是布尔值")
        if dino_variant not in DINOV3_VARIANTS:
            raise ValueError(f"DINOv3 variant必须属于{tuple(DINOV3_VARIANTS)}")
        if type(dino_input_size) is not int or dino_input_size <= 0 or dino_input_size % 16:
            raise ValueError("DINOv3 input_size必须是16的正整数倍")
        backbone, grid = f"dinov3_{dino_variant}", dino_input_size // 16
        if kwargs.get("backbone", backbone) != backbone or kwargs.get("grid_size", grid) != grid:
            raise ValueError("DINOv3 backbone/grid_size必须与variant/input_size一致")
        kwargs.update(backbone=backbone, grid_size=grid)
        kwargs["vision_train_policy"] = "frozen" if dino_frozen else "finetune"

        def create_vision():
            encoder = Dinov3VisionEncoder(
                dino_repo, variant=dino_variant, input_size=dino_input_size,
                frozen=dino_frozen, weights=dino_weights)
            return encoder, encoder.embed_dim

        super().__init__(vocab_size, _vision_factory=create_vision, **kwargs)
        self.architecture = "aerial_route_dino_v5"
        self.vision_batchnorm_protocol = "dinov3_layernorm_v1"
        self.visual_encoder = {
            "version": "dinov3_backbone_v1",
            "variant": dino_variant,
            "input_size": dino_input_size,
            "patch_size": 16,
            "embed_dim": self.vision.embed_dim,
            "grid_size": grid,
            "frozen": dino_frozen,
            "token_protocol": "cls_plus_patch_tokens_v1",
            "weights_sha256": self.vision.weights_sha256,
            "repo_source_sha256": self.vision.repo_source_sha256,
        }

    def vision_summary(self, image):
        # 父类负责vision_proj与区域位置编码，避免重复投影。
        return self.vision(image)

    def _encode_observation(self, batch):
        if "vision_mean" in batch or "vision_regions" in batch:
            raise ValueError("DINOv3不接受R18视觉特征缓存，必须编码当前图像")
        return super()._encode_observation(batch)


class AerialClauseRouteNet(AerialRecurrentRouteNet):
    """v3候选：冻结CLIP子句特征 + 只用过去信息的子句软指针。

    指针先验 = 上一步指针分布向前平移一格的混合（只读历史），观测只重新加权，
    目标真值、未来帧、教师动作不进入。文本特征由调用方离线缓存并随batch传入。
    """

    def __init__(self, vocab_size, clause_dim=512, window=2, **kwargs):
        if kwargs.get("text_query_mode", "visual_history") != "visual_history":
            raise ValueError("v3子句模型只支持visual_history文本查询")
        kwargs["text_query_mode"] = "visual_history"
        super().__init__(vocab_size, _token_text=False, **kwargs)
        self.architecture = "aerial_route_recurrent_clause_v3"
        self.clause_dim = clause_dim
        self.window = window
        self.clause_proj = nn.Linear(clause_dim, self.hidden_size)
        self.pointer_query = nn.Linear(self.hidden_size * 2, self.hidden_size)
        self.advance = nn.Linear(self.hidden_size, 1)

    def _encode_text(self, batch):
        return self.clause_proj(batch["clause_features"]), batch["clause_mask"]

    def _fuse_clauses(self, encoded, pointer):
        query, states, mask, regions = encoded
        if not mask.any(dim=1).all():
            raise ValueError("每个样本至少需要一个子句")
        count = states.shape[1]
        if pointer is None:
            pointer = torch.zeros(query.shape[0], count, device=query.device, dtype=query.dtype)
            pointer[:, 0] = 1.
        advance = torch.sigmoid(self.advance(query))
        shifted = torch.cat((torch.zeros_like(pointer[:, :1]), pointer[:, :-1]), dim=1)
        prior = (1 - advance) * pointer + advance * shifted
        prior = prior.masked_fill(~mask, 0.)
        scores = torch.matmul(self.pointer_query(torch.cat((query, states.mean(1)), dim=-1)).unsqueeze(1),
                              states.transpose(1, 2)).squeeze(1) / self.hidden_size ** 0.5
        scores = scores.masked_fill(~mask, torch.finfo(scores.dtype).min)
        posterior = (prior.clamp_min(1e-6).log() + scores).softmax(dim=-1) * mask
        posterior = posterior / posterior.sum(dim=-1, keepdim=True).clamp_min(1e-6)
        positions = torch.arange(count, device=query.device).unsqueeze(0)
        center = (posterior * positions).sum(-1, keepdim=True)
        window = ((positions - center).abs() <= self.window).to(query.dtype) * mask.to(query.dtype)
        weights = posterior * window
        weights = weights / weights.sum(dim=-1, keepdim=True).clamp_min(1e-6)
        context = torch.matmul(weights.unsqueeze(1), self.value(states)).squeeze(1)
        region_query = context
        if regions is None:
            region_context = torch.zeros_like(query)
        elif self.visual_fusion == "global":
            region_context = self.region_value(regions).mean(dim=1)
        else:
            region_scores = torch.matmul(region_query.unsqueeze(1), self.region_key(regions).transpose(1, 2)) / self.hidden_size ** 0.5
            region_context = torch.matmul(region_scores.softmax(dim=-1), self.region_value(regions)).squeeze(1)
        return query + context + region_context, posterior

    def forward_sequence(self, batch, state=None):
        encoded = self._encode_observation(batch)
        hidden, pointer = (None, None) if state is None else state
        outputs = []
        for index in range(encoded[0].shape[0]):
            step = tuple(value[index:index + 1] if value is not None else None for value in encoded)
            fused, pointer = self._fuse_clauses(step, pointer)
            output, hidden = self._memory(fused.unsqueeze(1), hidden, 1)
            outputs.append(self.head(output.squeeze(1)))
        return torch.cat(outputs, dim=0), (hidden, pointer)

    def forward_step(self, batch, state=None):
        hidden, pointer = (None, None) if state is None else state
        fused, pointer = self._fuse_clauses(self._encode_observation(batch), pointer)
        output, hidden = self._memory(fused.unsqueeze(1), hidden, len(fused))
        return self.head(output.squeeze(1)), (hidden, pointer)


class AerialRGBDRecurrentRouteNet(AerialRecurrentRouteNet):
    """v2单因素深度候选：归一化深度卷积后加到融合输入，保留128维GRU。"""

    def __init__(self, vocab_size, **kwargs):
        super().__init__(vocab_size, **kwargs)
        self.architecture = "aerial_route_recurrent_rgbd_v3"
        self.depth_encoder = nn.Sequential(
            nn.Conv2d(1, 32, 5, stride=4, padding=2), nn.ReLU(),
            nn.Conv2d(32, 64, 3, stride=2, padding=1), nn.ReLU(),
            nn.Conv2d(64, 128, 3, stride=2, padding=1), nn.ReLU(),
            nn.AdaptiveAvgPool2d(1), nn.Flatten(), nn.Linear(128, self.hidden_size))

    def _encode_recurrent_observation(self, batch):
        encoded = super()._encode_recurrent_observation(batch)
        depth = validate_depth_batch(batch)
        return (*encoded, self.depth_encoder(depth))

    def _fuse_recurrent_observation(self, encoded, state):
        *base, depth_fused = encoded
        return super()._fuse_recurrent_observation(tuple(base), state) + depth_fused

    def encode_fused(self, batch, query_state=None):
        depth = validate_depth_batch(batch)
        fused = super().encode_fused(batch, query_state=query_state)
        return fused if self.ablate == "no_image" else fused + self.depth_encoder(depth)


def validate_depth_batch(batch):
    depth = batch.get("depth")
    if (not isinstance(depth, torch.Tensor) or not depth.is_floating_point()
            or depth.shape != (len(batch["image"]), 1, 256, 256)
            or not torch.isfinite(depth).all() or ((depth < 0) | (depth > 1)).any()):
        raise ValueError("RGB-D需要有限Nx1x256x256浮点深度，值域[0,1]")
    return depth


_AIRVLN_PROCESS_OWNER = None


def airvln_source_sha256(root):
    """完整上游Python来源清单；不修改上游、不以mtime替代内容核验。"""
    root = Path(root).resolve()
    if not (root / "Model/policy.py").is_file():
        raise FileNotFoundError(f"缺AirVLN原版源码: {root}")
    return {path.relative_to(root).as_posix(): hashlib.sha256(path.read_bytes()).hexdigest()
            for path in sorted(root.rglob("*.py")) if ".git" not in path.relative_to(root).parts}


def _airvln_policy(vocab_size, config, pretrained):
    """原版网络导入适配。参数/BN/输入差异必须保存在checkpoint合同中。"""
    global _AIRVLN_PROCESS_OWNER
    for key in ("upstream_root", "upstream_project_prefix", "upstream_log_dir"):
        if not isinstance(config.get(key), (str, Path)) or not str(config[key]).strip():
            raise ValueError(f"AirVLN适配缺少显式路径: {key}")
    root = Path(config["upstream_root"]).resolve()
    project = Path(config["upstream_project_prefix"]).resolve()
    log_dir = Path(config["upstream_log_dir"]).resolve()
    if log_dir == root or root in log_dir.parents:
        raise ValueError("AirVLN适配日志必须位于上游源码目录之外")
    sources = airvln_source_sha256(root)
    if sources != config.get("upstream_source_sha256"):
        raise ValueError("AirVLN源码集合或SHA256与冻结清单不一致")
    checkpoint = project / "DATA/models/ddppo-models/gibson-2plus-resnet50.pth"
    if not checkpoint.is_file():
        raise FileNotFoundError(f"原版网络构造需要真实DDPPO预训练权重: {checkpoint}")
    if hashlib.sha256(checkpoint.read_bytes()).hexdigest() != config.get("ddppo_checkpoint_sha256"):
        raise ValueError("DDPPO预训练权重SHA256不一致")
    if not callable(getattr(torch.serialization, "safe_globals", None)):
        raise RuntimeError("AirVLN资产安全加载要求PyTorch支持torch.serialization.safe_globals，拒绝不安全回退")
    policy_type = "seq2seq" if config["architecture"] in ("airvln_seq2seq_rgb_v1", "airvln_seq2seq_rgbd_v1") else "cma"
    rgbd = config["architecture"] in AIRVLN_RGBD_ARCHITECTURES
    owner = (str(root), policy_type, rgbd)
    if _AIRVLN_PROCESS_OWNER is not None and _AIRVLN_PROCESS_OWNER != owner:
        raise RuntimeError("上游使用全局args，一个进程仅允许一个AirVLN源码目录和策略类型")
    existing = sys.modules.get("src.common.param")
    if existing is not None and Path(existing.__file__).resolve() != root / "src/common/param.py":
        raise RuntimeError("src.common.param与AirVLN上游导入冲突，请使用独立进程")
    for name in ("Model", "utils", "src"):
        existing = sys.modules.get(name)
        if existing is not None and getattr(existing, "__file__", None):
            if root not in Path(existing.__file__).resolve().parents:
                raise RuntimeError(f"{name}与AirVLN上游导入冲突，请使用独立进程")
    old_argv = sys.argv
    old_path = sys.path[:]
    try:
        sys.path.insert(0, str(root))
        sys.argv = [str(root / "src/common/param.py"), "--project_prefix", str(project),
                    "--policy_type", policy_type]
        params = importlib.import_module("src.common.param")
        args = params.args
        args.policy_type, args.vocab_size = policy_type, vocab_size
        args.tokenizer_use_bert = args.rgb_encoder_use_place365 = False
        args.ablate_instruction = args.ablate_rgb = False
        args.ablate_depth = not rgbd
        args.SEQ2SEQ_use_prev_action = True
        args.PROGRESS_MONITOR_use = False
        args.project_prefix = str(project)
        args.logger_file_name = str(log_dir / "upstream.log")
        from gym import spaces
        module = importlib.import_module(f"Model.{policy_type}_policy")
        constructor = getattr(module, "Seq2SeqPolicy" if policy_type == "seq2seq" else "CMAPolicy")
        observation_space = spaces.Dict({
            "rgb": spaces.Box(0, 255, shape=(224, 224, 3), dtype=np.uint8),
            "depth": spaces.Box(0., 1., shape=(256, 256, 1), dtype=np.float32),
            "instruction": spaces.Box(0, vocab_size - 1, shape=(300,), dtype=np.int64)})
        # checkpoint重载无需下载RGB初值；真正训练保留原版ImageNetV1初始化。
        import torchvision.models as models
        original_resnet50 = models.resnet50
        context = nullcontext() if pretrained else patch.object(
            models, "resnet50", side_effect=lambda *a, **kw: original_resnet50(weights=None))
        # 官方DDPPO包含标准Namespace元信息；保留现代PyTorch的weights_only安全加载。
        with context, torch.serialization.safe_globals([argparse.Namespace]):
            policy = constructor(observation_space, spaces.Discrete(8), device=torch.device("cpu"))
        _AIRVLN_PROCESS_OWNER = owner
        return policy
    except ImportError as error:
        raise RuntimeError(f"AirVLN原版网络依赖缺失，拒绝替换为近似网络: {error}") from error
    finally:
        sys.argv = old_argv
        sys.path[:] = old_path


class AirVLNRGBAdapter(nn.Module):
    """直接调用原版Seq2Seq/CMA；同RGB权限、因果BN及本项目词表的显式适配。"""

    def __init__(self, vocab_size, config, pretrained=False):
        super().__init__()
        if config.get("hidden", 512) != 512 or config.get("memory_mode", "carry") != "carry":
            raise ValueError("原版AirVLN网络要求hidden=512及memory_mode=carry")
        if config.get("ablate", "none") != "none" or config.get("imgsz", 224) != 224:
            raise ValueError("AirVLN RGB基线仅支持完整语言/RGB和224像素输入")
        if config.get("vision_train_policy", "frozen") != "frozen":
            raise ValueError("原版AirVLN RGB骨干参数必须冻结")
        self.architecture = config["architecture"]
        self.input_modality = "rgbd" if self.architecture in AIRVLN_RGBD_ARCHITECTURES else "rgb"
        self.hidden_size, self.history_frames, self.memory_mode = 512, config.get("history_frames", 8), "carry"
        self.backbone = "resnet50"
        seq2seq = self.architecture in ("airvln_seq2seq_rgb_v1", "airvln_seq2seq_rgbd_v1")
        self.visual_fusion = "global" if seq2seq else "spatial"
        self.recurrent_state_layers = 1 if seq2seq else 2
        self.vision_train_policy, self.vision_batchnorm_protocol = "frozen", "causal_fixed_bn_v1"
        self.policy = _airvln_policy(vocab_size, config, pretrained)
        if any(parameter.requires_grad for parameter in self.vision.parameters()):
            raise ValueError("AirVLN冻结合同要求上游RGB CNN参数已冻结，不能静默微调或冻结投影")
        self.upstream_metadata = {
            "baseline_protocol": "official_network_matched_training_adapter_v1",
            "memory_protocol": "airvln_recurrent_gru_v1",
            "network_source": "direct_official_policy_import_v1",
            "raw_rgb_adapter": "imagenet_denormalize_round_uint8_v1",
            "token_adapter": "project_route_numeric_vocab_full_instruction_v1",
            "depth_policy": ("official_ablate_depth_false_normalized_nhwc_v1" if self.input_modality == "rgbd"
                             else "official_ablate_depth_true_environment_depth_retained_v1"),
            "visual_bn": self.vision_batchnorm_protocol,
            "prev_action_protocol": "last_executed_action_or_start_zero_v1",
            "rnn_mask_protocol": "bool_valid_prefix_v1",
            "progress_monitor": False, "rgb_pretraining": "imagenet1k_v1",
            "recurrent_state_layers": self.recurrent_state_layers,
            "memory_layers": self.recurrent_state_layers, "memory_hidden_size": 512,
        }
        self.train(self.training)

    @property
    def vision(self):
        return self.policy.net.rgb_encoder.cnn

    def train(self, mode=True):
        super().train(mode)
        if hasattr(self, "policy"):
            self.vision.eval()
            if self.input_modality == "rgbd":
                self.policy.net.depth_encoder.visual_encoder.eval()
        return self

    def _observations(self, batch):
        image = batch["image"].float()
        if image.ndim != 4 or image.shape[1:] != (3, 224, 224) or not torch.isfinite(image).all():
            raise ValueError("AirVLN RGB适配需要有限Nx3x224x224归一化输入")
        mean = image.new_tensor([.485, .456, .406]).view(1, 3, 1, 1)
        std = image.new_tensor([.229, .224, .225]).view(1, 3, 1, 1)
        rgb = ((image * std + mean) * 255).round().clamp(0, 255).permute(0, 2, 3, 1).contiguous()
        tokens, mask = batch["tokens"], batch["token_mask"]
        if not mask.any(dim=1).all() or not torch.equal(mask, tokens != 0):
            raise ValueError("AirVLN指令需要非空、右padding且token_mask与PAD0一致")
        if (mask[:, 1:] & ~mask[:, :-1]).any():
            raise ValueError("AirVLN packed指令不允许内部padding")
        history = batch["history"]
        if (history.ndim != 3 or history.shape[2] != 8 or history.shape[1] != self.history_frames
                or history.shape[0] != len(image) or not torch.isfinite(history).all()):
            raise ValueError("AirVLN历史必须为本项目Nxhistory_framesx8动作onehot")
        lengths = batch["history_length"]
        if (lengths.shape != (len(image),) or lengths.dtype not in (torch.int32, torch.int64)
                or ((lengths < 0) | (lengths > self.history_frames)).any()):
            raise ValueError("AirVLN历史有效长度越界")
        valid = torch.arange(self.history_frames, device=history.device).unsqueeze(0) >= (self.history_frames-lengths).unsqueeze(1)
        if ((history != 0) & (history != 1)).any() or not torch.equal(history.sum(dim=2), valid.to(history.dtype)):
            raise ValueError("AirVLN历史需要真实onehot动作及左侧零padding")
        previous = history[:, -1].argmax(dim=-1).reshape(-1, 1)
        masks = (lengths > 0).reshape(-1, 1)
        observations = {"rgb": rgb, "instruction": tokens}
        if self.input_modality == "rgbd":
            observations["depth"] = validate_depth_batch(batch).float().permute(0, 2, 3, 1).contiguous()
        return observations, previous, masks

    def _forward(self, batch, state, batch_size):
        observations, previous, masks = self._observations(batch)
        # 原版保存了不随Module.to迁移的device属性，按真实输入设备更新。
        self.policy.net.device = batch["image"].device
        self.policy.net.rgb_encoder.device = batch["image"].device
        if state is None:
            state = batch["image"].new_zeros((self.recurrent_state_layers, batch_size, 512), dtype=torch.float32)
        if state.shape != (self.recurrent_state_layers, batch_size, 512) or not torch.isfinite(state).all():
            raise ValueError("AirVLN记忆必须为有限(L,B,512)，跨episode清零")
        # 原版双GRU、注意力及输入保持FP32；避免与原版状态赋值的autocast dtype冲突。
        with torch.autocast(device_type=batch["image"].device.type, enabled=False):
            features, next_state = self.policy.net(observations, state.permute(1, 0, 2).contiguous().float(),
                                                   previous, masks)
            logits = self.policy.action_distribution.linear(features)
        return logits, next_state.permute(1, 0, 2).contiguous()

    def forward_sequence(self, batch, state=None):
        return self._forward(batch, state, 1)

    def forward_step(self, batch, state=None):
        return self._forward(batch, state, len(batch["image"]))

    def forward(self, batch):
        return self.forward_step(batch)[0]


def validate_encoder_configuration(config):
    """只校验架构与编码器配置互斥，不访问源码、权重或缓存路径。"""
    architecture = config.get("architecture", "legacy_waypoint_v1")
    dino = architecture in DINOV3_ARCHITECTURES
    clause = architecture == "aerial_route_recurrent_clause_v3"
    if not dino:
        unexpected = [key for key, value in config.items()
                      if value is not None and (key == "visual_encoder" or key.startswith("dino_"))]
        if unexpected or config.get("backbone") in DINOV3_BACKBONES:
            raise ValueError("DINOv3编码器配置仅属于aerial_route_dino_v5")
    else:
        visual = config.get("visual_encoder")
        variant = config.get("dino_variant", "vits16")
        if isinstance(visual, dict):
            variant = visual.get("variant", variant)
            for outer, inner, expected_type in (("dino_variant", "variant", str),
                                                 ("dino_input_size", "input_size", int),
                                                 ("dino_frozen", "frozen", bool)):
                requested = config.get(outer)
                if requested is not None and (type(requested) is not expected_type
                                               or requested != visual.get(inner)):
                    raise ValueError(f"{outer}必须与visual_encoder.{inner}一致")
        if "backbone" in config and config["backbone"] != f"dinov3_{variant}":
            raise ValueError("DINOv3 backbone必须与variant一致")
        if config.get("vision_feature_cache") is not None:
            raise ValueError("DINOv3不支持R18视觉特征缓存")
    if not clause and any(config.get(key) is not None for key in ("text_encoder", "clause_dim", "text_feature_cache")):
        raise ValueError("CLIP子句编码器配置仅属于aerial_route_recurrent_clause_v3")
    if clause and config.get("text_query_mode", "visual_history") != "visual_history":
        raise ValueError("v3子句模型只支持visual_history文本查询")


def build_model(vocab_size, config, pretrained=False):
    """缺 architecture 只表示历史结构；未知或不支持的组合直接拒绝。"""
    architecture = config.get("architecture", "legacy_waypoint_v1")
    if architecture not in ARCHITECTURES:
        raise ValueError(f"architecture 必须属于 {ARCHITECTURES}")
    validate_encoder_configuration(config)
    text_query_mode = config.get("text_query_mode", "visual_history")
    if text_query_mode not in TEXT_QUERY_MODES:
        raise ValueError(f"text_query_mode必须属于{TEXT_QUERY_MODES}")
    if architecture != "aerial_route_recurrent_v2" and text_query_mode != "visual_history":
        raise ValueError("状态条件文本查询仅支持aerial_route_recurrent_v2")
    if architecture in AIRVLN_ARCHITECTURES:
        return AirVLNRGBAdapter(vocab_size, config, pretrained)
    if architecture in DINOV3_ARCHITECTURES:
        visual = config.get("visual_encoder")
        if not isinstance(visual, dict):
            raise ValueError("v5需要visual_encoder映射")
        variant = visual.get("variant")
        if variant not in DINOV3_VARIANTS:
            raise ValueError(f"v5 DINOv3 variant必须属于{tuple(DINOV3_VARIANTS)}")
        input_size = visual.get("input_size")
        if (type(input_size) is not int or input_size <= 0 or input_size % 16
                or input_size != config.get("imgsz", input_size)):
            raise ValueError("v5 visual_encoder.input_size必须等于imgsz且为16的正整数倍")
        frozen = visual.get("frozen")
        if not isinstance(frozen, bool):
            raise ValueError("v5 visual_encoder.frozen必须是布尔值")
        if visual.get("patch_size") != 16 or visual.get("embed_dim") != DINOV3_VARIANTS[variant][1]:
            raise ValueError("v5 DINOv3 patch size或embed dim与variant不一致")
        if visual.get("grid_size") != input_size // 16:
            raise ValueError("v5 DINOv3 grid_size与input_size不一致")
        if config.get("visual_fusion", "spatial") != "spatial" or config.get("fusion_mode") != "query_plus_text":
            raise ValueError("v5只支持spatial区域注意力和query_plus_text融合")
        repo_dir = os.environ.get("UAVNAV_DINO_REPO") or visual.get("repo_dir")
        if not isinstance(repo_dir, (str, Path)) or not str(repo_dir).strip():
            raise ValueError("v5需要DINOv3源码目录")
        ablate = config.get("ablate", "none")
        if ablate not in ABLATIONS:
            raise ValueError(f"ablate 必须属于 {ABLATIONS}")
        return AerialDinoRouteNet(
            vocab_size, dino_repo=repo_dir, dino_variant=variant,
            dino_input_size=input_size, dino_frozen=frozen,
            dino_weights=config.get("dino_weights") if pretrained else None,
            history_frames=config.get("history_frames", 8), hidden=config.get("hidden", 128),
            ablate=ablate, pretrained=False, memory_mode=config.get("memory_mode", "carry"),
            vision_train_policy="frozen" if frozen else "finetune",
            text_query_mode="visual_history", backbone=f"dinov3_{variant}",
            visual_fusion="spatial", grid_size=input_size // 16,
            fusion_mode="query_plus_text", stop_enabled=True)
    if config.get("backbone") in DINOV3_BACKBONES:
        raise ValueError("DINOv3 backbone只支持aerial_route_dino_v5")
    ablate = config.get("ablate", "none")
    if ablate not in ABLATIONS:
        raise ValueError(f"ablate 必须属于 {ABLATIONS}")
    common = {"history_frames": config.get("history_frames", 8),
              "hidden": config.get("hidden", 128), "ablate": ablate, "pretrained": pretrained}
    if architecture in ("aerial_route_recurrent_v2", "aerial_route_recurrent_rgbd_v3", "aerial_route_recurrent_clause_v3"):
        common["memory_mode"] = config.get("memory_mode", "carry")
        common["vision_train_policy"] = config.get("vision_train_policy", "finetune")
        common["text_query_mode"] = config.get("text_query_mode", "visual_history")
        if architecture != "aerial_route_recurrent_v2" and common["text_query_mode"] != "visual_history":
            raise ValueError("状态条件文本查询仅支持轻量RGB循环路线模型")
    elif config.get("memory_mode") is not None:
        raise ValueError("memory_mode只属于aerial_route_recurrent_v2，旧架构不接受")
    if architecture not in ("aerial_route_recurrent_v2", "aerial_route_recurrent_rgbd_v3", "aerial_route_recurrent_clause_v3") and config.get("vision_train_policy", "finetune") != "finetune":
        raise ValueError("视觉训练模式frozen只支持aerial_route_recurrent_v2")
    if architecture == "legacy_waypoint_v1":
        if (config.get("backbone", "resnet50") != "resnet50"
                or config.get("visual_fusion", "global") != "global"
                or config.get("stop_enabled", False) is not False):
            raise ValueError("legacy_waypoint_v1 仅支持 resnet50/global 且没有 STOP 头")
        return WaypointNet(vocab_size, **common,
                           fusion_mode=config.get("fusion_mode", "text_context_only"))
    constructors = {"grounded_v1": GroundedWaypointNet, "aerial_route_v1": AerialRouteNet,
                    "aerial_route_recurrent_v2": AerialRecurrentRouteNet,
                    "aerial_route_recurrent_clause_v3": AerialClauseRouteNet,
                    "aerial_route_recurrent_rgbd_v3": AerialRGBDRecurrentRouteNet}
    constructor = constructors[architecture]
    if architecture == "aerial_route_recurrent_clause_v3":
        common["clause_dim"] = config.get("clause_dim", 512)
    return constructor(vocab_size, **common,
                              backbone=config.get("backbone", "resnet18"),
                              visual_fusion=config.get("visual_fusion", "spatial"),
                              grid_size=config.get("grid_size", 4),
                              fusion_mode=config.get("fusion_mode", "query_plus_text"),
                              stop_enabled=config.get("stop_enabled", architecture in ("aerial_route_v1", "aerial_route_recurrent_v2", "aerial_route_recurrent_rgbd_v3")))
