"""路线八动作模仿学习与历史航点回归；导航指标等待独立闭环证据。"""

import csv
import contextlib
import functools
import hashlib
import json
import math
import os
import random
import platform
import time
from collections import Counter
from pathlib import Path

import numpy as np
import torch
import yaml
from torch.utils.data import DataLoader
from tqdm import tqdm

from uavnav.avln.closed_loop import write_metrics
from uavnav.avln.data import (
    FOV_FRAME_GAP, SAMPLE_POLICY, Vocab, attach_vision_features, build_vision_feature_cache, collate,
    group_aerial_episodes, iter_samples, load_instructions, load_list, load_vision_feature_cache,
    attach_text_features, build_text_feature_cache, load_text_feature_cache,
)
from uavnav.avln.model import (DINOV3_VARIANTS, FUSION_MODES, TEXT_QUERY_MODES, build_model,
                               dinov3_source_sha256, sha256_file, validate_encoder_configuration)
from uavnav.avln.metadata import validate_task_protocol, task_protocol_sha256

# 消融开关，按名字取反/置零输入。名字必须说清消掉的是什么：
# no_image 去视觉、no_history 去惯性外推、no_text 去指令。
ABLATIONS = ("none", "no_image", "no_history", "no_text", "constant_text")
AIRVLN_BASELINES = ("airvln_seq2seq_rgb_v1", "airvln_cma_rgb_v1",
                    "airvln_seq2seq_rgbd_v1", "airvln_cma_rgbd_v1")
RGBD_ARCHITECTURES = ("aerial_route_recurrent_rgbd_v3", "airvln_seq2seq_rgbd_v1", "airvln_cma_rgbd_v1")


def validate_training_controls(hparams):
    """所有入口的运行边界；环境变量不能代替用户授权改变单seed约束。"""
    validate_encoder_configuration(hparams)
    architecture = hparams.get("architecture", "aerial_route_v1")
    if not hparams.get("vision_feature_cache") and hparams.get("vision_feature_cache_dtype", "float32") != "float32":
        raise ValueError("未启用vision_feature_cache，不能设置无效的缓存精度")
    if hparams.get("vision_feature_cache") and (
            architecture not in ("aerial_route_recurrent_v2", "aerial_route_recurrent_clause_v3")
            or hparams.get("vision_train_policy", "finetune") != "frozen"
            or hparams.get("ablate", "none") == "no_image" or hparams.get("render_pass_manifests")):
        raise ValueError("vision_feature_cache仅支持冻结视觉的RGB单pass v2/v3，不接受DINO或其他视觉编码器缓存")
    if architecture == "aerial_route_recurrent_clause_v3":
        if hparams.get("text_control", "original") != "original":
            raise ValueError("v3子句模型仅支持original文本，constant不会替换子句特征")
        if hparams.get("ablate", "none") == "no_text":
            raise ValueError("v3子句模型不支持no_text消融，避免静默保留子句特征")
        if (hparams.get("vision_train_policy", "finetune") != "frozen"
                or not hparams.get("vision_feature_cache") or not hparams.get("text_feature_cache")):
            raise ValueError("v3需要冻结视觉、视觉特征缓存及text_feature_cache")
    if type(hparams.get("seed", 0)) is not int or hparams.get("seed", 0) != 0:
        raise ValueError("当前实验仅支持seed=0，不接受多seed环境开关")
    candidates = hparams.get("candidate_epochs", [])
    if (not isinstance(candidates, list) or any(type(e) is not int or not 1 <= e <= hparams.get("epochs", 20)
                                              for e in candidates)
            or candidates != sorted(set(candidates))):
        raise ValueError("candidate_epochs必须是训练开始前冻结的升序不重复epoch列表，且位于训练范围内")
    interval = hparams.get("diagnostics_interval", 128)
    if type(interval) is not int or interval < 0:
        raise ValueError("diagnostics_interval必须为非负整数；0关闭低频分支梯度记录")
    if hparams.get("validation_split", "development_train_grouped") == "val_unseen":
        raise ValueError("val_unseen只用于冻结权重后的独立评测，禁止每epoch选模")
    stage = hparams.get("stage", "bc")
    if stage not in ("bc", "dagger"):
        raise ValueError("stage只支持bc/dagger")
    resume, warm = hparams.get("resume_checkpoint"), hparams.get("warm_start_checkpoint")
    if resume and warm:
        raise ValueError("resume与warm_start不能同时使用")
    manifests = hparams.get("dagger_manifests", [])
    if not isinstance(manifests, list) or any(not isinstance(p, (str, Path)) or not str(p) for p in manifests):
        raise ValueError("dagger_manifests必须为路径列表")
    if stage == "dagger" and (not manifests or not (warm or resume)):
        raise ValueError("DAgger必须显式提供偏轨清单和BC暖启动，不能静默执行BC")
    if stage == "bc" and manifests:
        raise ValueError("BC阶段不能混入未声明的DAgger样本")
    if type(hparams.get("require_full_train", False)) is not bool:
        raise ValueError("require_full_train必须为布尔值")
    if resume and hparams.get("architecture", "aerial_route_v1") == "aerial_route_v1":
        raise ValueError("训练恢复仅支持完整episode循环策略")


def _atomic_checkpoint(payload, path):
    """同盘原子替换，读者只会看到完整checkpoint。"""
    path = Path(path)
    temporary = path.with_name(path.name + ".pending")
    try:
        torch.save(payload, temporary)
        with temporary.open("r+b") as stream:
            os.fsync(stream.fileno())
        os.replace(temporary, path)
    finally:
        temporary.unlink(missing_ok=True)


def _rng_state(device):
    state = np.random.get_state()
    return {"python": random.getstate(), "numpy": [state[0], state[1].tolist(), *state[2:]],
            "torch": torch.get_rng_state(), "cuda": torch.cuda.get_rng_state_all() if device.type == "cuda" else []}


def _save_epoch_candidate(checkpoint, run_dir, candidate_epochs, updates):
    """仅登记验证完成的epoch末权重；候选不改变教师best的选模语义。"""
    epoch = checkpoint["epoch"]
    if epoch not in candidate_epochs:
        return
    path = run_dir / "weights" / f"epoch_{epoch:03d}.pt"
    if path.exists():
        existing = torch.load(path, map_location="cpu", weights_only=True)
        if (existing.get("epoch") != epoch or existing.get("val_loss") != checkpoint["val_loss"]
                or existing.get("model_config") != checkpoint["model_config"]
                or existing.get("vocab") != checkpoint["vocab"]
                or existing.get("length_scale") != checkpoint["length_scale"]
                or existing["model"].keys() != checkpoint["model"].keys()
                or any(not torch.equal(existing["model"][k].cpu(), v.cpu()) for k, v in checkpoint["model"].items())):
            raise ValueError("已存在epoch候选与提交权重不同，拒绝覆盖")
    else:
        _atomic_checkpoint({key: checkpoint[key] for key in ("model", "vocab", "epoch", "val_loss", "length_scale", "model_config")}, path)
    inventory_path = run_dir / "candidate_inventory.json"
    inventory = {"version": "epoch_end_teacher_candidates_v1", "candidate_epochs": candidate_epochs,
                 "split_manifest_sha256": checkpoint["model_config"]["split_manifest_sha256"],
                 "navigation_selection": None, "candidates": []}
    if inventory_path.exists():
        recorded = json.loads(inventory_path.read_text(encoding="utf-8"))
        if any(recorded.get(k) != inventory[k] for k in ("version", "candidate_epochs", "split_manifest_sha256")):
            raise ValueError("候选清单合同改变")
        inventory = recorded
        for entry in inventory["candidates"]:
            expected_path = f"weights/epoch_{entry['epoch']:03d}.pt"
            if entry["path"] != expected_path or sha256_file(run_dir / expected_path) != entry["sha256"]:
                raise ValueError("候选权重摘要改变")
    if {entry["epoch"] for entry in inventory["candidates"] if entry["epoch"] < epoch} != {e for e in candidate_epochs if e < epoch}:
        raise ValueError("已提交的早期候选登记缺失，拒绝伪造完整候选清单")
    entry = {"epoch": epoch, "optimizer_updates_total": updates, "path": path.relative_to(run_dir).as_posix(),
             "sha256": sha256_file(path), "unweighted_teacher_validation_ce": checkpoint["val_loss"]}
    previous = next((e for e in inventory["candidates"] if e["epoch"] == epoch), None)
    if previous is not None and previous != entry:
        raise ValueError("候选登记与原记录不同")
    if previous is None:
        inventory["candidates"].append(entry)
        inventory["candidates"].sort(key=lambda e: e["epoch"])
    temporary = inventory_path.with_suffix(".json.pending")
    try:
        temporary.write_text(json.dumps(inventory, ensure_ascii=False, indent=2) + "\n", encoding="utf-8")
        os.replace(temporary, inventory_path)
    finally:
        temporary.unlink(missing_ok=True)


def _training_runtime(device):
    import torchvision
    return {"python": platform.python_version(), "torch": str(torch.__version__),
            "torchvision": str(torchvision.__version__), "cuda": torch.version.cuda,
            "cudnn": torch.backends.cudnn.version(), "device": str(device),
            "device_name": torch.cuda.get_device_name(device) if device.type == "cuda" else platform.processor(),
            "cudnn_benchmark": torch.backends.cudnn.benchmark,
            "cudnn_deterministic": torch.backends.cudnn.deterministic,
            "deterministic_algorithms": torch.are_deterministic_algorithms_enabled(),
            "matmul_precision": torch.get_float32_matmul_precision(),
            "cuda_matmul_allow_tf32": torch.backends.cuda.matmul.allow_tf32,
            "cudnn_allow_tf32": torch.backends.cudnn.allow_tf32}


def _gradient_observation(model):
    """低频采样裁剪前分支范数；不修改梯度或插入影响forward的hook。"""
    groups = {"vision_proj": [], "text": [], "history": [], "query": [], "GRU": [], "head": []}
    for name, parameter in model.named_parameters():
        if parameter.grad is None:
            continue
        root = name.split(".")[0]
        group = ("text" if root in ("embed", "instruction", "key", "value") else
                 "history" if root == "history_proj" else "GRU" if root == "memory" else root)
        if group in groups:
            groups[group].append(parameter.grad.detach().float().norm().square())
    return {key: float(torch.stack(values).sum().sqrt()) if values else None for key, values in groups.items()}


def _restore_rng(state):
    random.setstate(state["python"])
    name, values, pos, gaussian, cached = state["numpy"]
    np.random.set_state((name, np.asarray(values, dtype=np.uint32), pos, gaussian, cached))
    torch.set_rng_state(state["torch"])
    if state["cuda"]:
        torch.cuda.set_rng_state_all(state["cuda"])


def _resume_request(hparams):
    ignored = {"resume_checkpoint", "warm_start_checkpoint"}
    def normalize(value):
        if isinstance(value, Path):
            return str(value)
        if isinstance(value, dict):
            return {key: normalize(item) for key, item in value.items()}
        if isinstance(value, (tuple, list)):
            return [normalize(item) for item in value]
        return value
    return {key: normalize(value) for key, value in hparams.items() if key not in ignored}


def _committed_logs(run_dir):
    return {name: (run_dir / name).read_bytes() if (run_dir / name).is_file() else None
            for name in ("results.csv", "render_pass_selections.jsonl", "action_confusion.json", "training_diagnostics.jsonl")}


def _restore_committed_logs(run_dir, saved, epoch):
    """只回滚中断追加的尾部；已提交的日志前缀变化会被拒绝。"""
    data = saved.get("results.csv")
    if data is None:
        raise ValueError("恢复checkpoint缺少已提交CSV")
    import io
    rows = list(csv.DictReader(io.StringIO(data.decode("utf-8"))))
    if [int(row["epoch"]) for row in rows] != list(range(1, epoch + 1)):
        raise ValueError("恢复CSV的已提交epoch不完整")
    ledger = saved.get("render_pass_selections.jsonl")
    if ledger is not None and [json.loads(line)["epoch"] for line in ledger.splitlines()] != list(range(1, epoch + 1)):
        raise ValueError("恢复pass ledger的epoch不完整")
    diagnostics = run_dir / "training_diagnostics.jsonl"
    preserve_uncommitted_diagnostics = False
    if "training_diagnostics.jsonl" not in saved and diagnostics.exists():
        rows = [json.loads(line) for line in diagnostics.read_text(encoding="utf-8").splitlines()]
        if any(type(row.get("epoch")) is not int or row["epoch"] <= epoch for row in rows):
            raise ValueError("旧checkpoint无诊断日志快照，现有内容无法认证为未提交尾部")
        # 旧格式没有该日志基线，保留中断产物后从空日志继续，不能重复append。
        preserve_uncommitted_diagnostics = True
    for name, content in saved.items():
        path = run_dir / name
        if content is None:
            if path.exists():
                raise ValueError(f"恢复出现未经提交日志: {name}")
            continue
        if not path.is_file() or (name != "action_confusion.json" and not path.read_bytes().startswith(content)):
            raise ValueError(f"恢复日志已提交内容损坏: {name}")
        if name == "action_confusion.json" and path.read_bytes() != content:
            actual_epoch = json.loads(path.read_text(encoding="utf-8")).get("epoch")
            if type(actual_epoch) is not int or actual_epoch != epoch + 1:
                raise ValueError("恢复混淆矩阵不是下一未提交epoch的统计")
    if preserve_uncommitted_diagnostics:
        diagnostics.rename(diagnostics.with_name(f"training_diagnostics_uncommitted_{time.time_ns()}.jsonl"))
    for name, content in saved.items():
        if content is not None:
            (run_dir / name).write_bytes(content)


def _apply_ablation(batch, ablate):
    # no_image 由模型内部绕过骨干（WaypointNet.forward），不在这里置零图像：
    # 零图会让 BatchNorm 的 running_var 塌向 0，验证时把特征放大几百倍。
    if ablate == "no_history":
        batch["history"] = torch.zeros_like(batch["history"])
        batch["history_length"] = torch.zeros_like(batch["history_length"])
    elif ablate == "no_text":
        batch["tokens"] = torch.zeros_like(batch["tokens"])
        batch["token_mask"] = torch.zeros_like(batch["token_mask"])


def _unit(vector):
    return vector / vector.norm(dim=-1, keepdim=True).clamp_min(1e-6)


def waypoint_parts(prediction, target):
    """方向用余弦距离，步长用 L1。分开算才知道模型是把方向学错了还是把距离学短了。"""
    angle = (1 - (_unit(prediction) * _unit(target)).sum(-1)).mean()
    length = (prediction.norm(dim=-1) - target.norm(dim=-1)).abs().mean()
    return angle, length


def prediction_loss(prediction, batch, length_scale, stop_loss_weight=1.0):
    """未知停止标签不参与损失；无运动标签同时屏蔽方向和步长。"""
    displacement = prediction["body_displacement"] if isinstance(prediction, dict) else prediction
    displacement = displacement.float()
    valid = batch.get("motion_valid", torch.ones(len(displacement), device=displacement.device, dtype=torch.bool))
    if valid.any():
        angle, length = waypoint_parts(displacement[valid], batch["offset"][valid])
    else:
        angle = length = displacement.sum() * 0
    stop = displacement.sum() * 0
    if isinstance(prediction, dict):
        mask = batch.get("stop_valid")
        if mask is None:
            raise ValueError("STOP输出缺少可信停止标签mask")
        if mask.any():
            stop = torch.nn.functional.binary_cross_entropy_with_logits(
                prediction["stop_logit"].float()[mask], batch["stop_target"].float()[mask])
    loss = angle + length / length_scale + stop_loss_weight * stop
    return loss, angle, length


def split_by_trajectory(samples, val_ratio, seed):
    """按轨迹切，绝不按帧切。相邻帧共享同一条指令和 7/8 的历史，随机切会让验证指标虚高。"""
    traj_ids = sorted({sample["traj_id"] for sample in samples})
    rng = random.Random(seed)
    rng.shuffle(traj_ids)
    val_ids = set(traj_ids[: int(len(traj_ids) * val_ratio)])
    train = [s for s in samples if s["traj_id"] not in val_ids]
    val = [s for s in samples if s["traj_id"] in val_ids]
    return train, val, len(traj_ids)


def split_from_manifest(samples, manifest, expected):
    """复用既有轨迹划分，来源或样本集合变化时拒绝继续对照。"""
    if not isinstance(manifest, dict):
        raise ValueError("split_manifest 必须是 JSON 对象")
    for key, value in expected.items():
        if manifest.get(key) != value:
            raise ValueError(f"split_manifest.{key} 与当前数据/设置不一致")
    groups = []
    for key in ("train_trajectory_ids", "validation_trajectory_ids"):
        ids = manifest.get(key)
        if not isinstance(ids, list) or not ids or any(not isinstance(item, str) for item in ids):
            raise ValueError(f"split_manifest.{key} 必须是非空轨迹 ID 列表")
        if len(ids) != len(set(ids)):
            raise ValueError(f"split_manifest.{key} 有重复 ID")
        groups.append(set(ids))
    train_ids, val_ids = groups
    actual_ids = {sample["traj_id"] for sample in samples}
    if train_ids & val_ids or train_ids | val_ids != actual_ids:
        raise ValueError("split_manifest 划分重叠，或与当前有效轨迹集合不一致")
    train = [sample for sample in samples if sample["traj_id"] in train_ids]
    val = [sample for sample in samples if sample["traj_id"] in val_ids]
    for key, count in (("train_samples", len(train)), ("validation_samples", len(val)),
                       ("eligible_trajectories", len(actual_ids))):
        if manifest.get(key) != count:
            raise ValueError(f"split_manifest.{key} 与当前样本数量不一致")
    return train, val, len(actual_ids)


def _checkpoint(model, vocab, epoch, val_loss, length_scale, model_config):
    # best.pt 和 last.pt 存同一套字段：少一个字段，下游推理就少一样能自证的东西。
    return {
        "model": model.state_dict(),
        "vocab": vocab.words,
        "epoch": epoch,
        "val_loss": val_loss,
        "length_scale": length_scale,
        "model_config": model_config,
    }


def _json_sha256(value):
    return hashlib.sha256(json.dumps(value, ensure_ascii=False, sort_keys=True, separators=(",", ":"),
                                     allow_nan=False).encode("utf-8")).hexdigest()


def sample_content_sha256(samples):
    """冻结实际输入、监督和文件内容，不只冻结轨迹数量。"""
    file_hashes = {}
    # Keep the historical canonical JSON list bytes while holding one row at a
    # time: full splits repeat provenance/history over a million sample states.
    digest = hashlib.sha256(b"[")
    first = True
    for sample in samples:
        row = {}
        for key, value in sample.items():
            if isinstance(value, Path):
                path = value.resolve()
                row[key] = str(path)
                if path not in file_hashes:
                    file_hashes[path] = hashlib.sha256(path.read_bytes()).hexdigest()
                row[f"{key}_content_sha256"] = file_hashes[path]
                if key == "image" and "image_sha256" in sample and file_hashes[path] != sample["image_sha256"]:
                    raise ValueError("真实渲染图像在reader核验后发生变化，与缓存源摘要不一致")
            elif isinstance(value, np.ndarray):
                row[key] = value.tolist()
            else:
                row[key] = value
        image = sample.get("image")
        if image is not None and "action" not in sample:
            trajectory = Path(image).parent.parent
            # 原FOV的监督和历史来自日志；绑定整条已用轨迹日志可发现未采样状态的变化。
            key = (trajectory, "logs")
            if key not in file_hashes:
                logs = [[path.name, hashlib.sha256(path.read_bytes()).hexdigest()]
                        for path in sorted((trajectory / "log").glob("*.json"))]
                file_hashes[key] = _json_sha256(logs)
            row["trajectory_logs_sha256"] = file_hashes[key]
        if not first:
            digest.update(b",")
        digest.update(json.dumps(row, ensure_ascii=False, sort_keys=True,
                                 separators=(",", ":"), allow_nan=False).encode("utf-8"))
        first = False
    digest.update(b"]")
    return digest.hexdigest()


def initial_state_sha256(state):
    """Bind initial tensor values, names, shapes and dtypes for paired experiments."""
    digest = hashlib.sha256()
    for name, tensor in sorted(state.items()):
        header = _json_sha256({"name": name, "dtype": str(tensor.dtype), "shape": list(tensor.shape)})
        digest.update(header.encode("ascii"))
        values = tensor.detach().cpu().contiguous().reshape(-1).view(torch.uint8)
        digest.update(values.numpy().tobytes())
    return digest.hexdigest()


def _snapshot_sources(run_dir, upstream_root=None, upstream_source_sha256=None,
                      dinov3_root=None, dinov3_source_sha256_value=None):
    root = Path(__file__).resolve().parents[2]
    files = [root / "train.py", *sorted((root / "uavnav").rglob("*.py")),
             root / "scripts" / "audit_training.py", root / "scripts" / "verify_stage2.py"]
    manifest = {}
    for source in files:
        target = run_dir / "source_snapshot" / source.relative_to(root)
        target.parent.mkdir(parents=True, exist_ok=True)
        content = source.read_bytes()
        target.write_bytes(content)
        manifest[source.relative_to(root).as_posix()] = hashlib.sha256(content).hexdigest()
    if upstream_root is not None:
        upstream_root = Path(upstream_root).resolve()
        actual = {source.relative_to(upstream_root).as_posix(): hashlib.sha256(source.read_bytes()).hexdigest()
                  for source in sorted(upstream_root.rglob("*.py")) if ".git" not in source.relative_to(upstream_root).parts}
        if not actual or actual != upstream_source_sha256:
            raise ValueError("上游源码内容与冻结来源清单不一致")
        for relative, digest in actual.items():
            target = run_dir / "source_snapshot" / "upstream" / "AirVLN" / relative
            target.parent.mkdir(parents=True, exist_ok=True)
            content = (upstream_root / relative).read_bytes()
            if hashlib.sha256(content).hexdigest() != digest:
                raise ValueError("上游源码在快照复制前改变")
            target.write_bytes(content)
            manifest[f"upstream/AirVLN/{relative}"] = digest
    if dinov3_root is not None:
        from uavnav.avln.model import dinov3_source_manifest, dinov3_source_sha256 as _dinov3_digest
        dinov3_root = Path(dinov3_root).resolve()
        actual = dinov3_source_manifest(dinov3_root)
        if not actual or _dinov3_digest(dinov3_root) != dinov3_source_sha256_value:
            raise ValueError("DINOv3源码内容与冻结来源清单不一致")
        for relative, digest in actual.items():
            target = run_dir / "source_snapshot" / "upstream" / "DINOv3" / relative
            target.parent.mkdir(parents=True, exist_ok=True)
            content = (dinov3_root / relative).read_bytes()
            if hashlib.sha256(content).hexdigest() != digest:
                raise ValueError("DINOv3源码在快照复制前改变")
            target.write_bytes(content)
            manifest[f"upstream/DINOv3/{relative}"] = digest
    (run_dir / "source_manifest.json").write_text(json.dumps(manifest, indent=2) + "\n", encoding="utf-8")


def load_aerial_training_partitions(annotation_root, cache_path, validation_cache, pass_paths, history_frames,
                                    validation_split, development_fraction=.2, development_split_seed=0,
                                    development_split_manifest=None, require_depth=False, index_mode="off", index_dir=None):
    """训练来源的几何开发拆分显式启用；旧官方验证读取和样本内容保持原义。"""
    from uavnav.avln.data import (load_aerial_render_passes, load_aerial_samples,
                                 split_aerial_route_groups, select_aerial_route_partition)
    if validation_split != "development_train_grouped":
        if validation_split not in ("val_seen", "val_unseen") or development_split_manifest is not None:
            raise ValueError("独立开发名单只能用于development_train_grouped，旧验证只支持官方带标签split")
        return (load_aerial_render_passes(annotation_root, "train", pass_paths, history_frames, require_depth=require_depth,
                                          index_mode=index_mode, index_dir=index_dir),
                load_aerial_samples(annotation_root, validation_split, validation_cache, history_frames, require_depth=require_depth,
                                    index_mode=index_mode, index_dir=index_dir),
                None, validation_split)
    passes = load_aerial_render_passes(annotation_root, "train", pass_paths, history_frames,
                                      include_route_metadata=True, require_depth=require_depth,
                                      index_mode=index_mode, index_dir=index_dir)
    if development_split_manifest is None:
        _, _, route_split = split_aerial_route_groups(passes[0], development_fraction, development_split_seed)
    else:
        route_split = json.loads(Path(development_split_manifest).read_text(encoding="utf-8"))
        route_split = route_split.get("development_route_split", route_split)
        if (route_split.get("dev_fraction") != development_fraction
                or route_split.get("split_seed") != development_split_seed):
            raise ValueError("复用开发名单的比例/seed与显式配置不一致")
    selected = [select_aerial_route_partition(samples, route_split, "train") for samples in passes]
    validation = load_aerial_samples(annotation_root, "train", validation_cache, history_frames,
                                    include_route_metadata=True, require_depth=require_depth,
                                    index_mode=index_mode, index_dir=index_dir)
    validation = select_aerial_route_partition(validation, route_split, "dev")
    sessions = {sample.get("capture_session_id") for samples in selected for sample in samples}
    dev_sessions = {sample.get("capture_session_id") for sample in validation}
    if (None in sessions or None in dev_sessions or sessions & dev_sessions):
        raise ValueError("新开发模式需要可核验且独立的训练/开发采集session，不用同渲染冒独立启动")
    return selected, validation, route_split, "train"


def load_training_dagger_groups(annotation_root, manifests, history_frames, allowed_episode_ids, require_depth=False):
    """聚合偏轨状态只来自冻结训练成员，开发路线不能通过DAgger回流。"""
    from uavnav.avln.data import load_aerial_dagger_samples, group_aerial_dagger_episodes
    groups, records, identities, paths = [], [], set(), set()
    for value in manifests:
        path = Path(value).resolve()
        if path in paths:
            raise ValueError("DAgger清单路径重复")
        paths.add(path)
        samples = load_aerial_dagger_samples(annotation_root, path, history_frames, require_depth=require_depth)
        if any(f"{row['scene_id']}/{row['source_episode_id']}" not in allowed_episode_ids for row in samples):
            raise ValueError("DAgger源episode不在冻结BC训练成员，禁止开发/验证路线回流")
        selected = group_aerial_dagger_episodes(samples, history_frames)
        for episode in selected:
            identity = (episode[0]["scene_id"], str(episode[0]["episode_id"]))
            if identity in identities:
                raise ValueError("DAgger重复采集episode，不能计为新增训练数据")
            identities.add(identity)
        digest = hashlib.sha256(path.read_bytes()).hexdigest()
        if any(row["cache_manifest_sha256"] != digest for row in samples):
            raise ValueError("DAgger清单在reader核验后改变")
        records.append({"source": str(path), "manifest_sha256": digest,
                        "sample_content_sha256": sample_content_sha256(samples),
                        "episodes": len(selected), "samples": len(samples)})
        groups.extend(selected)
    return groups, records


def aerial_child_source_records(paths, validation_cache):
    """绑定多场景索引引用的每个真实缓存清单，不将顶层SHA冒充子清单审核。"""
    from uavnav.avln.data import aerial_cache_index_children
    records = []
    sources = [(f"train_pass_{index:03d}", Path(path)) for index, path in enumerate(paths)]
    sources.append(("validation", Path(validation_cache)))
    for role, parent in sources:
        for index, child in enumerate(aerial_cache_index_children(parent)):
            records.append({"role": role, "source": str(child.resolve()),
                            "manifest_sha256": hashlib.sha256(child.read_bytes()).hexdigest(),
                            "snapshot": f"cache_source_manifests/{role}/shard_{index:03d}.json"})
    return records


@contextlib.contextmanager
def _aerial_run_lock(run_dir):
    """OS释放进程锁；同run拒绝双写，独立run继续并行。锁文件保留避免inode竞争。"""
    run_dir = Path(run_dir).resolve()
    directory = run_dir.parent / ".training_locks"
    directory.mkdir(parents=True, exist_ok=True)
    identity = hashlib.sha256(os.path.normcase(str(run_dir)).encode("utf-8")).hexdigest()
    with (directory / f"{identity}.lock").open("a+b") as stream:
        stream.seek(0, 2)
        if stream.tell() == 0:
            stream.write(b"0")
            stream.flush()
        stream.seek(0)
        if os.name == "nt":
            import msvcrt
            acquire = lambda: msvcrt.locking(stream.fileno(), msvcrt.LK_NBLCK, 1)
            release = lambda: msvcrt.locking(stream.fileno(), msvcrt.LK_UNLCK, 1)
        else:
            import fcntl
            acquire = lambda: fcntl.flock(stream.fileno(), fcntl.LOCK_EX | fcntl.LOCK_NB)
            release = lambda: fcntl.flock(stream.fileno(), fcntl.LOCK_UN)
        try:
            acquire()
        except OSError as error:
            raise RuntimeError("同一训练run正在执行，拒绝并发写权重/日志；并行实验使用独立name") from error
        try:
            yield
        finally:
            stream.seek(0)
            release()


def fit_aerial(**hparams):
    validate_training_controls(hparams)
    with _aerial_run_lock(_run_dir(hparams["project"], hparams["name"])):
        return _fit_aerial_locked(**hparams)


def _fit_aerial_locked(**hparams):
    """用真实渲染缓存进行八动作BC；局部缓存仅用于集成，不生成导航成绩。"""
    validate_training_controls(hparams)
    requested_hparams = _resume_request(hparams)
    # 特性加入前的旧v2训练状态没有text_query_mode，旧调用按默认视觉/历史查询续训。
    requested_hparams.setdefault("text_query_mode", "visual_history")
    requested_hparams.setdefault("candidate_epochs", [])
    requested_hparams.setdefault("diagnostics_interval", 128)
    candidate_epochs = hparams.get("candidate_epochs", [])
    diagnostics_interval = hparams.get("diagnostics_interval", 128)
    stage = hparams.get("stage", "bc")
    resume_path = Path(hparams["resume_checkpoint"]).resolve() if hparams.get("resume_checkpoint") else None
    resume = torch.load(resume_path, map_location="cpu", weights_only=True) if resume_path else None
    warm_path = Path(hparams["warm_start_checkpoint"]).resolve() if hparams.get("warm_start_checkpoint") else None
    warm_sha = hashlib.sha256(warm_path.read_bytes()).hexdigest() if warm_path else None
    warm = torch.load(warm_path, map_location="cpu", weights_only=True) if warm_path else None
    if warm_path and hashlib.sha256(warm_path.read_bytes()).hexdigest() != warm_sha:
        raise ValueError("暖启动checkpoint读取期间改变，拒绝不确定来源")
    if resume or warm:
        from uavnav.avln.inference import _validate_checkpoint
        _validate_checkpoint(resume or warm)
        starting_config = (resume or warm)["model_config"]
        if type(starting_config.get("seed")) is int and starting_config["seed"] == 0:
            pass
        elif warm and "seed" not in starting_config:
            source_hparams = warm_path.parent.parent / "hparams.yaml"
            recorded = yaml.safe_load(source_hparams.read_text(encoding="utf-8")) if source_hparams.is_file() else None
            if (not isinstance(recorded, dict) or type(recorded.get("seed")) is not int
                    or recorded["seed"] != 0 or recorded.get("model_config") != starting_config):
                raise ValueError("旧暖启动checkpoint缺seed；需要同run hparams认证seed0，不能假设")
        else:
            raise ValueError("暖启动/恢复checkpoint必须证明seed=0")
    from uavnav.avln.data import load_aerial_samples, load_aerial_episodes, load_aerial_render_passes
    from uavnav.avln.metadata import aerial_task_protocol
    for module in ("matplotlib", "yaml", "tqdm", "PIL"):
        __import__(module)
    architecture = hparams.get("architecture", "aerial_route_v1")
    if architecture not in ("aerial_route_v1", "aerial_route_recurrent_v2", "aerial_route_recurrent_clause_v3", "aerial_route_dino_v5", *RGBD_ARCHITECTURES, *AIRVLN_BASELINES):
        raise ValueError("fit_aerial需要显式版本化路线架构")
    baseline = architecture in AIRVLN_BASELINES
    require_depth = architecture in RGBD_ARCHITECTURES
    recurrent = architecture != "aerial_route_v1"
    vision_train_policy = hparams.get("vision_train_policy", "finetune")
    extra_passes = hparams.get("render_pass_manifests", [])
    if (vision_train_policy not in ("finetune", "frozen") or not isinstance(extra_passes, list)
            or any(not isinstance(path, (str, Path)) or not str(path).strip() for path in extra_passes)):
        raise ValueError("视觉训练模式或额外render pass清单格式错误")
    if not recurrent and (vision_train_policy != "finetune" or extra_passes):
        raise ValueError("完全冻结和多pass训练仅支持路线v2")
    render_pass_seed = hparams.get("render_pass_seed", 0)
    if type(render_pass_seed) is not int:
        raise ValueError("render_pass_seed必须是独立随机源的整数seed")
    memory_mode = hparams.get("memory_mode", "carry") if recurrent else None
    if recurrent and memory_mode not in ("carry", "reset_each_step"):
        raise ValueError("v2 memory_mode仅支持carry/reset_each_step")
    if not recurrent and hparams.get("memory_mode") is not None:
        raise ValueError("旧v1没有循环记忆，不能设置memory_mode")
    text_control = hparams.get("text_control", "original")
    if text_control not in ("original", "constant") or (text_control != "original" and not recurrent):
        raise ValueError("v2文本控制仅支持original/constant；v1保留原文本协议")
    if architecture == "aerial_route_recurrent_clause_v3":
        if text_control != "original":
            raise ValueError("v3子句模型仅支持original文本，constant不会替换子句特征")
        if hparams.get("ablate", "none") == "no_text":
            raise ValueError("v3子句模型不支持no_text消融，避免静默保留子句特征")
    text_query_mode = hparams.get("text_query_mode", "visual_history")
    if text_query_mode not in TEXT_QUERY_MODES:
        raise ValueError(f"text_query_mode必须属于{TEXT_QUERY_MODES}")
    if architecture not in ("aerial_route_recurrent_v2", "aerial_route_recurrent_clause_v3") and text_query_mode != "visual_history":
        raise ValueError("状态条件文本查询仅支持轻量循环路线模型")
    if baseline and (vision_train_policy != "frozen" or extra_passes or memory_mode != "carry"
                     or text_control != "original" or hparams.get("ablate", "none") != "none"
                     or hparams.get("backbone", "resnet50") != "resnet50"
                     or hparams.get("hidden", 512) != 512 or hparams.get("pretrained", True) is not True
                     or hparams.get("imgsz", 224) != 224):
        raise ValueError("官方RGB网络对照固定冻结预训练ResNet50、512维carry记忆、原指令和单pass")
    if baseline:
        for field in ("upstream_root", "upstream_project_prefix", "upstream_log_dir"):
            if not isinstance(hparams.get(field), str) or not hparams[field].strip():
                raise ValueError(f"官方网络训练必须提供{field}")
        if not isinstance(hparams.get("upstream_source_sha256"), dict) or not hparams["upstream_source_sha256"]:
            raise ValueError("官方网络训练必须提供全部上游.py的来源SHA清单")
        digest = hparams.get("ddppo_checkpoint_sha256")
        if not isinstance(digest, str) or len(digest) != 64 or any(char not in "0123456789abcdef" for char in digest):
            raise ValueError("官方网络训练必须提供真实DDPPO资产SHA")
    chunk_size = int(hparams.get("sequence_chunk_size", 16))
    if chunk_size <= 0:
        raise ValueError("sequence_chunk_size 必须是正整数")
    episode_batch = hparams.get("episode_batch")
    if episode_batch is not None and (type(episode_batch) is not int or episode_batch <= 0 or architecture != "aerial_route_recurrent_v2"
                                      or memory_mode != "carry" or text_query_mode != "visual_history"
                                      or text_control != "original" or extra_passes):
        raise ValueError("episode_batch仅支持aerial_route_recurrent_v2的carry/原文本/单pass路径")
    if episode_batch is not None and float(hparams.get("history_dropout", 0.)) > 0:
        raise ValueError("episode_batch路径不支持history_dropout，避免配置被静默忽略")
    loss_protocol = validate_aerial_loss_protocol(hparams.get("loss_protocol", {
        "version": "transition_weighted_ce_v1", "inflection_weight": 1.9,
        "stop_weight": 1.9, "normalization": "sum_weights",
    })) if recurrent else None
    tokenizer_version = "route_numeric_v1" if recurrent else "fov_numeric_v1"
    seed = int(hparams.get("seed", 0))
    random.seed(seed)
    np.random.seed(seed)
    torch.manual_seed(seed)
    torch.cuda.manual_seed_all(seed)
    device = torch.device(hparams.get("device", "cuda"))
    if device.type == "cuda" and not torch.cuda.is_available():
        raise RuntimeError("AerialVLN-S训练要求CUDA，但当前无可用GPU，拒绝回退CPU")
    epochs, batch_size = int(hparams["epochs"]), int(hparams["batch"])
    workers, history_frames, imgsz = int(hparams["workers"]), int(hparams["history"]), int(hparams["imgsz"])
    lr = float(hparams["lr"])
    history_dropout = float(hparams.get("history_dropout", 0.))
    if (epochs <= 0 or batch_size <= 0 or workers < 0 or history_frames <= 0 or imgsz <= 0
            or not math.isfinite(lr) or lr <= 0):
        raise ValueError("epochs/batch/history/imgsz/lr需为正数，workers不能为负")
    dino_repo = dino_weights = dino_variant = None
    if architecture == "aerial_route_dino_v5":
        if vision_train_policy != "frozen":
            raise ValueError("v5首版只支持冻结DINOv3，视觉微调需另立版本")
        if imgsz not in (224, 320):
            raise ValueError("v5首版输入只支持224或320")
        dino_repo = hparams.get("dino_repo")
        dino_weights = hparams.get("dino_weights")
        dino_variant = hparams.get("dino_variant", "vits16")
        if not isinstance(dino_repo, (str, Path)) or not Path(dino_repo).is_dir():
            raise ValueError("v5需要存在的DINOv3源码目录")
        if not isinstance(dino_weights, (str, Path)) or not Path(dino_weights).is_file():
            raise ValueError("v5需要存在的DINOv3预训练权重")
        if dino_variant not in ("vits16", "vits16plus", "vitb16", "vitl16"):
            raise ValueError("未知DINOv3 variant")
        if hparams.get("grid_size") not in (None, imgsz // 16):
            raise ValueError("v5 grid_size必须由输入尺寸和patch16推导")
        if hparams.get("vision_feature_cache"):
            raise ValueError("v5不做R18特征缓存，DINOv3 patch token在线计算")
        if hparams.get("pretrained", True) is not True:
            raise ValueError("v5必须先加载DINOv3预训练权重，禁止随机初始化视觉骨干")
        if hparams.get("dino_frozen", True) is not True:
            raise ValueError("v5首版只支持冻结DINOv3，dino_frozen必须为True")
        if hparams.get("dino_input_size", imgsz) != imgsz:
            raise ValueError("v5 dino_input_size必须等于imgsz")
    if recurrent and workers != 0 and not hparams.get("episode_batch"):
        raise ValueError("当前v2按单episode连续分块读取，workers必须为0；不以随机帧并行打断时序")
    validation_split = hparams.get("validation_split", "development_train_grouped")
    if validation_split not in ("val_seen", "val_unseen", "development_train_grouped"):
        raise ValueError("验证仅支持官方带标签split或显式训练来源的成组独立开发集")
    annotation_root = Path(hparams["annotation_root"])
    cache_path = Path(hparams["cache_manifest"])
    validation_cache = Path(hparams.get("validation_cache_manifest") or cache_path)
    pass_paths = [cache_path, *[Path(path) for path in extra_passes]]
    if len({path.resolve() for path in pass_paths}) != len(pass_paths):
        raise ValueError("render pass清单路径重复")
    train_passes, val_samples, development_split, validation_source_split = load_aerial_training_partitions(
        annotation_root, cache_path, validation_cache, pass_paths, history_frames, validation_split,
        hparams.get("development_fraction", .2), hparams.get("development_split_seed", 0),
        hparams.get("development_split_manifest"), require_depth=require_depth,
        index_mode=hparams.get("sample_index_mode", "off"), index_dir=hparams.get("sample_index_dir"))
    train_samples = train_passes[0]
    if not train_samples or not val_samples:
        raise ValueError("真实渲染训练/官方验证样本不能为空")
    train_sessions = {sample.get("capture_session_id") for samples in train_passes for sample in samples}
    validation_sessions = {sample.get("capture_session_id") for sample in val_samples}
    if (train_sessions & validation_sessions) - {None}:
        raise ValueError("训练和验证render pass共享采集session，拒绝会话泄漏")
    train_episode_ids = {f"{s['scene_id']}/{s['episode_id']}" for s in train_samples}
    val_episode_ids = {f"{s['scene_id']}/{s['episode_id']}" for s in val_samples}
    if train_episode_ids & val_episode_ids:
        raise ValueError("训练与验证episode ID重叠")
    if stage == "dagger" and warm:
        warm_manifest_path = warm_path.parent.parent / "split_manifest.json"
        if (not warm_manifest_path.is_file() or hashlib.sha256(warm_manifest_path.read_bytes()).hexdigest()
                != warm["model_config"].get("split_manifest_sha256")):
            raise ValueError("DAgger暖启动必须带可核验BC run划分清单")
        warm_manifest = json.loads(warm_manifest_path.read_text(encoding="utf-8"))
        if (set(warm_manifest.get("train_episode_ids", [])) != train_episode_ids
                or set(warm_manifest.get("validation_episode_ids", [])) != val_episode_ids):
            raise ValueError("DAgger暖启动BC训练/开发名单变化，禁止间接开发数据泄漏")
    train_episodes = group_aerial_episodes(train_samples, history_frames)
    render_pass_episodes = [train_episodes, *[group_aerial_episodes(samples, history_frames) for samples in train_passes[1:]]]
    dagger_groups, dagger_records = [], []
    if stage == "dagger":
        if not recurrent:
            raise ValueError("DAgger阶段只支持完整episode循环策略")
        dagger_groups, dagger_records = load_training_dagger_groups(
            annotation_root, hparams["dagger_manifests"], history_frames, train_episode_ids, require_depth)
        render_pass_episodes = [episodes + dagger_groups for episodes in render_pass_episodes]
        train_episodes = render_pass_episodes[0]
    val_episodes = group_aerial_episodes(val_samples, history_frames)
    vocab = Vocab([s["instruction"] for s in train_samples], tokenizer_version=tokenizer_version)
    starting = resume or warm
    if starting:
        if starting["model_config"].get("tokenizer_version") != tokenizer_version:
            raise ValueError("暖启动/恢复的tokenizer版本不同")
        if starting["vocab"] != vocab.words:
            raise ValueError("暖启动/恢复必须保留同一BC训练词表，不能静默新增或重编号")
        vocab.words = dict(starting["vocab"])
    ablate = hparams.get("ablate", "none")
    if ablate not in ("none", "no_image", "no_text", "no_history"):
        raise ValueError("未知八动作消融模式")
    options = {"architecture": architecture, "backbone": hparams.get("backbone", "resnet18"),
               "visual_fusion": hparams.get("visual_fusion", "spatial"), "grid_size": int(hparams.get("grid_size", 4)),
               "hidden": int(hparams.get("hidden", 128)), "history_frames": history_frames,
               "fusion_mode": "query_plus_text", "stop_enabled": True, "ablate": ablate}
    if recurrent:
        options["memory_mode"] = memory_mode
        options["vision_train_policy"] = vision_train_policy
        options["text_query_mode"] = text_query_mode
    if architecture == "aerial_route_recurrent_clause_v3":
        from uavnav.avln.data import text_cache_key
        options["text_encoder"] = text_cache_key()
        options["text_encoder"]["version"] = "frozen_clip_clause_cache_v1"
        options["clause_dim"] = 512
    if architecture == "aerial_route_dino_v5":
        repo_path = Path(dino_repo).resolve()
        weights_path = Path(dino_weights).resolve()
        options["backbone"] = f"dinov3_{dino_variant}"
        options["grid_size"] = imgsz // 16
        options["dino_repo"] = str(repo_path)
        options["dino_weights"] = str(weights_path)
        options["dino_variant"] = dino_variant
        options["dino_input_size"] = imgsz
        options["dino_frozen"] = True
        options["visual_encoder"] = {
            "version": "dinov3_backbone_v1",
            "variant": dino_variant,
            "repo_dir": str(repo_path),
            "repo_source_sha256": dinov3_source_sha256(repo_path),
            "weights_sha256": sha256_file(weights_path),
            "input_size": imgsz,
            "patch_size": 16,
            "embed_dim": DINOV3_VARIANTS[dino_variant][1],
            "grid_size": imgsz // 16,
            "frozen": True,
            "token_protocol": "cls_plus_patch_tokens_v1",
        }
    if baseline:
        options.update(hidden=512, backbone="resnet50", fusion_mode="official_policy",
                       visual_fusion="spatial" if architecture.startswith("airvln_cma_") else "global",
                       baseline_protocol="official_network_matched_training_adapter_v1",
                       memory_layers=2 if architecture.startswith("airvln_cma_") else 1,
                       memory_hidden_size=512, raw_rgb_adapter="imagenet_denormalize_round_uint8_v1",
                       prev_action_protocol="last_executed_action_or_start_zero_v1")
        for field in ("upstream_root", "upstream_project_prefix", "upstream_log_dir", "upstream_source_sha256", "ddppo_checkpoint_sha256"):
            options[field] = hparams.get(field)
    if require_depth:
        options.update(input_modality="rgbd", depth_input_protocol="front_0_scene_normalized_256_v1",
                       depth_size=256, depth_fusion="official_depth_encoder_v1" if baseline else "conv32_64_128_add_fused_v1")
    memory_protocol = "airvln_recurrent_gru_v1" if baseline else "fused_gru_v1"
    bn_protocol = ("dinov3_layernorm_v1" if architecture == "aerial_route_dino_v5"
                   else "causal_fixed_bn_v1" if baseline else "frozen_running_stats_v1")
    pretrained = bool(hparams.get("pretrained", True))
    protocol = aerial_task_protocol(imgsz)
    cache_bytes, validation_cache_bytes = cache_path.read_bytes(), validation_cache.read_bytes()
    cache_sha, validation_cache_sha = hashlib.sha256(cache_bytes).hexdigest(), hashlib.sha256(validation_cache_bytes).hexdigest()
    if (any(s["cache_manifest_sha256"] != cache_sha for s in train_samples)
            or any(s["cache_manifest_sha256"] != validation_cache_sha for s in val_samples)):
        raise ValueError("真实渲染清单在reader核验后发生变化，拒绝混合内容状态")
    cache_payload, validation_cache_payload = json.loads(cache_bytes), json.loads(validation_cache_bytes)
    pass_bytes = [path.read_bytes() for path in pass_paths]
    render_pass_records = []
    for index, (path, source, samples) in enumerate(zip(pass_paths, pass_bytes, train_passes)):
        digest = hashlib.sha256(source).hexdigest()
        if any(sample["cache_manifest_sha256"] != digest for sample in samples):
            raise ValueError("render pass清单在reader核验后发生变化")
        render_pass_records.append({"pass_index": index, "source": str(path.resolve()),
                                    "manifest_sha256": digest, "sample_content_sha256": sample_content_sha256(samples),
                                    "capture_session_id": samples[0].get("capture_session_id")})
    if pass_bytes[0] != cache_bytes:
        raise ValueError("基础render pass清单在reader核验后发生变化")
    # scope来自已核验真实缓存，不根据样本数猜测完整训练。
    scope = {"train": cache_payload.get("scope"), "validation": validation_cache_payload.get("scope")}
    if any(not isinstance(value, str) or not value.strip() for value in scope.values()):
        raise ValueError("训练和验证缓存必须声明非空scope，局部缓存使用integration_episode_subset")
    if development_split is not None:
        source_scope = dict(scope)
        scope = {"train": "training_source_route_group_partition", "validation": "independent_train_route_holdout"}
    render_protocols = {"train": cache_payload["render_protocol"], "validation": validation_cache_payload["render_protocol"]}
    if any(render["camera_name"] != protocol["camera"] for render in render_protocols.values()):
        raise ValueError("真实渲染camera_name与路线前视front_0任务合同冲突")
    official_train = load_aerial_episodes(annotation_root, "train")
    if official_train[0]["_annotation_sha256"] != train_samples[0]["annotation_sha256"]:
        raise ValueError("训练标注在采样后发生变化")
    candidates = [{"scene_id": episode["scene_id"], "episode_id": episode["episode_id"],
                   "reason": episode["_quarantine_reason"]} for episode in official_train if episode["_quarantine_reason"]]
    selected = {(row["scene_id"], str(row["episode_id"])) for row in cache_payload["episodes"]}
    child_records = aerial_child_source_records(pass_paths, validation_cache)
    manifest = {"schema_version": 3, "data_protocol": "aerialvln_s_v1",
                "sample_policy": "aerialvln_s_before_action_v1", "history_policy": "action_onehot8_v1",
                "official_validation_split": validation_split if development_split is None else None, "scope": scope,
                "input_render_protocols": render_protocols,
                "train_episode_ids": sorted(train_episode_ids), "validation_episode_ids": sorted(val_episode_ids),
                "annotation_quarantine_candidates": candidates,
                "selected_quarantined_episodes": [row for row in candidates if (row["scene_id"], str(row["episode_id"])) in selected],
                "train_samples": len(train_samples), "validation_samples": len(val_samples),
                "train_action_counts": dict(Counter(int(s["action"]) for s in train_samples)),
                "validation_action_counts": dict(Counter(int(s["action"]) for s in val_samples)),
                "train_sample_content_sha256": render_pass_records[0]["sample_content_sha256"],
                "validation_sample_content_sha256": sample_content_sha256(val_samples),
                "train_cache_manifest_sha256": cache_sha,
                "validation_cache_manifest_sha256": validation_cache_sha,
                "train_annotation_sha256": train_samples[0]["annotation_sha256"],
                "validation_annotation_sha256": val_samples[0]["annotation_sha256"]}
    if child_records:
        manifest["child_cache_sources"] = child_records
    if development_split is not None:
        manifest.update(training_split_protocol=development_split["split_protocol"],
                        development_route_split=development_split, source_cache_scopes=source_scope,
                        validation_source_split="train", validation_purpose="development_train_grouped",
                        development_route_split_sha256=development_split["manifest_sha256"])
    manifest["validation_capture_session_ids"] = sorted(validation_sessions - {None})
    manifest.update(tokenizer_version=tokenizer_version, text_control=text_control,
                    vocab_sha256=_json_sha256(vocab.words),
                    token_statistics={"train": aerial_token_statistics(train_episodes, vocab),
                                      "validation": aerial_token_statistics(val_episodes, vocab)},
                    missing_training_actions=sorted(set(range(8)) - {s["action"] for s in train_samples}),
                    missing_validation_actions=sorted(set(range(8)) - {s["action"] for s in val_samples}),
                    label_prior_baselines=aerial_action_priors(train_samples, val_samples))
    if recurrent:
        manifest.update(schema_version=4, sequence_policy="episode_contiguous_tbptt_v1",
                        vision_train_policy=vision_train_policy,
                        text_query_mode=text_query_mode,
                        render_pass_policy="episode_uniform_pass_v1", render_pass_seed=render_pass_seed,
                        train_render_passes=render_pass_records,
                        memory_protocol=memory_protocol, memory_mode=memory_mode,
                        vision_batchnorm_protocol=bn_protocol,
                        sequence_chunk_size=chunk_size, loss_protocol=loss_protocol,
                        train_episode_sequence_sha256=_json_sha256([
                            {"scene_id": ep[0]["scene_id"], "episode_id": ep[0]["episode_id"],
                             "frames_actions": [[s["frame_index"], s["action"]] for s in ep]} for ep in train_episodes]),
                        validation_episode_sequence_sha256=_json_sha256([
                            {"scene_id": ep[0]["scene_id"], "episode_id": ep[0]["episode_id"],
                             "frames_actions": [[s["frame_index"], s["action"]] for s in ep]} for ep in val_episodes]))
    if baseline:
        manifest.update({key: options[key] for key in ("baseline_protocol", "memory_layers", "memory_hidden_size",
                         "raw_rgb_adapter", "prev_action_protocol", "upstream_source_sha256", "ddppo_checkpoint_sha256")})
    if stage == "dagger":
        manifest.update(dagger_manifests=dagger_records, training_aggregation="bc_plus_reviewed_student_rollouts_v1",
                        aggregated_training_samples=sum(len(ep) for ep in train_episodes),
                        aggregated_training_episodes=len(train_episodes))
    manifest["train_official_eligible_episodes"] = sum(episode["_quarantine_reason"] is None for episode in official_train)
    eligible_ids = {f"{ep['scene_id']}/{ep['episode_id']}" for ep in official_train if ep["_quarantine_reason"] is None}
    source_ids = {f"{row['scene_id']}/{row['episode_id']}" for row in cache_payload["episodes"]}
    manifest["train_covers_official_eligible_split"] = train_episode_ids == eligible_ids
    official_ids = {f"{ep['scene_id']}/{ep['episode_id']}" for ep in official_train}
    manifest["train_source_covers_official_eligible_split"] = source_ids & eligible_ids == eligible_ids and source_ids <= official_ids
    manifest["train_source_covers_official_raw_split"] = source_ids == official_ids
    if hparams.get("require_full_train", False):
        from uavnav.avln.metadata import validate_official_aerial_split
        manifest["official_train_source"] = validate_official_aerial_split(annotation_root, "train")
    if hparams.get("require_full_train", False) and not manifest["train_source_covers_official_eligible_split"]:
        raise ValueError("正式训练要求完整官方有效train ID集合；局部缓存不能启动")
    official_validation = load_aerial_episodes(annotation_root, validation_source_split)
    if official_validation[0]["_annotation_sha256"] != val_samples[0]["annotation_sha256"]:
        raise ValueError("验证标注在采样后发生变化")
    manifest["validation_official_episodes"] = len(official_validation)
    manifest["validation_covers_official_split"] = val_episode_ids == {f"{ep['scene_id']}/{ep['episode_id']}" for ep in official_validation}
    for key, flag in (("train", "train_covers_official_eligible_split"), ("validation", "validation_covers_official_split")):
        if scope[key] == "official_split_complete" and not manifest[flag]:
            raise ValueError("缓存scope声称完整split，但episode内容集合尚未覆盖全部官方有效任务")
    if scope["train"] == "official_split_complete" and manifest["missing_training_actions"]:
        raise ValueError("正式完整训练scope必须覆盖八动作，缺类不能升级为完整训练")
    run_dir = _run_dir(hparams["project"], hparams["name"])
    if resume_path and resume_path != (run_dir / "weights" / "last.pt").resolve():
        raise ValueError("resume必须使用同run的weights/last.pt")
    if not resume_path and run_dir.exists() and any(run_dir.iterdir()):
        raise FileExistsError(f"实验目录已有文件，使用独立name防止覆盖证据: {run_dir}")
    model = build_model(len(vocab.words), options, pretrained=pretrained).to(device)
    if architecture == "aerial_route_dino_v5":
        encoder = dict(model.visual_encoder)
        encoder["repo_dir"] = options["dino_repo"]
        options["visual_encoder"] = encoder
    if warm:
        source_config = warm["model_config"]
        for key in ("architecture", "history_frames", "hidden", "backbone", "visual_fusion", "grid_size",
                    "memory_mode", "vision_train_policy", "ablate", "input_modality", "depth_input_protocol",
                    "depth_fusion", "depth_size", "text_query_mode", "visual_encoder",
                    "dino_variant", "dino_input_size", "dino_frozen"):
            source_value = source_config.get(key, "visual_history" if key == "text_query_mode" else None)
            if source_value != options.get(key):
                raise ValueError(f"暖启动模型配置不一致: {key}")
        model.load_state_dict(warm["model"], strict=True)
    if baseline:
        options["upstream_adapter"] = dict(model.upstream_metadata)
        options["network_precision"] = "fp32_with_outer_autocast_disabled_v1"
        manifest["upstream_adapter"] = options["upstream_adapter"]
        manifest["network_precision"] = options["network_precision"]
    feature_cache_path = hparams.get("vision_feature_cache")
    if feature_cache_path:
        if (baseline or require_depth or not recurrent or vision_train_policy != "frozen"
                or ablate == "no_image" or extra_passes):
            raise ValueError("vision_feature_cache仅支持冻结视觉的RGB单pass路线v2")
        cache_file = Path(feature_cache_path)
        cache_dtype = hparams.get("vision_feature_cache_dtype", "float32")
        if cache_file.is_file():
            feature_payload = load_vision_feature_cache(cache_file, model, imgsz, cache_dtype)
        else:
            feature_payload = build_vision_feature_cache(model, [*train_episodes, *val_episodes], imgsz, device, cache_file, storage_dtype=cache_dtype)
        for group in (train_episodes, val_episodes, *render_pass_episodes):
            attach_vision_features(group, feature_payload)
        hparams["vision_feature_cache_key_sha256"] = _json_sha256(feature_payload["key"])
        del feature_payload
    if architecture == "aerial_route_recurrent_clause_v3":
        text_path = hparams.get("text_feature_cache")
        if not text_path or vision_train_policy != "frozen" or not hparams.get("vision_feature_cache"):
            raise ValueError("v3需要冻结视觉、视觉特征缓存及text_feature_cache")
        text_file = Path(text_path)
        if text_file.is_file():
            text_payload = load_text_feature_cache(text_file)
        else:
            from itertools import chain
            text_payload = build_text_feature_cache(
                [ep[0]["instruction"] for ep in chain(train_episodes, val_episodes)], text_file, device)
        for group in (train_episodes, val_episodes, *render_pass_episodes):
            attach_text_features(group, text_payload)
        hparams["text_feature_cache_key_sha256"] = _json_sha256(text_payload["key"])
        del text_payload
    training_contract = {
        "training_stage": stage,
        "training_seed": seed,
        # 只记录本次构造方式。旧权重仍按原forward严格加载；不同构造的同seed不保证相同初值。
        "model_construction_version": "direct_selected_encoders_v1",
        "model_selection_basis": "lowest_unweighted_teacher_validation_ce_not_navigation",
        "training_precision": {
            "version": "aerial_training_precision_v1", "device_type": device.type,
            "forward": "bf16_autocast" if device.type == "cuda" and not baseline else "fp32",
            "memory": "fp32" if recurrent else "none", "loss": "fp32", "inference": "fp32",
        },
    }
    manifest.update(training_contract)
    model_initial_sha = initial_state_sha256(model.state_dict())
    vision_initial_sha = initial_state_sha256(model.vision.state_dict())
    parameter_groups = [{"params": [p for name, p in model.named_parameters() if name.startswith("vision.") and p.requires_grad], "lr": lr * .1},
                        {"params": [p for name, p in model.named_parameters() if not name.startswith("vision.") and p.requires_grad], "lr": lr}]
    optimizer = torch.optim.AdamW(parameter_groups, weight_decay=.01)
    scheduler = torch.optim.lr_scheduler.CosineAnnealingLR(optimizer, T_max=epochs)
    if device.type == "cuda":
        torch.backends.cudnn.benchmark = True
        torch.set_float32_matmul_precision("high")
        torch.cuda.reset_peak_memory_stats(device)
    manifest_bytes = (json.dumps(manifest, ensure_ascii=False, indent=2) + "\n").encode("utf-8")
    if resume:
        for name, content in (("split_manifest.json", manifest_bytes), ("train_cache_manifest.json", cache_bytes),
                              ("validation_cache_manifest.json", validation_cache_bytes)):
            if not (run_dir / name).is_file() or (run_dir / name).read_bytes() != content:
                raise ValueError(f"恢复数据/划分合同改变: {name}")
        for index, record in enumerate(dagger_records):
            snapshot = run_dir / "dagger_manifests" / f"collection_{index:03d}.json"
            if not snapshot.is_file() or hashlib.sha256(snapshot.read_bytes()).hexdigest() != record["manifest_sha256"]:
                raise ValueError("恢复DAgger来源清单快照损坏")
        for record in child_records:
            snapshot = run_dir / record["snapshot"]
            if not snapshot.is_file() or hashlib.sha256(snapshot.read_bytes()).hexdigest() != record["manifest_sha256"]:
                raise ValueError("恢复多场景子缓存清单快照损坏")
        sources = json.loads((run_dir / "source_manifest.json").read_text(encoding="utf-8"))
        source_root = Path(__file__).resolve().parents[2]
        for relative, digest in sources.items():
            if relative.startswith("upstream/AirVLN/"):
                current = Path(options["upstream_root"]) / relative.removeprefix("upstream/AirVLN/")
            elif relative.startswith("upstream/DINOv3/"):
                current = Path(options["dino_repo"]) / relative.removeprefix("upstream/DINOv3/")
            else:
                current = source_root / relative
            snapshot = run_dir / "source_snapshot" / relative
            if (not current.is_file() or not snapshot.is_file()
                    or hashlib.sha256(current.read_bytes()).hexdigest() != digest
                    or hashlib.sha256(snapshot.read_bytes()).hexdigest() != digest):
                raise ValueError(f"恢复源码与冻结run不一致: {relative}")
        model_initial_sha = resume["model_config"].get("model_init_state_sha256")
        vision_initial_sha = resume["model_config"].get("vision_init_state_sha256")
    else:
        (run_dir / "weights").mkdir(parents=True)
        (run_dir / "split_manifest.json").write_bytes(manifest_bytes)
        (run_dir / "task_config.json").write_text(json.dumps(protocol, ensure_ascii=False, indent=2) + "\n", encoding="utf-8")
        (run_dir / "train_cache_manifest.json").write_bytes(cache_bytes)
        (run_dir / "validation_cache_manifest.json").write_bytes(validation_cache_bytes)
        for record in child_records:
            snapshot = run_dir / record["snapshot"]
            snapshot.parent.mkdir(parents=True, exist_ok=True)
            content = Path(record["source"]).read_bytes()
            if hashlib.sha256(content).hexdigest() != record["manifest_sha256"]:
                raise ValueError("多场景子缓存清单快照复制前改变")
            snapshot.write_bytes(content)
        if len(pass_paths) > 1:
            (run_dir / "render_pass_manifests").mkdir()
            for index, source in enumerate(pass_bytes):
                (run_dir / "render_pass_manifests" / f"pass_{index:03d}.json").write_bytes(source)
        if dagger_records:
            (run_dir / "dagger_manifests").mkdir()
            for index, record in enumerate(dagger_records):
                content = Path(record["source"]).read_bytes()
                if hashlib.sha256(content).hexdigest() != record["manifest_sha256"]:
                    raise ValueError("DAgger来源清单在快照复制前改变")
                (run_dir / "dagger_manifests" / f"collection_{index:03d}.json").write_bytes(content)
        _snapshot_sources(
            run_dir,
            options["upstream_root"] if baseline else None,
            options["upstream_source_sha256"] if baseline else None,
            options["dino_repo"] if architecture == "aerial_route_dino_v5" else None,
            options["visual_encoder"]["repo_source_sha256"] if architecture == "aerial_route_dino_v5" else None)
    config = {**options, "checkpoint_format_version": (8 if architecture == "aerial_route_dino_v5"
                                                       else 7 if require_depth else (6 if baseline else (5 if recurrent else 4))),
              "output_version": "aerial_action8_v1",
              "seed": seed,
              "history_policy": "action_onehot8_v1", "data_protocol": "aerialvln_s_v1",
              "input_render_protocols": render_protocols, "input_render_protocols_sha256": _json_sha256(render_protocols),
              "task_protocol": protocol, "task_protocol_sha256": _json_sha256(protocol),
              "text_control": text_control, "strip_direction": False, "pretrained": pretrained,
              "tokenizer_version": tokenizer_version,
              "imgsz": imgsz, "image_mean": [0.485, .456, .406], "image_std": [.229, .224, .225],
              "split_manifest_sha256": hashlib.sha256(manifest_bytes).hexdigest(),
              **training_contract}
    if development_split is not None:
        config.update(training_split_protocol=development_split["split_protocol"],
                      development_route_split_sha256=development_split["manifest_sha256"],
                      validation_purpose="development_train_grouped", validation_source_split="train")
    if recurrent:
        config.update(memory_protocol=memory_protocol, sequence_policy="episode_contiguous_tbptt_v1",
                      model_init_state_sha256=model_initial_sha, vision_init_state_sha256=vision_initial_sha,
                      render_pass_policy="episode_uniform_pass_v1", render_pass_seed=render_pass_seed,
                      render_pass_count=len(train_passes), train_render_passes=render_pass_records,
                      sequence_chunk_size=chunk_size, loss_protocol=loss_protocol,
                      vision_batchnorm_protocol=bn_protocol,
                      constant_text_token="<unk>" if text_control == "constant" else None)
    if dagger_records:
        config.update(dagger_manifests=dagger_records, training_aggregation="bc_plus_reviewed_student_rollouts_v1")
    hparams.update(options, data_protocol="aerialvln_s_v1", history_policy="action_onehot8_v1",
                   task_protocol=protocol, task_protocol_sha256=config["task_protocol_sha256"],
                   scope=scope, pretrained=pretrained, validation_split=validation_split,
                   csv_float_precision="17_significant_digits", model_config=config)
    hparams.update(training_contract)
    if development_split is not None:
        hparams.update({key: config[key] for key in ("training_split_protocol", "development_route_split_sha256",
                                                   "validation_purpose", "validation_source_split")})
    hparams.update(tokenizer_version=tokenizer_version, text_control=text_control,
                   loss_protocol=loss_protocol, sequence_chunk_size=chunk_size if recurrent else None)
    if recurrent:
        hparams.update(memory_protocol=memory_protocol, sequence_policy="episode_contiguous_tbptt_v1",
                       model_init_state_sha256=model_initial_sha, vision_init_state_sha256=vision_initial_sha,
                       render_pass_manifests=[str(path) for path in pass_paths[1:]],
                       render_pass_seed=render_pass_seed, render_pass_policy="episode_uniform_pass_v1",
                       render_pass_count=len(train_passes), train_render_passes=render_pass_records,
                       trainable_parameters=sum(p.numel() for p in model.parameters() if p.requires_grad),
                       memory_mode=memory_mode, vision_batchnorm_protocol=bn_protocol,
                       requested_batch=batch_size, batch=episode_batch or 1,
                       batch_policy="episode_batch_tbptt_v2" if episode_batch else "single_episode_chunk",
                       optimizer_updates_per_epoch=(sum(math.ceil(max(len(e) for e in train_episodes[i:i + episode_batch]) / chunk_size)
                                                        for i in range(0, len(train_episodes), episode_batch))
                                                    if episode_batch else
                                                    sum(math.ceil(len(ep) / chunk_size) for ep in train_episodes)))
    hparams.update(stage=stage, require_full_train=hparams.get("require_full_train", False),
                   warm_start_sha256=warm_sha if warm_path else
                       resume.get("training_state", {}).get("warm_start_sha256") if resume else None)
    if dagger_records:
        hparams.update(dagger_manifests=[record["source"] for record in dagger_records],
                       dagger_sources=dagger_records, training_aggregation="bc_plus_reviewed_student_rollouts_v1",
                       aggregated_training_samples=sum(len(ep) for ep in train_episodes),
                       aggregated_training_episodes=len(train_episodes))
    n_param = sum(p.numel() for p in model.parameters())
    if not resume:
        (run_dir / "runtime.json").write_text(json.dumps(_training_runtime(device), indent=2) + "\n", encoding="utf-8")
        _write_hparams(run_dir, hparams, str(device), len(vocab.words), sum(len(ep) for ep in train_episodes), n_param,
                       1., len(train_episode_ids), {"official_aerial_annotations": len(train_samples),
                                                    "reviewed_dagger_states": sum(len(ep) for ep in dagger_groups)})
    if not recurrent:
        make_loader = functools.partial(DataLoader, batch_size=batch_size, num_workers=workers,
                                      collate_fn=functools.partial(collate, vocab=vocab, imgsz=imgsz, history_frames=history_frames),
                                      persistent_workers=workers > 0, pin_memory=device.type == "cuda")
        train_loader = make_loader(train_samples, shuffle=True, generator=torch.Generator().manual_seed(seed))
        val_loader = make_loader(val_samples, shuffle=False)
    print(f"AerialVLN-S八动作{stage}: train={sum(len(ep) for ep in train_episodes)} val={len(val_samples)}, scope={scope}, device={device}")
    print("训练/验证为真实教师状态动作分类；导航NE/SR/OSR/nDTW/sDTW保持null直到独立闭环。")
    started, best_val, best_epoch, start_epoch = time.time(), float("inf"), 0, 0
    csv_path = run_dir / "results.csv"
    elapsed_committed = 0.
    cumulative_updates = 0
    if resume:
        state = resume.get("training_state")
        if not state or state.get("version") != "aerial_epoch_resume_v1":
            raise ValueError("旧checkpoint无完整训练状态，不能假装resume；可显式warm_start新run")
        committed_request = dict(state["request"])
        # 特性加入前的默认v2 run没有该字段，沿用原始查询语义；候选run字段存在时必须严格匹配。
        committed_request.setdefault("text_query_mode", "visual_history")
        committed_request.setdefault("candidate_epochs", [])
        committed_request.setdefault("diagnostics_interval", 128)
        if committed_request != requested_hparams or state["device"] != str(device):
            raise ValueError("resume配置/device改变；不能换stage、数据、epochs或优化时间表")
        resume_config = dict(resume["model_config"])
        # 旧v2 checkpoint没有候选字段，缺省解释为原始视觉/历史查询；候选模式不得借此静默切换。
        resume_config.setdefault("text_query_mode", "visual_history")
        if resume_config != config or resume["vocab"] != vocab.words:
            raise ValueError("resume模型/词表/划分合同改变")
        start_epoch = resume["epoch"]
        if type(start_epoch) is not int or not 0 < start_epoch <= epochs:
            raise ValueError("恢复epoch不在冻结优化时间表内")
        best_val, best_epoch = state["best_val"], state["best_epoch"]
        if not math.isfinite(best_val) or not 1 <= best_epoch <= start_epoch:
            raise ValueError("恢复best统计非法")
        model.load_state_dict(resume["model"], strict=True)
        optimizer.load_state_dict(resume["optimizer"])
        scheduler.load_state_dict(resume["scheduler"])
        if scheduler.last_epoch != start_epoch or scheduler.T_max != epochs:
            raise ValueError("恢复scheduler与epoch/优化时间表不一致")
        _restore_committed_logs(run_dir, state["logs"], start_epoch)
        best_path = run_dir / "weights" / "best.pt"
        best = torch.load(best_path, map_location="cpu", weights_only=True) if best_path.exists() else None
        if not best or best.get("epoch") != best_epoch or best.get("val_loss") != best_val:
            if best_epoch == start_epoch and best_val == resume["val_loss"]:
                _atomic_checkpoint(_checkpoint(model, vocab, best_epoch, best_val, 1., config), best_path)
            else:
                raise ValueError("恢复best checkpoint损坏或与已提交统计不一致")
        _restore_rng(state["rng"])
        elapsed_committed = state["elapsed"]
        cumulative_updates = state.get("optimizer_updates_total")
        if cumulative_updates is None:
            ledger = state["logs"].get("render_pass_selections.jsonl")
            rows = [json.loads(line) for line in ledger.splitlines()] if ledger else []
            if rows and all(type(row.get("optimizer_updates")) is int and row["optimizer_updates"] > 0 for row in rows):
                cumulative_updates = sum(row["optimizer_updates"] for row in rows)
        if cumulative_updates is not None and (type(cumulative_updates) is not int or cumulative_updates < 0):
            raise ValueError("恢复累计更新数不是合法整数")
        if candidate_epochs:
            if cumulative_updates is None:
                raise ValueError("候选保存需要真实累计更新记录，不能由计划预算猜测")
            _save_epoch_candidate(resume, run_dir, candidate_epochs, cumulative_updates)
    for epoch in range(start_epoch, epochs):
        epoch_started = time.perf_counter()
        lr_used = optimizer.param_groups[1]["lr"]
        if recurrent and episode_batch:
            train_stats = _aerial_batched_epoch(model, train_episodes, vocab, imgsz, history_frames, chunk_size, device,
                                               episode_batch, optimizer=optimizer, epoch=epoch, epochs=epochs,
                                               loss_protocol=loss_protocol, seed=seed, workers=workers)
            val_stats = _aerial_batched_epoch(model, val_episodes, vocab, imgsz, history_frames, chunk_size, device,
                                             episode_batch, loss_protocol=loss_protocol, seed=seed, workers=workers)
        elif recurrent:
            parameters = dict(vocab=vocab, imgsz=imgsz, history_frames=history_frames, chunk_size=chunk_size,
                              device=device, loss_protocol=loss_protocol, text_control=text_control, seed=seed)
            train_stats = _aerial_sequence_epoch(model, train_episodes, optimizer=optimizer, epoch=epoch, epochs=epochs,
                                                render_pass_episodes=render_pass_episodes, render_pass_seed=render_pass_seed,
                                                history_dropout=history_dropout, diagnostics_interval=diagnostics_interval,
                                                failure_path=run_dir / "training_failure.json", **parameters)
            val_stats = _aerial_sequence_epoch(model, val_episodes, **parameters)
            with (run_dir / "render_pass_selections.jsonl").open("a", encoding="utf-8") as stream:
                stream.write(json.dumps({"epoch": epoch + 1, "seed": render_pass_seed,
                                         "policy": "episode_uniform_pass_v1", "pass_count": len(train_passes),
                                         "selections": train_stats["render_pass_selections"],
                                         "samples": train_stats["samples"], "optimizer_updates": train_stats["optimizer_updates"]},
                                        ensure_ascii=False) + "\n")
        else:
            train_stats = _aerial_epoch(model, train_loader, device, optimizer, epoch, epochs)
            val_stats = _aerial_epoch(model, val_loader, device)
        if cumulative_updates is not None:
            cumulative_updates += train_stats.get("optimizer_updates", len(train_loader) if not recurrent else 0)
        with (run_dir / "training_diagnostics.jsonl").open("a", encoding="utf-8") as stream:
            stream.write(json.dumps({"epoch": epoch + 1, "optimizer_updates_total": cumulative_updates,
                                     "optimizer_updates_in_epoch": train_stats.get("optimizer_updates", len(train_loader) if not recurrent else 0),
                                     "train_statistics_basis": "predictions_during_parameter_updates",
                                     "validation_statistics_basis": "fixed_epoch_end_weights_eval",
                                     "epoch_wall_seconds": time.perf_counter() - epoch_started,
                                     "train": train_stats.get("optimization_diagnostics"),
                                     "validation": val_stats.get("optimization_diagnostics"),
                                     "train_samples": train_stats.get("samples", len(train_samples)),
                                     "validation_samples": val_stats.get("samples", len(val_samples))},
                                    ensure_ascii=False, allow_nan=False) + "\n")
        scheduler.step()
        _append_action_csv(csv_path, epoch + 1, elapsed_committed + time.time() - started, train_stats, val_stats,
                           lr_used, optimizer.param_groups[1]["lr"])
        improved = val_stats["loss"] < best_val
        if improved:
            best_val, best_epoch = val_stats["loss"], epoch + 1
        last = _checkpoint(model, vocab, epoch + 1, val_stats["loss"], 1., config)
        last.update(optimizer=optimizer.state_dict(), scheduler=scheduler.state_dict(),
                    training_state={"version": "aerial_epoch_resume_v1", "request": requested_hparams,
                                    "device": str(device), "best_val": best_val, "best_epoch": best_epoch,
                                    "rng": _rng_state(device), "logs": _committed_logs(run_dir),
                                    "elapsed": elapsed_committed + time.time() - started,
                                    "optimizer_updates_total": cumulative_updates,
                                    "warm_start_sha256": hparams["warm_start_sha256"]})
        _atomic_checkpoint(last, run_dir / "weights" / "last.pt")
        if improved:
            _atomic_checkpoint(_checkpoint(model, vocab, best_epoch, best_val, 1., config), run_dir / "weights" / "best.pt")
        _save_epoch_candidate(last, run_dir, candidate_epochs, cumulative_updates)
        write_metrics(run_dir, peak_vram_gb=_memory_gb_value(device))
        metrics_path = run_dir / "metrics.json"
        metrics = json.loads(metrics_path.read_text(encoding="utf-8"))
        metrics.update(ndtw=None, sdtw=None, task_protocol=protocol, training_scope=scope)
        metrics_path.write_text(json.dumps(metrics, ensure_ascii=False, indent=2) + "\n", encoding="utf-8")
        print(f"epoch {epoch+1}/{epochs}: train CE={train_stats['loss']:.6g}, val CE={val_stats['loss']:.6g}, val acc={val_stats['accuracy']:.4g}")
    _plot_loss(csv_path)
    return run_dir


LOSS_PROTOCOL_VERSIONS = {"transition_weighted_ce_v1": "sum_weights", "episode_normalized_ce_v2": "episode_sum_weights"}


def validate_aerial_loss_protocol(protocol):
    expected = {"version", "inflection_weight", "stop_weight", "normalization"}
    if (not isinstance(protocol, dict) or set(protocol) != expected
            or LOSS_PROTOCOL_VERSIONS.get(protocol["version"]) != protocol["normalization"]):
        raise ValueError("时序loss_protocol必须声明已知版本及其对应归一化(v1=sum_weights, v2=episode_sum_weights)")
    result = dict(protocol)
    for key in ("inflection_weight", "stop_weight"):
        value = result[key]
        if isinstance(value, bool) or not isinstance(value, (int, float)) or not math.isfinite(value) or value <= 0:
            raise ValueError(f"loss_protocol.{key} 必须为有限正数")
        result[key] = float(value)
    return result


def aerial_transition_weights(actions, protocol):
    """只改训练损失权重；STOP 与转折权重取max，不能重复相乘。"""
    protocol = validate_aerial_loss_protocol(protocol)
    target = torch.as_tensor(actions)
    if target.dtype not in (torch.uint8, torch.int8, torch.int16, torch.int32, torch.int64):
        raise ValueError("动作权重的标签必须是整数，不能把浮点/布尔标签转为类别")
    target = target.to(torch.long)
    if target.ndim != 1 or not len(target) or ((target < 0) | (target > 7)).any():
        raise ValueError("动作权重需要非空八动作序列")
    weights = torch.ones(len(target), dtype=torch.float32)
    changed = torch.zeros(len(target), dtype=torch.bool)
    changed[1:] = target[1:] != target[:-1]
    weights[changed] = protocol["inflection_weight"]
    stop = target == 0
    weights[stop] = torch.maximum(weights[stop], torch.full_like(weights[stop], protocol["stop_weight"]))
    return weights


def aerial_token_statistics(episodes, vocab):
    total, unknown, weighted_total, weighted_unknown, max_tokens = 0, 0, 0, 0, 0
    for episode in episodes:
        ids = vocab.encode(episode[0]["instruction"])
        oov = sum(token == vocab.words["<unk>"] for token in ids)
        total += len(ids)
        unknown += oov
        weighted_total += len(ids) * len(episode)
        weighted_unknown += oov * len(episode)
        max_tokens = max(max_tokens, len(ids))
    return {"tokenizer_version": vocab.tokenizer_version, "episodes": len(episodes), "tokens": total,
            "oov_tokens": unknown, "oov_rate": unknown / total if total else None,
            "frame_weighted_oov_rate": weighted_unknown / weighted_total if weighted_total else None,
            "max_instruction_tokens": max_tokens}


def aerial_action_priors(train_samples, validation_samples):
    train = Counter(sample["action"] for sample in train_samples)
    validation = Counter(sample["action"] for sample in validation_samples)
    ntrain, nval = len(train_samples), len(validation_samples)
    majority = max(range(8), key=lambda action: train[action])
    unsupported = [action for action in range(8) if validation[action] and not train[action]]
    empirical = None if unsupported else -sum(validation[a] / nval * math.log(train[a] / ntrain)
                                             for a in range(8) if validation[a])
    return {"training_majority_action": majority, "training_majority_validation_accuracy": validation[majority] / nval,
            "constant_forward_validation_accuracy": validation[1] / nval, "uniform_eight_ce": math.log(8),
            "train_empirical_prior_validation_ce": empirical,
            "train_empirical_prior_status": "infinite_unseen_class" if unsupported else "finite",
            "validation_classes_absent_in_train": unsupported,
            "laplace_plus1_train_prior_validation_ce": -sum(validation[a] / nval * math.log((train[a] + 1) / (ntrain + 8))
                                                            for a in range(8) if validation[a])}


def _aerial_statistics(total_loss, count, matrix, objective_sum=None, weight_sum=None):
    if not count or not math.isfinite(total_loss):
        raise RuntimeError("八动作epoch没有有效有限样本")
    actual, predicted = matrix.sum(1), matrix.sum(0)
    recalls = [float(matrix[a, a]) / int(actual[a]) if actual[a] else None for a in range(8)]
    precisions = [float(matrix[a, a]) / int(predicted[a]) if predicted[a] else None for a in range(8)]
    return {"loss": total_loss / count, "accuracy": float(matrix.diag().sum()) / count, "samples": count,
            "stop_recall": recalls[0], "stop_precision": precisions[0], "class_recall": recalls,
            "class_precision": precisions, "macro_recall_present": float(np.mean([r for r in recalls if r is not None])),
            "majority_accuracy": int(actual.max()) / count, "missing_classes": [a for a in range(8) if not actual[a]],
            "objective_loss": objective_sum / weight_sum if weight_sum else total_loss / count,
            "confusion_matrix": matrix.tolist()}


def _detach_state(state):
    return tuple(part.detach() for part in state) if isinstance(state, tuple) else state.detach()


def _aerial_sequence_epoch(model, episodes, vocab, imgsz, history_frames, chunk_size, device,
                           optimizer=None, epoch=0, epochs=1, loss_protocol=None, text_control="original", seed=0,
                           render_pass_episodes=None, render_pass_seed=0, history_dropout=0.,
                           diagnostics_interval=128, failure_path=None):
    """仅在episode之间打乱，连续分块携带状态；每个episode显式清空GRU。"""
    if type(chunk_size) is not int or chunk_size <= 0 or text_control not in ("original", "constant"):
        raise ValueError("chunk_size为正整数，text_control仅支持original/constant")
    if isinstance(history_dropout, bool) or not isinstance(history_dropout, (int, float)) or not 0 <= history_dropout < 1:
        raise ValueError("history_dropout必须在[0,1)")
    if type(diagnostics_interval) is not int or diagnostics_interval < 0:
        raise ValueError("diagnostics_interval必须为非负整数")
    protocol = validate_aerial_loss_protocol(loss_protocol or {
        "version": "transition_weighted_ce_v1", "inflection_weight": 1.9,
        "stop_weight": 1.9, "normalization": "sum_weights",
    })
    if not episodes or not hasattr(model, "forward_sequence"):
        raise ValueError("时序epoch需要完整episode和forward_sequence模型")
    if type(render_pass_seed) is not int:
        raise ValueError("render_pass_seed必须为整数")
    passes = [episodes] if render_pass_episodes is None else render_pass_episodes
    identity = lambda group: [[(sample["scene_id"], str(sample["episode_id"]), sample["frame_index"],
                               sample["action"], sample["instruction"]) for sample in ep] for ep in group]
    reference = identity(episodes)
    if not isinstance(passes, list) or not passes or any(identity(group) != reference for group in passes):
        raise ValueError("每个render pass必须包含相同完整episode顺序与监督身份")
    training = optimizer is not None
    model.train(training)
    order = list(range(len(episodes)))
    if training:
        random.Random(seed + epoch).shuffle(order)
    pass_rng = random.Random(render_pass_seed + epoch)
    pass_choices = [pass_rng.randrange(len(passes)) if training else 0 for _ in episodes]
    selections = []
    iterator = tqdm(order, desc=f"{epoch+1}/{epochs} episodes", leave=False) if training else order
    total_loss, objective_sum, weight_sum, chunk_objective_sum, count, chunks = 0., 0., 0., 0., 0, 0
    matrix = torch.zeros(8, 8, dtype=torch.long)
    gradient_samples = []
    norm_sum = torch.zeros((), device=device)
    clipped_count = torch.zeros((), device=device)
    timings = {"input_wall_seconds": 0., "forward_wall_seconds": 0., "backward_step_wall_seconds": 0.}
    for episode_index in iterator:
        pass_index = pass_choices[episode_index]
        episode = passes[pass_index][episode_index]
        selections.append({"scene_id": episode[0]["scene_id"], "episode_id": str(episode[0]["episode_id"]),
                           "pass_index": pass_index})
        state = None
        weights = aerial_transition_weights([sample["action"] for sample in episode], protocol)
        denominator = weights.sum() if protocol["version"] == "episode_normalized_ce_v2" else None
        for begin in range(0, len(episode), chunk_size):
            stage_started = time.perf_counter()
            selected = episode[begin:begin + chunk_size]
            if text_control == "constant":
                selected = [{**sample, "instruction": "<unk>"} for sample in selected]
            data = collate(selected, vocab, imgsz, history_frames)
            data = {key: value.to(device) for key, value in data.items()}
            target = data["action_target"]
            chunk_weights = weights[begin:begin + len(target)].to(device)
            timings["input_wall_seconds"] += time.perf_counter() - stage_started
            stage_started = time.perf_counter()
            with torch.set_grad_enabled(training):
                if training:
                    optimizer.zero_grad(set_to_none=True)
                with _autocast(device):
                    inputs = {key: data[key] for key in ("image", "tokens", "token_mask", "history", "history_length", "depth", "vision_mean", "vision_regions", "clause_features", "clause_mask") if key in data}
                    if training and history_dropout > 0:
                        drop = torch.rand(len(target), device=device, generator=None) < history_dropout
                        inputs["history"] = inputs["history"].masked_fill(drop.view(-1, 1, 1), 0)
                        inputs["history_length"] = inputs["history_length"].masked_fill(drop, 0)
                    logits, state = model.forward_sequence(inputs, state)
                if logits.shape != (len(target), 8) or not torch.isfinite(logits).all():
                    raise RuntimeError("时序八动作logits形状错误或存在非有限值")
                per_frame = torch.nn.functional.cross_entropy(logits.float(), target, reduction="none")
                objective = (per_frame * chunk_weights).sum() / (chunk_weights.sum() if denominator is None else denominator.to(device))
                if not torch.isfinite(objective):
                    raise RuntimeError("时序训练损失存在非有限值")
                timings["forward_wall_seconds"] += time.perf_counter() - stage_started
                if training:
                    stage_started = time.perf_counter()
                    objective.backward()
                    if diagnostics_interval and chunks % diagnostics_interval == 0:
                        gradient_samples.append({"update": chunks + 1, "branches_pre_clip_norm": _gradient_observation(model)})
                    try:
                        norm = torch.nn.utils.clip_grad_norm_(model.parameters(), 1., error_if_nonfinite=True)
                    except RuntimeError:
                        if failure_path is not None:
                            failure = Path(failure_path)
                            if failure.exists():
                                failure = failure.with_name(f"{failure.stem}_{time.time_ns()}{failure.suffix}")
                            with failure.open("x", encoding="utf-8") as stream:
                                stream.write(json.dumps({"reason": "nonfinite_gradient_before_optimizer_step",
                                "epoch": epoch + 1, "scene_id": episode[0]["scene_id"],
                                "episode_id": str(episode[0]["episode_id"]), "chunk_begin": begin,
                                "completed_optimizer_updates_in_epoch": chunks}, ensure_ascii=False) + "\n")
                        raise
                    norm_sum += norm.detach()
                    clipped_count += (norm.detach() > 1.)
                    optimizer.step()
                    timings["backward_step_wall_seconds"] += time.perf_counter() - stage_started
                state = _detach_state(state)
            total_loss += float(per_frame.detach().sum())
            objective_sum += float((per_frame.detach() * chunk_weights).sum())
            weight_sum += float(chunk_weights.sum())
            chunk_objective_sum += float(objective.detach())
            count += len(target)
            chunks += 1
            predicted = logits.argmax(-1)
            matrix += torch.bincount((target * 8 + predicted).detach().cpu(), minlength=64).reshape(8, 8)
        if training:
            iterator.set_description(f"{epoch+1}/{epochs} episodes CE={total_loss/count:.4g}")
    return {**_aerial_statistics(total_loss, count, matrix, objective_sum, weight_sum),
            "optimization_diagnostics": {**timings, "timing_basis": "host_wall_cuda_unsynchronized",
                "gradient_samples": gradient_samples, "gradient_sample_interval_updates": diagnostics_interval,
                "pre_clip_total_norm_mean": float(norm_sum / chunks) if training else None,
                "clipped_update_fraction": float(clipped_count / chunks) if training else None},
            "samples": count, "render_pass_count": len(passes), "render_pass_seed": render_pass_seed,
            "render_pass_policy": "episode_uniform_pass_v1", "render_pass_selections": selections,
            "episodes": len(episodes), "sequence_chunks": chunks, "optimizer_updates": chunks if training else 0,
            "chunk_objective_mean_diagnostic": chunk_objective_sum / chunks,
            "chunk_objective_diagnostic_version": "mean_chunk_weighted_ce_v1",
            "sequence_policy": "episode_contiguous_tbptt_v1", "text_control": text_control}


class _ChunkPlan(torch.utils.data.Dataset):
    """?(episode?, chunk??)???????????worker?????????????????"""

    def __init__(self, groups, episodes, protocol, vocab, imgsz, history_frames, chunk_size):
        self.items, self.episodes, self.protocol = [], episodes, protocol
        self.vocab, self.imgsz, self.history_frames = vocab, imgsz, history_frames
        for group in groups:
            longest = max(len(episodes[i]) for i in group)
            for begin in range(0, longest, chunk_size):
                active = [i for i in group if begin < len(episodes[i])]
                width = min(chunk_size, max(len(episodes[i]) - begin for i in active))
                self.items.append((group, active, begin, width))

    def __len__(self):
        return len(self.items)

    def __getitem__(self, index):
        group, active, begin, width = self.items[index]
        samples, valid, weights = [], [], []
        for i in active:
            episode = self.episodes[i]
            piece = episode[begin:begin + width]
            pad = width - len(piece)
            samples += piece + [piece[-1]] * pad
            valid += [True] * len(piece) + [False] * pad
            full = aerial_transition_weights([s["action"] for s in episode], self.protocol)
            weights += full[begin:begin + len(piece)].tolist() + [0.] * pad
        data = collate(samples, self.vocab, self.imgsz, self.history_frames)
        data["_valid"] = torch.tensor(valid)
        data["_weights"] = torch.tensor(weights, dtype=torch.float32)
        data["_active"] = torch.tensor(active)
        data["_first"] = torch.tensor(begin == 0)
        data["_width"] = torch.tensor(width)
        return data


def _aerial_batched_epoch(model, episodes, vocab, imgsz, history_frames, chunk_size, device, episode_batch,
                          optimizer=None, epoch=0, epochs=1, loss_protocol=None, seed=0, workers=0):
    """episode_batch_tbptt_v2?E?episode???chunk???GRU??(1,E,H)????????????"""
    protocol = validate_aerial_loss_protocol(loss_protocol)
    if protocol["version"] != "transition_weighted_ce_v1":
        raise ValueError("多episode并行路径仅支持transition_weighted_ce_v1；整episode归一需逐episode路径")
    if (type(episode_batch) is not int or episode_batch <= 0 or type(chunk_size) is not int or chunk_size <= 0
            or type(workers) is not int or workers < 0):
        raise ValueError("episode_batch?chunk_size?????workers?????")
    training = optimizer is not None
    model.train(training)
    order = list(range(len(episodes)))
    if training:
        random.Random(seed + epoch).shuffle(order)
    groups = [order[i:i + episode_batch] for i in range(0, len(order), episode_batch)]
    plan = _ChunkPlan(groups, episodes, protocol, vocab, imgsz, history_frames, chunk_size)
    loader = DataLoader(plan, batch_size=None, shuffle=False, num_workers=workers, pin_memory=device.type == "cuda",
                        persistent_workers=False, prefetch_factor=4 if workers else None)
    total_loss, objective_sum, weight_sum, count, updates = 0., 0., 0., 0, 0
    matrix = torch.zeros(8, 8, dtype=torch.long)
    iterator = tqdm(loader, desc=f"{epoch+1}/{epochs} episode-batches", leave=False) if training else loader
    state, rows_prev = None, None
    for data in iterator:
        mask, w = data.pop("_valid").to(device), data.pop("_weights").to(device)
        active, width = data.pop("_active").tolist(), int(data.pop("_width"))
        if bool(data.pop("_first")):
            state = None
        data = {key: value.to(device, non_blocking=True) for key, value in data.items()}
        target = data["action_target"]
        if state is not None and active != rows_prev:
            state = state[:, [rows_prev.index(i) for i in active]].contiguous()
        rows_prev = active
        with torch.set_grad_enabled(training):
            if training:
                optimizer.zero_grad(set_to_none=True)
            with _autocast(device):
                inputs = {key: data[key] for key in ("image", "tokens", "token_mask", "history", "history_length", "vision_mean", "vision_regions") if key in data}
                logits, state = model.forward_sequence_batch(inputs, state, len(active), width)
            if not torch.isfinite(logits[mask]).all():
                raise RuntimeError("????logits??????")
            per_frame = torch.nn.functional.cross_entropy(logits.float(), target, reduction="none")
            objective = (per_frame * w).sum() / w.sum()
            if not torch.isfinite(objective):
                raise RuntimeError("??????????????")
            if training:
                objective.backward()
                torch.nn.utils.clip_grad_norm_(model.parameters(), 1.)
                optimizer.step()
                updates += 1
            state = state.detach()
        total_loss += float(per_frame.detach()[mask].sum())
        objective_sum += float((per_frame.detach() * w).sum())
        weight_sum += float(w.sum())
        count += int(mask.sum())
        predicted = logits.argmax(-1)
        matrix += torch.bincount((target[mask] * 8 + predicted[mask]).detach().cpu(), minlength=64).reshape(8, 8)
    return {**_aerial_statistics(total_loss, count, matrix, objective_sum, weight_sum),
            "samples": count, "episodes": len(episodes), "optimizer_updates": updates,
            "sequence_policy": "episode_batch_tbptt_v2", "episode_batch": episode_batch,
            "render_pass_selections": [], "render_pass_count": 1, "render_pass_seed": 0}


def _aerial_epoch(model, loader, device, optimizer=None, epoch=0, epochs=1):
    training = optimizer is not None
    model.train(training)
    total_loss, count, correct = 0., 0, 0
    matrix = torch.zeros(8, 8, dtype=torch.long)
    batches = tqdm(loader, desc=f"{epoch+1}/{epochs}", leave=False) if training else loader
    for data in batches:
        data = {key: value.to(device, non_blocking=True) for key, value in data.items()}
        with torch.set_grad_enabled(training):
            if training:
                optimizer.zero_grad(set_to_none=True)
            with _autocast(device):
                inputs = {key: data[key] for key in ("image", "tokens", "token_mask", "history", "history_length", "depth") if key in data}
                logits = model(inputs)
            target = data["action_target"]
            if logits.shape != (len(target), 8) or not torch.isfinite(logits).all():
                raise RuntimeError("八动作logits形状错误或存在非有限值")
            loss = torch.nn.functional.cross_entropy(logits.float(), target)
            if training:
                loss.backward()
                torch.nn.utils.clip_grad_norm_(model.parameters(), 1.)
                optimizer.step()
        predicted = logits.argmax(-1)
        total_loss += float(loss.detach()) * len(target)
        count += len(target)
        correct += int((predicted == target).sum())
        matrix += torch.bincount((target * 8 + predicted).detach().cpu(), minlength=64).reshape(8, 8)
        if training:
            batches.set_description(f"{epoch+1}/{epochs} CE={total_loss/count:.4g}")
    return _aerial_statistics(total_loss, count, matrix)


def _append_action_csv(path, epoch, elapsed, train, val, lr_used, lr_next):
    keys = ("loss", "objective_loss", "accuracy", "samples", "stop_recall", "stop_precision", "macro_recall_present", "majority_accuracy")
    new_file = not path.exists()
    with path.open("a", encoding="utf-8", newline="") as handle:
        writer = csv.writer(handle)
        if new_file:
            writer.writerow(["epoch", "time", *[f"{split}/{key}" for split in ("train", "val") for key in keys], "lr_used", "lr_next"])
        writer.writerow([epoch, elapsed, *[stats[key] for stats in (train, val) for key in keys], lr_used, lr_next])
    (path.parent / "action_confusion.json").write_text(json.dumps({"epoch": epoch, "train": train,
                                                                  "validation": val}, indent=2) + "\n", encoding="utf-8")


def fit(**hparams):
    validate_training_controls(hparams)
    seed = int(hparams["seed"])
    random.seed(seed)
    np.random.seed(seed)
    torch.manual_seed(seed)
    torch.cuda.manual_seed_all(seed)

    # 缺包要在开跑前就炸。matplotlib 缺失只会打一行 warn 然后 results.png 悄悄不生成，
    # 等发现时 GPU 已经跑完几小时了。
    for module in ("matplotlib", "yaml", "tqdm", "scipy", "PIL"):
        __import__(module)

    ablate = hparams.get("ablate") or "none"
    if ablate not in ABLATIONS:
        raise ValueError(f"ablate={ablate!r} 只能是 {ABLATIONS}")
    architecture = hparams.get("architecture", "legacy_waypoint_v1")
    if architecture in ("aerial_route_v1", "aerial_route_recurrent_v2", *RGBD_ARCHITECTURES, *AIRVLN_BASELINES):
        raise ValueError("路线八动作训练使用fit_aerial，不能沿用FOV回归标签")
    if ablate == "constant_text" and architecture != "grounded_v1":
        raise ValueError("同构constant_text控制仅支持grounded_v1")
    fusion_mode = hparams.get("fusion_mode", "query_plus_text" if architecture == "grounded_v1" else "text_context_only")
    if fusion_mode not in FUSION_MODES:
        raise ValueError(f"fusion_mode={fusion_mode!r} 只能是 {FUSION_MODES}")
    hparams["fusion_mode"] = fusion_mode
    stop_enabled = hparams.get("stop_enabled", False)
    if not isinstance(stop_enabled, bool):
        raise ValueError("stop_enabled必须是布尔值")
    if stop_enabled and not hparams.get("stop_annotations"):
        raise ValueError("启用STOP训练必须提供已审核的stop_annotations，禁止把末帧自动标为成功")

    paths = load_list(hparams["data_root"], hparams["list_json"])
    instruction_json = hparams.get("instruction_json")
    if instruction_json and not Path(instruction_json).is_file():
        # 静默回退到 obj_des.json 是个陷阱：路径写错时训练照跑，只是指令全换了，
        # 而 hparams.yaml 里记的还是那个从未被读过的 meta 路径。直接报错。
        raise FileNotFoundError(f"指令表不存在: {instruction_json}")
    strip_direction = bool(hparams.get("strip_direction", True))
    instructions = load_instructions(instruction_json, strip_direction) if instruction_json else None
    if instructions:
        print(f"指令表载入 {len(instructions)} 条，来源 {instruction_json}")
        print(f"  剥离句末初始朝向线索: {strip_direction}")
        print(f"  样例: {next(iter(instructions.values()))}")
    history_frames = int(hparams["history"])
    if history_frames <= 0:
        raise ValueError("history 必须为正数；关闭历史输入请使用 no_history 消融")
    hparams["training_frame_index_gap"] = FOV_FRAME_GAP
    hparams["data_sample_policy"] = SAMPLE_POLICY
    samples = list(iter_samples(paths, history_frames, instructions, strip_direction))
    task_protocol = hparams.get("task_protocol") or {
        "version": "fov_front_motion_v1", "camera": "FrontCamera",
        "image_size": int(hparams["imgsz"]), "strip_direction": strip_direction,
        "goal_access": "training_labels_and_offline_scoring_only",
        "stop_source": "disabled", "stop_timing": "disabled",
    }
    task_protocol = validate_task_protocol(task_protocol)
    if (task_protocol["image_size"] != int(hparams["imgsz"])
            or task_protocol["strip_direction"] != strip_direction
            or (task_protocol["stop_source"] == "reviewed_annotations") != stop_enabled):
        raise ValueError("task_protocol与图像/指令/STOP配置冲突")
    hparams["task_protocol"] = task_protocol
    hparams["task_protocol_sha256"] = task_protocol_sha256(task_protocol)
    split_seed = int(hparams.get("split_seed", seed))
    hparams["split_seed"] = split_seed
    list_path = Path(hparams["list_json"])
    if not list_path.is_absolute():
        list_path = Path(hparams["data_root"]) / list_path
    source_contract = {
        "split_seed": split_seed,
        "val_ratio": float(hparams["val_ratio"]),
        "data_sample_policy": SAMPLE_POLICY,
        "training_frame_index_gap": FOV_FRAME_GAP,
        "data_root": str(Path(hparams["data_root"]).resolve()),
        "source_list_sha256": hashlib.sha256(list_path.read_bytes()).hexdigest(),
        "instruction_json_sha256": hashlib.sha256(Path(instruction_json).read_bytes()).hexdigest() if instruction_json else None,
    }
    manifest_source = hparams.get("split_manifest_source")
    manifest_bytes = None
    motion_manifest_bytes = None
    if manifest_source:
        manifest_bytes = Path(manifest_source).read_bytes()
        manifest = json.loads(manifest_bytes)
        train_samples, val_samples, n_traj = split_from_manifest(samples, manifest, source_contract)
        hparams["reference_split_manifest_sha256"] = hashlib.sha256(manifest_bytes).hexdigest()
    else:
        train_samples, val_samples, n_traj = split_by_trajectory(samples, float(hparams["val_ratio"]), split_seed)
        manifest = {
            **source_contract,
            "train_trajectory_ids": sorted({sample["traj_id"] for sample in train_samples}),
            "validation_trajectory_ids": sorted({sample["traj_id"] for sample in val_samples}),
            "train_samples": len(train_samples),
            "validation_samples": len(val_samples),
            "eligible_trajectories": n_traj,
        }
    if stop_enabled:
        from uavnav.avln.data import add_stop_annotations
        annotation_digest = hashlib.sha256(Path(hparams["stop_annotations"]).read_bytes()).hexdigest()
        annotated = add_stop_annotations(samples, paths, hparams["stop_annotations"], task_protocol)
        if annotation_digest != hashlib.sha256(Path(hparams["stop_annotations"]).read_bytes()).hexdigest():
            raise ValueError("STOP标注在核验期间发生变化，拒绝绑定错误摘要")
        train_ids = set(manifest["train_trajectory_ids"])
        val_ids = set(manifest["validation_trajectory_ids"])
        train_samples = [s for s in annotated if s["traj_id"] in train_ids]
        val_samples = [s for s in annotated if s["traj_id"] in val_ids]
        classes = {int(s["stop_target"]) for s in train_samples if s["stop_valid"]}
        if classes != {0, 1} or not any(s["stop_valid"] for s in val_samples):
            raise ValueError("STOP训练需要train可信正负例和validation可信标签")
        motion_manifest_bytes = manifest_bytes or (json.dumps(manifest, ensure_ascii=False, indent=2) + "\n").encode("utf-8")
        manifest = {**manifest, "motion_split_manifest_sha256": hashlib.sha256(motion_manifest_bytes).hexdigest(),
            "stop_annotations_sha256": annotation_digest,
            "derived_sample_policy": "fov_reviewed_stop_v1", "train_samples": len(train_samples),
            "validation_samples": len(val_samples)}
        hparams["stop_annotations_sha256"] = manifest["stop_annotations_sha256"]
        manifest_bytes = None
    # 同构控制仍复用训练原文词表，两组同样保留一个固定控制token。
    vocab_texts = [sample["instruction"] for sample in train_samples]
    if architecture == "grounded_v1" or ablate == "constant_text":
        vocab_texts.append("<neutral>")
    vocab = Vocab(vocab_texts)
    # 同构非语义文本控制：保留计算路径，不伪造替代目标的标签。
    if ablate == "constant_text":
        if not strip_direction:
            raise ValueError("constant_text当前仅支持去方向协议，防止同时移除合法方向信息")
        train_samples = [{**s, "instruction": "<neutral>"} for s in train_samples]
        val_samples = [{**s, "instruction": "<neutral>"} for s in val_samples]
    # 词表只读训练原文及固定控制token，验证文本不参与建表。
    if not train_samples or not val_samples:
        raise RuntimeError("训练/验证切分后有一边为空，调 val_ratio 或检查数据")

    device_name = hparams["device"]
    # 静默退回 CPU 是最贵的坑：ResNet-50 在 CPU 上跑满 20 epoch 要十几小时，
    # 而且不报错、日志里 device: cpu 会被几百行训练输出埋掉。忘挂卡就直接退出。
    if device_name.startswith("cuda") and not torch.cuda.is_available():
        raise RuntimeError(
            f"要求 {device_name}，但 torch.cuda.is_available() 是 False。"
            "检查 nvidia-smi 看得见卡、CUDA_VISIBLE_DEVICES 没把它屏蔽掉。"
        )
    device = torch.device(device_name)
    model_options = {"architecture": architecture, "history_frames": history_frames,
                     "hidden": int(hparams.get("hidden", 128)), "ablate": "none" if ablate == "constant_text" else ablate,
                     "fusion_mode": fusion_mode, "backbone": hparams.get("backbone", "resnet50" if architecture == "legacy_waypoint_v1" else "resnet18"),
                     "visual_fusion": hparams.get("visual_fusion", "global" if architecture == "legacy_waypoint_v1" else "spatial"),
                     "grid_size": int(hparams.get("grid_size", 4)), "stop_enabled": stop_enabled}
    if architecture in ("aerial_route_recurrent_v2", "aerial_route_recurrent_rgbd_v3"):
        model_options["text_query_mode"] = hparams.get("text_query_mode", "visual_history")
    model = build_model(len(vocab.words), model_options, pretrained=bool(hparams.get("pretrained", True))).to(device)
    content_sha256 = sample_content_sha256(samples)
    if "effective_sample_content_sha256" in manifest and manifest["effective_sample_content_sha256"] != content_sha256:
        raise ValueError("实际图像/日志/标签内容与冻结样本摘要不一致")
    # 旧清单只冻结轨迹，不回写原文件；新运行另存升级字段并保留旧来源摘要。
    manifest = {**manifest, "sample_manifest_version": 2, "effective_sample_content_sha256": content_sha256}
    if manifest_bytes is not None:
        manifest["source_split_manifest_sha256"] = hashlib.sha256(manifest_bytes).hexdigest()
        manifest_bytes = None
    hparams.update(model_options)
    hparams["ablate"] = ablate
    hparams["pretrained"] = bool(hparams.get("pretrained", True))
    hparams["csv_float_precision"] = "17_significant_digits"
    stop_weight = float(hparams.get("stop_loss_weight", 1.0))
    if not math.isfinite(stop_weight) or stop_weight <= 0:
        raise ValueError("stop_loss_weight必须是有限正数")
    model.stop_loss_weight = stop_weight
    lr = float(hparams["lr"])
    # backbone 是预训练来的，学习率压低一档，否则前几个 epoch 就把通用特征冲掉了
    vision_decay = [p for n, p in model.named_parameters() if n.startswith("vision.") and p.ndim > 1]
    vision_nodecay = [p for n, p in model.named_parameters() if n.startswith("vision.") and p.ndim <= 1]
    head_decay = [p for n, p in model.named_parameters() if not n.startswith("vision.") and p.ndim > 1]
    head_nodecay = [p for n, p in model.named_parameters() if not n.startswith("vision.") and p.ndim <= 1]
    parameter_groups = [
        {"params": vision_decay, "weight_decay": 0.01, "lr": lr * 0.1},
        {"params": vision_nodecay, "weight_decay": 0.0, "lr": lr * 0.1},
        {"params": head_decay, "weight_decay": 0.01, "lr": lr},
        {"params": head_nodecay, "weight_decay": 0.0, "lr": lr},
    ]
    all_parameters = list(model.parameters())
    group_ids = [id(parameter) for group in parameter_groups for parameter in group["params"]]
    expected_ids = {id(parameter) for parameter in all_parameters}
    if len(group_ids) != len(set(group_ids)):
        raise RuntimeError("优化器参数分组存在重复参数")
    if set(group_ids) != expected_ids:
        raise RuntimeError("优化器参数分组数量与模型参数数量不一致")
    optimizer = torch.optim.AdamW(
        parameter_groups
    )
    scheduler = torch.optim.lr_scheduler.CosineAnnealingLR(optimizer, T_max=int(hparams["epochs"]))
    epochs = int(hparams["epochs"])
    batch = int(hparams["batch"])
    imgsz = int(hparams["imgsz"])
    workers = int(hparams["workers"])
    # imgsz 固定，cudnn.benchmark 能白捡一截卷积选择时间；TF32 让 matmul 走张量核
    if device.type == "cuda":
        torch.backends.cudnn.benchmark = True
        torch.set_float32_matmul_precision("high")

    # offset 的绝对尺度是米，不归一化的话 L1 项会主导损失且很快压平
    norms = np.array([float(np.linalg.norm(s["offset"])) for s in train_samples if s.get("motion_valid", True)])
    length_scale = float(np.median(norms)) or 1.0

    run_dir = _run_dir(hparams["project"], hparams["name"])
    # results.csv 是追加写的。同名目录里已经有数据还往里追加，画出来的曲线会同时含
    # 两次运行的 epoch，x 轴全是重复值还看不太出来。把旧的挪走，别静默污染。
    if (run_dir / "results.csv").is_file() and (run_dir / "results.csv").stat().st_size:
        stamp = time.strftime("%Y%m%d-%H%M%S")
        archived = run_dir.with_name(f"{run_dir.name}_{stamp}")
        run_dir.rename(archived)
        print(f"[warn] {run_dir.name} 已有结果，改名归档成 {archived.name}")
    run_dir.mkdir(parents=True, exist_ok=True)
    (run_dir / "weights").mkdir(exist_ok=True)
    if manifest_bytes is None:
        manifest_bytes = (json.dumps(manifest, ensure_ascii=False, indent=2) + "\n").encode("utf-8")
    (run_dir / "split_manifest.json").write_bytes(manifest_bytes)
    if motion_manifest_bytes is not None:
        (run_dir / "motion_split_manifest.json").write_bytes(motion_manifest_bytes)
    (run_dir / "task_config.json").write_text(json.dumps(task_protocol, ensure_ascii=False, indent=2) + "\n", encoding="utf-8")
    _snapshot_sources(run_dir)
    csv_path = run_dir / "results.csv"
    n_param = sum(p.numel() for p in model.parameters())
    instruction_sources = Counter(sample.get("instruction_source", "unknown") for sample in samples)
    _write_hparams(
        run_dir,
        hparams,
        device_name,
        len(vocab.words),
        len(train_samples),
        n_param,
        length_scale,
        n_traj,
        dict(instruction_sources),
    )
    print(
        f"\nModel summary: {n_param} parameters\n"
        f"optimizer: AdamW(lr={lr}, cosine)\n"
        f"trajectories: {n_traj}  train samples: {len(train_samples)}  val samples: {len(val_samples)}\n"
        f"vocab: {len(vocab.words)}  offset 中位数: {length_scale:.4g} m  ablate: {ablate}  fusion: {fusion_mode}\n"
        f"Image sizes {imgsz} train\n"
        f"device: {device_name}  dataloader workers: {workers}\n"
        f"Logging results to {run_dir.resolve()}\n"
        f"Starting training for {epochs} epochs...\n"
        "loss = angle (cosine) + length (L1, 已按 offset 中位数归一化). "
        "NE, SR, OSR and SPL stay empty until closed-loop eval."
    )
    started = time.time()
    make_loader = functools.partial(
        DataLoader,
        batch_size=batch,
        num_workers=workers,
        collate_fn=functools.partial(collate, vocab=vocab, imgsz=imgsz, history_frames=history_frames),
        persistent_workers=workers > 0,
        pin_memory=device.type == "cuda",
    )
    loader = make_loader(train_samples, shuffle=True, generator=torch.Generator().manual_seed(seed))
    val_loader = make_loader(val_samples, shuffle=False)
    best_val = float("inf")
    val = None
    for epoch in range(epochs):
        lr_used = optimizer.param_groups[2]["lr"]  # 本轮 head decay 的实际学习率
        model.train()
        stats = _run_epoch(model, loader, optimizer, device, epoch, epochs, length_scale, ablate)
        val = _evaluate(model, val_loader, device, length_scale, ablate)
        scheduler.step()
        lr_next = optimizer.param_groups[2]["lr"]
        _append_csv(csv_path, epoch + 1, time.time() - started, stats, val, lr_used, lr_next)
        print(
            ("%13s" * 6)
            % (
                f"{epoch + 1}/{epochs}",
                _memory_gb(device),
                f"{stats['loss']:.4g}",
                f"{stats['angle']:.4g}",
                f"{stats['length']:.4g}",
                f"{val['loss']:.4g}",
            )
        )
        # val 变成 NaN 时 val["loss"] < best_val 永远为 False，best.pt 一个字节都不会写，
        # 但其他产物照常齐全——看着像跑完了，其实全 NaN。立刻停下。
        if not math.isfinite(val["loss"]):
            raise RuntimeError(
                f"epoch {epoch + 1} 的 val/loss = {val['loss']} 不是有限数，训练已发散。"
                f" 本轮 lr_used={lr_used:.3g}，train/loss={stats['loss']:.4g}"
            )
        # 每个 epoch 都覆盖写一次 last.pt 和 metrics.json：SSH 断开或 OOM 发生在第 19 个
        # epoch 时，不能只留下 hparams.yaml 和 results.csv 而把权重全丢掉。
        model_config = {
            **model_options,
            "checkpoint_format_version": 3,
            "text_control": "constant" if ablate == "constant_text" else "original",
            "task_protocol": task_protocol,
            "task_protocol_sha256": hparams["task_protocol_sha256"],
            "output_version": "waypoint_stop_v1" if stop_enabled else "waypoint_v1",
            "pretrained": hparams["pretrained"],
            "backbone_weights": ("ResNet18_Weights.IMAGENET1K_V1" if model_options["backbone"] == "resnet18"
                                 else "ResNet50_Weights.IMAGENET1K_V2") if hparams["pretrained"] and ablate != "no_image" else "none",
            "history_frames": history_frames,
            "hidden": model.hidden_size,
            "ablate": model_options["ablate"],
            "fusion_mode": fusion_mode,
            "imgsz": imgsz,
            "image_mean": [float(value) for value in (0.485, 0.456, 0.406)],
            "image_std": [float(value) for value in (0.229, 0.224, 0.225)],
            "strip_direction": strip_direction,
            "coordinate_frame": "body",
            "quaternion_order": "xyzw",
            "length_unit": "meter",
            "training_frame_index_gap": FOV_FRAME_GAP,
            "data_sample_policy": SAMPLE_POLICY,
            "split_seed": split_seed,
            "split_manifest_sha256": hashlib.sha256((run_dir / "split_manifest.json").read_bytes()).hexdigest(),
        }
        checkpoint = _checkpoint(model, vocab, epoch + 1, val["loss"], length_scale, model_config)
        checkpoint["optimizer"] = optimizer.state_dict()
        checkpoint["scheduler"] = scheduler.state_dict()
        torch.save(checkpoint, run_dir / "weights" / "last.pt")
        write_metrics(run_dir, peak_vram_gb=_memory_gb_value(device))
        if val["loss"] < best_val:
            best_val = val["loss"]
            torch.save(
                _checkpoint(model, vocab, epoch + 1, best_val, length_scale, model_config),
                run_dir / "weights" / "best.pt",
            )
    # 先写 metrics 再画图：画图失败不能连带丢掉 metrics.json
    write_metrics(run_dir, peak_vram_gb=_memory_gb_value(device))
    _plot_loss(csv_path)
    print(f"\n{epochs} epochs completed in {(time.time() - started) / 3600:.3f} hours. best val/loss = {best_val:.4g}")
    print(f"Results saved to {run_dir.resolve()}")
    return run_dir


def _run_epoch(model, loader, optimizer, device, epoch, epochs, length_scale, ablate):
    total = {"angle": 0.0, "length": 0.0, "stop": 0.0, "motion_count": 0, "stop_count": 0}
    seen = 0
    print(("\n" + "%13s" * 6) % ("Epoch", "GPU_mem", "train/loss", "train/angle", "train/length", "val/loss"))
    bar = tqdm(loader, desc=f"{epoch + 1}/{epochs}", unit="batch", leave=False)
    for batch_data in bar:
        batch_data = {key: value.to(device, non_blocking=True) for key, value in batch_data.items()}
        _apply_ablation(batch_data, ablate)
        optimizer.zero_grad(set_to_none=True)
        with _autocast(device):
            prediction = model(batch_data)
        # loss 和指标回 fp32 算：角度损失量级在 1e-3，bf16 只有 8 位尾数，
        # 拿它直接当指标会把差异抹平。权重是 bf16 算的，梯度不受影响。
        loss, angle, length = prediction_loss(prediction, batch_data, length_scale, getattr(model, "stop_loss_weight", 1.0))
        if not torch.isfinite(loss):
            raise RuntimeError("训练损失包含非有限数，停止更新")
        loss.backward()
        torch.nn.utils.clip_grad_norm_(model.parameters(), 1.0)
        optimizer.step()
        count = len(batch_data["offset"])
        _accumulate_losses(total, prediction, batch_data, angle, length)
        seen += count
        # 显存和 loss.item() 都是 GPU->CPU 同步，每 batch 调会把流水线打断，
        # 放在 tqdm 的 postfix 上由tqdm 自己节流。
        running = _epoch_losses(total, length_scale, getattr(model, "stop_loss_weight", 1.0))
        bar.set_description(f"{epoch + 1}/{epochs} loss={running['loss']:.4g}")
    return _epoch_losses(total, length_scale, getattr(model, "stop_loss_weight", 1.0))


def _accumulate_losses(total, prediction, batch, angle, length):
    motion_count = int(batch["motion_valid"].sum()) if "motion_valid" in batch else len(batch["offset"])
    total["angle"] += float(angle.detach()) * motion_count
    total["length"] += float(length.detach()) * motion_count
    total["motion_count"] += motion_count
    if isinstance(prediction, dict):
        mask = batch["stop_valid"]
        count = int(mask.sum())
        if count:
            stop = torch.nn.functional.binary_cross_entropy_with_logits(
                prediction["stop_logit"].detach().float()[mask], batch["stop_target"].float()[mask], reduction="sum")
            total["stop"] += float(stop)
            total["stop_count"] += count


def _epoch_losses(total, length_scale, stop_weight):
    angle = total["angle"] / max(total["motion_count"], 1)
    length = total["length"] / max(total["motion_count"], 1)
    stop = total["stop"] / max(total["stop_count"], 1)
    return {"loss": angle + length / length_scale + stop_weight * stop,
            "angle": angle, "length": length, "stop": stop,
            "motion_count": total["motion_count"], "stop_count": total["stop_count"]}


def _autocast(device):
    # bf16 在 5090 上约 2x，且不像 fp16 那样容易溢出。loss 在 autocast 外算，保持 fp32。
    return torch.autocast(device_type=device.type, dtype=torch.bfloat16, enabled=device.type == "cuda")


@torch.no_grad()
def _evaluate(model, loader, device, length_scale, ablate):
    model.eval()
    total = {"angle": 0.0, "length": 0.0, "stop": 0.0, "motion_count": 0, "stop_count": 0}
    seen = 0
    for batch_data in loader:
        batch_data = {key: value.to(device, non_blocking=True) for key, value in batch_data.items()}
        # 消融必须和训练同口径：验证若喂真图，测的就不是被消融的模型，
        # 而且 BatchNorm 的 running 统计是在训练输入上累积的，口径不一致必然不可解释。
        _apply_ablation(batch_data, ablate)
        with _autocast(device):
            prediction = model(batch_data)
        loss, angle, length = prediction_loss(prediction, batch_data, length_scale, getattr(model, "stop_loss_weight", 1.0))
        count = len(batch_data["offset"])
        _accumulate_losses(total, prediction, batch_data, angle, length)
        seen += count
    return _epoch_losses(total, length_scale, getattr(model, "stop_loss_weight", 1.0))


def _memory_gb_value(device):
    # CPU 上没有显存这个量。返回 None 让 metrics.json 保持 null，别写 0.0 那种像实测值的假数。
    if device.type != "cuda":
        return None
    return torch.cuda.max_memory_allocated(device) / 1024 ** 3


def _memory_gb(device):
    value = _memory_gb_value(device)
    return "-" if value is None else f"{value:.3g}G"


def _append_csv(path, epoch, elapsed, train, val, lr_used, lr_next):
    new_file = not path.exists()
    with path.open("a", encoding="utf-8", newline="") as handle:
        writer = csv.writer(handle)
        if new_file:
            writer.writerow(
                [
                    "epoch", "time",
                    "train/loss", "train/angle", "train/length",
                    "val/loss", "val/angle", "val/length",
                    "lr_used", "lr_next",
                    "train/stop", "val/stop", "train/motion_count", "val/motion_count",
                    "train/stop_count", "val/stop_count",
                ]
            )
        writer.writerow(
            [epoch, f"{elapsed:.17g}"]
            + [f"{train[key]:.17g}" for key in ("loss", "angle", "length")]
            + [f"{val[key]:.17g}" for key in ("loss", "angle", "length")]
            + [f"{lr_used:.17g}", f"{lr_next:.17g}"]
            + [train.get("stop", 0.0), val.get("stop", 0.0), train.get("motion_count"),
               val.get("motion_count"), train.get("stop_count"), val.get("stop_count")]
        )


def _write_hparams(
    run_dir,
    hparams,
    device_name,
    vocab_size,
    sample_count,
    n_param,
    length_scale,
    n_traj,
    instruction_sources,
):
    used = {key: (str(value) if isinstance(value, Path) else value) for key, value in hparams.items()}
    used["device"] = device_name
    used["vocab_size"] = vocab_size
    used["samples"] = sample_count
    used["trajectories"] = n_traj
    used["n_param"] = n_param
    used["length_scale"] = length_scale
    used["instruction_sources"] = instruction_sources
    (run_dir / "hparams.yaml").write_text(yaml.safe_dump(used, allow_unicode=True, sort_keys=False), encoding="utf-8")


def _plot_loss(csv_path):
    try:
        import matplotlib
    except ImportError:
        print("[warn] 没装 matplotlib，跳过 results.png")
        return

    matplotlib.use("Agg")
    import matplotlib.pyplot as plt

    with csv_path.open(encoding="utf-8", newline="") as handle:
        rows = list(csv.DictReader(handle))
    if not rows:
        print(f"[warn] {csv_path} 里没有数据行，跳过 results.png")
        return
    epochs = [int(row["epoch"]) for row in rows]
    fig, axes = plt.subplots(1, 2, figsize=(10, 4))
    action_mode = "train/accuracy" in rows[0]
    loss_keys = ("train/loss", "val/loss") if action_mode else ("train/loss", "train/angle", "train/length", "val/loss", "val/angle", "val/length")
    auxiliary_keys = ("train/accuracy", "val/accuracy") if action_mode else ("train/angle", "val/angle", "train/length", "val/length")
    for key in loss_keys:
        axes[0].plot(epochs, [float(row[key]) for row in rows], marker=".", linewidth=1, label=key)
    for key in auxiliary_keys:
        axes[1].plot(epochs, [float(row[key]) for row in rows], marker=".", linewidth=1, label=key)
    axes[0].set_title("loss")
    axes[1].set_title("action accuracy" if action_mode else "angle / length")
    for ax in axes:
        ax.set_xlabel("epoch")
        ax.legend()
        ax.grid(alpha=0.3)
    fig.tight_layout()
    fig.savefig(csv_path.parent / "results.png", dpi=150)
    plt.close(fig)


def _run_dir(project, name):
    """固定目录名。重跑就改 train.py 里的 name，别自动加数字后缀——
    约束 10 要求一次实验只看 runs/train/<实验名>/ 一个目录。"""
    return Path(__file__).resolve().parents[2] / project / name
