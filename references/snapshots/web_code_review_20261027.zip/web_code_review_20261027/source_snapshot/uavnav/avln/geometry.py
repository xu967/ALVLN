"""机体坐标与 TravelUAV 的 generate_merged_json 一致。"""

import numpy as np
from scipy.spatial.transform import Rotation as R


def validate_aerial_teacher_review(review, scene_id):
    """审核合同结构与已记录case一致性；不代替真实场景复验。"""
    import re
    required = {"schema_version", "protocol", "scene_id", "source_sha256", "assets_sha256", "checks", "cases"}
    checks = {"on_route_pose_orientation", "off_route_pose", "route_order", "stop_pose", "graph_connectivity"}
    if (not isinstance(review, dict) or set(review) != required or type(review["schema_version"]) is not int
            or review["schema_version"] != 1 or review["protocol"] != "airvln_upstream_pose_guard_v1"
            or type(scene_id) is not int or review["scene_id"] != scene_id):
        raise ValueError("DAgger教师审核版本/场景不符")
    if (not isinstance(review["checks"], dict) or set(review["checks"]) != checks
            or any(value is not True for value in review["checks"].values())):
        raise ValueError("教师位姿/偏轨/阶段/STOP/图连通性审核尚未通过")
    for key, expected in (("source_sha256", {"utils/env_utils.py", "utils/shorest_path_sensor.py", "airsim_plugin/airsim_settings.py"}),
                          ("assets_sha256", {"graph", "tokens"})):
        if (not isinstance(review[key], dict) or set(review[key]) != expected
                or any(not isinstance(d, str) or re.fullmatch(r"[0-9a-f]{64}", d) is None for d in review[key].values())):
            raise ValueError("教师源码/导航图审核SHA字段不完整")
    cases = review["cases"]
    if not isinstance(cases, list) or not cases:
        raise ValueError("教师审核需要实际case记录")
    names = set()
    for case in cases:
        fields = {"name", "kind", "current_position", "current_orientation_xyzw", "reference_stage", "expected_action", "observed_action"}
        if (not isinstance(case, dict) or set(case) != fields or not isinstance(case["name"], str) or not case["name"].strip()
                or case["name"] in names or case["kind"] not in checks):
            raise ValueError("教师case身份/种类不完整或重复")
        names.add(case["name"])
        p, q = np.asarray(case["current_position"], dtype=float), np.asarray(case["current_orientation_xyzw"], dtype=float)
        if (p.shape != (3,) or q.shape != (4,) or not np.isfinite(p).all() or not np.isfinite(q).all()
                or abs(np.linalg.norm(q) - 1) > 1e-4 or type(case["reference_stage"]) is not int or case["reference_stage"] < 0
                or type(case["expected_action"]) is not int or not 0 <= case["expected_action"] < 8
                or type(case["observed_action"]) is not int or case["observed_action"] != case["expected_action"]):
            raise ValueError("教师case位姿/标签不合法或实际预测未通过")
    if {case["kind"] for case in cases} != checks:
        raise ValueError("教师case未覆盖全部语义审核项")
    return review


class AirVLNDaggerTeacher:
    """冻结源码直接复用的训练期教师；缺导航图或语义审核即拒绝采集。

    不进入部署策略。上游仅XYZ的参考索引快捷分支由本适配层校朝向；
    同XYZ但错朝向时拒绝标签，不把参考动作强贴到学生状态。
    """

    def __init__(self, upstream_root, nav_graph_path, token_dict_path, scene_id, review_path):
        import ast
        import copy
        import hashlib
        import importlib.util
        import json
        import math
        import logging
        from pathlib import Path
        from types import SimpleNamespace
        import airsim

        root, graph_root, token_root = map(Path, (upstream_root, nav_graph_path, token_dict_path))
        self.review = validate_aerial_teacher_review(json.loads(Path(review_path).read_text(encoding="utf-8")), scene_id)
        required = {"schema_version", "protocol", "scene_id", "source_sha256", "assets_sha256", "checks", "cases"}
        if (set(self.review) != required or self.review["schema_version"] != 1
                or self.review["protocol"] != "airvln_upstream_pose_guard_v1"
                or self.review["scene_id"] != scene_id):
            raise ValueError("DAgger需要与场景绑定的上游教师审核合同")
        checks = {"on_route_pose_orientation", "off_route_pose", "route_order", "stop_pose", "graph_connectivity"}
        if (set(self.review["checks"]) != checks or any(v is not True for v in self.review["checks"].values())
                or not isinstance(self.review["cases"], list) or len(self.review["cases"]) < 5):
            raise ValueError("DAgger教师尚未通过位姿/阶段/STOP/导航图语义审核")
        files = {"utils/env_utils.py": root / "utils/env_utils.py",
                 "utils/shorest_path_sensor.py": root / "utils/shorest_path_sensor.py",
                 "airsim_plugin/airsim_settings.py": root / "airsim_plugin/airsim_settings.py"}
        actual = {key: hashlib.sha256(path.read_bytes()).hexdigest() for key, path in files.items()}
        if actual != self.review["source_sha256"]:
            raise ValueError("上游教师源码与审核版本不一致")
        assets = {"graph": graph_root / f"nav_graph_dict_{scene_id}.pkl",
                  "tokens": token_root / f"TokenDict_{scene_id}.json"}
        if {key: hashlib.sha256(path.read_bytes()).hexdigest() for key, path in assets.items()} != self.review["assets_sha256"]:
            raise ValueError("教师导航图/节点数据与审核版本不一致")
        def load_file(name, path):
            spec = importlib.util.spec_from_file_location(name, path)
            module = importlib.util.module_from_spec(spec)
            tree = ast.parse(path.read_text(encoding="utf-8"))
            # 禁止Numba在只读上游树写缓存；保留装饰器和原函数数值行为。
            for node in ast.walk(tree):
                if isinstance(node, ast.FunctionDef):
                    for decorator in node.decorator_list:
                        if (isinstance(decorator, ast.Call) and isinstance(decorator.func, ast.Attribute)
                                and isinstance(decorator.func.value, ast.Name)
                                and decorator.func.value.id == "nb" and decorator.func.attr == "njit"):
                            for keyword in decorator.keywords:
                                if keyword.arg == "cache":
                                    keyword.value = ast.Constant(value=False)
            exec(compile(ast.fix_missing_locations(tree), str(path), "exec"), module.__dict__)
            return module
        settings = load_file("uavnav_airvln_teacher_actions", files["airsim_plugin/airsim_settings.py"])
        sensor_module = load_file("uavnav_airvln_teacher_graph", files["utils/shorest_path_sensor.py"])
        self.sensor = sensor_module.ShortestPathSensor(str(graph_root), str(token_root), [scene_id])
        tokens, graph = self.sensor.token_dicts[scene_id], self.sensor.graphs[scene_id]
        points = np.asarray(list(tokens.values()), dtype=float)
        if (not tokens or points.shape != (len(tokens), 3) or not np.isfinite(points).all()
                or any(not isinstance(key, str) or not key for key in tokens)
                or graph.vcount() != len(tokens) or set(graph.vs["name"]) != set(tokens)
                or not graph.is_connected()):
            raise ValueError("教师节点必须有限且与非空连通导航图匹配，拒绝空图近邻无限搜索")
        weights = np.asarray(graph.es["weight"], dtype=float)
        if weights.shape != (graph.ecount(),) or not np.isfinite(weights).all() or (weights < 0).any():
            raise ValueError("教师导航图边权不合法")
        # 只隔离导入与全局args/logger；函数体直接编译冻结上游AST，不改教师算法。
        tree = ast.parse(files["utils/env_utils.py"].read_text(encoding="utf-8"))
        names = {"SimState", "get_teacher_action_at", "find_waypoint_at", "find_carrot_pos",
                 "getPoseAfterMakeAction", "get_progress_sensor_at", "cast_point_to_nearest_node_in_nav_graph_2", "VerticesPreprocess", "WhereIs3"}
        nodes = [node for node in tree.body if isinstance(node, (ast.FunctionDef, ast.ClassDef)) and node.name in names]
        for node in nodes:
            if isinstance(node, ast.FunctionDef) and node.decorator_list:
                # 缓存装饰器不能在抽取AST时写上游目录；函数体/数值语义保持。
                node.decorator_list = []
        namespace = dict(math=math, np=np, copy=copy, airsim=airsim,
                         AirsimActions=settings.AirsimActions, AirsimActionSettings=settings.AirsimActionSettings,
                         args=SimpleNamespace(dagger_mode="nearest"), ShortestPathSensor=sensor_module.ShortestPathSensor,
                         logger=logging.getLogger("uavnav.airvln_teacher"),
                         EuclideanDistance3=sensor_module.EuclideanDistance3, EuclideanDistance1=sensor_module.EuclideanDistance1)
        exec(compile(ast.Module(body=nodes, type_ignores=[]), str(files["utils/env_utils.py"]), "exec"), namespace)
        self.namespace, self.scene_id, self.state = namespace, scene_id, None
        self.contract_sha256 = hashlib.sha256(json.dumps(self.review, sort_keys=True, separators=(",", ":"),
                                                         ensure_ascii=False, allow_nan=False).encode()).hexdigest()

    def reset_episode(self, episode):
        from copy import deepcopy
        if episode["scene_id"] != self.scene_id or not episode.get("actions"):
            raise ValueError("教师episode不属于当前已审核训练场景")
        self.episode = deepcopy(episode)
        self.state = None

    def label(self, observation, step, executed_actions):
        if (type(step) is not int or step < 0 or len(executed_actions) != step
                or any(type(action) is not int or not 1 <= action < 8 for action in executed_actions)):
            raise ValueError("教师时序必须绑定真实已执行动作")
        ns = self.namespace
        if self.state is None:
            self.state = ns["SimState"](index=0, step=0, episode_info=self.episode)
            _, _, self.state.unique_path = ns["find_carrot_pos"](
                observation.position.tolist(), 0, self.episode["reference_path"], None)
        sdk = ns["airsim"]
        self.state.pose = sdk.Pose(sdk.Vector3r(*observation.position), sdk.Quaternionr(*observation.orientation))
        self.state.step, self.state.pre_action = step, executed_actions[-1] if executed_actions else 0
        path = self.episode["reference_path"]
        if step < len(path) and np.allclose(observation.position, path[step][:3], atol=1e-3, rtol=1e-5):
            expected = R.from_euler("xyz", [path[step][4], path[step][3], path[step][5]])
            if (expected.inv() * R.from_quat(observation.orientation)).magnitude() > 1e-4:
                raise ValueError("教师XYZ索引快捷分支朝向不符，拒绝伪纠偏标签")
        action, self.state = ns["get_teacher_action_at"](
            0, self.state, {self.scene_id: self.sensor.token_dicts[self.scene_id]}, self.sensor)
        # 官方ENV在每个教师动作后更新进度；快捷参考分支也必须执行，
        # 否则第一次偏轨时会从初始carrot搜索，将长路线学生引回前段。
        _, self.state = ns["get_progress_sensor_at"](
            0, self.state, {self.scene_id: self.sensor.token_dicts[self.scene_id]}, self.sensor)
        if type(action) not in (int, np.int64, np.int32) or not 0 <= action < 8:
            raise ValueError("上游教师返回非法动作")
        if action == 0:
            goal = np.asarray(self.episode["goals"][0]["position"])
            if (self.state.pre_carrot_idx < len(self.state.unique_path) - 1
                    or np.linalg.norm(observation.position - goal) > 20):
                # 参考末帧快捷分支可能未更新carrot；必须确实位于末参考pose。
                if not (step == len(path) - 1 and np.linalg.norm(observation.position - path[-1][:3]) <= .02):
                    raise ValueError("教师STOP尚未满足路线阶段与目标审核条件")
        return {"action": int(action), "teacher_protocol": "airvln_upstream_pose_guard_v1",
                "teacher_contract_sha256": self.contract_sha256, "reference_stage": self.state.pre_carrot_idx}


def aerial_pose_transition(pose, action):
    """AirVLN八动作转换，单个6维pose或N×6 pose与N个整数动作。"""
    state = np.asarray(pose, dtype=np.float64)
    scalar = state.shape == (6,)
    if (not scalar and (state.ndim != 2 or state.shape[1] != 6)) or not np.isfinite(state).all():
        raise ValueError("AerialVLN pose必须为有限6维或N×6状态")
    if scalar:
        if isinstance(action, (bool, np.bool_)) or not isinstance(action, (int, np.integer)) or not 0 <= action < 8:
            raise ValueError("AerialVLN action必须是0至7的整数")
        actions = np.asarray([action], dtype=np.int64)
        result = state.reshape(1, 6).copy()
    else:
        # 混合[1,True]经NumPy转换后会变为整数，必须先保留原类型核验。
        if isinstance(action, (list, tuple)) and any(isinstance(value, (bool, np.bool_)) for value in action):
            raise ValueError("AerialVLN action数组不能包含布尔标签")
        actions = np.asarray(action)
        if (actions.shape != (len(state),) or actions.dtype.kind not in "iu"
                or ((actions < 0) | (actions > 7)).any()):
            raise ValueError("AerialVLN action必须是与pose等长的0至7整数数组")
        result = state.copy()
    yaw = result[:, 5].copy()
    forward = actions == 1
    result[forward, 0] += 5 * np.cos(yaw[forward])
    result[forward, 1] += 5 * np.sin(yaw[forward])
    turn = (actions == 2) | (actions == 3)
    result[turn, 3:5] = 0
    result[turn, 5] = (yaw[turn] + np.where(actions[turn] == 2, -1, 1) * np.pi / 12 + np.pi) % (2 * np.pi) - np.pi
    vertical = (actions == 4) | (actions == 5)
    result[vertical, 2] += np.where(actions[vertical] == 4, -2, 2)
    lateral = (actions == 6) | (actions == 7)
    sign = np.where(actions[lateral] == 6, 5, -5)
    result[lateral, 0] += sign * np.sin(yaw[lateral])
    result[lateral, 1] -= sign * np.cos(yaw[lateral])
    return result[0] if scalar else result


def body_offset(position, orientation, origin_position, origin_orientation):
    """把世界坐标中的 position 变到 origin 的机体坐标。

    数据中的姿态是标准四元数顺序 (x, y, z, w)。直接使用四元数构造
    旋转矩阵，避免先转欧拉角时交换 roll 和 pitch 轴。
    """
    delta = np.asarray(position, dtype=np.float64) - np.asarray(origin_position, dtype=np.float64)
    quaternion = np.asarray(origin_orientation, dtype=np.float64)
    if quaternion.shape != (4,) or not np.isfinite(quaternion).all():
        raise ValueError(f"无效姿态四元数: shape={quaternion.shape}, value={origin_orientation}")
    if np.linalg.norm(quaternion) < 1e-12:
        raise ValueError("姿态四元数范数过小")
    rotation = R.from_quat(quaternion).as_matrix()
    return rotation.T @ delta
