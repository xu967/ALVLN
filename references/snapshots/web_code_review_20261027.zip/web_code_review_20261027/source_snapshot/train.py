"""路线训练的唯一配置入口；旧FOV需显式选择。"""

import json
import os
from pathlib import Path

from uavnav.avln.model import TEXT_QUERY_MODES


AIRVLN_BASELINES = ("airvln_seq2seq_rgb_v1", "airvln_cma_rgb_v1", "airvln_seq2seq_rgbd_v1", "airvln_cma_rgbd_v1")


def aerial_training_parameters(overrides=None):
    """唯一的路线训练配置入口；验收程序只能显式覆盖实验范围。"""
    cache_manifest = os.environ.get("UAVNAV_CACHE_MANIFEST")
    annotation_root = os.environ.get("UAVNAV_DATA_ROOT", r"D:\datasets\aerialvln\DATA\data\aerialvln-s" if os.name == "nt"
                                     else "/root/rivermind-data/aerialvln/DATA/data/aerialvln-s")
    architecture = os.environ.get("UAVNAV_ARCHITECTURE", "aerial_route_recurrent_v2")
    if architecture not in ("aerial_route_v1", "aerial_route_recurrent_v2", "aerial_route_recurrent_clause_v3", "aerial_route_recurrent_rgbd_v3", "aerial_route_dino_v5", *AIRVLN_BASELINES):
        raise ValueError("未知AerialVLN-S路线架构")
    imgsz = int(os.environ.get("UAVNAV_IMGSZ", "224"))
    parameters = dict(stage=os.environ.get("UAVNAV_STAGE", "bc"),
                      warm_start_checkpoint=os.environ.get("UAVNAV_WARM_START_CHECKPOINT"),
                      resume_checkpoint=os.environ.get("UAVNAV_RESUME_CHECKPOINT"),
                      dagger_manifests=json.loads(os.environ.get("UAVNAV_DAGGER_MANIFESTS", "[]")),
                      require_full_train=os.environ.get("UAVNAV_REQUIRE_FULL_TRAIN", "0") == "1",
                      annotation_root=annotation_root, cache_manifest=cache_manifest,
                      architecture=architecture,
                      memory_mode=os.environ.get("UAVNAV_MEMORY_MODE", "carry") if architecture != "aerial_route_v1" else None,
                      validation_cache_manifest=os.environ.get("UAVNAV_VALIDATION_CACHE_MANIFEST"),
                      render_pass_manifests=json.loads(os.environ.get("UAVNAV_RENDER_PASS_MANIFESTS", "[]")),
                      render_pass_seed=int(os.environ.get("UAVNAV_RENDER_PASS_SEED", "0")),
                      vision_feature_cache=os.environ.get("UAVNAV_VISION_FEATURE_CACHE"),
                      vision_feature_cache_dtype=os.environ.get("UAVNAV_VISION_CACHE_DTYPE", "float32"),
                      history_dropout=float(os.environ.get("UAVNAV_HISTORY_DROPOUT", "0")),
                      text_feature_cache=os.environ.get("UAVNAV_TEXT_FEATURE_CACHE"),
                      sample_index_mode=os.environ.get("UAVNAV_SAMPLE_INDEX", "off"),
                      sample_index_dir=os.environ.get("UAVNAV_SAMPLE_INDEX_DIR"),
                      # 官方 AirVLN 冻结预训练视觉骨干。循环路线模型沿用该默认；
                      # 旧 v1 兼容路径保留原 finetune 语义，视觉微调必须显式用于新路线对照。
                      vision_train_policy=os.environ.get(
                          "UAVNAV_VISION_TRAIN_POLICY",
                          "finetune" if architecture == "aerial_route_v1" else "frozen",
                      ),
                      upstream_root=os.environ.get("UAVNAV_UPSTREAM_ROOT"),
                      upstream_project_prefix=os.environ.get("UAVNAV_UPSTREAM_PROJECT_PREFIX"),
                      upstream_log_dir=os.environ.get("UAVNAV_UPSTREAM_LOG_DIR"),
                      upstream_source_sha256=json.loads(os.environ.get("UAVNAV_UPSTREAM_SOURCE_SHA256", "null")),
                      ddppo_checkpoint_sha256=os.environ.get("UAVNAV_DDPPO_CHECKPOINT_SHA256"),
                      validation_split=os.environ.get("UAVNAV_VALIDATION_SPLIT", "development_train_grouped"),
                      development_fraction=float(os.environ.get("UAVNAV_DEVELOPMENT_FRACTION", "0.2")),
                      development_split_seed=int(os.environ.get("UAVNAV_DEVELOPMENT_SPLIT_SEED", "0")),
                      development_split_manifest=os.environ.get("UAVNAV_DEVELOPMENT_SPLIT_MANIFEST"),
                      epochs=int(os.environ.get("UAVNAV_EPOCHS", "20")),
                      candidate_epochs=json.loads(os.environ.get("UAVNAV_CANDIDATE_EPOCHS", "[]")),
                      diagnostics_interval=int(os.environ.get("UAVNAV_DIAGNOSTICS_INTERVAL", "128")),
                      batch=int(os.environ.get("UAVNAV_BATCH", "4" if os.name == "nt" else "64")),
                      workers=int(os.environ.get("UAVNAV_WORKERS", "0")),
                      lr=1e-4, imgsz=imgsz, history=8, seed=0, device=os.environ.get("UAVNAV_DEVICE", "cuda"),
                      dino_repo=os.environ.get("UAVNAV_DINO_REPO"),
                      dino_weights=os.environ.get("UAVNAV_DINO_WEIGHTS"),
                      dino_variant=os.environ.get("UAVNAV_DINO_VARIANT", "vits16"),
                      dino_input_size=imgsz,
                      dino_frozen=os.environ.get("UAVNAV_DINO_FROZEN", "1") == "1",
                      backbone=os.environ.get("UAVNAV_BACKBONE", "resnet50" if architecture in AIRVLN_BASELINES else "resnet18"),
                      visual_fusion=os.environ.get("UAVNAV_VISUAL_FUSION", "global" if architecture.startswith("airvln_seq2seq_") else "spatial"),
                      ablate=os.environ.get("UAVNAV_ABLATE", "none"),
                      text_control=os.environ.get("UAVNAV_TEXT_CONTROL", "original"),
                      text_query_mode=os.environ.get("UAVNAV_TEXT_QUERY_MODE", "visual_history"),
                      sequence_chunk_size=int(os.environ.get("UAVNAV_SEQUENCE_CHUNK", "16")),
                      **({"episode_batch": int(os.environ["UAVNAV_EPISODE_BATCH"])} if os.environ.get("UAVNAV_EPISODE_BATCH") else {}),
                      loss_protocol={"version": os.environ.get("UAVNAV_LOSS_VERSION", "transition_weighted_ce_v1"),
                                     "inflection_weight": float(os.environ.get("UAVNAV_INFLECTION_WEIGHT", "1.9")),
                                     "stop_weight": float(os.environ.get("UAVNAV_STOP_WEIGHT", "1.9")),
                                     "normalization": "episode_sum_weights" if os.environ.get("UAVNAV_LOSS_VERSION") == "episode_normalized_ce_v2" else "sum_weights"},
                      pretrained=os.environ.get("UAVNAV_PRETRAINED", "1") == "1",
                      project=str(Path(__file__).resolve().parent / "runs/train"),
                      name=os.environ.get("UAVNAV_NAME")
    )
    if overrides:
        unknown = set(overrides) - set(parameters)
        if unknown:
            raise ValueError(f"未知路线训练配置: {sorted(unknown)}")
        parameters.update(overrides)
    if (not overrides or "vision_train_policy" not in overrides) and "UAVNAV_VISION_TRAIN_POLICY" not in os.environ:
        # 架构可能被 overrides 改写；默认视觉策略必须依据最终架构。
        parameters["vision_train_policy"] = "finetune" if parameters["architecture"] == "aerial_route_v1" else "frozen"
    if (not overrides or "backbone" not in overrides) and "UAVNAV_BACKBONE" not in os.environ:
        if parameters["architecture"] == "aerial_route_dino_v5":
            parameters["backbone"] = f"dinov3_{parameters['dino_variant']}"
        else:
            parameters["backbone"] = "resnet50" if parameters["architecture"] in AIRVLN_BASELINES else "resnet18"
    if parameters["architecture"] == "aerial_route_dino_v5":
        if overrides and "dino_input_size" in overrides and overrides["dino_input_size"] != parameters["imgsz"]:
            raise ValueError("dino_input_size必须等于imgsz")
        expected_backbone = f"dinov3_{parameters['dino_variant']}"
        if parameters["backbone"] != expected_backbone:
            raise ValueError("v5 backbone必须与dino_variant一致")
        if parameters["visual_fusion"] != "spatial":
            raise ValueError("v5只支持spatial视觉融合")
        parameters["dino_input_size"] = parameters["imgsz"]
    else:
        dino_fields = ("dino_repo", "dino_weights", "dino_variant", "dino_input_size", "dino_frozen")
        dino_env = ("UAVNAV_DINO_REPO", "UAVNAV_DINO_WEIGHTS", "UAVNAV_DINO_VARIANT", "UAVNAV_DINO_FROZEN")
        if ((overrides and any(key in overrides for key in dino_fields))
                or any(key in os.environ for key in dino_env)):
            raise ValueError("DINOv3配置只用于aerial_route_dino_v5；切回其他架构前清除DINO环境变量")
        for key in dino_fields:
            parameters.pop(key, None)
    if (not overrides or "visual_fusion" not in overrides) and "UAVNAV_VISUAL_FUSION" not in os.environ:
        parameters["visual_fusion"] = "global" if parameters["architecture"].startswith("airvln_seq2seq_") else "spatial"
    from uavnav.avln.fit import validate_training_controls
    validate_training_controls(parameters)
    if parameters["architecture"] == "aerial_route_v1":
        parameters["memory_mode"] = None
        if parameters["text_query_mode"] != "visual_history":
            raise ValueError("状态条件文本查询仅支持aerial_route_recurrent_v2")
    elif not overrides or "memory_mode" not in overrides:
        parameters["memory_mode"] = os.environ.get("UAVNAV_MEMORY_MODE", "carry")
    if not parameters["cache_manifest"] or not parameters["validation_cache_manifest"]:
        raise ValueError("AerialVLN-S训练需要独立train和validation真实缓存，不能只提供标注JSON")
    if (not isinstance(parameters["render_pass_manifests"], list)
            or any(not isinstance(path, (str, Path)) or not str(path).strip()
                   for path in parameters["render_pass_manifests"])):
        raise ValueError("render_pass_manifests必须是额外缓存清单路径的JSON列表")
    if parameters["vision_train_policy"] not in ("finetune", "frozen"):
        raise ValueError("vision_train_policy仅支持finetune/frozen")
    if parameters["architecture"] == "aerial_route_v1" and (
            parameters["vision_train_policy"] != "finetune" or parameters["render_pass_manifests"]):
        raise ValueError("完全冻结和多pass训练仅支持aerial_route_recurrent_v2")
    if parameters["architecture"] in AIRVLN_BASELINES:
        if (parameters["vision_train_policy"] != "frozen" or parameters["render_pass_manifests"]
                or parameters["memory_mode"] != "carry" or parameters["text_control"] != "original"
                or parameters["text_query_mode"] != "visual_history"
                or parameters["ablate"] != "none" or parameters["backbone"] != "resnet50"
                or parameters["visual_fusion"] != ("global" if parameters["architecture"].startswith("airvln_seq2seq_") else "spatial")):
            raise ValueError("本轮官方RGB网络对照固定真实ResNet50、carry记忆、原指令及单次渲染")
        parameters["hidden"] = 512
    else:
        for field in ("upstream_root", "upstream_project_prefix", "upstream_log_dir", "upstream_source_sha256", "ddppo_checkpoint_sha256"):
            parameters.pop(field)
    if parameters["text_query_mode"] not in TEXT_QUERY_MODES:
        raise ValueError(f"text_query_mode必须属于{TEXT_QUERY_MODES}")
    if parameters["architecture"] != "aerial_route_recurrent_v2" and parameters["text_query_mode"] != "visual_history":
        raise ValueError("状态条件文本查询仅支持aerial_route_recurrent_v2")
    if (not overrides or "name" not in overrides) and "UAVNAV_NAME" not in os.environ:
        parameters["name"] = f"{parameters['architecture']}_{parameters['backbone']}_{parameters['visual_fusion']}_seed{parameters['seed']}"
    return parameters


def lani_training_parameters(overrides=None):
    """Independent four-action full LANI BC contract, seed0 only."""
    architecture = os.environ.get("UAVNAV_ARCHITECTURE", "lani_dino_recurrent_v1")
    parameters = dict(architecture=architecture, seed=0, device=os.environ.get("UAVNAV_DEVICE", "cuda"),
                      annotation_root=os.environ.get("UAVNAV_DATA_ROOT"),
                      cache_manifest=os.environ.get("UAVNAV_CACHE_MANIFEST"),
                      validation_cache_manifest=os.environ.get("UAVNAV_VALIDATION_CACHE_MANIFEST"),
                      dino_repo=os.environ.get("UAVNAV_DINO_REPO"), dino_weights=os.environ.get("UAVNAV_DINO_WEIGHTS"),
                      upstream_root=os.environ.get("UAVNAV_UPSTREAM_ROOT"), hidden=128, history_frames=8,
                      imgsz=224 if architecture == "lani_dino_recurrent_v1" else 128,
                      max_episode_length=512, epochs=int(os.environ.get("UAVNAV_EPOCHS", "20")),
                      require_full_train=os.environ.get("UAVNAV_LANI_DIAGNOSTIC", "0") != "1",
                      sequence_chunk_size=int(os.environ.get("UAVNAV_SEQUENCE_CHUNK", "16")), lr=1e-4,
                      project=os.environ.get("UAVNAV_LANI_PROJECT", str(Path(__file__).resolve().parent / "runs/train")),
                      name=os.environ.get("UAVNAV_NAME", f"{architecture}_full_seed0"))
    if overrides:
        unknown = set(overrides) - set(parameters)
        if unknown:
            raise ValueError(f"Unknown LANI training controls: {sorted(unknown)}")
        parameters.update(overrides)
    return parameters


def train(dataset=None, overrides=None):
    dataset = dataset or os.environ.get("UAVNAV_DATASET", "aerialvln_s_v1")
    if dataset == "lani_v1":
        from uavnav.lani.fit import fit_lani
        return fit_lani(**lani_training_parameters(overrides))
    if dataset not in ("uav_vln_fov", "aerialvln_s_v1"):
        raise ValueError("UAVNAV_DATASET只接受uav_vln_fov、aerialvln_s_v1或lani_v1")
    if dataset == "aerialvln_s_v1":
        from uavnav.avln.fit import fit_aerial
        return fit_aerial(**aerial_training_parameters(overrides))
    if overrides:
        raise ValueError("旧FOV入口保留原配置；不要给它传路线覆盖参数")
    # 服务器（GPU）上：
    #   data_root       = "/root/rivermind-data/uav_vln_fov/train"
    #   instruction_json = "/root/rivermind-data/uav_vln_fov/meta/train_scene_trajectory_instruction_direction.json"
    # 环境变量优先，避免在本地和服务器之间手动改代码。
    if os.name == "nt":
        default_root = r"D:\datasets\uav_vln_fov\train"
        default_instruction = r"D:\datasets\uav_vln_fov\meta\train_scene_trajectory_instruction_direction.json"
    else:
        default_root = "/root/rivermind-data/uav_vln_fov/train"
        default_instruction = "/root/rivermind-data/uav_vln_fov/meta/train_scene_trajectory_instruction_direction.json"
    data_root = os.environ.get("UAVNAV_DATA_ROOT", default_root)   # 指到 split 层
    list_json = "train.json"                       # 相对 data_root，每项含 {"dir": "<Map>/<uuid>"}
    instruction_json = os.environ.get("UAVNAV_INSTRUCTION_JSON", default_instruction)
    epochs = int(os.environ.get("UAVNAV_EPOCHS", "20"))
    # batch 和 workers 要一起看。瓶颈在 CPU 解 png，不在 GPU：workers=2 时GPU 约九成
    # 时间在空等。workers 先拉起来，再谈 batch，顺序反了 batch 调大也没收益。
    batch = int(os.environ.get("UAVNAV_BATCH", "4" if os.name == "nt" else "64"))
    lr = 1e-4                  # backbone 用它的 0.1 倍，见 fit() 里的分组
    imgsz = 224
    history = 8
    workers = int(os.environ.get("UAVNAV_WORKERS", "0" if os.name == "nt" else "12"))
    val_ratio = 0.1             # 按轨迹切验证集的比例，不是按帧
    strip_direction = True      # 去掉句末 "It's straight ahead." 这类初始朝向线索
    seed = 0
    split_seed = 0             # 固定轨迹划分，后续更换训练seed仍沿用同一验证集
    device = os.environ.get("UAVNAV_DEVICE", "cuda")
    ablate = "none"             # "no_image" 去视觉 / "no_history" 去惯性 / "no_text" 去指令
    fusion_mode = "query_plus_text"  # 只改变视觉/历史 query 到动作头的直接通路
    architecture = "grounded_v1"
    backbone = os.environ.get("UAVNAV_BACKBONE", "resnet18")
    visual_fusion = os.environ.get("UAVNAV_VISUAL_FUSION", "spatial")
    grid_size = 4
    stop_enabled = False         # 没有已审核完成标签时禁止启用STOP训练
    split_manifest_source = str(Path(__file__).resolve().parent / "runs/train/avln_fixedgap_seed0/split_manifest.json")
    project = "runs/train"
    # 一次实验一个目录。同名目录里已有结果时会自动改名归档，不会往旧 results.csv 上追加
    name = os.environ.get("UAVNAV_NAME", f"avln_grounded_{backbone}_{visual_fusion}_seed{seed}")

    from uavnav.avln.fit import fit

    fit(
        data_root=data_root,
        list_json=list_json,
        instruction_json=instruction_json,
        epochs=epochs,
        batch=batch,
        lr=lr,
        imgsz=imgsz,
        history=history,
        workers=workers,
        val_ratio=val_ratio,
        strip_direction=strip_direction,
        seed=seed,
        split_seed=split_seed,
        device=device,
        ablate=ablate,
        fusion_mode=fusion_mode,
        architecture=architecture,
        backbone=backbone,
        visual_fusion=visual_fusion,
        grid_size=grid_size,
        stop_enabled=stop_enabled,
        split_manifest_source=split_manifest_source,
        project=project,
        name=name,
    )


if __name__ == "__main__":
    import argparse
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--dataset", choices=("aerialvln_s_v1", "uav_vln_fov", "lani_v1"))
    args = parser.parse_args()
    train(dataset=args.dataset)
