"""LANI source isolation, corruption rejection and causal episode contracts."""

import hashlib
import json
from pathlib import Path
import tempfile
import unittest

import numpy as np
from PIL import Image

from uavnav.lani.data import LANIVocabulary, LaniTeacherCache


class LaniCacheTests(unittest.TestCase):
    def setUp(self):
        self.tmp = tempfile.TemporaryDirectory()
        self.addCleanup(self.tmp.cleanup)
        self.root = Path(self.tmp.name)
        self.vocab = LANIVocabulary({"<PAD>": 0, "<UNK>": 1, "turn": 2}, "a"*64)
        images, shas = [], []
        for step in range(4):
            path = self.root / f"{step}.png"
            Image.fromarray(np.full((128,128,3),step*40,dtype=np.uint8)).save(path)
            images.append(path.name)
            shas.append(hashlib.sha256(path.read_bytes()).hexdigest())
        self.row = dict(task_id="scene_0001_00", split="train", instruction="turn unseen", actions=[0,1,2,3],
                        images=images, image_sha256=shas, native_size=[128,128],
                        source_shas={key: "a"*64 for key in ("annotation","config","scene_config","scene_path","official_vocab")})
        self.manifest = dict(protocol="lani_teacher_cache_v1", split="train", native_size=[128,128],
                             source_annotation_sha256="a"*64, source_config_sha256="a"*64, episodes=[self.row])

    def cache(self):
        path = self.root / "manifest.json"
        path.write_text(json.dumps(self.manifest))
        return LaniTeacherCache(path, self.vocab)

    def test_history_is_past_only_and_continues_at_chunk_boundary(self):
        chunks = list(self.cache().iter_chunks(2,history_frames=2))
        np.testing.assert_array_equal(chunks[0]["history_length"],[0,1])
        np.testing.assert_array_equal(chunks[1]["history"][0],[[1,0,0,0],[0,1,0,0]])
        np.testing.assert_array_equal(chunks[1]["history"][1],[[0,1,0,0],[0,0,1,0]])
        self.assertTrue(chunks[0]["episode_start"])
        self.assertTrue(chunks[1]["episode_end"])
        self.assertEqual(chunks[0]["tokens"][0].tolist(),[2,1])

    def test_corrupt_image_is_rejected_before_model_use(self):
        cache = self.cache()
        (self.root/"0.png").write_bytes(b"changed")
        with self.assertRaisesRegex(ValueError,"SHA256 mismatch"):
            next(cache.iter_chunks(2))

    def test_internal_stop_and_truncated_episode_are_rejected(self):
        self.row["actions"]=[0,3,2,3]
        with self.assertRaisesRegex(ValueError,"terminal STOP"):
            self.cache()
        self.row["actions"]=[0,1,2,3]
        self.row["images"].pop()
        with self.assertRaisesRegex(ValueError,"lengths differ"):
            self.cache()

    def test_source_disagreement_is_rejected(self):
        self.row["source_shas"]["annotation"]="b"*64
        with self.assertRaisesRegex(ValueError,"source disagrees"):
            self.cache()

    def test_outside_image_path_is_rejected(self):
        self.row["images"][0]="../outside.png"
        with self.assertRaisesRegex(ValueError,"Unsafe"):
            self.cache()


if __name__ == "__main__":
    unittest.main()
