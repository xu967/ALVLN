"""Fusion compatibility and information-path regressions; no navigation claims."""

import copy
import csv
import os
import unittest
from unittest.mock import patch
from pathlib import Path
from tempfile import TemporaryDirectory

import torch
from torch import nn

from uavnav.avln.data import IMAGENET_MEAN, IMAGENET_STD, Vocab
from uavnav.avln.fit import _append_csv, split_from_manifest, prediction_loss, _evaluate, _json_sha256, _aerial_epoch, _aerial_sequence_epoch, sample_content_sha256
from uavnav.avln.inference import AerialActionPredictor, CheckpointFormatError, WaypointPredictor, _validate_checkpoint
from uavnav.avln.metadata import aerial_task_protocol, task_protocol_sha256
from uavnav.avln.model import AerialRecurrentRouteNet, AerialRouteNet, GroundedWaypointNet, WaypointNet, build_model


def batch():
    return {"image": torch.zeros(2, 3, 8, 8), "tokens": torch.tensor([[2], [2]]),
            "token_mask": torch.ones(2, 1, dtype=torch.bool),
            "history": torch.zeros(2, 2, 3), "history_length": torch.tensor([2, 2])}


def controlled_model(mode):
    model = WaypointNet(3, history_frames=2, hidden=4, ablate="no_image", pretrained=False,
                        fusion_mode=mode).eval()
    # A deterministic fixture exposes only one history coordinate through query.
    model.vision = nn.Sequential(nn.AdaptiveAvgPool2d(1), nn.Conv2d(3, 2048, 1, bias=False))
    with torch.no_grad():
        model.vision[1].weight.zero_()
        model.vision_proj.weight.zero_()
        model.vision_proj.bias.zero_()
        model.history_proj.weight.zero_()
        model.history_proj.bias.zero_()
        model.history_proj.weight[0, 0] = 1
        model.query.weight.zero_()
        model.query.bias.zero_()
        model.query.weight[0, 4] = 1
        model.value.weight.zero_()
        model.value.bias.zero_()
        model.head.weight.zero_()
        model.head.bias.zero_()
        model.head.weight[0, 0] = 1
        model.head.bias[1] = 1
    return model


def payload(model):
    return {"model": model.state_dict(), "vocab": {"<pad>": 0, "<unk>": 1, "car": 2},
            "length_scale": 5.0, "model_config": {"history_frames": 2, "hidden": 4,
                "ablate": "no_image", "imgsz": 8, "image_mean": [float(x) for x in IMAGENET_MEAN],
                "image_std": [float(x) for x in IMAGENET_STD], "strip_direction": True}}


class FusionTests(unittest.TestCase):
    def test_single_token_history_gradient_path(self):
        for mode, has_path in (("text_context_only", False), ("query_plus_text", True)):
            model = controlled_model(mode)
            inputs = batch()
            inputs["history"].requires_grad_()
            output = model(inputs)
            output[:, 0].sum().backward()
            magnitude = inputs["history"].grad.abs().sum().item()
            if has_path:
                self.assertGreater(magnitude, 0.1)
            else:
                self.assertEqual(magnitude, 0.0)

    def test_same_parameters_and_no_text_output(self):
        old = controlled_model("text_context_only")
        new = controlled_model("query_plus_text")
        new.load_state_dict(old.state_dict(), strict=True)
        self.assertEqual(sum(p.numel() for p in old.parameters()), sum(p.numel() for p in new.parameters()))
        self.assertEqual({k: v.shape for k, v in old.state_dict().items()},
                         {k: v.shape for k, v in new.state_dict().items()})
        old.ablate = new.ablate = "no_text"
        inputs = batch()
        inputs["history"][1, 0, 0] = 2
        self.assertTrue(torch.equal(old(inputs), new(inputs)))

    def test_uniform_attention_keeps_direct_query(self):
        model = controlled_model("query_plus_text")
        inputs = batch()
        inputs["tokens"] = torch.tensor([[2, 1], [2, 1]])
        inputs["token_mask"] = torch.ones(2, 2, dtype=torch.bool)
        inputs["history"][1, 0, 0] = 2
        handle = model.key.register_forward_hook(lambda module, args, output: torch.zeros_like(output))
        try:
            with torch.no_grad():
                actual = model(inputs)
        finally:
            handle.remove()
        model.ablate = "no_text"
        with torch.no_grad():
            expected = model(inputs)
        self.assertTrue(torch.equal(actual, expected))
        self.assertGreater((actual[0] - actual[1]).abs().max().item(), 0.1)

    def test_checkpoint_default_and_roundtrip(self):
        # Use the full backbone state here so the real strict loader is exercised.
        model = WaypointNet(3, history_frames=2, hidden=4, ablate="no_image", pretrained=False).eval()
        saved = payload(model)
        with TemporaryDirectory() as folder:
            path = Path(folder) / "model.pt"
            for mode in (None, "text_context_only", "query_plus_text"):
                if mode is not None:
                    saved["model_config"]["fusion_mode"] = mode
                torch.save(saved, path)
                predictor = WaypointPredictor(path, device="cpu")
                expected_mode = mode or "text_context_only"
                self.assertEqual(predictor.config["fusion_mode"], expected_mode)
                model.fusion_mode = expected_mode
                with torch.no_grad():
                    self.assertTrue(torch.equal(model(batch()), predictor.model(batch())))

    def test_unknown_modes_rejected(self):
        with self.assertRaises(ValueError):
            WaypointNet(3, fusion_mode="typo", pretrained=False)
        model = controlled_model("text_context_only")
        saved = payload(model)
        saved["model_config"]["fusion_mode"] = "typo"
        with self.assertRaises(CheckpointFormatError):
            _validate_checkpoint(saved)


class GroundedFusionTests(unittest.TestCase):
    def model(self, fusion="spatial", **kwargs):
        model = GroundedWaypointNet(5, history_frames=2, hidden=4, pretrained=False,
                                   visual_fusion=fusion, **kwargs).eval()
        # 保留空间变化，同时避免每个信息通路回归重复执行完整骨干。
        model.vision = nn.Conv2d(3, model.vision_proj.in_features, 1, bias=False)
        return model

    def inputs(self):
        inputs = batch()
        inputs["image"] = torch.rand(2, 3, 8, 8)
        inputs["tokens"] = torch.tensor([[2, 3], [3, 4]])
        inputs["token_mask"] = torch.ones(2, 2, dtype=torch.bool)
        return inputs

    def test_factory_legacy_keeps_state_and_forward(self):
        old = WaypointNet(3, history_frames=2, hidden=4, ablate="no_image", pretrained=False).eval()
        rebuilt = build_model(3, {"history_frames": 2, "hidden": 4, "ablate": "no_image"}).eval()
        rebuilt.load_state_dict(old.state_dict(), strict=True)
        self.assertEqual(rebuilt.fusion_mode, "text_context_only")
        self.assertTrue(torch.equal(old(batch()), rebuilt(batch())))

    def test_four_combinations_and_stop_shapes(self):
        for backbone in ("resnet18", "resnet50"):
            for fusion in ("global", "spatial"):
                for stop_enabled in (False, True):
                    model = build_model(5, {"architecture": "grounded_v1", "backbone": backbone,
                                           "visual_fusion": fusion, "history_frames": 2, "hidden": 4,
                                           "grid_size": 4, "ablate": "no_image",
                                           "stop_enabled": stop_enabled}).eval()
                    output = model(self.inputs())
                    displacement = output["body_displacement"] if stop_enabled else output
                    self.assertEqual(displacement.shape, (2, 3))
                    self.assertTrue(torch.isfinite(displacement).all())
                    self.assertEqual(model.vision_proj.in_features, 512 if backbone == "resnet18" else 2048)
                    if stop_enabled:
                        self.assertEqual(output["stop_logit"].shape, (2,))
                        output["stop_logit"].sum().backward()
                        self.assertGreater(model.stop_head.weight.grad.abs().sum().item(), 0)

    def test_spatial_query_has_region_gradient_and_global_has_same_parameters(self):
        torch.manual_seed(12)
        spatial = self.model()
        global_model = self.model("global")
        global_model.load_state_dict(spatial.state_dict(), strict=True)
        self.assertEqual({k: v.shape for k, v in spatial.state_dict().items()},
                         {k: v.shape for k, v in global_model.state_dict().items()})
        inputs = self.inputs()
        for model in (spatial, global_model):
            model(inputs)[:, 0].sum().backward()
            for parameter in (model.vision.weight, model.embed.weight, model.history_proj.weight):
                self.assertGreater(parameter.grad.abs().sum().item(), 0)
        self.assertGreater(spatial.region_key.weight.grad.abs().sum().item(), 0)
        self.assertIsNone(global_model.region_key.weight.grad)

    def test_identical_regions_make_both_aggregations_equal(self):
        spatial = self.model()
        global_model = self.model("global")
        with torch.no_grad():
            spatial.position_proj.weight.zero_()
        global_model.load_state_dict(spatial.state_dict(), strict=True)
        inputs = self.inputs()
        inputs["image"] = torch.ones_like(inputs["image"])
        with torch.no_grad():
            self.assertTrue(torch.allclose(spatial(inputs), global_model(inputs), atol=1e-6, rtol=1e-6))

    def test_no_text_ignores_tokens_padding_and_length(self):
        for fusion in ("global", "spatial"):
            model = self.model(fusion, ablate="no_text")
            inputs = self.inputs()
            with torch.no_grad():
                expected = model(inputs)
                inputs["tokens"] = torch.zeros(2, 7, dtype=torch.long)
                inputs["token_mask"] = torch.zeros(2, 7, dtype=torch.bool)
                self.assertTrue(torch.equal(expected, model(inputs)))

    def test_no_image_skips_backbone_and_download(self):
        for backbone in ("resnet18", "resnet50"):
            import uavnav.avln.model as module
            constructor = getattr(module, backbone)
            with patch.object(module, backbone, wraps=constructor) as build:
                model = GroundedWaypointNet(5, history_frames=2, hidden=4, backbone=backbone,
                                            pretrained=True, ablate="no_image").eval()
                self.assertIsNone(build.call_args.kwargs["weights"])
            with patch.object(model.vision, "forward", side_effect=AssertionError("视觉消融执行了骨干")):
                model(self.inputs())

    def test_real_backbones_keep_spatial_grid(self):
        for backbone in ("resnet18", "resnet50"):
            model = GroundedWaypointNet(5, history_frames=2, hidden=4, backbone=backbone,
                                        pretrained=False).eval()
            inputs = self.inputs()
            inputs["image"] = torch.rand(2, 3, 64, 64)
            captured = []
            handle = model.region_pool.register_forward_hook(lambda module, args, output: captured.append(output.shape))
            try:
                with torch.no_grad():
                    self.assertTrue(torch.isfinite(model(inputs)).all())
            finally:
                handle.remove()
            self.assertEqual(captured, [torch.Size((2, model.vision_proj.in_features, 4, 4))])

    def test_new_state_roundtrip_and_invalid_combinations(self):
        model = self.model(stop_enabled=True)
        restored = self.model(stop_enabled=True)
        restored.load_state_dict(model.state_dict(), strict=True)
        inputs = self.inputs()
        with torch.no_grad():
            expected, actual = model(inputs), restored(inputs)
        for key in expected:
            self.assertTrue(torch.equal(expected[key], actual[key]))
        for config in ({"architecture": "unknown"},
                       {"architecture": "legacy_waypoint_v1", "backbone": "resnet18"},
                       {"architecture": "legacy_waypoint_v1", "visual_fusion": "spatial"},
                       {"architecture": "legacy_waypoint_v1", "stop_enabled": True},
                       {"architecture": "grounded_v1", "fusion_mode": "text_context_only"},
                       {"architecture": "grounded_v1", "backbone": "unknown"},
                       {"architecture": "grounded_v1", "visual_fusion": "unknown"},
                       {"architecture": "grounded_v1", "grid_size": 0},
                       {"architecture": "grounded_v1", "stop_enabled": 1}):
            with self.subTest(config=config), self.assertRaises(ValueError):
                build_model(5, config)


class IntegratedGroundedTests(unittest.TestCase):
    def checkpoint(self, stop_enabled):
        model = GroundedWaypointNet(4, history_frames=2, hidden=4, pretrained=False,
                                    ablate="no_image", stop_enabled=stop_enabled).eval()
        protocol = {"version": "fov_stop_v1" if stop_enabled else "fov_front_motion_v1",
                    "camera": "FrontCamera", "image_size": 8, "strip_direction": True,
                    "goal_access": "training_labels_and_offline_scoring_only",
                    "stop_source": "reviewed_annotations" if stop_enabled else "disabled",
                    "stop_timing": "before_action" if stop_enabled else "disabled"}
        if stop_enabled:
            protocol.update(goal_source="object_metadata", success_distance_m=5.0)
        saved = payload(model)
        saved["vocab"]["<neutral>"] = 3
        saved["model_config"].update(
            checkpoint_format_version=3, architecture="grounded_v1", backbone="resnet18",
            visual_fusion="spatial", grid_size=4, stop_enabled=stop_enabled,
            fusion_mode="query_plus_text", text_control="original", task_protocol=protocol,
            task_protocol_sha256=task_protocol_sha256(protocol),
            output_version="waypoint_stop_v1" if stop_enabled else "waypoint_v1")
        return model, saved

    def test_checkpoint_task_digest_output_and_schema_tamper_rejected(self):
        _, saved = self.checkpoint(True)
        for change in (lambda c: c.update(task_protocol_sha256="0" * 64),
                       lambda c: c["task_protocol"].update(success_distance_m=6.0),
                       lambda c: c.update(output_version="waypoint_v1"),
                       lambda c: c.pop("task_protocol_sha256"),
                       lambda c: c.pop("fusion_mode"),
                       lambda c: c.update(checkpoint_format_version=4),
                       lambda c: c.update(checkpoint_format_version=3.0),
                       lambda c: c.update(stop_enabled=False)):
            tampered = copy.deepcopy(saved)
            change(tampered["model_config"])
            with self.assertRaises(CheckpointFormatError):
                _validate_checkpoint(tampered)

    def test_new_checkpoint_strict_reload_and_constant_prediction(self):
        for stop_enabled in (False, True):
            model, saved = self.checkpoint(stop_enabled)
            saved["model_config"]["text_control"] = "constant"
            with TemporaryDirectory() as folder:
                path = Path(folder) / "checkpoint.pt"
                torch.save(saved, path)
                predictor = WaypointPredictor(path, device="cpu")
                image = __import__("numpy").zeros((8, 8, 3), dtype="uint8")
                first = predictor._batch(image, "red car", None)
                second = predictor._batch(image, "blue building near tree", None)
                self.assertTrue(torch.equal(first["tokens"], second["tokens"]))
                self.assertEqual(first["tokens"].tolist(), [[3]])
                with torch.no_grad():
                    expected, actual = model(first), predictor.model(first)
                if stop_enabled:
                    for key in expected:
                        self.assertTrue(torch.equal(expected[key], actual[key]))
                else:
                    self.assertTrue(torch.equal(expected, actual))
                result = predictor.predict(image, "red car")
                self.assertEqual(len(result["body_displacement"]), 3)
                self.assertEqual(result["stop_enabled"], stop_enabled)
                if stop_enabled:
                    self.assertGreaterEqual(result["stop_probability"], 0)
                    self.assertLessEqual(result["stop_probability"], 1)
                else:
                    self.assertIsNone(result["stop_probability"])

    def test_motion_mask_excludes_both_losses_and_stop_has_independent_gradient(self):
        displacement = torch.tensor([[2., 0., 0.], [0., 3., 0.]], requires_grad=True)
        logits = torch.tensor([0., 0.], requires_grad=True)
        inputs = {"offset": torch.tensor([[1., 0., 0.], [100., 0., 0.]]),
                  "motion_valid": torch.tensor([True, False]),
                  "stop_valid": torch.tensor([False, True]), "stop_target": torch.tensor([0., 1.])}
        loss, angle, length = prediction_loss({"body_displacement": displacement, "stop_logit": logits},
                                              inputs, length_scale=2., stop_loss_weight=3.)
        self.assertEqual(angle.item(), 0.)
        self.assertEqual(length.item(), 1.)
        loss.backward()
        self.assertGreater(displacement.grad[0].abs().sum().item(), 0)
        self.assertEqual(displacement.grad[1].abs().sum().item(), 0)
        self.assertEqual(logits.grad[0].item(), 0)
        self.assertLess(logits.grad[1].item(), 0)
        prediction = torch.tensor([[2., 0., 0.]], requires_grad=True)
        loss, _, length = prediction_loss(prediction, {"offset": torch.tensor([[1., 0., 0.]])}, 2.)
        self.assertEqual(length.item(), 1.)
        loss.backward()
        self.assertGreater(prediction.grad.abs().sum().item(), 0)

    def test_constant_control_uses_same_original_training_vocab(self):
        import uavnav.avln.fit as fit_module
        captured = []
        def record_vocab(texts):
            vocab = Vocab(texts)
            captured.append(vocab.words)
            return vocab
        class StopBeforeModelConstruction(Exception):
            pass
        samples = [{"traj_id": "Map/a", "instruction": "red car"},
                   {"traj_id": "Map/b", "instruction": "blue building"}]
        with TemporaryDirectory() as folder:
            listing = Path(folder) / "train.json"
            listing.write_text("[]", encoding="utf-8")
            for ablate in ("none", "constant_text"):
                with patch.object(fit_module, "load_list", return_value=[]), \
                     patch.object(fit_module, "iter_samples", return_value=samples), \
                     patch.object(fit_module, "Vocab", side_effect=record_vocab), \
                     patch.object(fit_module, "build_model", side_effect=StopBeforeModelConstruction):
                    with self.assertRaises(StopBeforeModelConstruction):
                        fit_module.fit(seed=0, architecture="grounded_v1", fusion_mode="query_plus_text",
                                       ablate=ablate, data_root=folder, list_json=listing,
                                       history=2, imgsz=8, strip_direction=True, val_ratio=.5, device="cpu")
        self.assertEqual(captured[0], captured[1])
        self.assertIn("<neutral>", captured[0])
        self.assertGreater(len(captured[0]), 3)

    def test_evaluate_uses_valid_label_counts_across_uneven_batches(self):
        class ControlledPrediction(nn.Module):
            stop_loss_weight = 2.5
            def forward(self, inputs):
                target = inputs["offset"]
                return {"body_displacement": target + target.new_tensor([0., 1., 0.]),
                        "stop_logit": target[:, 0] - 2.}
        inputs = {"offset": torch.tensor([[1., 0., 0.], [2., 0., 0.], [3., 0., 0.],
                                           [4., 0., 0.], [5., 0., 0.]]),
                  "motion_valid": torch.tensor([True, False, False, True, False]),
                  "stop_valid": torch.tensor([False, True, True, False, False]),
                  "stop_target": torch.tensor([0., 0., 1., 0., 0.])}
        model = ControlledPrediction()
        complete = _evaluate(model, [inputs], torch.device("cpu"), 2., "none")
        self.assertEqual(complete["motion_count"], 2)
        self.assertEqual(complete["stop_count"], 2)
        self.assertGreater(complete["angle"], 0)
        self.assertGreater(complete["length"], 0)
        self.assertGreater(complete["stop"], 0)
        for groups in (((0,), (1,), (2,), (3,), (4,)),
                       ((0, 3), (1, 2), (4,)), ((0, 1, 4), (2, 3))):
            batches = [{key: value[list(group)] for key, value in inputs.items()} for group in groups]
            result = _evaluate(model, batches, torch.device("cpu"), 2., "none")
            for key in complete:
                with self.subTest(groups=groups, metric=key):
                    self.assertAlmostEqual(result[key], complete[key], places=6)


class TrainingEntryTests(unittest.TestCase):
    def test_encoder_selection_rejects_unused_environment_and_cache_options(self):
        from train import aerial_training_parameters
        required = {"cache_manifest": "train.json", "validation_cache_manifest": "dev.json"}
        for key, value in (("UAVNAV_DINO_REPO", "DINOv3"), ("UAVNAV_DINO_WEIGHTS", "dino.pt"),
                           ("UAVNAV_DINO_VARIANT", "vits16"), ("UAVNAV_DINO_FROZEN", "1"),
                           ("UAVNAV_TEXT_FEATURE_CACHE", "clip.pt")):
            with self.subTest(environment=key), patch.dict(os.environ, {key: value}, clear=True):
                with self.assertRaises(ValueError):
                    aerial_training_parameters(required)
        with patch.dict(os.environ, {}, clear=True):
            for extra in ({"text_feature_cache": "clip.pt"}, {"vision_feature_cache_dtype": "float16"},
                          {"architecture": "aerial_route_recurrent_rgbd_v3", "vision_feature_cache": "r18.pt"},
                          {"architecture": "aerial_route_dino_v5", "vision_feature_cache": "r18.pt"},
                          {"architecture": "aerial_route_dino_v5", "text_feature_cache": "clip.pt"}):
                with self.subTest(options=extra), self.assertRaises(ValueError):
                    aerial_training_parameters({**required, **extra})
            dino = aerial_training_parameters({**required, "architecture": "aerial_route_dino_v5"})
            self.assertEqual(dino["backbone"], "dinov3_vits16")
            clause = aerial_training_parameters({**required, "architecture": "aerial_route_recurrent_clause_v3",
                                                "vision_feature_cache": "r18.pt", "text_feature_cache": "clip.pt"})
            self.assertEqual(clause["backbone"], "resnet18")

    def test_direct_fit_rejects_encoder_mismatch_before_lock_or_data_access(self):
        from uavnav.avln.fit import fit_aerial
        with TemporaryDirectory() as tmp, patch("uavnav.avln.fit._aerial_run_lock") as lock, \
                patch("uavnav.avln.fit._fit_aerial_locked") as body:
            root = Path(tmp) / "runs"
            for extra in ({"text_feature_cache": "clip.pt"}, {"dino_weights": "dino.pt"},
                          {"visual_encoder": {"variant": "vits16"}},
                          {"backbone": "dinov3_vits16"},
                          {"vision_feature_cache": "r18.pt", "vision_train_policy": "finetune"},
                          {"vision_feature_cache": "r18.pt", "vision_train_policy": "frozen", "render_pass_manifests": ["pass2.json"]},
                          {"architecture": "aerial_route_dino_v5", "text_feature_cache": "clip.pt"},
                          {"architecture": "aerial_route_recurrent_clause_v3"}):
                controls = {"architecture": "aerial_route_recurrent_v2", "project": root, "name": "rejected", **extra}
                with self.subTest(options=extra), self.assertRaises(ValueError):
                    fit_aerial(**controls)
            lock.assert_not_called()
            body.assert_not_called()
            self.assertFalse(root.exists())

    def test_default_main_and_development_share_route_parameters(self):
        from train import train, aerial_training_parameters
        with patch.dict(os.environ, {}, clear=True), patch("uavnav.avln.fit.fit_aerial", return_value="run") as fit:
            overrides = {"cache_manifest": "train-cache.json", "validation_cache_manifest": "val-cache.json", "epochs": 1}
            self.assertEqual(train(overrides=overrides), "run")
            actual = fit.call_args.kwargs
            self.assertEqual(actual["architecture"], "aerial_route_recurrent_v2")
            self.assertEqual(actual["epochs"], 1)
            self.assertEqual(actual["lr"], 1e-4)
            self.assertEqual(actual["imgsz"], 224)
            self.assertEqual(actual, aerial_training_parameters(overrides))
            with self.assertRaisesRegex(ValueError, "未知"):
                aerial_training_parameters({**overrides, "undocumented_hyperparameter": 1})
            with self.assertRaisesRegex(ValueError, "独立"):
                aerial_training_parameters({"cache_manifest": "train-only.json"})
            v1 = aerial_training_parameters({**overrides, "architecture": "aerial_route_v1"})
            self.assertIsNone(v1["memory_mode"])
            with patch.dict(os.environ, {"UAVNAV_ARCHITECTURE": "aerial_route_v1"}):
                v2 = aerial_training_parameters({**overrides, "architecture": "aerial_route_recurrent_v2"})
                self.assertEqual(v2["memory_mode"], "carry")
                self.assertIn("recurrent_v2", v2["name"])

    def test_vision_default_follows_final_architecture_in_both_directions(self):
        from train import AIRVLN_BASELINES, aerial_training_parameters
        required = {"cache_manifest": "train.json", "validation_cache_manifest": "val.json"}
        with patch.dict(os.environ, {"UAVNAV_ARCHITECTURE": "aerial_route_v1"}, clear=True):
            self.assertEqual(aerial_training_parameters(required)["vision_train_policy"], "finetune")
            for architecture in ("aerial_route_recurrent_v2", "aerial_route_recurrent_rgbd_v3", *AIRVLN_BASELINES):
                with self.subTest(architecture=architecture):
                    actual = aerial_training_parameters({**required, "architecture": architecture})
                    self.assertEqual(actual["vision_train_policy"], "frozen")
        with patch.dict(os.environ, {"UAVNAV_ARCHITECTURE": "aerial_route_recurrent_v2"}, clear=True):
            actual = aerial_training_parameters({**required, "architecture": "aerial_route_v1"})
            self.assertEqual(actual["vision_train_policy"], "finetune")
            self.assertIsNone(actual["memory_mode"])

    def test_explicit_vision_policy_takes_priority_over_architecture_default(self):
        from train import aerial_training_parameters
        required = {"cache_manifest": "train.json", "validation_cache_manifest": "val.json"}
        with patch.dict(os.environ, {}, clear=True):
            actual = aerial_training_parameters({**required, "vision_train_policy": "finetune"})
            self.assertEqual(actual["vision_train_policy"], "finetune")
        with patch.dict(os.environ, {"UAVNAV_ARCHITECTURE": "aerial_route_v1",
                                     "UAVNAV_VISION_TRAIN_POLICY": "finetune"}, clear=True):
            selected = {**required, "architecture": "aerial_route_recurrent_v2"}
            self.assertEqual(aerial_training_parameters(selected)["vision_train_policy"], "finetune")
            selected["vision_train_policy"] = "frozen"
            self.assertEqual(aerial_training_parameters(selected)["vision_train_policy"], "frozen")
        with patch.dict(os.environ, {"UAVNAV_ARCHITECTURE": "aerial_route_v1",
                                     "UAVNAV_VISION_TRAIN_POLICY": "frozen"}, clear=True):
            selected = {**required, "architecture": "aerial_route_recurrent_v2", "vision_train_policy": "finetune"}
            self.assertEqual(aerial_training_parameters(selected)["vision_train_policy"], "finetune")
            with self.assertRaisesRegex(ValueError, "完全冻结"):
                aerial_training_parameters(required)

    def test_final_architecture_recomputes_visual_defaults_and_names_both_directions(self):
        from train import AIRVLN_BASELINES, aerial_training_parameters
        required = {"cache_manifest": "train.json", "validation_cache_manifest": "val.json"}
        for initial in ("airvln_seq2seq_rgbd_v1", "airvln_cma_rgbd_v1"):
            with patch.dict(os.environ, {"UAVNAV_ARCHITECTURE": initial}, clear=True):
                for selected in ("aerial_route_v1", "aerial_route_recurrent_v2", "aerial_route_recurrent_rgbd_v3"):
                    with self.subTest(initial=initial, selected=selected):
                        config = aerial_training_parameters({**required, "architecture": selected})
                        self.assertEqual((config["backbone"], config["visual_fusion"]), ("resnet18", "spatial"))
                        self.assertEqual(config["name"], f"{selected}_resnet18_spatial_seed0")
        with patch.dict(os.environ, {"UAVNAV_ARCHITECTURE": "aerial_route_recurrent_v2"}, clear=True):
            for selected in AIRVLN_BASELINES:
                with self.subTest(selected=selected):
                    config = aerial_training_parameters({**required, "architecture": selected})
                    fusion = "global" if selected.startswith("airvln_seq2seq_") else "spatial"
                    self.assertEqual((config["backbone"], config["visual_fusion"]), ("resnet50", fusion))
                    self.assertEqual(config["name"], f"{selected}_resnet50_{fusion}_seed0")

    def test_explicit_visual_defaults_and_run_names_are_preserved(self):
        from train import aerial_training_parameters
        required = {"cache_manifest": "train.json", "validation_cache_manifest": "val.json",
                    "architecture": "aerial_route_recurrent_v2"}
        environment = {"UAVNAV_ARCHITECTURE": "airvln_cma_rgbd_v1", "UAVNAV_BACKBONE": "resnet50",
                       "UAVNAV_VISUAL_FUSION": "global"}
        with patch.dict(os.environ, environment, clear=True):
            config = aerial_training_parameters(required)
            self.assertEqual((config["backbone"], config["visual_fusion"]), ("resnet50", "global"))
            self.assertEqual(config["name"], "aerial_route_recurrent_v2_resnet50_global_seed0")
            explicit = aerial_training_parameters({**required, "backbone": "resnet18", "visual_fusion": "spatial"})
            self.assertEqual((explicit["backbone"], explicit["visual_fusion"]), ("resnet18", "spatial"))
            self.assertEqual(explicit["name"], "aerial_route_recurrent_v2_resnet18_spatial_seed0")
            with patch.dict(os.environ, {"UAVNAV_NAME": "environment-run"}):
                self.assertEqual(aerial_training_parameters(required)["name"], "environment-run")
                self.assertEqual(aerial_training_parameters({**required, "name": "explicit-run"})["name"], "explicit-run")
            with self.assertRaisesRegex(ValueError, "固定真实ResNet50"):
                aerial_training_parameters({**required, "architecture": "airvln_cma_rgbd_v1", "backbone": "resnet18"})


class TrainingPreparationTests(unittest.TestCase):
    def test_same_run_os_lock_rejects_concurrent_writer_and_releases(self):
        from uavnav.avln.fit import _aerial_run_lock, fit_aerial
        with TemporaryDirectory() as tmp:
            run = Path(tmp) / "shared"
            with _aerial_run_lock(run):
                with self.assertRaisesRegex(RuntimeError, "并发写"):
                    fit_aerial(project=Path(tmp), name="shared", seed=0)
                with _aerial_run_lock(Path(tmp) / "independent"):
                    pass
            with _aerial_run_lock(run):
                pass
            self.assertFalse(run.exists())

    def test_multiscene_full_source_training_snapshots_children_and_preserves_holdout(self):
        import contextlib
        import hashlib
        import io
        import json
        import yaml
        from types import SimpleNamespace
        from test_data import aerial_episode, aerial_v2_cache
        from uavnav.avln.data import load_aerial_episodes
        from uavnav.avln.metadata import AERIALVLN_S_RELEASE, authenticate_aerial_release
        from uavnav.avln.fit import fit_aerial
        from scripts.audit_training import audit_aerial, audit_loss_scale
        sha = lambda path: hashlib.sha256(path.read_bytes()).hexdigest()
        with TemporaryDirectory() as tmp:
            root = Path(tmp)
            episodes = [aerial_episode("scene2"), aerial_episode("scene3")]
            episodes[1]["scene_id"] = 3
            annotations = root / "annotations"
            annotations.mkdir()
            annotation = annotations / "train.json"
            annotation.write_text(json.dumps({"episodes": episodes}), encoding="utf-8")
            indices = []
            with patch.dict(AERIALVLN_S_RELEASE, {"train": {"sha256": sha(annotation), "episodes": 2}}):
                certificate = authenticate_aerial_release("train", load_aerial_episodes(annotations, "train"))
                for role in ("train", "dev"):
                    folder = root / role
                    folder.mkdir()
                    shards, protocols = [], {}
                    for episode in episodes:
                        scene = folder / str(episode["scene_id"])
                        scene.mkdir()
                        _, child, payload = aerial_v2_cache(scene, f"{role}-{episode['scene_id']}", [episode])
                        payload["annotation_sha256"] = sha(annotation)
                        child.write_text(json.dumps(payload), encoding="utf-8")
                        shards.append(dict(path=child.relative_to(folder).as_posix(), sha256=sha(child), scene_id=episode["scene_id"]))
                        protocols[str(episode["scene_id"])] = payload["render_protocol"]
                    index = folder / "index.json"
                    index.write_text(json.dumps(dict(schema_version=1, data_protocol="aerialvln_s_v1", split="train",
                        cache_kind="scene_shards_v1", shards=shards,
                        episodes=[dict(scene_id=ep["scene_id"], episode_id=ep["episode_id"]) for ep in episodes],
                        annotation_sha256=sha(annotation), scope="official_split_complete", status="complete",
                        official_source_authentication=certificate,
                        excluded_quarantine=[], excluded_quarantine_sha256=_json_sha256([]),
                        render_protocol=dict(protocol_version="aerialvln_s_multiscene_rgb_v1", camera_name="front_0", scenes=protocols))),
                        encoding="utf-8")
                    indices.append(index)
                with patch("uavnav.avln.fit._plot_loss"), contextlib.redirect_stdout(io.StringIO()):
                    run = fit_aerial(annotation_root=annotations, cache_manifest=indices[0], validation_cache_manifest=indices[1],
                        validation_split="development_train_grouped", development_fraction=.5, development_split_seed=0,
                        require_full_train=True, architecture="aerial_route_recurrent_v2", epochs=1, batch=1, workers=0,
                        history=2, imgsz=16, lr=1e-4, device="cpu", seed=0, pretrained=False, hidden=4,
                        sequence_chunk_size=3, project=root / "runs", name="multiscene")
                    manifest = json.loads((run / "split_manifest.json").read_text(encoding="utf-8"))
                    hparams = yaml.safe_load((run / "hparams.yaml").read_text(encoding="utf-8"))
                    report = audit_aerial(SimpleNamespace(run_dir=run, output_dir=root / "audit", device="cpu"), hparams)
                    budget = audit_loss_scale(SimpleNamespace(run_dir=run, output_json=root / "loss.json", supervision_json=None))
                self.assertTrue(manifest["train_source_covers_official_raw_split"])
                self.assertTrue(manifest["train_source_covers_official_eligible_split"])
                self.assertFalse(manifest["train_covers_official_eligible_split"])
                self.assertEqual(len(manifest["child_cache_sources"]), 4)
                checkpoint = torch.load(run / "weights" / "last.pt", map_location="cpu", weights_only=True)
                for record in (manifest, hparams, hparams["model_config"], checkpoint["model_config"]):
                    self.assertEqual(record["model_construction_version"], "direct_selected_encoders_v1")
                self.assertEqual(report["samples"], {"train": 8, "validation": 8})
                self.assertEqual(budget["actual_sequence_budget"]["states_per_epoch"], 8)
                (run / manifest["child_cache_sources"][0]["snapshot"]).write_bytes(b"{}")
                with self.assertRaisesRegex(ValueError, "子缓存来源快照"):
                    audit_aerial(SimpleNamespace(run_dir=run, output_dir=root / "broken-audit", device="cpu"), hparams)

    def test_rgbd_cpu_fit_and_independent_reload_use_real_depth(self):
        import contextlib
        import hashlib
        import io
        import json
        import numpy as np
        import yaml
        from types import SimpleNamespace
        from test_data import DataContractTests
        from scripts.audit_training import audit_aerial
        from uavnav.avln.fit import fit_aerial
        with TemporaryDirectory() as tmp:
            root = Path(tmp)
            folders, paths = DataContractTests()._grouped_training_caches(root)
            for path in paths:
                document = json.loads(path.read_text(encoding="utf-8"))
                document["scope"] = "synthetic_interface_fixture"
                document["render_protocol"]["depth_protocol"] = "scene1_7_depthvis255_else_depthperspective100_v1"
                for episode in document["episodes"]:
                    for frame in episode["frames"]:
                        depth = path.parent / f"{episode['episode_id']}_{frame['frame_index']}.npy"
                        np.save(depth, np.full((256, 256), frame["frame_index"] / 10, np.float32))
                        frame["depth"] = {"path": depth.name, "sha256": hashlib.sha256(depth.read_bytes()).hexdigest()}
                path.write_text(json.dumps(document), encoding="utf-8")
            with patch("uavnav.avln.fit._plot_loss"), contextlib.redirect_stdout(io.StringIO()):
                run = fit_aerial(annotation_root=folders[0], cache_manifest=paths[0],
                                 validation_cache_manifest=paths[1], validation_split="development_train_grouped",
                                 development_fraction=.5, development_split_seed=0,
                                 architecture="aerial_route_recurrent_rgbd_v3", epochs=1, batch=1, workers=0,
                                 history=2, imgsz=16, lr=1e-4, device="cpu", seed=0, pretrained=False,
                                 hidden=4, sequence_chunk_size=3, project=root / "runs", name="rgbd")
                hparams = yaml.safe_load((run / "hparams.yaml").read_text(encoding="utf-8"))
                report = audit_aerial(SimpleNamespace(run_dir=run, output_dir=root / "audit", device="cpu"), hparams)
            saved = torch.load(run / "weights" / "last.pt", weights_only=True)
            self.assertEqual(saved["model_config"]["checkpoint_format_version"], 7)
            self.assertEqual(saved["model_config"]["input_modality"], "rgbd")
            self.assertGreater(sum(key.startswith("depth_encoder.") for key in saved["model"]), 0)
            self.assertEqual(report["samples"]["train"], 8)

    def test_dagger_warm_start_executes_bc_plus_actual_history_and_audits(self):
        import contextlib
        import hashlib
        import io
        import json
        import yaml
        from types import SimpleNamespace
        from test_data import DataContractTests, aerial_v2_cache, aerial_episode
        from scripts.audit_training import audit_aerial, audit_loss_scale
        from uavnav.avln.fit import fit_aerial, load_training_dagger_groups
        from uavnav.avln.metadata import AERIALVLN_S_RELEASE
        with TemporaryDirectory() as tmp:
            root = Path(tmp)
            train_root, dev_root = root / "train", root / "dev"
            train_root.mkdir()
            dev_root.mkdir()
            dagger, _ = DataContractTests()._dagger_cache(train_root)
            source, dev_cache, dev_payload = aerial_v2_cache(dev_root, "dev-session", [aerial_episode("dev")])
            (train_root / "val_seen.json").write_bytes(source.read_bytes())
            dev_payload["split"] = "val_seen"
            dev_payload["scope"] = "synthetic_interface_fixture"
            dev_cache.write_text(json.dumps(dev_payload), encoding="utf-8")
            train_cache = train_root / "render.json"
            payload = json.loads(train_cache.read_text(encoding="utf-8"))
            payload["scope"] = "synthetic_interface_fixture"
            train_cache.write_text(json.dumps(payload), encoding="utf-8")
            common = dict(annotation_root=train_root, cache_manifest=train_cache,
                          validation_cache_manifest=dev_cache, validation_split="val_seen",
                          architecture="aerial_route_recurrent_v2", epochs=1, batch=1, workers=0,
                          history=2, imgsz=16, lr=1e-4, device="cpu", seed=0, pretrained=False,
                          hidden=4, sequence_chunk_size=3, project=root / "runs")
            with patch("uavnav.avln.fit._plot_loss"), contextlib.redirect_stdout(io.StringIO()):
                bc = fit_aerial(**common, name="bc")
                run = fit_aerial(**common, name="dagger", stage="dagger", dagger_manifests=[dagger],
                                 warm_start_checkpoint=bc / "weights" / "last.pt")
                hparams = yaml.safe_load((run / "hparams.yaml").read_text(encoding="utf-8"))
                report = audit_aerial(SimpleNamespace(run_dir=run, output_dir=root / "audit", device="cpu"), hparams)
                budget = audit_loss_scale(SimpleNamespace(run_dir=run, output_json=root / "loss.json", supervision_json=None))
                fit_aerial(**common, name="dagger", stage="dagger", dagger_manifests=[dagger],
                           resume_checkpoint=run / "weights" / "last.pt")
            self.assertEqual(report["samples"]["train"], 11)
            self.assertEqual(report["stratified_training_scope"]["samples"], 8)
            self.assertEqual(report["stratified_training_scope"]["dagger_samples_excluded_from_full_teacher_prefix"], 3)
            self.assertTrue(report["stratified_training_scope"]["independent_reload_train_includes_dagger"])
            self.assertEqual(hparams["stage"], "dagger")
            self.assertEqual(hparams["optimizer_updates_per_epoch"], 4)
            self.assertEqual(budget["actual_sequence_budget"]["states_per_epoch"], 11)
            self.assertEqual(torch.load(run / "weights" / "last.pt", weights_only=True)["model_config"]["training_stage"], "dagger")
            with self.assertRaisesRegex(ValueError, "开发/验证"):
                load_training_dagger_groups(train_root, [dagger], 2, {"2/dev"})
            # A valid but truncated cache cannot impersonate complete official training.
            annotation = train_root / "train.json"
            official = json.loads(annotation.read_text(encoding="utf-8"))
            official["episodes"].append(aerial_episode("uncached"))
            annotation.write_text(json.dumps(official), encoding="utf-8")
            digest = hashlib.sha256(annotation.read_bytes()).hexdigest()
            payload["annotation_sha256"] = digest
            train_cache.write_text(json.dumps(payload), encoding="utf-8")
            with patch.dict(AERIALVLN_S_RELEASE, {"train": {"sha256": digest, "episodes": 2}}):
                with self.assertRaisesRegex(ValueError, "完整官方有效train"):
                    fit_aerial(**common, name="reject-subset", require_full_train=True)
            self.assertFalse((root / "runs" / "reject-subset").exists())

    def test_experimental_paths_reject_silent_contract_mismatch(self):
        from uavnav.avln.fit import fit_aerial
        with TemporaryDirectory() as tmp:
            root = Path(tmp)
            common = dict(annotation_root=root, cache_manifest=root / "train.json",
                          validation_cache_manifest=root / "dev.json",
                          validation_split="development_train_grouped", epochs=1, batch=1,
                          workers=0, history=2, imgsz=16, lr=1e-4, device="cpu", seed=0,
                          pretrained=False, hidden=4, sequence_chunk_size=3, project=root / "runs")
            with self.assertRaisesRegex(ValueError, "v3子句模型仅支持original"):
                fit_aerial(**common, architecture="aerial_route_recurrent_clause_v3",
                           vision_train_policy="frozen", text_control="constant", name="v3-constant")
            with self.assertRaisesRegex(ValueError, "v3子句模型不支持no_text"):
                fit_aerial(**common, architecture="aerial_route_recurrent_clause_v3",
                           vision_train_policy="frozen", ablate="no_text", name="v3-notext")
            with self.assertRaisesRegex(ValueError, "episode_batch路径不支持history_dropout"):
                fit_aerial(**common, architecture="aerial_route_recurrent_v2",
                           episode_batch=2, history_dropout=.1, name="batch-dropout")

    def test_seed_and_unseen_are_rejected_at_real_training_entry(self):
        from train import aerial_training_parameters
        from uavnav.avln.fit import fit, fit_aerial, validate_training_controls
        with patch.dict(os.environ, {"UAVNAV_ALLOW_MULTI_SEED": "1"}, clear=True):
            for entry in (fit, fit_aerial):
                with self.assertRaisesRegex(ValueError, "seed=0"):
                    entry(seed=1)
            with self.assertRaisesRegex(ValueError, "seed=0"):
                aerial_training_parameters({"seed": 1})
        with self.assertRaisesRegex(ValueError, "val_unseen"):
            fit_aerial(seed=0, validation_split="val_unseen")
        for controls in ({"stage": "dagger"}, {"stage": "bc", "dagger_manifests": ["offset.json"]},
                         {"resume_checkpoint": "last.pt", "warm_start_checkpoint": "best.pt"}):
            with self.assertRaises(ValueError):
                validate_training_controls(controls)

    def test_cpu_epoch_resume_matches_uninterrupted_and_rejects_changed_contract(self):
        import contextlib
        import io
        import json
        from test_data import DataContractTests
        from uavnav.avln.fit import fit_aerial, _aerial_sequence_epoch
        with TemporaryDirectory() as tmp:
            root = Path(tmp)
            folders, paths = DataContractTests()._grouped_training_caches(root)
            common = dict(annotation_root=folders[0], cache_manifest=paths[0],
                          validation_cache_manifest=paths[1], validation_split="development_train_grouped",
                          development_fraction=.5, development_split_seed=0,
                          architecture="aerial_route_recurrent_v2", epochs=3, batch=1, workers=0,
                          candidate_epochs=[1, 3], diagnostics_interval=1,
                          history=2, imgsz=16, lr=1e-4, device="cpu", seed=0, pretrained=False,
                          hidden=4, sequence_chunk_size=3, project=root / "runs")
            for path in paths:
                document = json.loads(path.read_text(encoding="utf-8"))
                document["scope"] = "synthetic_interface_fixture"
                path.write_text(json.dumps(document), encoding="utf-8")
            def interrupt(*args, **kwargs):
                if kwargs.get("optimizer") is not None and kwargs.get("epoch") == 1:
                    raise RuntimeError("simulated interruption")
                return _aerial_sequence_epoch(*args, **kwargs)
            with patch("uavnav.avln.fit._plot_loss"), contextlib.redirect_stdout(io.StringIO()):
                complete = fit_aerial(**common, name="complete")
                with patch("uavnav.avln.fit._aerial_sequence_epoch", side_effect=interrupt):
                    with self.assertRaisesRegex(RuntimeError, "simulated interruption"):
                        fit_aerial(**common, name="resumable")
                partial = root / "runs" / "resumable"
                checkpoint = partial / "weights" / "last.pt"
                saved = torch.load(checkpoint, weights_only=True)
                self.assertEqual(saved["epoch"], 1)
                # Legacy state lacks the total, so recover from its committed actual-update ledger.
                saved["training_state"].pop("optimizer_updates_total")
                torch.save(saved, checkpoint)
                # Emulate a crash after last.pt committed but before its candidate was saved.
                (partial / "weights" / "epoch_001.pt").unlink()
                (partial / "candidate_inventory.json").unlink()
                # Interruptions after appending logs must roll back only the uncommitted suffix.
                with (partial / "results.csv").open("a", encoding="utf-8") as stream:
                    stream.write("uncommitted tail\n")
                with self.assertRaisesRegex(ValueError, "配置/device"):
                    fit_aerial(**{**common, "lr": 2e-4}, name="resumable", resume_checkpoint=checkpoint)
                resumed = fit_aerial(**common, name="resumable", resume_checkpoint=checkpoint)
                # Completed resume is a no-op, never appends duplicate epochs.
                fit_aerial(**common, name="resumable", resume_checkpoint=checkpoint)
            actual = torch.load(resumed / "weights" / "last.pt", weights_only=True)
            expected = torch.load(complete / "weights" / "last.pt", weights_only=True)
            for key, tensor in expected["model"].items():
                self.assertTrue(torch.equal(tensor, actual["model"][key]), key)
            self.assertEqual(expected["scheduler"], actual["scheduler"])
            import hashlib
            inventory = json.loads((resumed / "candidate_inventory.json").read_text(encoding="utf-8"))
            self.assertEqual(inventory["candidate_epochs"], [1, 3])
            self.assertIsNone(inventory["navigation_selection"])
            self.assertEqual([entry["epoch"] for entry in inventory["candidates"]], [1, 3])
            self.assertFalse((resumed / "weights" / "epoch_002.pt").exists())
            for entry in inventory["candidates"]:
                self.assertEqual(hashlib.sha256((resumed / entry["path"]).read_bytes()).hexdigest(), entry["sha256"])
            self.assertEqual(inventory["candidates"][-1]["optimizer_updates_total"], actual["training_state"]["optimizer_updates_total"])
            runtime = json.loads((resumed / "runtime.json").read_text(encoding="utf-8"))
            self.assertIn("deterministic_algorithms", runtime)
            diagnostics = [json.loads(line) for line in (resumed / "training_diagnostics.jsonl").read_text(encoding="utf-8").splitlines()]
            self.assertEqual([row["epoch"] for row in diagnostics], [1, 2, 3])
            self.assertEqual(diagnostics[-1]["train_statistics_basis"], "predictions_during_parameter_updates")
            self.assertEqual(actual["training_state"]["best_epoch"], expected["training_state"]["best_epoch"])
            for key in ("exp_avg", "exp_avg_sq", "step"):
                for param in expected["optimizer"]["state"]:
                    self.assertTrue(torch.equal(expected["optimizer"]["state"][param][key],
                                                actual["optimizer"]["state"][param][key]))
            ledger = [json.loads(line) for line in (resumed / "render_pass_selections.jsonl").read_text().splitlines()]
            self.assertEqual([row["epoch"] for row in ledger], [1, 2, 3])
            self.assertEqual(ledger, [json.loads(line) for line in (complete / "render_pass_selections.jsonl").read_text().splitlines()])
            with (resumed / "results.csv").open() as stream:
                self.assertEqual([int(row["epoch"]) for row in csv.DictReader(stream)], [1, 2, 3])
            self.assertEqual(torch.load(resumed / "weights" / "best.pt", weights_only=True)["epoch"],
                             actual["training_state"]["best_epoch"])
            self.assertFalse(list(resumed.rglob("*.pending")))
            import yaml
            from types import SimpleNamespace
            from scripts.audit_training import audit_aerial
            with contextlib.redirect_stdout(io.StringIO()):
                report = audit_aerial(SimpleNamespace(run_dir=resumed, output_dir=root / "candidate_audit", device="cpu",
                    teacher_checkpoint=resumed / "weights" / "epoch_001.pt"),
                    yaml.safe_load((resumed / "hparams.yaml").read_text(encoding="utf-8")))
            self.assertEqual(report["selected_teacher_checkpoint"]["choice"], "candidate")
            self.assertEqual(report["selected_teacher_checkpoint"]["epoch"], 1)
            original_last = checkpoint.read_bytes()
            unregistered = copy.deepcopy(actual)
            unregistered["training_state"]["request"]["candidate_epochs"] = []
            torch.save(unregistered, checkpoint)
            with self.assertRaisesRegex(ValueError, "事后补登记"):
                audit_aerial(SimpleNamespace(run_dir=resumed, output_dir=root / "unregistered_audit", device="cpu",
                    teacher_checkpoint=resumed / "weights" / "epoch_001.pt"),
                    yaml.safe_load((resumed / "hparams.yaml").read_text(encoding="utf-8")))
            checkpoint.write_bytes(original_last)
            from uavnav.avln.fit import _save_epoch_candidate
            tampered = copy.deepcopy(actual)
            next(iter(tampered["model"].values())).add_(1)
            with self.assertRaisesRegex(ValueError, "拒绝覆盖"):
                _save_epoch_candidate(tampered, resumed, [1, 3], actual["training_state"]["optimizer_updates_total"])
            (resumed / "results.csv").write_bytes(b"corrupted committed rows")
            with patch("uavnav.avln.fit._plot_loss"), contextlib.redirect_stdout(io.StringIO()):
                with self.assertRaisesRegex(ValueError, "已提交内容损坏"):
                    fit_aerial(**common, name="resumable", resume_checkpoint=checkpoint)


class FixedSplitAndLogTests(unittest.TestCase):
    def setUp(self):
        self.samples = [{"traj_id": "Map/b"}, {"traj_id": "Map/a"}, {"traj_id": "Map/b"}]
        self.manifest = {"source_list_sha256": "source", "train_trajectory_ids": ["Map/a"],
                         "validation_trajectory_ids": ["Map/b"], "train_samples": 1,
                         "validation_samples": 2, "eligible_trajectories": 2}

    def test_saved_split_keeps_sample_order(self):
        train, val, count = split_from_manifest(self.samples, self.manifest, {"source_list_sha256": "source"})
        self.assertEqual(train, [self.samples[1]])
        self.assertEqual(val, [self.samples[0], self.samples[2]])
        self.assertEqual(count, 2)

    def test_changed_source_overlap_missing_ids_and_counts_rejected(self):
        for changes in ({"source_list_sha256": "changed"}, {"validation_trajectory_ids": ["Map/a"]},
                        {"train_trajectory_ids": ["Map/c"]}, {"train_samples": 2},
                        {"train_trajectory_ids": ["Map/a", "Map/a"]}):
            manifest = copy.deepcopy(self.manifest)
            manifest.update(changes)
            with self.assertRaises(ValueError):
                split_from_manifest(self.samples, manifest, {"source_list_sha256": "source"})

    def test_learning_rate_log_separates_used_and_next(self):
        parameter = nn.Parameter(torch.tensor(1.0))
        optimizer = torch.optim.AdamW([parameter], lr=1e-4)
        scheduler = torch.optim.lr_scheduler.CosineAnnealingLR(optimizer, T_max=20)
        stats = {"loss": 0.1, "angle": 0.01, "length": 0.2}
        with TemporaryDirectory() as folder:
            path = Path(folder) / "results.csv"
            for epoch in range(20):
                used = optimizer.param_groups[0]["lr"]
                optimizer.zero_grad()
                parameter.square().backward()
                optimizer.step()
                scheduler.step()
                _append_csv(path, epoch + 1, epoch, stats, stats, used, optimizer.param_groups[0]["lr"])
            with path.open() as handle:
                rows = list(csv.DictReader(handle))
        self.assertEqual(float(rows[0]["lr_used"]), 1e-4)
        self.assertGreater(float(rows[-1]["lr_used"]), 0)
        self.assertAlmostEqual(float(rows[-1]["lr_used"]), 6.15583e-7, delta=1e-12)
        self.assertEqual(float(rows[-1]["lr_next"]), 0)

    def test_csv_keeps_checkpoint_loss_precision(self):
        values = [0.12345671, 0.12345669]
        with TemporaryDirectory() as folder:
            path = Path(folder) / "results.csv"
            for epoch, value in enumerate(values, 1):
                stats = {"loss": value, "angle": 0., "length": value}
                _append_csv(path, epoch, 1., stats, stats, 1e-4, 1e-4)
            with path.open(encoding="utf-8") as handle:
                rows = list(csv.DictReader(handle))
        self.assertEqual([float(row["val/loss"]) for row in rows], values)
        self.assertEqual(int(min(rows, key=lambda row: float(row["val/loss"]))["epoch"]), 2)

    def test_legacy_rounded_ties_do_not_reject_true_best(self):
        from scripts.audit_training import validate_logged_best
        rows = [{"epoch": "1", "val/loss": "0.123457"}, {"epoch": "2", "val/loss": "0.123457"}]
        selected = validate_logged_best(rows, {"epoch": 2, "val_loss": .1234566})
        self.assertEqual(selected["epoch"], "2")
        with self.assertRaises(ValueError):
            validate_logged_best(rows, {"epoch": 2, "val_loss": .12346})

    def test_last_checkpoint_log_validation_does_not_require_best_ce(self):
        from scripts.audit_training import validate_logged_best, validate_logged_checkpoint
        rows = [{"epoch": "1", "val/loss": "0.3"}, {"epoch": "2", "val/loss": "0.8"}]
        last = {"epoch": 2, "val_loss": .8}
        self.assertEqual(validate_logged_checkpoint(rows, last, name="last"), rows[1])
        with self.assertRaisesRegex(ValueError, "较优epoch"):
            validate_logged_best(rows, last)
        with self.assertRaisesRegex(ValueError, "last checkpoint损失"):
            validate_logged_checkpoint(rows, {**last, "val_loss": .3}, name="last")

    def test_teacher_audit_selects_weight_ce_and_query_without_reusing_trace_choice(self):
        import contextlib
        import io
        import json
        from types import SimpleNamespace
        import numpy as np
        from scripts.audit_training import audit_aerial, sha256
        with TemporaryDirectory() as tmp:
            root = Path(tmp)
            run = root / "run"
            (run / "weights").mkdir(parents=True)
            annotation = root / "annotations"
            annotation.mkdir()
            train_cache, val_cache = root / "train.json", root / "val.json"
            train_cache.write_text("train", encoding="utf-8")
            val_cache.write_text("val", encoding="utf-8")
            manifest = {"train_cache_manifest_sha256": sha256(train_cache),
                        "validation_cache_manifest_sha256": sha256(val_cache),
                        "train_sample_content_sha256": "samples", "validation_sample_content_sha256": "samples",
                        "scope": "synthetic_interface_fixture"}
            (run / "split_manifest.json").write_text(json.dumps(manifest), encoding="utf-8")
            (run / "source_manifest.json").write_text("{}", encoding="utf-8")
            (run / "results.csv").write_text(
                "epoch,train/loss,val/loss,train/accuracy,val/accuracy\n1,0.4,0.3,0.5,0.5\n2,0.4,0.8,0.5,0.5\n",
                encoding="utf-8")
            config = {"architecture": "aerial_route_recurrent_v2", "imgsz": 8, "history_frames": 2,
                      "sequence_chunk_size": 2, "loss_protocol": {}, "text_control": "original",
                      "tokenizer_version": "route_numeric_v1", "memory_mode": "carry",
                      "vision_batchnorm_protocol": "fixed", "text_query_mode": "state_conditioned_v1",
                      "split_manifest_sha256": sha256(run / "split_manifest.json")}
            for name, epoch, loss in (("best", 1, .3), ("last", 2, .8)):
                torch.save({"model_config": config, "model": {"marker": torch.tensor(float(epoch))},
                            "epoch": epoch, "val_loss": loss}, run / "weights" / f"{name}.pt")
            hparams = {**config, "annotation_root": str(annotation), "cache_manifest": str(train_cache),
                       "validation_cache_manifest": str(val_cache), "validation_split": "val_seen",
                       "history": 2, "epochs": 2}
            from PIL import Image
            image = root / "sample.png"
            Image.new("RGB", (8, 8)).save(image)
            sample = {"scene_id": 2, "episode_id": "ep", "frame_index": 0, "action": 0,
                      "image": image, "image_sha256": sha256(image)}
            train, val = [{**sample, "capture_session_id": "train"}], [{**sample, "capture_session_id": "dev"}]
            diagnostic = {key: sample[key] for key in ("scene_id", "episode_id", "frame_index")}
            diagnostic.update(teacher_action=0, prediction={"action": 0})
            matrix = np.zeros((8, 8), dtype=np.int64)
            matrix[0, 0] = 1
            def predictor(path, device):
                return SimpleNamespace(model=path.stem, vocab=None, config=config, checkpoint_sha256=sha256(path))
            def epoch(*, model, **kwargs):
                return {"loss": .3 if model == "best" else .8, "accuracy": 1., "confusion_matrix": matrix.tolist()}
            with patch("uavnav.avln.data.load_aerial_samples", side_effect=lambda _root, split, *a, **k: train if split == "train" else val), \
                    patch("uavnav.avln.data.group_aerial_episodes", side_effect=lambda samples: [samples]), \
                    patch("scripts.audit_training.sample_content_sha256", return_value="samples"), \
                    patch("scripts.audit_training.load_predictor", side_effect=predictor) as loaded, \
                    patch("uavnav.avln.fit._aerial_sequence_epoch", side_effect=epoch) as evaluated, \
                    patch("uavnav.avln.closed_loop.replay_aerial_teacher_samples", return_value=[diagnostic]), \
                    contextlib.redirect_stdout(io.StringIO()):
                for index, choice in enumerate((None, "best", "last")):
                    args = SimpleNamespace(run_dir=run, output_dir=root / f"audit{index}", device="cpu", checkpoint_choice="last")
                    if choice is not None:
                        args.teacher_checkpoint_choice = choice
                    selected = choice or "best"
                    report = audit_aerial(args, hparams)
                    self.assertEqual(loaded.call_args.args[0].name, selected + ".pt")
                    self.assertEqual(report["selected_teacher_checkpoint"]["choice"], selected)
                    self.assertEqual(report["selected_teacher_checkpoint"]["sha256"], sha256(run / "weights" / f"{selected}.pt"))
                    self.assertEqual(report["selected_teacher_checkpoint"]["epoch"], 1 if selected == "best" else 2)
                    self.assertEqual(report["logged_selected_teacher_epoch"]["epoch"], "1" if selected == "best" else "2")
                    self.assertEqual(report["logged_best_epoch"]["epoch"], "1")
                    self.assertEqual(report["independent_reload_validation"]["loss"], .3 if selected == "best" else .8)
                    self.assertEqual(report["text_query_mode"], "state_conditioned_v1")
                    self.assertEqual(set(report["checkpoint"]), {"best", "last"})
                args = SimpleNamespace(run_dir=run, output_dir=root / "wrong-ce", device="cpu", teacher_checkpoint_choice="last")
                evaluated.side_effect = lambda **kwargs: {"loss": .3, "confusion_matrix": matrix.tolist()}
                with self.assertRaisesRegex(ValueError, "独立重载"):
                    audit_aerial(args, hparams)
                args.output_dir = root / "wrong-query"
                with self.assertRaisesRegex(ValueError, "text_query_mode"):
                    audit_aerial(args, {**hparams, "text_query_mode": "visual_history"})

    def test_sample_binding_detects_image_log_and_label_mutation(self):
        with TemporaryDirectory() as folder:
            root = Path(folder)
            (root / "FrontCamera").mkdir()
            (root / "log").mkdir()
            image = root / "FrontCamera" / "0.png"
            image.write_bytes(b"image1")
            log = root / "log" / "0.json"
            log.write_text("{}")
            samples = [{"image": image, "instruction": "go", "offset": torch.zeros(3).numpy()}]
            baseline = sample_content_sha256(samples)
            image.write_bytes(b"image2")
            self.assertNotEqual(baseline, sample_content_sha256(samples))
            image.write_bytes(b"image1")
            log.write_text('{"changed":true}')
            self.assertNotEqual(baseline, sample_content_sha256(samples))
            log.write_text("{}")
            samples[0]["offset"][0] = 1
            self.assertNotEqual(baseline, sample_content_sha256(samples))

    def test_sample_hash_stream_matches_historical_json_and_one_pass_inputs(self):
        import hashlib
        import json
        import numpy as np

        def historical(samples):
            hashes, rows = {}, []
            for sample in samples:
                row = {}
                for key, value in sample.items():
                    if isinstance(value, Path):
                        path = value.resolve()
                        row[key] = str(path)
                        if path not in hashes:
                            hashes[path] = hashlib.sha256(path.read_bytes()).hexdigest()
                        row[f"{key}_content_sha256"] = hashes[path]
                    elif isinstance(value, np.ndarray):
                        row[key] = value.tolist()
                    else:
                        row[key] = value
                if sample.get("image") is not None and "action" not in sample:
                    trajectory = Path(sample["image"]).parent.parent
                    key = (trajectory, "logs")
                    if key not in hashes:
                        hashes[key] = _json_sha256([
                            [p.name, hashlib.sha256(p.read_bytes()).hexdigest()]
                            for p in sorted((trajectory / "log").glob("*.json"))])
                    row["trajectory_logs_sha256"] = hashes[key]
                rows.append(row)
            return _json_sha256(rows)

        class OnePass:
            def __init__(self, values):
                self.values, self.used = values, False

            def __len__(self):
                raise AssertionError("sample hashing must not materialize the input")

            def __iter__(self):
                if self.used:
                    raise AssertionError("sample hashing must use one input pass")
                self.used = True
                yield from self.values

        with TemporaryDirectory() as folder:
            root = Path(folder)
            (root / "FrontCamera").mkdir()
            (root / "log").mkdir()
            image = root / "FrontCamera" / "路线.png"
            image.write_bytes(b"image-content")
            depth = root / "depth.npy.gz"
            depth.write_bytes(b"depth-content")
            (root / "log" / "1.json").write_text('{"pose":1}', encoding="utf-8")
            image_sha = hashlib.sha256(image.read_bytes()).hexdigest()
            samples = [{"image": image, "instruction": "右转 café 🛩", "image_sha256": image_sha,
                        "history": np.eye(8, dtype=np.float32)[:2], "depth": depth, "action": 7,
                        "render_protocol": {"provenance": {"settings": {"宽度": 256}}, "active": True}},
                       {"image": image, "instruction": "原FOV", "offset": np.array([-.0, .125, -1.],
                                                                                       dtype=np.float32)}]
            expected = historical(samples)
            original_dumps = json.dumps

            def row_only(value, *args, **kwargs):
                self.assertIsInstance(value, dict)
                return original_dumps(value, *args, **kwargs)

            # The FOV logs themselves retain their historical list digest; only
            # the all-sample container must avoid an aggregate JSON allocation.
            aerial = [samples[0], {**samples[0], "action": 0}]
            aerial_expected = historical(aerial)
            with patch("uavnav.avln.fit.json.dumps", side_effect=row_only):
                self.assertEqual(sample_content_sha256(OnePass(aerial)), aerial_expected)
                self.assertEqual(sample_content_sha256(OnePass([])), hashlib.sha256(b"[]").hexdigest())
            self.assertEqual(sample_content_sha256(OnePass(samples)), expected)
            with self.assertRaises(ValueError):
                sample_content_sha256([{**samples[0], "image_sha256": "0" * 64}])
            with self.assertRaises(ValueError):
                sample_content_sha256([{"invalid": float("nan")}])


class AerialActionTests(unittest.TestCase):
    def checkpoint(self):
        model = AerialRouteNet(3, history_frames=2, hidden=4, pretrained=False, ablate="no_image").eval()
        saved = payload(model)
        saved["length_scale"] = 1.
        protocol = aerial_task_protocol(8)
        saved["model_config"].update(checkpoint_format_version=4, architecture="aerial_route_v1",
            backbone="resnet18", visual_fusion="spatial", grid_size=4, stop_enabled=True,
            fusion_mode="query_plus_text", output_version="aerial_action8_v1", history_policy="action_onehot8_v1",
            data_protocol="aerialvln_s_v1", task_protocol=protocol, task_protocol_sha256=_json_sha256(protocol),
            text_control="original", strip_direction=False, split_manifest_sha256="a" * 64)
        render = {"protocol_version": "aerialvln_s_pose_rgb_v1", "pose_mode": "simSetVehiclePose_ignore_collision",
                  "pixel_order": "RGB", "rgb_type": "Scene", "camera_name": "front_0", "width": 8, "height": 8}
        rendered = {"train": render, "validation": dict(render)}
        saved["model_config"].update(input_render_protocols=rendered, input_render_protocols_sha256=_json_sha256(rendered))
        return model, saved

    def inputs(self):
        inputs = batch()
        inputs["history"] = torch.zeros(2, 2, 8)
        inputs["history"][0, -1, 2] = 1
        inputs["history"][1, -1, 3] = 1
        inputs["history_length"] = torch.ones(2, dtype=torch.long)
        return inputs

    def test_turn_and_stop_are_distinct_classes_with_gradient(self):
        model, _ = self.checkpoint()
        logits = model(self.inputs())
        self.assertEqual(logits.shape, (2, 8))
        loss = torch.nn.functional.cross_entropy(logits, torch.tensor([2, 0]))
        loss.backward()
        self.assertGreater(model.head.weight.grad[2].abs().sum().item(), 0)
        self.assertGreater(model.head.weight.grad[0].abs().sum().item(), 0)
        self.assertGreater(model.history_proj.weight.grad.abs().sum().item(), 0)

    def test_independent_reload_action_probability_and_history_equivalence(self):
        import numpy as np
        model, saved = self.checkpoint()
        with TemporaryDirectory() as folder:
            path = Path(folder) / "aerial.pt"
            torch.save(saved, path)
            predictor = AerialActionPredictor(path, device="cpu")
            image = np.zeros((8, 8, 3), dtype=np.uint8)
            ids = [2, 3]
            inputs = predictor._batch(image, "car", ids)
            with torch.no_grad():
                self.assertTrue(torch.equal(model(inputs), predictor.model(inputs)))
            other = predictor._batch(image, "car", np.eye(8, dtype=np.float32)[ids])
            self.assertTrue(torch.equal(inputs["history"], other["history"]))
            result = predictor.predict_action(image, "car", ids)
            self.assertEqual(len(result["action_probabilities"]), 8)
            self.assertAlmostEqual(sum(result["action_probabilities"]), 1., places=6)
            self.assertEqual(result["stop_probability"], result["action_probabilities"][0])
            with self.assertRaises(CheckpointFormatError):
                WaypointPredictor(path, device="cpu")
            for bad in ([1.5], [True], [-1], [8], [[0, 0, 0]]):
                with self.subTest(history=bad), self.assertRaises(ValueError):
                    predictor.predict_action(image, "car", bad)

    def test_route_checkpoint_requires_complete_versioned_contract(self):
        _, saved = self.checkpoint()
        for change in (lambda c: c.pop("fusion_mode"), lambda c: c.update(stop_enabled=False),
                       lambda c: c.update(checkpoint_format_version=3), lambda c: c.update(history_policy="body3"),
                       lambda c: c.update(data_protocol="fov"), lambda c: c.update(strip_direction=True),
                       lambda c: c.update(output_version="waypoint_v1")):
            tampered = copy.deepcopy(saved)
            change(tampered["model_config"])
            with self.assertRaises(CheckpointFormatError):
                _validate_checkpoint(tampered)

    def test_action_epoch_is_independent_of_batch_partition(self):
        class ControlledAction(nn.Module):
            def forward(self, inputs):
                self_outer.assertEqual(set(inputs), {"image", "tokens", "token_mask", "history", "history_length"})
                return inputs["image"]
        self_outer = self
        data = {"image": torch.tensor([[2., 0, 0, 0, 0, 0, 0, 0],
                                       [0., 0, 2, 0, 0, 0, 0, 0],
                                       [2., 0, 0, 0, 0, 0, 0, 0]]),
                "tokens": torch.ones(3, 1, dtype=torch.long), "token_mask": torch.ones(3, 1, dtype=torch.bool),
                "history": torch.zeros(3, 2, 8), "history_length": torch.zeros(3, dtype=torch.long),
                "action_target": torch.tensor([0, 2, 3])}
        full = _aerial_epoch(ControlledAction(), [data], torch.device("cpu"))
        singles = [{key: value[i:i+1] for key, value in data.items()} for i in range(3)]
        split = _aerial_epoch(ControlledAction(), singles, torch.device("cpu"))
        self.assertAlmostEqual(full["loss"], split["loss"], places=6)
        for key in ("accuracy", "samples", "stop_recall", "stop_precision", "confusion_matrix"):
            self.assertEqual(full[key], split[key])


class AerialRecurrentTests(unittest.TestCase):
    def model(self):
        torch.manual_seed(41)
        model = AerialRecurrentRouteNet(5, history_frames=2, hidden=4, pretrained=False).eval()
        model.vision = nn.Conv2d(3, 512, 1, bias=False)
        return model

    def inputs(self, length=4):
        torch.manual_seed(42)
        return {"image": torch.rand(length, 3, 8, 8), "tokens": torch.tensor([[2, 3]] * length),
                "token_mask": torch.ones(length, 2, dtype=torch.bool),
                "history": torch.eye(8)[torch.tensor([[1, 2]] * length)],
                "history_length": torch.tensor([2] * length)}

    def slice(self, batch, begin, end):
        return {key: value[begin:end] for key, value in batch.items()}

    def checkpoint(self, text_control="original", memory_mode="carry"):
        torch.manual_seed(41)
        model = AerialRecurrentRouteNet(3, history_frames=2, hidden=4, pretrained=False,
                                        ablate="no_image", memory_mode=memory_mode).eval()
        _, saved = AerialActionTests().checkpoint()
        saved["model"] = model.state_dict()
        saved["model_config"].update(checkpoint_format_version=5, architecture="aerial_route_recurrent_v2",
            memory_protocol="fused_gru_v1", sequence_policy="episode_contiguous_tbptt_v1",
            tokenizer_version="route_numeric_v1", text_control=text_control, sequence_chunk_size=4,
            memory_mode=memory_mode, vision_batchnorm_protocol="frozen_running_stats_v1",
            constant_text_token="<unk>" if text_control == "constant" else None,
            loss_protocol={"version": "transition_weighted_ce_v1", "inflection_weight": 1.9,
                           "stop_weight": 1.9, "normalization": "sum_weights"})
        return model, saved

    def test_episode_batch_matches_per_episode_sequences(self):
        model = self.model()
        first, second = self.inputs(3), self.inputs(3)
        second["image"] = second["image"].flip(0) + 0.1
        merged = {key: torch.cat((first[key], second[key])) for key in first}
        with torch.no_grad():
            expected_a, state_a = model.forward_sequence(first)
            expected_b, state_b = model.forward_sequence(second)
            logits, state = model.forward_sequence_batch(merged, None, 2, 3)
        self.assertTrue(torch.allclose(logits, torch.cat((expected_a, expected_b)), atol=1e-6, rtol=1e-6))
        self.assertTrue(torch.allclose(state, torch.cat((state_a, state_b), dim=1), atol=1e-6, rtol=1e-6))

    def test_sequence_chunks_and_online_steps_agree(self):
        model, inputs = self.model(), self.inputs()
        with torch.no_grad():
            complete, state = model.forward_sequence(inputs)
            first, prefix = model.forward_sequence(self.slice(inputs, 0, 2))
            second, following = model.forward_sequence(self.slice(inputs, 2, 4), prefix.detach())
            sequential, current = [], None
            for index in range(4):
                output, current = model.forward_step(self.slice(inputs, index, index + 1), current)
                sequential.append(output)
        self.assertTrue(torch.allclose(complete, torch.cat((first, second)), atol=1e-6, rtol=1e-6))
        self.assertTrue(torch.allclose(complete, torch.cat(sequential), atol=1e-6, rtol=1e-6))
        self.assertTrue(torch.allclose(state, following, atol=1e-6, rtol=1e-6))
        self.assertTrue(torch.allclose(state, current, atol=1e-6, rtol=1e-6))

    def test_state_conditioned_query_sequence_and_online_steps_agree(self):
        """候选文本查询只能使用当前及过去状态，分块与在线路径必须同语义。"""
        torch.manual_seed(41)
        model = AerialRecurrentRouteNet(
            5, history_frames=2, hidden=4, pretrained=False,
            text_query_mode="state_conditioned_v1").eval()
        model.vision = nn.Conv2d(3, 512, 1, bias=False)
        inputs = self.inputs()
        with torch.no_grad():
            complete, complete_state = model.forward_sequence(inputs)
            first, prefix = model.forward_sequence(self.slice(inputs, 0, 2))
            second, following = model.forward_sequence(self.slice(inputs, 2, 4), prefix.detach())
            online, state = [], None
            for index in range(4):
                output, state = model.forward_step(self.slice(inputs, index, index + 1), state)
                online.append(output)
        chunked = torch.cat((first, second))
        stepped = torch.cat(online)
        atol = 2e-4 if complete.device.type == "cuda" else 1e-6
        self.assertTrue(torch.allclose(complete, chunked, atol=atol, rtol=1e-6))
        self.assertTrue(torch.allclose(complete, stepped, atol=atol, rtol=1e-6))
        self.assertTrue(torch.equal(complete.argmax(dim=-1), chunked.argmax(dim=-1)))
        self.assertTrue(torch.equal(complete.argmax(dim=-1), stepped.argmax(dim=-1)))
        self.assertTrue(torch.allclose(complete_state, following, atol=atol, rtol=1e-6))
        self.assertTrue(torch.allclose(complete_state, state, atol=atol, rtol=1e-6))
        self.assertTrue(hasattr(model, "state_query"))
        self.assertEqual(model.text_query_mode, "state_conditioned_v1")

    def test_default_v2_keeps_legacy_text_query_and_state_dict_shape(self):
        """默认 v2 必须维持旧查询语义，避免旧 checkpoint 被隐式改写。"""
        legacy = self.model()
        explicit = AerialRecurrentRouteNet(5, history_frames=2, hidden=4,
                                           pretrained=False, text_query_mode="visual_history").eval()
        explicit.vision = nn.Conv2d(3, 512, 1, bias=False)
        self.assertEqual(legacy.text_query_mode, "visual_history")
        self.assertFalse(hasattr(legacy, "state_query"))
        self.assertFalse(hasattr(explicit, "state_query"))
        self.assertEqual({key: value.shape for key, value in legacy.state_dict().items()},
                         {key: value.shape for key, value in explicit.state_dict().items()})
        rebuilt = build_model(5, {"architecture": "aerial_route_recurrent_v2",
                                  "history_frames": 2, "hidden": 4, "pretrained": False},
                              pretrained=False).eval()
        self.assertEqual(rebuilt.text_query_mode, "visual_history")
        self.assertFalse(hasattr(rebuilt, "state_query"))
        with self.assertRaises(ValueError):
            AerialRecurrentRouteNet(5, history_frames=2, hidden=4,
                                    pretrained=False, text_query_mode="unknown")

    def test_state_conditioned_query_has_finite_gradients_and_rejects_bad_state(self):
        torch.manual_seed(43)
        model = AerialRecurrentRouteNet(
            5, history_frames=2, hidden=4, pretrained=False,
            text_query_mode="state_conditioned_v1").eval()
        model.vision = nn.Conv2d(3, 512, 1, bias=False)
        inputs = self.inputs()
        first, state = model.forward_step(self.slice(inputs, 0, 1))
        logits, state = model.forward_step(self.slice(inputs, 1, 2), state)
        self.assertEqual(first.shape, (1, 8))
        self.assertEqual(logits.shape, (1, 8))
        self.assertEqual(state.shape, (1, 1, 4))
        loss = logits.square().sum()
        loss.backward()
        self.assertIsNotNone(model.state_query.weight.grad)
        self.assertTrue(torch.isfinite(model.state_query.weight.grad).all())
        with self.assertRaises(ValueError):
            model.forward_step(self.slice(inputs, 1, 2), torch.ones(1, 2, 4))
        with self.assertRaises(ValueError):
            model.forward_step(self.slice(inputs, 1, 2), torch.full((1, 1, 4), float("nan")))

    def test_state_conditioned_query_has_no_future_frame_effect(self):
        """候选按时间步展开，未来观测不得改变更早动作。"""
        torch.manual_seed(44)
        model = AerialRecurrentRouteNet(
            5, history_frames=2, hidden=4, pretrained=False,
            text_query_mode="state_conditioned_v1")
        model.vision = nn.Sequential(nn.Conv2d(3, 512, 1, bias=False), nn.BatchNorm2d(512))
        model.train()
        inputs = self.inputs()
        changed = {key: value.clone() for key, value in inputs.items()}
        changed["image"][-1] = 10.0 * changed["image"][-1]
        baseline, _ = model.forward_sequence(inputs)
        altered, _ = model.forward_sequence(changed)
        self.assertTrue(torch.equal(baseline[:-1], altered[:-1]))
        self.assertFalse(model.vision[1].training)

    def test_state_conditioned_reset_each_step_clears_query_and_memory_state(self):
        torch.manual_seed(45)
        model = AerialRecurrentRouteNet(
            5, history_frames=2, hidden=4, pretrained=False,
            memory_mode="reset_each_step", text_query_mode="state_conditioned_v1").eval()
        model.vision = nn.Conv2d(3, 512, 1, bias=False)
        inputs = self.inputs()
        with torch.no_grad():
            clean, _ = model.forward_step(self.slice(inputs, 0, 1), None)
            contaminated, state = model.forward_step(
                self.slice(inputs, 0, 1), torch.ones(1, 1, 4))
        self.assertTrue(torch.allclose(clean, contaminated, atol=1e-6, rtol=1e-6))
        self.assertEqual(state.shape, (1, 1, 4))

    def test_checkpoint_render_pass_contract_and_v2_sources_are_bound(self):
        from test_data import aerial_v2_cache
        _, saved = self.checkpoint()
        with TemporaryDirectory() as folder:
            _, _, cache = aerial_v2_cache(Path(folder), session="new-session")
        config = saved["model_config"]
        config.update(vision_train_policy="frozen", render_pass_policy="episode_uniform_pass_v1",
                      render_pass_seed=0, render_pass_count=1,
                      train_render_passes=[{"pass_index": 0, "source": "/cache/pass0.json",
                                           "manifest_sha256": "a" * 64, "sample_content_sha256": "b" * 64,
                                           "capture_session_id": "new-session"}])
        config["input_render_protocols"] = {"train": cache["render_protocol"], "validation": cache["render_protocol"]}
        config["input_render_protocols_sha256"] = _json_sha256(config["input_render_protocols"])
        _validate_checkpoint(saved)
        for change in (lambda c: c.update(vision_train_policy="unknown"),
                       lambda c: c.pop("render_pass_seed"),
                       lambda c: c.update(render_pass_seed=True),
                       lambda c: c.update(render_pass_count=2),
                       lambda c: c["train_render_passes"][0].update(manifest_sha256="invalid"),
                       lambda c: c["input_render_protocols"]["train"]["provenance"]["settings"].update(changed=True)):
            altered = copy.deepcopy(saved)
            change(altered["model_config"])
            # Re-hashing the outer object cannot conceal inconsistent nested provenance.
            altered["model_config"]["input_render_protocols_sha256"] = _json_sha256(altered["model_config"]["input_render_protocols"])
            with self.subTest(config=altered["model_config"]), self.assertRaises(CheckpointFormatError):
                _validate_checkpoint(altered)

    def test_render_pass_audit_rejects_changed_choice_or_update_budget(self):
        import random
        from scripts.audit_training import validate_render_pass_ledger
        episodes = [[{"scene_id": 2, "episode_id": "a"}] * 3,
                    [{"scene_id": 2, "episode_id": "b"}] * 2]
        entries = []
        for epoch in range(2):
            choices_rng = random.Random(7 + epoch)
            choices = [choices_rng.randrange(2) for _ in episodes]
            order = [0, 1]
            random.Random(3 + epoch).shuffle(order)
            entries.append({"epoch": epoch + 1, "seed": 7, "policy": "episode_uniform_pass_v1",
                            "pass_count": 2, "samples": 5, "optimizer_updates": 3,
                            "selections": [{"scene_id": 2, "episode_id": episodes[i][0]["episode_id"],
                                            "pass_index": choices[i]} for i in order]})
        validate_render_pass_ledger(entries, episodes, 2, 7, 3, 2, 2)
        for change in (lambda rows: rows.pop(), lambda rows: rows[0].update(optimizer_updates=4),
                       lambda rows: rows[0].update(samples=10),
                       lambda rows: rows[0]["selections"][0].update(episode_id="foreign"),
                       lambda rows: rows[0]["selections"][0].update(pass_index=3)):
            altered = copy.deepcopy(entries)
            change(altered)
            with self.subTest(entries=altered), self.assertRaises(ValueError):
                validate_render_pass_ledger(altered, episodes, 2, 7, 3, 2, 2)

    def test_earlier_visual_observation_changes_later_action_and_receives_gradient(self):
        model, inputs = self.model(), self.inputs()
        changed = {key: value.clone() for key, value in inputs.items()}
        changed["image"][0] = 1. - changed["image"][0]
        with torch.no_grad():
            complete, _ = model.forward_sequence(inputs)
            altered, _ = model.forward_sequence(changed)
        self.assertGreater((complete[-1] - altered[-1]).abs().max().item(), 1e-8)
        inputs["image"].requires_grad_()
        logits, state = model.forward_sequence(inputs)
        torch.nn.functional.cross_entropy(logits[-1:], torch.tensor([0])).backward()
        self.assertGreater(inputs["image"].grad[0].abs().sum().item(), 0)
        self.assertTrue(torch.isfinite(inputs["image"].grad).all())
        self.assertGreater(model.memory.weight_hh_l0.grad.abs().sum().item(), 0)
        self.assertEqual(state.shape, (1, 1, 4))

    def test_reset_prevents_cross_episode_state_and_text_binding(self):
        import numpy as np
        _, saved = self.checkpoint()
        with TemporaryDirectory() as folder:
            path = Path(folder) / "recurrent.pt"
            torch.save(saved, path)
            predictor = AerialActionPredictor(path, device="cpu")
            image = np.zeros((8, 8, 3), dtype=np.uint8)
            first = predictor.predict_action(image, "car", [1, 2])
            second = predictor.predict_action(image, "car", [1, 2])
            self.assertGreater(max(abs(a - b) for a, b in zip(first["action_probabilities"], second["action_probabilities"])), 0)
            with self.assertRaises(ValueError):
                predictor.predict_action(image, "different instruction", [])
            predictor.reset_episode()
            repeated = predictor.predict_action(image, "car", [1, 2])
            self.assertEqual(first["action_probabilities"], repeated["action_probabilities"])
            predictor.reset_episode()
            self.assertIsNone(predictor._state)
            self.assertIsNone(predictor._session_instruction)
            predictor.predict_action(image, "different instruction", [])

    def test_recurrent_checkpoint_exact_protocol_and_old_route_compatibility(self):
        _, saved = self.checkpoint()
        _validate_checkpoint(saved)
        for change in (lambda c: c.pop("memory_protocol"), lambda c: c.update(memory_protocol="other"),
                       lambda c: c.update(sequence_policy="shuffled_frames"), lambda c: c.pop("tokenizer_version"),
                       lambda c: c.update(tokenizer_version="fov_numeric_v1"), lambda c: c.pop("loss_protocol"),
                       lambda c: c.pop("sequence_chunk_size"), lambda c: c.update(sequence_chunk_size=0),
                       lambda c: c.update(constant_text_token="<neutral>"),
                       lambda c: c.pop("memory_mode"), lambda c: c.update(memory_mode="unknown"),
                       lambda c: c.pop("vision_batchnorm_protocol"),
                       lambda c: c["loss_protocol"].update(stop_weight=0),
                       lambda c: c["loss_protocol"].update(inflection_weight=True),
                       lambda c: c["loss_protocol"].update(normalization="frames"),
                       lambda c: c.update(checkpoint_format_version=4)):
            changed = copy.deepcopy(saved)
            change(changed["model_config"])
            with self.subTest(change=changed["model_config"]), self.assertRaises(CheckpointFormatError):
                _validate_checkpoint(changed)
        _, legacy = AerialActionTests().checkpoint()
        _, _, config = _validate_checkpoint(legacy)
        self.assertEqual(config["tokenizer_version"], "fov_numeric_v1")
        self.assertEqual(config["architecture"], "aerial_route_v1")

    def test_reset_memory_control_keeps_parameters_and_removes_earlier_visual_effect(self):
        carry, inputs = self.model(), self.inputs()
        reset = self.model()
        reset.memory_mode = "reset_each_step"
        reset.load_state_dict(carry.state_dict(), strict=True)
        self.assertEqual(sum(p.numel() for p in carry.parameters()), sum(p.numel() for p in reset.parameters()))
        changed = {key: value.clone() for key, value in inputs.items()}
        changed["image"][0] = 1. - changed["image"][0]
        with torch.no_grad():
            baseline, _ = reset.forward_sequence(inputs)
            altered, _ = reset.forward_sequence(changed)
            outputs, state = [], None
            for index in range(4):
                output, state = reset.forward_step(self.slice(inputs, index, index + 1), state)
                outputs.append(output)
            final, _ = reset.forward_step(self.slice(inputs, 3, 4), torch.ones(1, 1, 4))
        self.assertTrue(torch.equal(baseline[-1], altered[-1]))
        self.assertTrue(torch.allclose(baseline, torch.cat(outputs), atol=1e-6, rtol=1e-6))
        self.assertTrue(torch.allclose(baseline[-1:], final, atol=1e-6, rtol=1e-6))
        with self.assertRaises(ValueError):
            build_model(5, {"architecture": "aerial_route_recurrent_v2", "memory_mode": "unknown"})
        with self.assertRaises(ValueError):
            build_model(5, {"architecture": "aerial_route_v1", "memory_mode": "carry"})

    def test_future_frame_cannot_change_earlier_action_in_training_mode(self):
        model = AerialRecurrentRouteNet(5, history_frames=2, hidden=4, pretrained=False)
        model.vision = nn.Sequential(nn.Conv2d(3, 512, 1, bias=False), nn.BatchNorm2d(512))
        model.train()
        inputs = self.inputs()
        changed = {key: value.clone() for key, value in inputs.items()}
        changed["image"][-1] = 10. * changed["image"][-1]
        batchnorm = model.vision[1]
        stats = (batchnorm.running_mean.clone(), batchnorm.running_var.clone())
        baseline, _ = model.forward_sequence(inputs)
        altered, _ = model.forward_sequence(changed)
        self.assertTrue(torch.equal(baseline[:-1], altered[:-1]))
        self.assertFalse(batchnorm.training)
        self.assertTrue(model.training)
        self.assertTrue(torch.equal(stats[0], batchnorm.running_mean))
        self.assertTrue(torch.equal(stats[1], batchnorm.running_var))
        baseline.sum().backward()
        self.assertGreater(model.vision[0].weight.grad.abs().sum().item(), 0)
        self.assertGreater(batchnorm.weight.grad.abs().sum().item(), 0)
        legacy = AerialRouteNet(5, history_frames=2, hidden=4, pretrained=False)
        legacy.train()
        self.assertTrue(all(module.training for module in legacy.vision.modules() if isinstance(module, nn.BatchNorm2d)))

    def test_teacher_sequence_api_does_not_mutate_online_state(self):
        model, saved = self.checkpoint()
        with TemporaryDirectory() as folder:
            path = Path(folder) / "recurrent.pt"
            torch.save(saved, path)
            predictor = AerialActionPredictor(path, device="cpu")
            batch = self.inputs()
            batch["tokens"] = torch.tensor([[2]] * 4)
            batch["token_mask"] = torch.ones(4, 1, dtype=torch.bool)
            logits, state = predictor.predict_sequence(batch)
            with torch.no_grad():
                expected, expected_state = model.forward_sequence(batch)
            self.assertTrue(torch.equal(logits, expected))
            self.assertTrue(torch.equal(state, expected_state))
            first, prefix = predictor.predict_sequence(self.slice(batch, 0, 2))
            second, following = predictor.predict_sequence(self.slice(batch, 2, 4), prefix)
            self.assertTrue(torch.allclose(logits, torch.cat((first, second)), atol=1e-6, rtol=1e-6))
            self.assertTrue(torch.allclose(state, following, atol=1e-6, rtol=1e-6))
            self.assertIsNone(predictor._state)
            self.assertIsNone(predictor._session_instruction)

    def test_numeric_and_constant_tokenizers_survive_checkpoint_reload(self):
        import contextlib
        import io
        import json
        import numpy as np
        from PIL import Image
        from scripts.verify_stage2 import _aerial_main
        _, saved = self.checkpoint()
        saved["vocab"] = {"<pad>": 0, "<unk>": 1, "car": 2, "10": 3, "20": 4}
        model = AerialRecurrentRouteNet(5, history_frames=2, hidden=4, pretrained=False,
                                        ablate="no_image").eval()
        saved["model"] = model.state_dict()
        with TemporaryDirectory() as folder:
            path = Path(folder) / "recurrent.pt"
            torch.save(saved, path)
            predictor = AerialActionPredictor(path, device="cpu")
            self.assertEqual(predictor.vocab.tokenizer_version, "route_numeric_v1")
            image = np.zeros((8, 8, 3), dtype=np.uint8)
            short = predictor._batch(image, "car 10", [])
            long = predictor._batch(image, "car 20", [])
            self.assertEqual(short["tokens"].tolist(), [[2, 3]])
            self.assertEqual(long["tokens"].tolist(), [[2, 4]])
            saved["model_config"]["text_control"] = "constant"
            saved["model_config"]["constant_text_token"] = "<unk>"
            torch.save(saved, path)
            predictor = AerialActionPredictor(path, device="cpu")
            first = predictor._batch(image, "red car", [])
            second = predictor._batch(image, "blue building", [])
            self.assertEqual(first["tokens"].tolist(), [[1]])
            self.assertTrue(torch.equal(first["tokens"], second["tokens"]))
            teacher = self.inputs()
            teacher["tokens"] = torch.tensor([[2, 3]] * 4)
            changed = dict(teacher, tokens=torch.tensor([[2, 4]] * 4))
            expected = dict(teacher, tokens=torch.ones(4, 1, dtype=torch.long),
                            token_mask=torch.ones(4, 1, dtype=torch.bool))
            original_logits, original_state = predictor.predict_sequence(teacher)
            changed_logits, changed_state = predictor.predict_sequence(changed)
            with torch.no_grad():
                expected_logits, expected_state = predictor.model.forward_sequence(expected)
            self.assertTrue(torch.equal(original_logits, changed_logits))
            self.assertTrue(torch.equal(original_logits, expected_logits))
            self.assertTrue(torch.equal(original_state, changed_state))
            self.assertTrue(torch.equal(original_state, expected_state))
            # Exercise the actual development entry: constant training must reach
            # independent prefix reload and preprocessing equality without reading text.
            run = Path(folder) / "run"
            (run / "weights").mkdir(parents=True)
            torch.save(saved, run / "weights" / "best.pt")
            image_path = Path(folder) / "frame.png"
            Image.new("RGB", (8, 8)).save(image_path)
            template = {"image": image_path, "instruction": "car 10", "scene_id": 2,
                        "image_sha256": __import__("hashlib").sha256(image_path.read_bytes()).hexdigest(),
                        "episode_id": "train", "traj_id": "2/route", "episode_sha256": "a" * 64,
                        "history_policy": "action_onehot8_v1"}
            samples = [{**template, "frame_index": 0, "action": 1, "history": np.zeros((0, 8), dtype=np.float32)},
                       {**template, "frame_index": 1, "action": 0, "history": np.eye(8, dtype=np.float32)[[1]]}]
            result_path = Path(folder) / "integration.json"
            with patch("train.train", return_value=run), \
                    patch("uavnav.avln.data.load_aerial_samples", return_value=samples), \
                    contextlib.redirect_stdout(io.StringIO()):
                _aerial_main(["--dataset", "aerialvln_s_v1", "--mode", "integration", "--device", "cpu",
                              "--annotation-root", folder, "--cache-manifest", "train.json",
                              "--validation-cache-manifest", "val.json", "--output", str(result_path)])
            report = json.loads(result_path.read_text(encoding="utf-8"))
            self.assertEqual(report["status"], "passed")
            self.assertTrue(report["preprocessing_identical"])
            self.assertEqual(report["independent_reload_prefix_frames"], 2)
            self.assertEqual(report["independent_process_max_absolute_error"], 0)
            self.assertEqual([sample["instruction"] for sample in samples], ["car 10", "car 10"])


class AerialRenderTrainingTests(unittest.TestCase):
    def test_grouped_development_audit_filters_passes_and_keeps_official_validation_unused(self):
        import contextlib
        import io
        import json
        import yaml
        from types import SimpleNamespace
        from test_data import DataContractTests
        from scripts.audit_training import audit_aerial, audit_loss_scale, loss_scale_training_cache_partition
        from uavnav.avln.fit import fit_aerial
        with TemporaryDirectory() as tmp:
            root = Path(tmp)
            folders, paths = DataContractTests()._grouped_training_caches(root)
            for path in paths:
                payload = json.loads(path.read_text(encoding="utf-8"))
                payload["scope"] = "synthetic_interface_fixture"
                path.write_text(json.dumps(payload), encoding="utf-8")
            with patch("uavnav.avln.fit._plot_loss"), contextlib.redirect_stdout(io.StringIO()):
                run = fit_aerial(annotation_root=folders[0], cache_manifest=paths[0],
                    validation_cache_manifest=paths[1], validation_split="development_train_grouped",
                    development_fraction=.5, development_split_seed=0,
                    architecture="aerial_route_recurrent_v2", epochs=1, batch=1, workers=0,
                    history=2, imgsz=16, lr=1e-4, device="cpu", seed=0, pretrained=False,
                    hidden=4, sequence_chunk_size=3, project=root / "runs", name="synthetic-grouped-contract")
                hparams = yaml.safe_load((run / "hparams.yaml").read_text(encoding="utf-8"))
                audited = audit_aerial(SimpleNamespace(run_dir=run, output_dir=root / "audit", device="cpu"), hparams)
                loss_audit = audit_loss_scale(SimpleNamespace(
                    run_dir=run, output_json=root / "loss-scale.json", supervision_json=None))
            self.assertEqual(audited["samples"], {"train": 8, "validation": 8})
            self.assertFalse(audited["development_route_split"]["official_validation_used"])
            self.assertEqual(audited["development_route_split"]["validation_source_split"], "train")
            self.assertIsNone(audited["SR"])
            self.assertEqual(loss_audit["actual_sequence_budget"]["episodes"], 1)
            self.assertEqual(loss_audit["actual_sequence_budget"]["states_per_epoch"], 8)
            self.assertEqual(loss_audit["actual_sequence_budget"]["chunks_per_epoch"], 3)
            self.assertEqual(loss_audit["source_cache_partition"]["source_cache_episodes"], 2)
            self.assertEqual(loss_audit["source_cache_partition"]["source_cache_dev_episodes"], 1)
            self.assertTrue(loss_audit["source_cache_partition"]["geometric_group_manifest_verified"])
            cache = json.loads((run / "train_cache_manifest.json").read_text(encoding="utf-8"))
            manifest = json.loads((run / "split_manifest.json").read_text(encoding="utf-8"))
            saved = torch.load(run / "weights" / "best.pt", map_location="cpu", weights_only=True)
            for field in ("model_selection_basis", "training_precision"):
                self.assertEqual(manifest[field], hparams[field])
                self.assertEqual(saved["model_config"][field], hparams[field])
            self.assertEqual(hparams["model_selection_basis"], "lowest_unweighted_teacher_validation_ce_not_navigation")
            self.assertEqual(hparams["training_precision"]["forward"], "fp32")
            self.assertEqual(audited["training_precision"], hparams["training_precision"])
            with self.assertRaisesRegex(ValueError, "冻结训练合同"):
                with contextlib.redirect_stdout(io.StringIO()):
                    audit_aerial(SimpleNamespace(run_dir=run, output_dir=root / "bad-selection-audit", device="cpu"),
                                 {**hparams, "model_selection_basis": "navigation_sr"})
            train_id = manifest["train_episode_ids"][0].split("/", 1)[1]
            missing = {**cache, "episodes": [ep for ep in cache["episodes"] if ep["episode_id"] != train_id]}
            unknown = {**cache, "episodes": [*cache["episodes"], {**cache["episodes"][0], "episode_id": "unknown"}]}
            duplicate = {**cache, "episodes": [*cache["episodes"], cache["episodes"][0]]}
            wrong_sha = copy.deepcopy(cache)
            wrong_sha["episodes"][0]["episode_sha256"] = "0" * 64
            short = copy.deepcopy(cache)
            short["episodes"][0]["frames"].pop()
            for invalid in (missing, unknown, duplicate, wrong_sha, short):
                with self.subTest(cache=invalid), self.assertRaises(ValueError):
                    loss_scale_training_cache_partition(invalid, manifest, hparams)
            with self.assertRaisesRegex(ValueError, "独立开发checkpoint/hparams"):
                with contextlib.redirect_stdout(io.StringIO()):
                    audit_aerial(SimpleNamespace(run_dir=run, output_dir=root / "invalid-audit", device="cpu"),
                                 {**hparams, "development_route_split_sha256": "wrong"})

    def test_cpu_fit_records_passes_and_excludes_frozen_parameters(self):
        import contextlib
        import io
        import json
        from types import SimpleNamespace
        import yaml
        from test_data import aerial_episode, aerial_v2_cache
        from scripts.audit_training import audit_aerial
        from uavnav.avln.fit import fit_aerial

        with TemporaryDirectory() as tmp:
            root = Path(tmp)
            folders = [root / name for name in ("pass0", "pass1", "validation")]
            for folder in folders:
                folder.mkdir()
            sources = [aerial_v2_cache(folder, f"session-{index}",
                                      [aerial_episode("validation" if index == 2 else "train")])
                       for index, folder in enumerate(folders)]
            (folders[0] / "val_seen.json").write_bytes(sources[2][0].read_bytes())
            for index, (_, manifest, payload) in enumerate(sources):
                payload["scope"] = "integration_episode_subset"
                if index == 2:
                    payload["split"] = "val_seen"
                manifest.write_text(json.dumps(payload), encoding="utf-8")
            with patch("uavnav.avln.fit._plot_loss"), \
                    contextlib.redirect_stdout(io.StringIO()):
                run = fit_aerial(annotation_root=folders[0], cache_manifest=sources[0][1],
                                 validation_cache_manifest=sources[2][1], validation_split="val_seen", render_pass_manifests=[sources[1][1]],
                                 render_pass_seed=0, vision_train_policy="frozen", architecture="aerial_route_recurrent_v2",
                                 epochs=1, batch=2, workers=0, history=2, imgsz=16, lr=1e-4, device="cpu", seed=0,
                                 pretrained=False, hidden=4, sequence_chunk_size=3, project=root / "runs", name="contract")
            saved = torch.load(run / "weights" / "last.pt", map_location="cpu", weights_only=False)
            self.assertEqual(len(saved["optimizer"]["param_groups"][0]["params"]), 0)
            self.assertGreater(len(saved["optimizer"]["param_groups"][1]["params"]), 0)
            _validate_checkpoint(saved)
            manifest = json.loads((run / "split_manifest.json").read_text(encoding="utf-8"))
            self.assertEqual(manifest["train_samples"], 8)
            self.assertEqual([row["capture_session_id"] for row in manifest["train_render_passes"]],
                             ["session-0", "session-1"])
            for index, (_, path, _) in enumerate(sources[:2]):
                self.assertEqual((run / "render_pass_manifests" / f"pass_{index:03d}.json").read_bytes(), path.read_bytes())
            selection = json.loads((run / "render_pass_selections.jsonl").read_text(encoding="utf-8"))
            self.assertEqual(selection["samples"], 8)
            self.assertEqual(selection["optimizer_updates"], 3)
            self.assertEqual(selection["selections"][0]["pass_index"], 1)
            hparams = yaml.safe_load((run / "hparams.yaml").read_text(encoding="utf-8"))
            with contextlib.redirect_stdout(io.StringIO()):
                audited = audit_aerial(SimpleNamespace(run_dir=run, output_dir=root / "audit", device="cpu"), hparams)
            self.assertEqual(audited["render_pass_sources_verified"], manifest["train_render_passes"])
            self.assertTrue(audited["source_snapshot_verified"])
            self.assertIsNone(audited["SR"])
            duplicate_snapshot = run / "train_cache_manifest.json"
            snapshot_bytes = duplicate_snapshot.read_bytes()
            duplicate_snapshot.write_bytes(b"{}")
            with self.assertRaisesRegex(ValueError, "顶层训练/验证来源清单副本损坏"):
                audit_aerial(SimpleNamespace(run_dir=run, output_dir=root / "corrupt_audit", device="cpu"), hparams)
            duplicate_snapshot.write_bytes(snapshot_bytes)
            sources[2][2]["capture_session_id"] = "session-1"
            sources[2][1].write_text(json.dumps(sources[2][2]), encoding="utf-8")
            with self.assertRaisesRegex(ValueError, "session"):
                fit_aerial(annotation_root=folders[0], cache_manifest=sources[0][1],
                           validation_cache_manifest=sources[2][1], validation_split="val_seen", render_pass_manifests=[sources[1][1]],
                           architecture="aerial_route_recurrent_v2", epochs=1, batch=2, workers=0,
                           history=2, imgsz=16, lr=1e-4, device="cpu", project=root / "runs", name="blocked")

    def test_visual_freeze_keeps_forward_and_head_gradients(self):
        from uavnav.avln.fit import initial_state_sha256
        options = {"architecture": "aerial_route_recurrent_v2", "hidden": 4, "history_frames": 2}
        torch.manual_seed(431)
        old = build_model(5, options).eval()
        torch.manual_seed(431)
        frozen = build_model(5, {**options, "vision_train_policy": "frozen"}).eval()
        self.assertEqual(set(old.state_dict()), set(frozen.state_dict()))
        for key, value in old.state_dict().items():
            self.assertTrue(torch.equal(value, frozen.state_dict()[key]))
        self.assertEqual(initial_state_sha256(old.state_dict()), initial_state_sha256(frozen.state_dict()))
        altered_state = {key: tensor.clone() for key, tensor in frozen.state_dict().items()}
        altered_state["head.bias"][0] += 1.
        self.assertNotEqual(initial_state_sha256(old.state_dict()), initial_state_sha256(altered_state))
        inputs = AerialRecurrentTests().inputs(2)
        with torch.no_grad():
            self.assertTrue(torch.equal(old(inputs), frozen(inputs)))
        frozen.train()
        self.assertTrue(all(not p.requires_grad for p in frozen.vision.parameters()))
        self.assertTrue(all(not module.training for module in frozen.vision.modules()
                            if isinstance(module, nn.modules.batchnorm._BatchNorm)))
        self.assertTrue(frozen.vision_proj.weight.requires_grad)
        loss = torch.nn.functional.cross_entropy(frozen(inputs), torch.tensor([1, 7]))
        loss.backward()
        self.assertTrue(all(p.grad is None for p in frozen.vision.parameters()))
        self.assertGreater(frozen.vision_proj.weight.grad.abs().sum().item(), 0)
        self.assertGreater(frozen.memory.weight_ih_l0.grad.abs().sum().item(), 0)
        self.assertTrue(all(p.requires_grad for p in old.vision.parameters()))
        with self.assertRaises(ValueError):
            build_model(5, {**options, "vision_train_policy": "unknown"})
        with self.assertRaises(ValueError):
            build_model(5, {**options, "architecture": "aerial_route_v1", "vision_train_policy": "frozen"})

    def test_sequence_selects_whole_pass_without_extra_updates_or_rng_changes(self):
        import random
        import numpy as np

        class Recorder(nn.Module):
            def __init__(self):
                super().__init__()
                self.weight = nn.Parameter(torch.zeros(8))
                self.calls = []

            def forward_sequence(self, data, state=None):
                self.calls.append((data["image"].tolist(), None if state is None else state.detach().clone(),
                                   None if state is None else state.grad_fn))
                return self.weight.expand(len(data["image"]), 8), self.weight[:1].reshape(1, 1, 1)

        base = [[{"scene_id": 2, "episode_id": str(ep), "frame_index": frame,
                  "action": 0 if frame == length - 1 else 1, "instruction": "turn right", "tag": ep}
                 for frame in range(length)] for ep, length in enumerate((5, 3))]
        alternate = [[{**sample, "tag": sample["tag"] + 10} for sample in ep] for ep in base]

        def fake_collate(samples, *args):
            return {"image": torch.tensor([sample["tag"] for sample in samples]),
                    "tokens": torch.ones(len(samples), 1, dtype=torch.long),
                    "token_mask": torch.ones(len(samples), 1, dtype=torch.bool),
                    "history": torch.zeros(len(samples), 2, 8),
                    "history_length": torch.zeros(len(samples), dtype=torch.long),
                    "action_target": torch.tensor([sample["action"] for sample in samples])}

        parameters = dict(vocab=None, imgsz=8, history_frames=2, chunk_size=2,
                          device=torch.device("cpu"), seed=7, render_pass_seed=0)
        py_before, np_before, torch_before = random.getstate(), np.random.get_state(), torch.get_rng_state()
        model = Recorder()
        with patch("uavnav.avln.fit.collate", side_effect=fake_collate):
            stats = _aerial_sequence_epoch(model, base, optimizer=torch.optim.SGD(model.parameters(), lr=.01),
                                           render_pass_episodes=[base, alternate], **parameters)
            single = _aerial_sequence_epoch(Recorder(), base, **parameters)
        self.assertEqual(stats["samples"], 8)
        self.assertEqual(stats["optimizer_updates"], 5)
        self.assertEqual(stats["sequence_chunks"], single["sequence_chunks"])
        self.assertEqual(stats["samples"], single["samples"])
        choices = {row["episode_id"]: row["pass_index"] for row in stats["render_pass_selections"]}
        self.assertEqual(choices, {"0": 1, "1": 1})
        tags = [tags[0] for tags, _, _ in model.calls]
        self.assertEqual(tags, [10, 10, 10, 11, 11])
        self.assertEqual([state is None for _, state, _ in model.calls], [True, False, False, True, False])
        self.assertTrue(all(grad_fn is None for _, _, grad_fn in model.calls))
        self.assertEqual(random.getstate(), py_before)
        self.assertEqual(np.random.get_state()[0], np_before[0])
        self.assertTrue(np.array_equal(np.random.get_state()[1], np_before[1]))
        self.assertEqual(np.random.get_state()[2:], np_before[2:])
        self.assertTrue(torch.equal(torch.get_rng_state(), torch_before))
        with patch("uavnav.avln.fit.collate", side_effect=fake_collate):
            repeat_model = Recorder()
            repeated = _aerial_sequence_epoch(repeat_model, base, optimizer=torch.optim.SGD(repeat_model.parameters(), lr=.01),
                                              render_pass_episodes=[base, alternate], **parameters)
        self.assertEqual(repeated["render_pass_selections"], stats["render_pass_selections"])
        broken = copy.deepcopy(alternate)
        broken[0][-1]["action"] = 2
        with self.assertRaises(ValueError):
            _aerial_sequence_epoch(Recorder(), base, render_pass_episodes=[base, broken], **parameters)

    def test_training_entry_render_options_are_explicit_and_validated(self):
        from train import aerial_training_parameters
        with patch.dict(os.environ, {}, clear=True):
            required = {"cache_manifest": "train.json", "validation_cache_manifest": "val.json"}
            defaults = aerial_training_parameters(required)
            self.assertEqual(defaults["vision_train_policy"], "frozen")
            self.assertEqual(defaults["render_pass_manifests"], [])
            with patch.dict(os.environ, {"UAVNAV_RENDER_PASS_MANIFESTS": '["another.json"]',
                                         "UAVNAV_RENDER_PASS_SEED": "21", "UAVNAV_VISION_TRAIN_POLICY": "frozen"}):
                options = aerial_training_parameters(required)
            self.assertEqual(options["render_pass_manifests"], ["another.json"])
            self.assertEqual(options["render_pass_seed"], 21)
            self.assertEqual(options["vision_train_policy"], "frozen")
            for extra in ({"vision_train_policy": "bad"}, {"render_pass_manifests": "one.json"},
                          {"architecture": "aerial_route_v1", "vision_train_policy": "frozen"}):
                with self.assertRaises(ValueError):
                    aerial_training_parameters({**required, **extra})


class AirVLNAdapterTests(unittest.TestCase):
    """合成上游接口合同，不冒称真实AirVLN网络或导航成绩。"""

    @staticmethod
    def policy(layers):
        class Encoder(nn.Module):
            def __init__(self):
                super().__init__()
                self.cnn = nn.Sequential(nn.BatchNorm2d(3))
                self.cnn.requires_grad_(False)

        class Net(nn.Module):
            def __init__(self):
                super().__init__()
                self.rgb_encoder = Encoder()
                self.calls = []

            def forward(self, observations, state, previous, masks):
                self.calls.append((observations, state.clone(), previous.clone(), masks.clone()))
                pixels = self.rgb_encoder.cnn(observations["rgb"].permute(0, 3, 1, 2) / 255.)
                values = pixels.mean(dim=(1, 2, 3)) + previous.flatten().float()
                outputs = []
                n = len(state)
                for begin in range(0, len(values), n):
                    state = state * masks[begin:begin+n].reshape(n, 1, 1)
                    state = state + values[begin:begin+n].reshape(n, 1, 1)
                    outputs.append(state[:, -1])
                return torch.cat(outputs), state

        policy = nn.Module()
        policy.net = Net()
        policy.action_distribution = nn.Module()
        policy.action_distribution.linear = nn.Linear(512, 8)
        return policy

    def model(self, architecture="airvln_seq2seq_rgb_v1"):
        config = {"architecture": architecture, "history_frames": 2, "hidden": 512,
                  "vision_train_policy": "frozen", "imgsz": 224}
        policy = self.policy(1 if "seq2seq" in architecture else 2)
        with patch("uavnav.avln.model._airvln_policy", return_value=policy):
            return build_model(5, config)

    def test_adapter_rejects_trainable_upstream_cnn_without_freezing_projection(self):
        policy = self.policy(1)
        policy.net.rgb_encoder.projection = nn.Linear(3, 4)
        config = {"architecture": "airvln_seq2seq_rgb_v1", "history_frames": 2,
                  "hidden": 512, "vision_train_policy": "frozen", "imgsz": 224}
        with patch("uavnav.avln.model._airvln_policy", return_value=policy):
            adapter = build_model(5, config)
        self.assertTrue(all(parameter.requires_grad for parameter in policy.net.rgb_encoder.projection.parameters()))
        self.assertTrue(all(not parameter.requires_grad for parameter in adapter.vision.parameters()))
        policy.net.rgb_encoder.cnn.requires_grad_(True)
        with patch("uavnav.avln.model._airvln_policy", return_value=policy), self.assertRaisesRegex(ValueError, "上游RGB CNN"):
            build_model(5, config)
        self.assertTrue(all(parameter.requires_grad for parameter in policy.net.rgb_encoder.cnn.parameters()))

    @staticmethod
    def inputs():
        raw = torch.randint(0, 256, (3, 3, 224, 224)).float()
        mean = raw.new_tensor(IMAGENET_MEAN).reshape(1, 3, 1, 1)
        std = raw.new_tensor(IMAGENET_STD).reshape(1, 3, 1, 1)
        history = torch.zeros(3, 2, 8)
        history[1, -1, 7] = 1
        history[2, -2, 7] = 1
        history[2, -1, 1] = 1
        return raw, {"image": (raw / 255 - mean) / std, "tokens": torch.tensor([[2, 3, 0]] * 3),
                     "token_mask": torch.tensor([[True, True, False]] * 3), "history": history,
                     "history_length": torch.tensor([0, 1, 2])}

    def test_pixels_prev_action_masks_and_state_shapes(self):
        raw, batch = self.inputs()
        for architecture, layers in (("airvln_seq2seq_rgb_v1", 1), ("airvln_cma_rgb_v1", 2)):
            model = self.model(architecture).eval()
            logits, state = model.forward_sequence(batch)
            self.assertEqual(tuple(logits.shape), (3, 8))
            self.assertEqual(tuple(state.shape), (layers, 1, 512))
            observation, before, previous, masks = model.policy.net.calls[-1]
            self.assertTrue(torch.equal(observation["rgb"], raw.permute(0, 2, 3, 1)))
            self.assertEqual(previous.flatten().tolist(), [0, 7, 1])
            self.assertEqual(masks.flatten().tolist(), [0, 1, 1])
            self.assertEqual(masks.dtype, torch.bool)
            self.assertEqual(before.abs().sum().item(), 0)
            individual, running = [], None
            for index in range(3):
                step = {key: value[index:index+1] for key, value in batch.items()}
                output, running = model.forward_step(step, running)
                individual.append(output)
            torch.testing.assert_close(logits, torch.cat(individual), rtol=1e-5, atol=1e-5)
            torch.testing.assert_close(state, running, rtol=1e-6, atol=1e-6)
            with self.assertRaises(ValueError):
                model.forward_step(step, torch.zeros(layers+1, 1, 512))

    def test_train_keeps_causal_bn_and_head_gradient(self):
        _, batch = self.inputs()
        model = self.model().train()
        self.assertFalse(model.vision[0].training)
        self.assertTrue(model.policy.action_distribution.linear.training)
        output, _ = model.forward_sequence(batch)
        changed = {key: value.clone() for key, value in batch.items()}
        changed["image"][1:] += 1
        changed_output, _ = model.forward_sequence(changed)
        self.assertTrue(torch.equal(output[0], changed_output[0]))
        output.sum().backward()
        self.assertIsNotNone(model.policy.action_distribution.linear.weight.grad)
        self.assertTrue(all(parameter.grad is None for parameter in model.vision.parameters()))
        bad = {key: value.clone() for key, value in batch.items()}
        bad["tokens"][:, 0] = 0
        with self.assertRaises(ValueError):
            model.forward_sequence(bad)

    def test_source_and_asset_validation_precedes_import(self):
        from uavnav.avln.model import airvln_source_sha256, _airvln_policy
        with TemporaryDirectory() as directory:
            root, project = Path(directory) / "upstream", Path(directory) / "assets"
            (root / "Model").mkdir(parents=True)
            (root / "Model/policy.py").write_text("# contract fixture", encoding="utf-8")
            config = {"architecture": "airvln_seq2seq_rgb_v1", "upstream_root": str(root),
                      "upstream_project_prefix": str(project), "upstream_log_dir": str(Path(directory)/"logs"),
                      "upstream_source_sha256": {}}
            with self.assertRaises(ValueError):
                _airvln_policy(5, config, False)
            config["upstream_source_sha256"] = airvln_source_sha256(root)
            with self.assertRaises(FileNotFoundError):
                _airvln_policy(5, config, False)
            checkpoint = project / "DATA/models/ddppo-models/gibson-2plus-resnet50.pth"
            checkpoint.parent.mkdir(parents=True)
            checkpoint.write_bytes(b"asset-validation-fixture-not-model")
            config["ddppo_checkpoint_sha256"] = "0" * 64
            with self.assertRaises(ValueError):
                _airvln_policy(5, config, False)
            import hashlib
            config["ddppo_checkpoint_sha256"] = hashlib.sha256(checkpoint.read_bytes()).hexdigest()
            with patch.object(torch.serialization, "safe_globals", None):
                with self.assertRaisesRegex(RuntimeError, "safe_globals"):
                    _airvln_policy(5, config, False)
            with patch("uavnav.avln.model._AIRVLN_PROCESS_OWNER", ("different-upstream", "cma")):
                with self.assertRaises(RuntimeError):
                    _airvln_policy(5, config, False)
            config["upstream_log_dir"] = str(root / "logs")
            with self.assertRaises(ValueError):
                _airvln_policy(5, config, False)


class AirVLNCheckpointContractTests(unittest.TestCase):
    """格式6仅使用合成Policy接口核合同，不读取权重或宣称官方网络成绩。"""

    def checkpoint(self, architecture="airvln_seq2seq_rgb_v1"):
        model = AirVLNAdapterTests().model(architecture).eval()
        layers = 1 if architecture == "airvln_seq2seq_rgb_v1" else 2
        protocol = aerial_task_protocol(224)
        render = {"protocol_version": "aerialvln_s_pose_rgb_v1", "pose_mode": "simSetVehiclePose_ignore_collision",
                  "pixel_order": "RGB", "rgb_type": "Scene", "camera_name": "front_0", "width": 224, "height": 224}
        rendered = {"train": render, "validation": dict(render)}
        config = {"checkpoint_format_version": 6, "architecture": architecture, "backbone": "resnet50",
                  "visual_fusion": "global" if layers == 1 else "spatial", "grid_size": 4, "stop_enabled": True,
                  "fusion_mode": "official_policy", "output_version": "aerial_action8_v1", "history_policy": "action_onehot8_v1",
                  "data_protocol": "aerialvln_s_v1", "task_protocol": protocol, "task_protocol_sha256": _json_sha256(protocol),
                  "text_control": "original", "strip_direction": False, "split_manifest_sha256": "a" * 64,
                  "input_render_protocols": rendered, "input_render_protocols_sha256": _json_sha256(rendered),
                  "history_frames": 2, "hidden": 512, "imgsz": 224, "ablate": "none",
                  "image_mean": [float(x) for x in IMAGENET_MEAN], "image_std": [float(x) for x in IMAGENET_STD],
                  "memory_protocol": "airvln_recurrent_gru_v1", "sequence_policy": "episode_contiguous_tbptt_v1",
                  "tokenizer_version": "route_numeric_v1", "memory_mode": "carry", "vision_train_policy": "frozen",
                  "vision_batchnorm_protocol": "causal_fixed_bn_v1", "sequence_chunk_size": 16, "constant_text_token": None,
                  "loss_protocol": {"version": "transition_weighted_ce_v1", "inflection_weight": 1.9,
                                    "stop_weight": 1.9, "normalization": "sum_weights"},
                  "baseline_protocol": "official_network_matched_training_adapter_v1", "memory_layers": layers,
                  "memory_hidden_size": 512, "raw_rgb_adapter": "imagenet_denormalize_round_uint8_v1",
                  "prev_action_protocol": "last_executed_action_or_start_zero_v1", "render_pass_policy": "episode_uniform_pass_v1",
                  "render_pass_seed": 0, "render_pass_count": 1,
                  "train_render_passes": [{"pass_index": 0, "source": "synthetic-contract-train.json",
                                           "manifest_sha256": "a" * 64, "sample_content_sha256": "b" * 64,
                                           "capture_session_id": "synthetic-contract-session"}],
                  "upstream_root": "synthetic-contract-upstream", "upstream_project_prefix": "synthetic-contract-assets",
                  "upstream_log_dir": "synthetic-contract-logs", "upstream_source_sha256": {"Model/policy.py": "c" * 64},
                  "ddppo_checkpoint_sha256": "d" * 64, "upstream_adapter": dict(model.upstream_metadata),
                  "network_precision": "fp32_with_outer_autocast_disabled_v1"}
        return model, {"model": model.state_dict(), "vocab": {"<pad>": 0, "<unk>": 1, "car": 2, "left": 3, "right": 4},
                       "length_scale": 1., "model_config": config}

    def test_baseline_entry_records_true_backbone_and_rejects_permission_changes(self):
        from train import aerial_training_parameters
        overrides = {"cache_manifest": "synthetic-train.json", "validation_cache_manifest": "synthetic-val.json"}
        with patch.dict(os.environ, {}, clear=True):
            for architecture, fusion in (("airvln_seq2seq_rgb_v1", "global"), ("airvln_cma_rgb_v1", "spatial")):
                selected = {**overrides, "architecture": architecture}
                config = aerial_training_parameters(selected)
                self.assertEqual((config["hidden"], config["backbone"], config["visual_fusion"]), (512, "resnet50", fusion))
                self.assertEqual((config["vision_train_policy"], config["memory_mode"], config["text_control"]),
                                 ("frozen", "carry", "original"))
                for changed in ({"render_pass_manifests": ["synthetic-pass1.json"]}, {"vision_train_policy": "finetune"},
                                {"memory_mode": "reset_each_step"}, {"text_control": "constant"}, {"backbone": "resnet18"}):
                    with self.subTest(architecture=architecture, changed=changed), self.assertRaises(ValueError):
                        aerial_training_parameters({**selected, **changed})

    def test_format6_sources_layers_permissions_and_version_are_required(self):
        for architecture in ("airvln_seq2seq_rgb_v1", "airvln_cma_rgb_v1"):
            _, saved = self.checkpoint(architecture)
            _validate_checkpoint(saved)
            for field in ("upstream_source_sha256", "ddppo_checkpoint_sha256", "upstream_adapter", "memory_layers"):
                altered = copy.deepcopy(saved)
                altered["model_config"].pop(field)
                with self.subTest(architecture=architecture, missing=field), self.assertRaises(CheckpointFormatError):
                    _validate_checkpoint(altered)
            mutations = {"checkpoint_format_version": 5, "hidden": 128, "memory_hidden_size": 128,
                         "memory_layers": 2 if "seq2seq" in architecture else 1,
                         "upstream_source_sha256": {}, "ddppo_checkpoint_sha256": "wrong",
                         "raw_rgb_adapter": "normalized_float_direct", "vision_batchnorm_protocol": "future_bn",
                         "memory_mode": "reset_each_step", "text_control": "constant"}
            for field, value in mutations.items():
                altered = copy.deepcopy(saved)
                altered["model_config"][field] = value
                with self.subTest(architecture=architecture, mutation=field), self.assertRaises(CheckpointFormatError):
                    _validate_checkpoint(altered)
            for field, value in (("progress_monitor", True), ("depth_policy", "remove_environment_depth"),
                                 ("rnn_mask_protocol", "float_masks"), ("token_adapter", "truncate_instruction")):
                altered = copy.deepcopy(saved)
                altered["model_config"]["upstream_adapter"][field] = value
                with self.subTest(architecture=architecture, permission=field), self.assertRaises(CheckpointFormatError):
                    _validate_checkpoint(altered)

    def test_format6_loader_routes_actions_and_resets_instruction_memory(self):
        import numpy as np
        from uavnav.avln.inference import load_predictor
        for architecture, layers in (("airvln_seq2seq_rgb_v1", 1), ("airvln_cma_rgb_v1", 2)):
            model, saved = self.checkpoint(architecture)
            with TemporaryDirectory() as folder:
                path = Path(folder) / "synthetic-interface-checkpoint.pt"
                torch.save(saved, path)
                with patch("uavnav.avln.inference._build_without_download", return_value=model) as constructor:
                    with self.assertRaises(CheckpointFormatError):
                        WaypointPredictor(path, device="cpu")
                    constructor.assert_not_called()
                    predictor = load_predictor(path, device="cpu")
                self.assertIsInstance(predictor, AerialActionPredictor)
                image = np.full((224, 224, 3), 64, dtype=np.uint8)
                predictor.predict_action(image, "car left", [])
                first = predictor.observation_state()
                self.assertEqual(first.shape, (layers, 1, 512))
                predictor.predict_action(image, "car left", [1])
                self.assertGreater(float(predictor.observation_state().sum()), float(first.sum()))
                with self.assertRaisesRegex(ValueError, "绑定"):
                    predictor.predict_action(image, "car right", [1])
                predictor.reset_episode()
                self.assertIsNone(predictor.observation_state())
                self.assertIsNone(predictor._session_instruction)
                predictor.predict_action(image, "car right", [])
                np.testing.assert_allclose(predictor.observation_state(), first, atol=0, rtol=0)


class LossScaleAuditTests(unittest.TestCase):
    protocol = {"version": "transition_weighted_ce_v1", "inflection_weight": 1.9,
                "stop_weight": 1.9, "normalization": "sum_weights"}

    def test_actual_sequence_objectives_gradients_clip_and_updates(self):
        import contextlib
        import io
        outer = self

        class FixedLogits(nn.Module):
            def __init__(self):
                super().__init__()
                self.logits = nn.Parameter(torch.zeros(17, 8))
                with torch.no_grad():
                    self.logits[:16, 1] = 2.
                    self.logits[16, 0] = -2.

            def forward_sequence(self, inputs, state=None):
                outer.assertEqual(set(inputs), {"image", "tokens", "token_mask", "history", "history_length"})
                indices = inputs["image"].long().flatten()
                return self.logits[indices], self.logits[:1, :1].reshape(1, 1, 1)

        actions = [1] * 16 + [0]
        episodes = [[{"scene_id": 2, "episode_id": "synthetic-fixed-logits", "frame_index": i,
                      "action": action, "instruction": "synthetic only"} for i, action in enumerate(actions)]]

        def fake_collate(rows, *args):
            length = len(rows)
            return {"image": torch.tensor([row["frame_index"] for row in rows]),
                    "tokens": torch.ones(length, 1, dtype=torch.long), "token_mask": torch.ones(length, 1, dtype=torch.bool),
                    "history": torch.zeros(length, 2, 8), "history_length": torch.zeros(length, dtype=torch.long),
                    "action_target": torch.tensor([row["action"] for row in rows]), "future_target": torch.ones(length)}

        model = FixedLogits()
        optimizer = torch.optim.SGD(model.parameters(), lr=0.)
        original = model.logits.detach().clone()
        original_clip = torch.nn.utils.clip_grad_norm_
        gradients, clipped_norms, limits = [], [], []

        def capture_clip(parameters, max_norm, **kwargs):
            gradients.append(model.logits.grad.detach().clone())
            limits.append(max_norm)
            norm = original_clip(parameters, max_norm, **kwargs)
            clipped_norms.append(float(model.logits.grad.norm()))
            return norm

        with patch("uavnav.avln.fit.collate", side_effect=fake_collate), \
                patch("uavnav.avln.fit.torch.nn.utils.clip_grad_norm_", side_effect=capture_clip), \
                patch.object(optimizer, "step", wraps=optimizer.step) as steps, contextlib.redirect_stdout(io.StringIO()):
            stats = _aerial_sequence_epoch(model, episodes, None, 8, 2, 16, torch.device("cpu"),
                                          optimizer=optimizer, loss_protocol=self.protocol)
        logits = original.requires_grad_(True)
        target = torch.tensor(actions)
        per_frame = torch.nn.functional.cross_entropy(logits, target, reduction="none")
        expected_objectives = [per_frame[:16].mean(), per_frame[16]]
        for observed, objective in zip(gradients, expected_objectives):
            expected, = torch.autograd.grad(objective, logits, retain_graph=True)
            torch.testing.assert_close(observed, expected)
            self.assertTrue(torch.isfinite(observed).all())
            self.assertGreater(float(observed.abs().sum()), 0.)
        self.assertEqual(steps.call_count, 2)
        self.assertEqual(stats["optimizer_updates"], 2)
        self.assertEqual(limits, [1., 1.])
        self.assertTrue(all(norm <= 1.000001 for norm in clipped_norms))
        torch.testing.assert_close(model.logits.detach(), original.detach(), rtol=0, atol=0)
        expected_weighted = (per_frame[:16].sum() + 1.9 * per_frame[16]) / 17.9
        expected_chunks = torch.stack(expected_objectives).mean()
        self.assertAlmostEqual(stats["loss"], float(per_frame.mean().detach()), places=6)
        self.assertAlmostEqual(stats["objective_loss"], float(expected_weighted.detach()), places=6)
        self.assertAlmostEqual(stats["chunk_objective_mean_diagnostic"], float(expected_chunks.detach()), places=6)
        self.assertEqual(stats["chunk_objective_diagnostic_version"], "mean_chunk_weighted_ce_v1")
        self.assertGreater(abs(stats["objective_loss"] - stats["chunk_objective_mean_diagnostic"]), .1)

    def test_real_upstream_rnn_flattened_sequence_and_cross_chunk_gradients(self):
        import hashlib
        import os
        import runpy
        upstream = Path(os.environ.get("UAVNAV_TEST_UPSTREAM_ROOT", Path(__file__).resolve().parents[2] / "idea/AirVLN"))
        source = upstream / "Model/encoders/rnn_state_encoder.py"
        if not source.is_file():
            self.skipTest("可选真实AirVLN RNN源码未提供；合成接口不能替代该集成检查")
        expected_sha = "1fa762af09ea45ba3f1da7ee3d9b4a3eaee4907c53a6e699d878f4011d6915a5"
        self.assertEqual(hashlib.sha256(source.read_bytes()).hexdigest(), expected_sha,
                         "上游源码身份变化，先审核新源码再更新集成锚点")
        encoder_type = runpy.run_path(str(source))["GRUStateEncoder"]
        for length in (3, 16):
            with self.subTest(length=length), torch.random.fork_rng(devices=[]):
                torch.manual_seed(7)
                encoder = encoder_type(4, 5).eval()
                inputs = torch.randn(length, 4, requires_grad=True)
                masks = torch.ones(length, 1, dtype=torch.bool)
                masks[0] = False
                initial = torch.zeros(1, 1, 5)
                complete, state = encoder(inputs, initial, masks)
                outputs, step_state = [], initial
                for i in range(length):
                    output, step_state = encoder(inputs[i:i + 1], step_state, masks[i:i + 1])
                    outputs.append(output)
                torch.testing.assert_close(complete, torch.cat(outputs), rtol=1e-5, atol=1e-6)
                torch.testing.assert_close(state, step_state, rtol=1e-5, atol=1e-6)
                first, prefix = encoder(inputs[:2], initial, masks[:2])
                second, following = encoder(inputs[2:], prefix.detach(), masks[2:])
                torch.testing.assert_close(complete, torch.cat((first, second)), rtol=1e-5, atol=1e-6)
                torch.testing.assert_close(state, following, rtol=1e-5, atol=1e-6)
                second[-1].sum().backward()
                self.assertEqual(float(inputs.grad[:2].abs().sum()), 0.)
                self.assertTrue((inputs.grad[2:].abs().sum(dim=1) > 0).all())

    def test_new_training_precision_contract_rejects_mutation_but_keeps_old_checkpoints(self):
        _, old = AerialRecurrentTests().checkpoint()
        _validate_checkpoint(old)
        saved = copy.deepcopy(old)
        saved["model_config"].update(
            model_selection_basis="lowest_unweighted_teacher_validation_ce_not_navigation",
            training_precision={"version": "aerial_training_precision_v1", "device_type": "cuda",
                                "forward": "bf16_autocast", "memory": "fp32", "loss": "fp32", "inference": "fp32"})
        _validate_checkpoint(saved)
        with TemporaryDirectory() as tmp:
            path = Path(tmp) / "synthetic-cuda-trained-checkpoint.pt"
            torch.save(saved, path)
            predictor = AerialActionPredictor(path, device="cpu")
            self.assertEqual(predictor.device.type, "cpu")
            self.assertEqual(predictor.config["training_precision"]["device_type"], "cuda")
        mutations = [lambda c: c.update(model_selection_basis="navigation_sr"),
                     lambda c: c["training_precision"].update(forward="fp32"),
                     lambda c: c["training_precision"].update(device_type="mps"),
                     lambda c: c["training_precision"].update(memory="bf16"),
                     lambda c: c["training_precision"].update(extra=True),
                     lambda c: c["training_precision"].pop("loss")]
        for change in mutations:
            altered = copy.deepcopy(saved)
            change(altered["model_config"])
            with self.subTest(change=change), self.assertRaises(CheckpointFormatError):
                _validate_checkpoint(altered)

    def test_grouped_budget_matches_fit_string_sorted_multiscene_ids(self):
        from test_data import aerial_episode, aerial_v2_cache
        from uavnav.avln.data import load_aerial_samples, split_aerial_route_groups
        from scripts.audit_training import loss_scale_training_cache_partition
        with TemporaryDirectory() as folder:
            root = Path(folder)
            episodes = [aerial_episode(f"scene-{scene}") for scene in (2, 10, 11)]
            for episode, scene in zip(episodes, (2, 10, 11)):
                episode["scene_id"] = scene
            _, cache_path, cache = aerial_v2_cache(root, "synthetic-multiscene", episodes)
            samples = load_aerial_samples(root, "train", cache_path, 2, include_route_metadata=True)
            for seed in range(64):
                train, _, split = split_aerial_route_groups(samples, 1 / 3, seed)
                if {sample["scene_id"] for sample in train} == {2, 10}:
                    break
            else:
                self.fail("synthetic split seed search did not produce the two target scenes")
            manifest = {"development_route_split": split, "development_route_split_sha256": split["manifest_sha256"],
                        "train_episode_ids": sorted({f"{sample['scene_id']}/{sample['episode_id']}" for sample in train})}
            hparams = {"validation_split": "development_train_grouped", "development_fraction": 1 / 3,
                       "development_split_seed": seed, "development_route_split_sha256": split["manifest_sha256"],
                       "training_split_protocol": split["split_protocol"]}
            selected, source = loss_scale_training_cache_partition(cache, manifest, hparams)
            self.assertEqual([row["scene_id"] for row in selected], [2, 10])
            self.assertEqual(source["source_cache_dev_episodes"], 1)

    def test_single_stop_weight_cancels_without_zero_gradient(self):
        from scripts.audit_training import loss_scale_summary
        report = loss_scale_summary([{"actions": [1] * 16 + [0]}], 16, self.protocol)
        complete, tail = report["chunks"]
        self.assertEqual(complete["frames"], 16)
        self.assertTrue(tail["single_frame_stop"])
        current = tail["formulas"]["v1_sum_weights"]
        candidate = tail["formulas"]["candidate_fixed_chunk_size_diagnostic"]
        self.assertEqual(current["per_state_coefficients"], [1.0])
        self.assertAlmostEqual(current["denominator"], 1.9, places=6)
        self.assertAlmostEqual(current["synthetic_uniform_logit_gradient_l1"], 1.75, places=6)
        self.assertTrue(current["synthetic_uniform_logit_gradients_finite_nonzero"])
        self.assertAlmostEqual(candidate["coefficient_sum"], 1.9 / 16, places=6)
        self.assertAlmostEqual(report["v1_coefficient_mass_over_updates"], 2.0, places=6)

    def test_cross_chunk_inflection_and_stop_use_full_episode_weights(self):
        from scripts.audit_training import loss_scale_summary
        report = loss_scale_summary([{"actions": [1] * 16 + [5, 0]}], 16, self.protocol)
        tail = report["chunks"][1]
        self.assertEqual(tail["actions"], [5, 0])
        self.assertAlmostEqual(tail["weights"][0], 1.9, places=6)
        self.assertAlmostEqual(tail["weights"][1], 1.9, places=6)
        self.assertEqual(tail["formulas"]["v1_sum_weights"]["per_state_coefficients"], [0.5, 0.5])

    def test_fixed_denominator_changes_full_transition_chunk_too(self):
        from scripts.audit_training import loss_scale_summary
        actions = [1, 5] * 8
        row = loss_scale_summary([{"actions": actions}], 16, self.protocol)["chunks"][0]
        self.assertAlmostEqual(row["formulas"]["v1_sum_weights"]["coefficient_sum"], 1., places=6)
        self.assertGreater(row["formulas"]["candidate_fixed_chunk_size_diagnostic"]["coefficient_sum"], 1.)

    def test_partial_recorded_labels_require_cache_identity_length_and_stop(self):
        from scripts.audit_training import recorded_action_episodes
        cache = [{"scene_id": 2, "episode_id": "long", "frames": [{}, {}, {}]}]
        rows = [{"scene_id": 2, "episode_id": "long", "frame_index": i, "teacher_action": action}
                for i, action in enumerate([1, 5, 0])]
        self.assertEqual(recorded_action_episodes({"long82_predictions": rows}, cache)[0]["actions"], [1, 5, 0])
        invalid = [rows[:2], rows[::-1], [rows[0], rows[0], rows[2]],
                   [rows[0], {**rows[1], "teacher_action": True}, rows[2]],
                   [rows[0], rows[1], {**rows[2], "teacher_action": 1}],
                   [{**row, "episode_id": "other"} for row in rows]]
        for altered in invalid:
            with self.subTest(altered=altered), self.assertRaises(ValueError):
                recorded_action_episodes({"long82_predictions": altered}, cache)

    def test_audit_loss_scale_freezes_update_budget_and_rejects_overwrite(self):
        import json
        import yaml
        from types import SimpleNamespace
        from scripts.audit_training import audit_loss_scale, sha256
        with TemporaryDirectory() as folder:
            root = Path(folder)
            run = root / "run"
            run.mkdir()
            hparams = {"sequence_chunk_size": 16, "loss_protocol": self.protocol,
                       "annotation_root": str(root / "annotations"), "epochs": 1,
                       "render_pass_seed": 0, "seed": 0}
            cache = {"annotation_sha256": "synthetic-annotation-identity", "episodes": [
                {"scene_id": 2, "episode_id": "a", "frames": [{"frame_index": i} for i in range(17)]}]}
            (run / "train_cache_manifest.json").write_text(json.dumps(cache), encoding="utf-8")
            manifest = {"sequence_chunk_size": 16, "loss_protocol": self.protocol, "train_samples": 17,
                        "train_cache_manifest_sha256": sha256(run / "train_cache_manifest.json"),
                        "train_annotation_sha256": cache["annotation_sha256"], "train_render_passes": [{}]}
            (run / "split_manifest.json").write_text(json.dumps(manifest), encoding="utf-8")
            (run / "hparams.yaml").write_text(yaml.safe_dump(hparams), encoding="utf-8")
            (run / "results.csv").write_text("epoch,train/samples\n1,17\n", encoding="utf-8")
            ledger = {"epoch": 1, "seed": 0, "policy": "episode_uniform_pass_v1", "pass_count": 1,
                      "selections": [{"scene_id": 2, "episode_id": "a", "pass_index": 0}],
                      "samples": 17, "optimizer_updates": 2}
            ledger_path = run / "render_pass_selections.jsonl"
            ledger_path.write_text(json.dumps(ledger) + "\n", encoding="utf-8")
            args = SimpleNamespace(run_dir=run, output_json=root / "report.json", supervision_json=None)
            report = audit_loss_scale(args)
            self.assertEqual(report["actual_sequence_budget"]["logged_optimizer_updates_total"], 2)
            self.assertEqual(report["actual_sequence_budget"]["single_frame_chunks_per_epoch"], 1)
            self.assertIsNone(report["recorded_label_scale"])
            self.assertFalse(report["training_defaults_changed"])
            with self.assertRaises(FileExistsError):
                audit_loss_scale(args)
            args.output_json = root / "invalid-report.json"
            ledger["optimizer_updates"] = 1
            ledger_path.write_text(json.dumps(ledger) + "\n", encoding="utf-8")
            with self.assertRaises(ValueError):
                audit_loss_scale(args)
            self.assertFalse(args.output_json.exists())


class CheckpointSnapshotTests(unittest.TestCase):
    def test_replaced_path_cannot_change_loaded_weights_architecture_or_sha(self):
        import hashlib
        from uavnav.avln.inference import load_predictor

        real_load = torch.load
        for is_aerial in (False, True):
            if is_aerial:
                model, saved = AerialActionTests().checkpoint()
                direct = AerialActionPredictor
            else:
                model = WaypointNet(3, history_frames=2, hidden=4, ablate="no_image", pretrained=False).eval()
                saved = payload(model)
                direct = WaypointPredictor
            for constructor in (direct, load_predictor):
                with self.subTest(aerial=is_aerial, constructor=constructor.__name__), TemporaryDirectory() as folder:
                    path = Path(folder) / "active.pt"
                    torch.save(saved, path)
                    expected_sha = hashlib.sha256(path.read_bytes()).hexdigest()
                    # Replace the active path during deserialization with a different architecture.
                    def replace_then_load(stream, **kwargs):
                        torch.save({"model_config": {"architecture": "invalid-replacement"}}, path)
                        return real_load(stream, **kwargs)
                    real_read = Path.read_bytes
                    with patch("uavnav.avln.inference.torch.load", side_effect=replace_then_load) as mocked, \
                            patch.object(Path, "read_bytes", autospec=True, side_effect=real_read) as reads:
                        predictor = constructor(path, device="cpu")
                    self.assertEqual(mocked.call_count, 1)
                    self.assertEqual(reads.call_count, 1)
                    self.assertEqual(predictor.checkpoint_sha256, expected_sha)
                    self.assertNotEqual(expected_sha, hashlib.sha256(path.read_bytes()).hexdigest())
                    self.assertIsInstance(predictor, direct)
                    for name, value in model.state_dict().items():
                        self.assertTrue(torch.equal(value, predictor.model.state_dict()[name]), name)

    def test_old_torch_fallback_rewinds_and_keeps_same_snapshot(self):
        import hashlib
        from uavnav.avln.inference import _load_checkpoint_snapshot

        real_load = torch.load
        with TemporaryDirectory() as folder:
            path = Path(folder) / "active.pt"
            torch.save({"fixture": torch.tensor([3.])}, path)
            expected_sha = hashlib.sha256(path.read_bytes()).hexdigest()
            def legacy_load(stream, **kwargs):
                if "weights_only" in kwargs:
                    stream.read(13)
                    torch.save({"fixture": torch.tensor([9.])}, path)
                    raise TypeError("legacy loader does not accept weights_only")
                self.assertEqual(stream.tell(), 0)
                return real_load(stream, **kwargs, weights_only=True)
            with patch("uavnav.avln.inference.torch.load", side_effect=legacy_load) as mocked:
                loaded, digest = _load_checkpoint_snapshot(path)
            self.assertEqual(mocked.call_count, 2)
            self.assertEqual(loaded["fixture"].item(), 3.)
            self.assertEqual(digest, expected_sha)


class ClauseRouteModelTests(unittest.TestCase):
    def test_clause_model_does_not_construct_unused_lstm_or_embedding(self):
        from uavnav.avln.model import AerialClauseRouteNet
        with patch("uavnav.avln.model.nn.LSTM", side_effect=AssertionError("unused LSTM")), \
                patch("uavnav.avln.model.nn.Embedding", side_effect=AssertionError("unused embedding")):
            model = self.model()
        self.assertFalse(hasattr(model, "instruction"))
        self.assertFalse(hasattr(model, "embed"))
        self.assertFalse(any(name.startswith(("instruction.", "embed.")) for name in model.state_dict()))
        with self.assertRaisesRegex(ValueError, "visual_history"):
            AerialClauseRouteNet(5, text_query_mode="state_conditioned_v1", pretrained=False)

    def v3_checkpoint(self):
        from uavnav.avln.model import AerialClauseRouteNet
        torch.manual_seed(41)
        model = AerialClauseRouteNet(3, history_frames=2, hidden=4, pretrained=False, backbone="resnet18",
                                     vision_train_policy="frozen", clause_dim=8, ablate="no_image").eval()
        _, saved = AerialRecurrentTests().checkpoint()
        saved["model"] = model.state_dict()
        saved["model_config"].update(
            architecture="aerial_route_recurrent_clause_v3", vision_train_policy="frozen", ablate="no_image",
            text_encoder={"version": "frozen_clip_clause_cache_v1"}, clause_dim=8)
        return model, saved

    def test_v3_checkpoint_validation_and_online_tuple_state(self):
        import numpy as np
        model, saved = self.v3_checkpoint()
        _validate_checkpoint(copy.deepcopy(saved))
        for change in (lambda c: c.pop("text_encoder"), lambda c: c.update(vision_train_policy="finetune"),
                       lambda c: c.update(text_control="constant")):
            changed = copy.deepcopy(saved)
            change(changed["model_config"])
            with self.subTest(change=changed["model_config"].get("text_encoder")), self.assertRaises(CheckpointFormatError):
                _validate_checkpoint(changed)
        with TemporaryDirectory() as folder:
            path = Path(folder) / "v3.pt"
            torch.save(saved, path)
            predictor = AerialActionPredictor(path, device="cpu")
            with patch.object(AerialActionPredictor, "_clause_features", return_value=torch.randn(3, 8)):
                first = predictor.predict_action(np.zeros((8, 8, 3), dtype=np.uint8), "turn right. go up.", [1])
                self.assertIsInstance(predictor._state, tuple)
                self.assertEqual(predictor.observation_state()[1].shape, (1, 3))
                second = predictor.predict_action(np.zeros((8, 8, 3), dtype=np.uint8), "turn right. go up.", [1])
                self.assertEqual(len(first["action_probabilities"]), 8)
                self.assertNotEqual(first["action_probabilities"], second["action_probabilities"])
                predictor.reset_episode()
                self.assertIsNone(predictor._state)

    def model(self):
        from uavnav.avln.model import AerialClauseRouteNet
        torch.manual_seed(0)
        return AerialClauseRouteNet(5, history_frames=2, hidden=16, pretrained=False, backbone="resnet18",
                                    vision_train_policy="frozen", clause_dim=8).eval()

    def batch(self, steps=4, clauses=3):
        torch.manual_seed(1)
        return {"image": torch.zeros(steps, 0), "vision_mean": torch.randn(steps, 512),
                "vision_regions": torch.randn(steps, 16, 512), "history": torch.zeros(steps, 2, 8),
                "history_length": torch.zeros(steps, dtype=torch.long),
                "clause_features": torch.randn(1, clauses, 8).expand(steps, -1, -1).contiguous(),
                "clause_mask": torch.ones(steps, clauses, dtype=torch.bool)}

    def test_forward_state_and_causality(self):
        model, batch = self.model(), self.batch()
        with torch.no_grad():
            logits, state = model.forward_sequence(batch)
            self.assertEqual(logits.shape, (4, 8))
            hidden, pointer = state
            self.assertEqual(pointer.shape, (1, 3))
            self.assertAlmostEqual(float(pointer.sum()), 1., places=5)
            changed = {**batch, "vision_mean": batch["vision_mean"].clone()}
            changed["vision_mean"][3] += 5.
            other, _ = model.forward_sequence(changed)
        self.assertTrue(torch.allclose(logits[:3], other[:3], atol=1e-6))

    def test_clause_order_changes_output(self):
        model, batch = self.model(), self.batch(steps=6)
        shuffled = {**batch, "clause_features": batch["clause_features"].flip(1)}
        with torch.no_grad():
            a, _ = model.forward_sequence(batch)
            b, _ = model.forward_sequence(shuffled)
        self.assertFalse(torch.allclose(a, b, atol=1e-5))

    def test_clause_split_and_cache_key(self):
        from uavnav.avln.data import clause_split, text_cache_key
        self.assertEqual(clause_split("Turn right. Go down; stop."), ["Turn right", "Go down", "stop"])
        self.assertEqual(clause_split("..."), ["..."])
        self.assertEqual(text_cache_key()["clause_split"], "period_semicolon_v1")


class EpisodeNormalizedLossTests(unittest.TestCase):
    proto1 = {"version": "transition_weighted_ce_v1", "inflection_weight": 1.9, "stop_weight": 1.9, "normalization": "sum_weights"}
    proto2 = {**proto1, "version": "episode_normalized_ce_v2", "normalization": "episode_sum_weights"}

    def episode(self, length):
        return [{"scene_id": 2, "episode_id": "0", "frame_index": f, "action": 0 if f == length - 1 else 1,
                 "instruction": "go"} for f in range(length)]

    def run_epoch(self, protocol, length=17):
        from uavnav.avln.fit import _aerial_sequence_epoch

        class Model(nn.Module):
            def __init__(self):
                super().__init__()
                self.logit = nn.Parameter(torch.zeros(8))

            def forward_sequence(self, data, state=None):
                return self.logit.expand(len(data["image"]), 8), self.logit[:1].reshape(1, 1, 1)

        def fake_collate(samples, *args):
            return {"image": torch.zeros(len(samples), 1), "tokens": torch.ones(len(samples), 1, dtype=torch.long),
                    "token_mask": torch.ones(len(samples), 1, dtype=torch.bool),
                    "history": torch.zeros(len(samples), 2, 8), "history_length": torch.zeros(len(samples), dtype=torch.long),
                    "action_target": torch.tensor([s["action"] for s in samples])}

        model, grads = Model(), []
        optimizer = torch.optim.SGD(model.parameters(), lr=0.)
        original = optimizer.step
        optimizer.step = lambda *a, **k: (grads.append(model.logit.grad.clone()), original(*a, **k))[1]
        with patch("uavnav.avln.fit.collate", side_effect=fake_collate):
            stats = _aerial_sequence_epoch(model, [self.episode(length)], vocab=None, imgsz=1, history_frames=2,
                                           chunk_size=16, device=torch.device("cpu"), optimizer=optimizer,
                                           loss_protocol=protocol)
        return stats, grads

    def test_history_dropout_only_in_training_and_validated(self):
        from uavnav.avln.fit import _aerial_sequence_epoch
        seen = []

        class Recorder(nn.Module):
            def __init__(self):
                super().__init__()
                self.logit = nn.Parameter(torch.zeros(8))

            def forward_sequence(self, data, state=None):
                seen.append(data["history_length"].clone())
                return self.logit.expand(len(data["image"]), 8), self.logit[:1].reshape(1, 1, 1)

        def fake_collate(samples, *args):
            return {"image": torch.zeros(len(samples), 1), "tokens": torch.ones(len(samples), 1, dtype=torch.long),
                    "token_mask": torch.ones(len(samples), 1, dtype=torch.bool),
                    "history": torch.ones(len(samples), 2, 8), "history_length": torch.full((len(samples),), 2),
                    "action_target": torch.tensor([s["action"] for s in samples])}

        common = dict(vocab=None, imgsz=1, history_frames=2, chunk_size=16, device=torch.device("cpu"),
                      loss_protocol=self.proto1)
        model = Recorder()
        with patch("uavnav.avln.fit.collate", side_effect=fake_collate):
            _aerial_sequence_epoch(model, [self.episode(16)], history_dropout=.5, **common)
            self.assertTrue(torch.equal(seen[-1], torch.full((16,), 2)))
            _aerial_sequence_epoch(model, [self.episode(16)], optimizer=torch.optim.SGD(model.parameters(), lr=0.),
                                   history_dropout=.5, seed=0, **common)
            self.assertTrue(0 < int((seen[-1] == 0).sum()) < 16)
            with self.assertRaisesRegex(ValueError, "history_dropout"):
                _aerial_sequence_epoch(model, [self.episode(16)], history_dropout=1., **common)

    def test_v2_removes_single_stop_tail_amplification(self):
        _, v1 = self.run_epoch(self.proto1)
        stats2, v2 = self.run_epoch(self.proto2)
        # v1：尾块只有STOP一帧，该块梯度全部落在STOP类上，系数为1。
        self.assertAlmostEqual(float(v1[-1][0]), (1 / 8 - 1), places=5)
        # v2：同一块按整episode总权重归一，系数远小于1。
        total = 16 + 1.9
        self.assertAlmostEqual(float(v2[-1][0]), 1.9 / total * (1 / 8 - 1), places=5)
        self.assertEqual(stats2["optimizer_updates"], 2)

    def test_v2_chunk_coefficients_sum_to_one_per_episode(self):
        from uavnav.avln.fit import aerial_transition_weights
        weights = aerial_transition_weights([1] * 39 + [0], self.proto2)
        self.assertAlmostEqual(sum(float(weights[b:b + 16].sum()) / float(weights.sum()) for b in range(0, 40, 16)), 1., places=6)

    def test_versions_are_validated_and_parallel_path_rejects_v2(self):
        from uavnav.avln.fit import validate_aerial_loss_protocol, _aerial_batched_epoch
        self.assertEqual(validate_aerial_loss_protocol(self.proto2)["version"], "episode_normalized_ce_v2")
        with self.assertRaises(ValueError):
            validate_aerial_loss_protocol({**self.proto2, "normalization": "sum_weights"})
        with self.assertRaisesRegex(ValueError, "仅支持transition_weighted_ce_v1"):
            _aerial_batched_epoch(None, [[]], None, 8, 2, 4, torch.device("cpu"), 2, loss_protocol=self.proto2)


class VisionFeatureCacheTests(unittest.TestCase):
    def test_episode_memo_reuses_within_process_and_isolates_mutation(self):
        from uavnav.avln import data as data_module
        with TemporaryDirectory() as tmp:
            root = Path(tmp)
            (root / "train.json").write_text("{}", encoding="utf-8")
            calls = []

            def strict(*args):
                calls.append(1)
                return [{"scene_id": 2, "nested": {"x": 1}}]

            with patch.object(data_module, "_load_aerial_episodes_strict", side_effect=strict):
                data_module._EPISODE_MEMO.clear()
                first = data_module.load_aerial_episodes(root, "train")
                first[0]["nested"]["x"] = 99
                second = data_module.load_aerial_episodes(root, "train")
                self.assertEqual((len(calls), second[0]["nested"]["x"]), (1, 1))
                (root / "train.json").write_text('{"changed": 1}', encoding="utf-8")
                data_module.load_aerial_episodes(root, "train")
                self.assertEqual(len(calls), 2)

    def test_sample_index_modes_hit_invalidate_and_validate(self):
        import json
        import numpy as np
        from uavnav.avln import data as data_module
        with TemporaryDirectory() as tmp:
            root = Path(tmp)
            image = root / "a.png"
            image.write_bytes(b"x")
            manifest = root / "m.json"
            manifest.write_text(json.dumps({"cache_kind": None}), encoding="utf-8")
            calls = []

            def strict(*args, **kwargs):
                calls.append(1)
                return [{"image": image, "frame_index": 0, "history": np.zeros((1, 8), dtype=np.float32),
                         "render_protocol": {"scenes": {"2": [1, 2]}}}]

            episodes = [{"_annotation_sha256": "a" * 64}]
            with patch.object(data_module, "_load_aerial_samples_strict", side_effect=strict), \
                    patch.object(data_module, "load_aerial_episodes", return_value=episodes):
                data_module._RAM_SAMPLE_INDEX.clear()
                args = (str(root), "train", manifest, 2)
                first = data_module.load_aerial_samples(*args, index_mode="disk", index_dir=root / "idx")
                self.assertEqual(len(calls), 1)
                data_module._RAM_SAMPLE_INDEX.clear()
                again = data_module.load_aerial_samples(*args, index_mode="disk", index_dir=root / "idx")
                self.assertEqual(len(calls), 1)
                self.assertEqual(again[0]["render_protocol"], first[0]["render_protocol"])
                self.assertTrue(np.array_equal(again[0]["history"], first[0]["history"]))
                self.assertEqual(again[0]["history"].dtype, np.float32)
                self.assertIsInstance(again[0]["image"], Path)
                again[0]["image"] = "mutated"
                self.assertEqual(data_module.load_aerial_samples(*args, index_mode="ram")[0]["image"], image)
                image.write_bytes(b"changed-size")
                data_module._RAM_SAMPLE_INDEX.clear()
                data_module.load_aerial_samples(*args, index_mode="disk", index_dir=root / "idx")
                self.assertEqual(len(calls), 2)
                self.assertEqual(data_module.load_aerial_samples(*args, index_mode="off")[0]["image"], first[0]["image"])
                self.assertEqual(len(calls), 3)
                with self.assertRaisesRegex(ValueError, "off/ram/disk"):
                    data_module.load_aerial_samples(*args, index_mode="bogus")
                with self.assertRaisesRegex(ValueError, "index_dir"):
                    data_module.load_aerial_samples(*args, index_mode="disk")

    def test_prefetched_sha_matches_serial_and_rejects_tampering(self):
        import hashlib
        from uavnav.avln import data as data_module
        with TemporaryDirectory() as tmp:
            root = Path(tmp).resolve()
            good = root / "a.png"
            good.write_bytes(b"alpha")
            item = {"path": "a.png", "sha256": hashlib.sha256(b"alpha").hexdigest()}
            serial = data_module._aerial_cache_file(root, item, "x")
            data_module.prefetch_verified_files(root, [item, {"path": "missing.png", "sha256": "0" * 64}])
            self.assertEqual(serial, data_module._aerial_cache_file(root, item, "x"))
            good.write_bytes(b"tampered")
            data_module._VERIFIED_FILES.clear()
            with self.assertRaisesRegex(ValueError, "SHA256"):
                data_module._aerial_cache_file(root, item, "x")

    def sample(self, tag, frame, image_sha):
        return {"scene_id": 2, "episode_id": str(tag), "frame_index": frame, "action": 1, "instruction": "turn right",
                "image_sha256": image_sha, "image": f"{image_sha}.png"}

    def model(self, vision_train_policy="frozen"):
        torch.manual_seed(5)
        model = AerialRecurrentRouteNet(5, history_frames=2, hidden=4, pretrained=False,
                                        vision_train_policy=vision_train_policy).eval()
        model.vision = nn.Sequential(nn.Conv2d(3, 512, 3, stride=2, padding=1), nn.ReLU())
        model.vision.requires_grad_(vision_train_policy != "frozen")
        return model

    def batch(self, length=4):
        torch.manual_seed(6)
        return {"image": torch.rand(length, 3, 16, 16), "tokens": torch.tensor([[2, 3]] * length),
                "token_mask": torch.ones(length, 2, dtype=torch.bool),
                "history": torch.eye(8)[torch.tensor([[1, 2]] * length)], "history_length": torch.tensor([2] * length)}

    def cached(self, model, batch):
        with torch.no_grad():
            pooled, regions = model.vision_summary(batch["image"])
        data = {key: value for key, value in batch.items() if key != "image"}
        return {**data, "image": torch.empty(len(pooled), 0), "vision_mean": pooled, "vision_regions": regions}

    def test_cached_sequence_matches_online_forward_bit_for_bit(self):
        model, batch = self.model(), self.batch()
        with torch.no_grad():
            online, online_state = model.forward_sequence(batch)
            cached, cached_state = model.forward_sequence(self.cached(model, batch))
        self.assertTrue(torch.equal(online, cached))
        self.assertTrue(torch.equal(online_state, cached_state))

    def test_cached_batched_episodes_match_online(self):
        model, batch = self.model(), self.batch(6)
        with torch.no_grad():
            online, _ = model.forward_sequence_batch(batch, None, 2, 3)
            cached, _ = model.forward_sequence_batch(self.cached(model, batch), None, 2, 3)
        self.assertTrue(torch.equal(online, cached))

    def test_cache_key_binds_backbone_weights_and_preprocessing(self):
        from uavnav.avln.data import vision_cache_key
        model = self.model()
        key = vision_cache_key(model, 16)
        self.assertEqual(key, vision_cache_key(model, 16))
        self.assertNotEqual(key, vision_cache_key(model, 32))
        with torch.no_grad():
            model.vision[0].weight.add_(1e-3)
        self.assertNotEqual(key["vision_state_sha256"], vision_cache_key(model, 16)["vision_state_sha256"])

    def test_build_load_attach_roundtrip_and_rejections(self):
        import hashlib
        import numpy as np
        from PIL import Image
        from uavnav.avln.data import (attach_vision_features, build_vision_feature_cache, collate,
                                      load_vision_feature_cache, preprocess_rgb)
        model = self.model()
        with TemporaryDirectory() as tmp:
            root = Path(tmp)
            episode = []
            for frame in range(3):
                path = root / f"f{frame}.png"
                Image.fromarray((torch.rand(16, 16, 3) * 255).byte().numpy()).save(path)
                episode.append({**self.sample(0, frame, hashlib.sha256(path.read_bytes()).hexdigest()), "image": str(path),
                                "history": np.zeros((0, 8), dtype=np.float32), "history_policy": "action_onehot8_v1"})
            vocab = Vocab(["turn right"], tokenizer_version="route_numeric_v1")
            cache_path = root / "features.pt"
            payload = build_vision_feature_cache(model, [episode], 16, torch.device("cpu"), cache_path)
            online = collate(episode, vocab, 16, 2)
            with torch.no_grad():
                expected, _ = model.forward_sequence(online)
            attach_vision_features([episode], load_vision_feature_cache(cache_path, model, 16))
            cached = collate(episode, vocab, 16, 2)
            self.assertEqual(cached["image"].numel(), 0)
            with torch.no_grad():
                actual, _ = model.forward_sequence(cached)
            self.assertTrue(torch.allclose(expected, actual, atol=1e-6, rtol=0))
            mixed = [dict(episode[0]), {k: v for k, v in episode[1].items() if k not in ("vision_mean", "vision_regions")}]
            with self.assertRaisesRegex(ValueError, "混合"):
                collate(mixed, vocab, 16, 2)
            with self.assertRaisesRegex(ValueError, "缺少帧"):
                attach_vision_features([[{**episode[0], "image_sha256": "f" * 64}]], payload)
            with self.assertRaisesRegex(ValueError, "image_sha256不符"):
                build_vision_feature_cache(model, [[{**episode[0], "image_sha256": "e" * 64}]], 16,
                                           torch.device("cpu"), root / "forged.pt")
            half_path = root / "features_fp16.pt"
            half = build_vision_feature_cache(model, [episode], 16, torch.device("cpu"), half_path, storage_dtype="float16")
            self.assertEqual(next(iter(half["mean"].values())).dtype, torch.float16)
            self.assertEqual(half["key"]["storage_dtype"], "float16")
            with self.assertRaisesRegex(ValueError, "不一致"):
                load_vision_feature_cache(half_path, model, 16)
            attach_vision_features([episode], load_vision_feature_cache(half_path, model, 16, "float16"))
            self.assertEqual(collate(episode, vocab, 16, 2)["vision_mean"].dtype, torch.float32)
            with torch.no_grad():
                model.vision[0].weight.add_(1e-3)
            with self.assertRaisesRegex(ValueError, "不一致"):
                load_vision_feature_cache(cache_path, model, 16)
            with self.assertRaisesRegex(ValueError, "完全冻结"):
                build_vision_feature_cache(self.model("finetune"), [episode], 16, torch.device("cpu"), root / "x.pt")


class DinoV5ConfigTests(unittest.TestCase):
    def config(self):
        return {
            "architecture": "aerial_route_dino_v5", "imgsz": 224, "hidden": 4,
            "history_frames": 2, "visual_fusion": "spatial", "fusion_mode": "query_plus_text",
            "stop_enabled": True,
            "visual_encoder": {
                "version": "dinov3_backbone_v1", "variant": "vits16",
                "input_size": 224, "patch_size": 16, "embed_dim": 384, "grid_size": 14,
                "frozen": True, "token_protocol": "cls_plus_patch_tokens_v1",
                "repo_dir": "/missing/DINOv3", "weights_sha256": "a" * 64,
                "repo_source_sha256": "b" * 64,
            },
        }

    def test_invalid_dino_visual_contract_is_rejected(self):
        for change in (lambda c: c.pop("visual_encoder"),
                       lambda c: c["visual_encoder"].update(variant="unknown"),
                       lambda c: c["visual_encoder"].update(input_size=256),
                       lambda c: c["visual_encoder"].update(patch_size=8),
                       lambda c: c["visual_encoder"].update(embed_dim=256),
                       lambda c: c["visual_encoder"].update(grid_size=10),
                       lambda c: c["visual_encoder"].update(frozen="yes"),
                       lambda c: c.update(visual_fusion="global"),
                       lambda c: c.update(fusion_mode="text_context_only")):
            config = self.config()
            change(config)
            with self.subTest(config=config), self.assertRaises(ValueError):
                build_model(4, config)

    def test_encoder_configurations_cannot_be_combined_or_ignored(self):
        from uavnav.avln.model import validate_encoder_configuration
        validate_encoder_configuration({"architecture": "aerial_route_recurrent_v2",
                                        "dino_repo": None, "text_feature_cache": None})
        for architecture in ("legacy_waypoint_v1", "aerial_route_recurrent_v2", "aerial_route_recurrent_clause_v3"):
            for extra in ({"dino_repo": "unused"}, {"dino_frozen": False},
                          {"visual_encoder": {}}, {"backbone": "dinov3_vits16"}):
                with self.subTest(architecture=architecture, extra=extra), self.assertRaises(ValueError):
                    build_model(4, {"architecture": architecture, **extra})
        for architecture in ("legacy_waypoint_v1", "aerial_route_recurrent_v2", "aerial_route_dino_v5"):
            for extra in ({"text_encoder": {}}, {"clause_dim": 512}, {"text_feature_cache": "unused"}):
                with self.subTest(architecture=architecture, extra=extra), self.assertRaises(ValueError):
                    build_model(4, {"architecture": architecture, **extra})
        for extra in ({"backbone": "resnet18"}, {"backbone": "dinov3_vitb16"},
                      {"vision_feature_cache": "unused"}, {"dino_variant": "vitb16"},
                      {"dino_input_size": 320}, {"dino_frozen": False}, {"dino_frozen": 1}):
            with self.subTest(extra=extra), self.assertRaises(ValueError):
                build_model(4, {**self.config(), **extra})
        validate_encoder_configuration({**self.config(), "dino_variant": "vits16",
                                        "dino_input_size": 224, "dino_frozen": True})
        with self.assertRaisesRegex(ValueError, "visual_history"):
            build_model(4, {"architecture": "aerial_route_recurrent_clause_v3",
                            "text_query_mode": "state_conditioned_v1"})

    def test_dino_constructs_only_selected_backbone_and_keeps_trainable_fusion(self):
        class FakeDinoBackbone(nn.Module):
            def __init__(self):
                super().__init__()
                self.projection = nn.Linear(3, 384)

            def forward(self, image, is_training=True):
                patches = torch.nn.functional.avg_pool2d(image, 16).flatten(2).transpose(1, 2)
                patches = self.projection(patches)
                return {"x_norm_clstoken": patches.mean(1), "x_norm_patchtokens": patches}

        with patch("uavnav.avln.model.resnet18", side_effect=AssertionError("unused R18")), \
                patch("uavnav.avln.model.resnet50", side_effect=AssertionError("unused R50")), \
                patch("uavnav.avln.model.dinov3_source_sha256", return_value="b" * 64), \
                patch("uavnav.avln.model._load_dinov3_backbone", side_effect=lambda *args: FakeDinoBackbone()) as factory:
            torch.manual_seed(0)
            model = build_model(4, self.config())
            self.assertEqual(factory.call_count, 1)
            self.assertEqual(model.backbone, "dinov3_vits16")
            self.assertEqual(model.grid_size, 14)
            self.assertEqual(tuple(model.region_coordinates.shape), (1, 196, 2))
            self.assertEqual(model.vision_proj.in_features, 384)
            self.assertEqual(sum(isinstance(module, nn.LSTM) for module in model.modules()), 1)
            model.train()
            self.assertFalse(model.vision.model.training)
            self.assertTrue(all(not parameter.requires_grad for parameter in model.vision.parameters()))
            data = AerialRecurrentTests().inputs(3)
            data["image"] = torch.randn(3, 3, 224, 224)
            logits, _ = model.forward_sequence(data)
            torch.nn.functional.cross_entropy(logits, torch.tensor([1, 2, 0])).backward()
            self.assertTrue(all(parameter.grad is None for parameter in model.vision.parameters()))
            for parameter in (model.vision_proj.weight, model.memory.weight_ih_l0, model.head.weight):
                self.assertIsNotNone(parameter.grad)
                self.assertTrue(torch.isfinite(parameter.grad).all())
                self.assertGreater(parameter.grad.abs().sum().item(), 0.)
            restored = build_model(4, self.config()).eval()
            restored.load_state_dict(model.state_dict(), strict=True)
            self.assertEqual(list(model.state_dict()), list(restored.state_dict()))
            self.assertEqual([name for name, _ in model.named_parameters()],
                             [name for name, _ in restored.named_parameters()])
            with torch.no_grad():
                expected, expected_state = model.eval().forward_sequence(data)
                actual, actual_state = restored.forward_sequence(data)
            torch.testing.assert_close(actual, expected, rtol=0, atol=0)
            torch.testing.assert_close(actual_state, expected_state, rtol=0, atol=0)
            for key in ("vision_mean", "vision_regions"):
                with self.subTest(key=key), self.assertRaisesRegex(ValueError, "视觉特征缓存"):
                    model.forward_sequence({**data, key: torch.zeros(3, 384)})

    def test_lstm_path_rejects_clause_features_even_in_no_text_ablation(self):
        for ablate in ("none", "no_text"):
            model = AerialRecurrentRouteNet(5, history_frames=2, hidden=4, ablate=ablate,
                                            pretrained=False)
            for key in ("clause_features", "clause_mask"):
                with self.subTest(ablate=ablate, key=key), self.assertRaisesRegex(ValueError, "CLIP"):
                    model._encode_text({**AerialRecurrentTests().inputs(), key: torch.ones(4, 1)})


class DinoV5CheckpointTests(unittest.TestCase):
    def test_checkpoint_rejects_cross_encoder_and_duplicate_declarations(self):
        saved = self.checkpoint()
        _validate_checkpoint(saved)  # 旧checkpoint无构造版本与重复DINO字段，仍接受。
        config = saved["model_config"]
        config.update(model_construction_version="direct_selected_encoders_v1",
                      dino_variant="vits16", dino_input_size=224, dino_frozen=True)
        _validate_checkpoint(saved)
        for extra in ({"text_encoder": {"version": "frozen_clip_clause_cache_v1"}},
                      {"text_feature_cache": "clip.pt"}, {"vision_feature_cache": "r18.pt"},
                      {"dino_variant": "vitb16"}, {"dino_input_size": 320},
                      {"dino_frozen": False}, {"dino_frozen": 1},
                      {"model_construction_version": "unknown"}):
            tampered = copy.deepcopy(saved)
            tampered["model_config"].update(extra)
            with self.subTest(extra=extra), self.assertRaises(CheckpointFormatError):
                _validate_checkpoint(tampered)
        _, r18 = AerialRecurrentTests().checkpoint()
        for extra in ({"visual_encoder": config["visual_encoder"]},
                      {"text_encoder": {"version": "frozen_clip_clause_cache_v1"}}, {"dino_weights": "dino.pt"}):
            tampered = copy.deepcopy(r18)
            tampered["model_config"].update(extra)
            with self.subTest(r18=extra), self.assertRaises(CheckpointFormatError):
                _validate_checkpoint(tampered)

    def checkpoint(self):
        _, saved = AerialActionTests().checkpoint()
        config = saved["model_config"]
        protocol = aerial_task_protocol(224)
        render = copy.deepcopy(config["input_render_protocols"]["train"])
        render.update(width=224, height=224)
        rendered = {"train": render, "validation": copy.deepcopy(render)}
        config.update(
            checkpoint_format_version=8, architecture="aerial_route_dino_v5",
            backbone="dinov3_vits16", visual_fusion="spatial", grid_size=14, imgsz=224,
            stop_enabled=True, fusion_mode="query_plus_text", output_version="aerial_action8_v1",
            history_policy="action_onehot8_v1", data_protocol="aerialvln_s_v1",
            strip_direction=False, text_control="original", text_query_mode="visual_history",
            vision_train_policy="frozen", memory_protocol="fused_gru_v1",
            sequence_policy="episode_contiguous_tbptt_v1", tokenizer_version="route_numeric_v1",
            sequence_chunk_size=4, memory_mode="carry", constant_text_token=None,
            vision_batchnorm_protocol="dinov3_layernorm_v1",
            loss_protocol={"version": "transition_weighted_ce_v1", "inflection_weight": 1.9,
                           "stop_weight": 1.9, "normalization": "sum_weights"},
            visual_encoder={
                "version": "dinov3_backbone_v1", "variant": "vits16", "repo_dir": "/missing/DINOv3",
                "repo_source_sha256": "b" * 64, "weights_sha256": "a" * 64,
                "input_size": 224, "patch_size": 16, "embed_dim": 384, "grid_size": 14,
                "frozen": True, "token_protocol": "cls_plus_patch_tokens_v1",
            },
            task_protocol=protocol, task_protocol_sha256=_json_sha256(protocol),
            input_render_protocols=rendered, input_render_protocols_sha256=_json_sha256(rendered),
            split_manifest_sha256="c" * 64)
        saved["model"] = {}
        return saved

    def test_format8_contract_accepts_and_rejects_tamper(self):
        saved = self.checkpoint()
        _validate_checkpoint(saved)
        for change in (lambda c: c["visual_encoder"].update(variant="unknown"),
                       lambda c: c["visual_encoder"].update(grid_size=10),
                       lambda c: c["visual_encoder"].update(weights_sha256="x"),
                       lambda c: c.update(vision_batchnorm_protocol="frozen_running_stats_v1"),
                       lambda c: c.update(vision_train_policy="finetune"),
                       lambda c: c.update(imgsz=320),
                       lambda c: c.update(checkpoint_format_version=5)):
            tampered = copy.deepcopy(saved)
            change(tampered["model_config"])
            with self.subTest(change=change), self.assertRaises(CheckpointFormatError):
                _validate_checkpoint(tampered)


@unittest.skipUnless(os.environ.get("UAVNAV_DINO_REPO") and os.environ.get("UAVNAV_DINO_WEIGHTS"),
                     "需要真实DINOv3源码和权重")
class DinoV5IntegrationTests(unittest.TestCase):
    def test_real_backbone_strict_load_and_forward(self):
        import hashlib
        from uavnav.avln.model import dinov3_source_sha256
        repo, weights = os.environ["UAVNAV_DINO_REPO"], os.environ["UAVNAV_DINO_WEIGHTS"]
        config = {
            "architecture": "aerial_route_dino_v5", "imgsz": 224, "hidden": 128,
            "history_frames": 8, "ablate": "none", "memory_mode": "carry",
            "vision_train_policy": "frozen", "text_query_mode": "visual_history",
            "backbone": "dinov3_vits16", "visual_fusion": "spatial", "grid_size": 14,
            "fusion_mode": "query_plus_text", "stop_enabled": True, "dino_weights": weights,
            "visual_encoder": {
                "version": "dinov3_backbone_v1", "variant": "vits16", "repo_dir": repo,
                "repo_source_sha256": dinov3_source_sha256(repo),
                "weights_sha256": hashlib.sha256(Path(weights).read_bytes()).hexdigest(),
                "input_size": 224, "patch_size": 16, "embed_dim": 384, "grid_size": 14,
                "frozen": True, "token_protocol": "cls_plus_patch_tokens_v1",
            },
        }
        model = build_model(8, config, pretrained=True).eval()
        self.assertTrue(model.vision.frozen)
        self.assertTrue(all(not parameter.requires_grad for parameter in model.vision.parameters()))
        batch = {"image": torch.randn(2, 3, 224, 224), "tokens": torch.tensor([[2, 3], [2, 4]]),
                 "token_mask": torch.ones(2, 2, dtype=torch.bool), "history": torch.zeros(2, 8, 8),
                 "history_length": torch.tensor([0, 2])}
        with torch.no_grad():
            logits = model(batch)
        self.assertEqual(tuple(logits.shape), (2, 8))
        self.assertTrue(torch.isfinite(logits).all())


class TrainingDiagnosticGuardTests(unittest.TestCase):
    def test_legacy_resume_preserves_uncommitted_new_diagnostics_without_duplicates(self):
        from uavnav.avln.fit import _restore_committed_logs
        with TemporaryDirectory() as tmp:
            run = Path(tmp)
            csv_bytes = b"epoch\n1\n"
            (run / "results.csv").write_bytes(csv_bytes)
            diagnostic = run / "training_diagnostics.jsonl"
            diagnostic.write_text('{"epoch":2}\n', encoding="utf-8")
            _restore_committed_logs(run, {"results.csv": csv_bytes}, 1)
            self.assertFalse(diagnostic.exists())
            preserved = list(run.glob("training_diagnostics_uncommitted_*.jsonl"))
            self.assertEqual(len(preserved), 1)
            self.assertEqual(preserved[0].read_text(), '{"epoch":2}\n')
            diagnostic.write_text('{"epoch":1}\n', encoding="utf-8")
            with self.assertRaisesRegex(ValueError, "无法认证"):
                _restore_committed_logs(run, {"results.csv": csv_bytes}, 1)

    def test_candidate_configuration_is_explicit_and_validated(self):
        from train import aerial_training_parameters
        common = {"cache_manifest": "train.json", "validation_cache_manifest": "dev.json", "epochs": 3}
        with patch.dict(os.environ, {}, clear=True):
            self.assertEqual(aerial_training_parameters(common)["candidate_epochs"], [])
            self.assertEqual(aerial_training_parameters({**common, "candidate_epochs": [1, 3]})["candidate_epochs"], [1, 3])
            for candidate_epochs in ([0], [4], [True], [2, 1], [1, 1], "1"):
                with self.subTest(candidate_epochs=candidate_epochs), self.assertRaisesRegex(ValueError, "candidate_epochs"):
                    aerial_training_parameters({**common, "candidate_epochs": candidate_epochs})
            with self.assertRaisesRegex(ValueError, "diagnostics_interval"):
                aerial_training_parameters({**common, "diagnostics_interval": -1})

    def test_nonfinite_gradient_stops_before_step_and_preserves_failure(self):
        import json
        class Model(nn.Module):
            def __init__(self):
                super().__init__()
                self.head = nn.Linear(1, 8)

            def forward_sequence(self, data, state=None):
                return self.head(data["image"]), self.head.weight[:1].reshape(1, 1, -1)

        model = Model()
        model.head.weight.register_hook(lambda grad: torch.full_like(grad, float("nan")))
        optimizer = torch.optim.SGD(model.parameters(), lr=.1)
        data = {"image": torch.ones(1, 1), "action_target": torch.zeros(1, dtype=torch.long)}
        episode = [{"scene_id": 2, "episode_id": "x", "frame_index": 0, "action": 0, "instruction": "stop"}]
        before = copy.deepcopy(model.state_dict())
        with TemporaryDirectory() as tmp, patch("uavnav.avln.fit.collate", return_value=data), patch.object(optimizer, "step") as step:
            failure = Path(tmp) / "failure.json"
            with self.assertRaisesRegex(RuntimeError, "non-finite"):
                _aerial_sequence_epoch(model, [episode], None, 1, 1, 1, torch.device("cpu"),
                                       optimizer=optimizer, failure_path=failure)
            step.assert_not_called()
            self.assertEqual(json.loads(failure.read_text())["chunk_begin"], 0)
        for key, value in model.state_dict().items():
            self.assertTrue(torch.equal(before[key], value))

    def test_gradient_observation_preserves_updates(self):
        class Model(nn.Module):
            def __init__(self):
                super().__init__()
                self.head = nn.Linear(1, 8)

            def forward_sequence(self, data, state=None):
                return self.head(data["image"]), self.head.weight[:1].reshape(1, 1, -1)

        first = Model()
        second = copy.deepcopy(first)
        data = {"image": torch.ones(1, 1), "action_target": torch.zeros(1, dtype=torch.long)}
        episode = [{"scene_id": 2, "episode_id": "x", "frame_index": 0, "action": 0, "instruction": "stop"}]
        with patch("uavnav.avln.fit.collate", return_value=data):
            for model, interval in ((first, 0), (second, 1)):
                stats = _aerial_sequence_epoch(model, [episode], None, 1, 1, 1, torch.device("cpu"),
                    optimizer=torch.optim.SGD(model.parameters(), lr=.1), diagnostics_interval=interval)
                self.assertEqual(len(stats["optimization_diagnostics"]["gradient_samples"]), 0 if interval == 0 else 1)
        for key, value in first.state_dict().items():
            self.assertTrue(torch.equal(value, second.state_dict()[key]))


if __name__ == "__main__":
    unittest.main()
