"""对象解析回归：标准库测试，不导入 Torch，不改原始数据。"""

import copy
import json
import os
import sys
import unittest
from pathlib import Path

sys.path.insert(0, str(Path(__file__).resolve().parents[1]))
from uavnav.avln.metadata import (
    ObjectMetadataError, resolve_object_metadata, validate_task_protocol, task_protocol_sha256,
    validate_evaluation_protocol, evaluation_protocol_sha256, canonical_eval_split,
    validate_evaluation_manifest, evaluation_manifest_sha256,
    aerial_metric_definition_contract, aerial_task_protocol,
)


def make_entry(asset="intended", position=(1.0, 2.0, 3.0), orientation=(0.0, 0.0, 0.0, 2.0), scale=1.0, anchor=(0.0, 0.0, 0.0)):
    entry = [0.0] * 18
    entry[:3] = anchor
    entry[9:12] = position
    entry[12:16] = [orientation[3], orientation[0], orientation[1], orientation[2]]
    entry[16:18] = [asset, scale]
    return entry


def evaluation_protocol():
    return {
        "version": "fov_static_v1", "benchmark": "UAV-VLN-FOV", "environment": "static",
        "goal_source": "object_metadata", "goal_access": "training_labels_and_offline_scoring_only",
        "success_distance_m": 10, "distance_dimensions": 3,
        "stop_protocol": "predicted_stop_before_action", "collision_source": "simulator_contact",
        "oracle_termination": "disabled", "instruction_source": "obj_des.json",
        "target_description_source": "instruction_only",
        "coordinate_frame": "airsim_local_ned_from_vehicle_spawn",
        "allowed_observations": ["front_rgb", "down_rgb", "instruction", "initial_direction", "vehicle_pose"],
        "control": {"protocol": "paused_static_fixed_duration_world_velocity", "max_steps": 64,
                    "action_duration_sim_s": 5., "speed_limit_m_s": 1., "sample_interval_sim_s": .1},
        "spl": {"definition": "success_distance_adjusted", "reference": "reference_path_proxy",
                "sampling": "sim_step_pose_samples", "zero_length_success": "one_if_denominator_le_1e-8"},
    }


class EvaluationContractTests(unittest.TestCase):
    def test_aerial_metric_reporting_records_decision_timing_and_distance_dimensions(self):
        definition = aerial_metric_definition_contract()
        self.assertEqual(definition["measurement_definition_version"], "aerial_metric_reporting_v2")
        self.assertEqual(definition["latency_measurement"], "model_inference_per_decision")
        self.assertEqual(definition["latency_percentile_method"], "linear")
        self.assertIn("stop_decision", definition["latency_boundary"]["includes"])
        self.assertIn("journal_writes", definition["latency_boundary"]["excludes"])
        self.assertIn("sensor_acquisition", definition["latency_boundary"]["excludes"])
        self.assertIn("controller_step", definition["latency_boundary"]["excludes"])
        self.assertEqual(definition["ndtw_distance_dimensions"], 3)
        self.assertTrue(all(definition[field] == 2 for field in (
            "ne_distance_dimensions", "sr_distance_dimensions", "osr_distance_dimensions")))
        # Reporting metadata is separate from the frozen checkpoint policy task.
        self.assertEqual(aerial_task_protocol()["distance_dimensions"], 2)
        self.assertNotIn("measurement_definition_version", aerial_task_protocol())

    def test_aerial_metric_reporting_separates_depth_proxy_contact_and_source_semantics(self):
        definition = aerial_metric_definition_contract()
        self.assertEqual(definition["initial_depth_proxy_policy"], "reject_episode_before_policy_decisions")
        self.assertEqual(definition["initial_contact_policy"], "record_only_not_a_depth_proxy_or_success_veto")
        self.assertIn("not_metric_distance", definition["depth_proxy_source"]["scene_1_7"])
        self.assertIn("float_m", definition["depth_proxy_source"]["other_scenes"])
        self.assertIs(definition["depth_proxy_source"]["physical_contact_equivalence"], False)
        definition["latency_boundary"]["includes"].clear()
        self.assertIn("stop_decision", aerial_metric_definition_contract()["latency_boundary"]["includes"])

    def manifest(self):
        return {"schema_version": 1, "scope": "subset_diagnostic", "split": "unobject",
                "source_sha256": None, "evaluation_protocol_sha256": None,
                "episodes": [{"traj_id": "Map/UUID", "split": "unobject"}]}

    def test_permissions_and_success_changes_are_rejected(self):
        for key, value in (("goal_access", "policy_input"), ("goal_source", "reference_endpoint"),
                           ("success_distance_m", 20), ("distance_dimensions", 2),
                           ("stop_protocol", "fixed_horizon"), ("collision_source", "distance_stall"),
                           ("oracle_termination", "enabled"), ("target_description_source", "oracle_description"),
                           ("coordinate_frame", "unreal_world")):
            with self.subTest(key=key):
                protocol = evaluation_protocol()
                protocol[key] = value
                with self.assertRaises(ValueError):
                    validate_evaluation_protocol(protocol)
        for observations in (["front_rgb", "instruction", "initial_direction", "vehicle_pose"],
                             evaluation_protocol()["allowed_observations"] + ["goal_position"],
                             evaluation_protocol()["allowed_observations"] + ["front_rgb"]):
            with self.subTest(observations=observations), self.assertRaises(ValueError):
                validate_evaluation_protocol({**evaluation_protocol(), "allowed_observations": observations})

    def test_control_and_undefined_fields_fail_before_execution(self):
        changes = [("success_distance_m", True), ("success_distance_m", float("nan")),
                   ("distance_dimensions", 3.), ("distance_dimensions", True)]
        for key, value in changes:
            with self.subTest(key=key, value=value), self.assertRaises(ValueError):
                validate_evaluation_protocol({**evaluation_protocol(), key: value})
        for key, value in (("max_steps", True), ("max_steps", 0), ("max_steps", 1.5),
                           ("action_duration_sim_s", float("inf")), ("speed_limit_m_s", float("nan")),
                           ("speed_limit_m_s", False), ("sample_interval_sim_s", 0),
                           ("sample_interval_sim_s", 6.)):
            protocol = evaluation_protocol()
            protocol["control"][key] = value
            with self.subTest(key=key, value=value), self.assertRaises(ValueError):
                validate_evaluation_protocol(protocol)
        for location in (None, "control", "spl"):
            protocol = evaluation_protocol()
            (protocol if location is None else protocol[location])["undefined_permission"] = True
            with self.subTest(location=location), self.assertRaises(ValueError):
                validate_evaluation_protocol(protocol)
        protocol = evaluation_protocol()
        protocol["spl"]["sampling"] = "action_endpoints"
        with self.assertRaises(ValueError):
            validate_evaluation_protocol(protocol)
        protocol = evaluation_protocol()
        protocol["spl"]["zero_length_success"] = "zero"
        with self.assertRaises(ValueError):
            validate_evaluation_protocol(protocol)

    def test_protocol_digest_canonicalizes_permissions_without_mutation(self):
        original = evaluation_protocol()
        copied = copy.deepcopy(original)
        reordered = dict(reversed(list(original.items())))
        reordered["allowed_observations"] = list(reversed(original["allowed_observations"]))
        reordered["success_distance_m"] = 10.
        self.assertEqual(evaluation_protocol_sha256(original), evaluation_protocol_sha256(reordered))
        self.assertEqual(original, copied)
        normalized = validate_evaluation_protocol(original)
        normalized["control"]["max_steps"] = 1
        normalized["spl"]["sampling"] = "changed"
        normalized["allowed_observations"].append("changed")
        self.assertEqual(original, copied)
        deeper = copy.deepcopy(original)
        deeper["allowed_observations"].append("depth")
        self.assertNotEqual(evaluation_protocol_sha256(original), evaluation_protocol_sha256(deeper))

    def test_manifest_binds_split_and_rejects_missing_or_unsafe_episodes(self):
        for traj_id in ("../UUID", "/Map/UUID", "Map/../UUID", "Map/..", "Map\\UUID",
                        "C:/UUID", "Map/", "Map", "Map/ UUID"):
            manifest = self.manifest()
            manifest["episodes"][0]["traj_id"] = traj_id
            with self.subTest(traj_id=traj_id), self.assertRaises(ValueError):
                validate_evaluation_manifest(manifest)
        for rows in ([], [{"traj_id": "Map/UUID", "split": "test"}],
                     self.manifest()["episodes"] * 2,
                     [{"traj_id": "Map/UUID", "split": "unobject", "extra": 1}]):
            with self.subTest(rows=rows), self.assertRaises(ValueError):
                validate_evaluation_manifest({**self.manifest(), "episodes": rows})
        with self.assertRaises(ValueError):
            validate_evaluation_manifest({**self.manifest(), "scope": "official_split"})
        with self.assertRaisesRegex(ValueError, "单轨迹"):
            validate_evaluation_manifest({**self.manifest(), "episodes": [
                {"traj_id": "Map/UUID", "split": "unobject"},
                {"traj_id": "Map/other", "split": "unobject"}]})
        for key, value in (("source_sha256", "bad"), ("evaluation_protocol_sha256", False),
                           ("schema_version", True), ("schema_version", 1.), ("split", "train"),
                           ("extra", 1)):
            with self.subTest(key=key), self.assertRaises(ValueError):
                validate_evaluation_manifest({**self.manifest(), key: value})

    def test_manifest_alias_digest_and_source_integrity(self):
        manifest = self.manifest()
        manifest.update(scope="official_split", source_sha256="A" * 64,
                        evaluation_protocol_sha256=evaluation_protocol_sha256(evaluation_protocol()))
        equivalent = copy.deepcopy(manifest)
        equivalent["split"] = equivalent["episodes"][0]["split"] = "unseen_object"
        equivalent["source_sha256"] = "a" * 64
        self.assertEqual(evaluation_manifest_sha256(manifest), evaluation_manifest_sha256(equivalent))
        self.assertEqual(manifest["source_sha256"], "A" * 64)
        normalized = validate_evaluation_manifest(manifest)
        normalized["episodes"][0]["traj_id"] = "Map/changed"
        normalized["episodes"].append({"traj_id": "Map/new", "split": "unobject"})
        self.assertEqual(manifest["episodes"], [{"traj_id": "Map/UUID", "split": "unobject"}])
        equivalent["source_sha256"] = "b" * 64
        self.assertNotEqual(evaluation_manifest_sha256(manifest), evaluation_manifest_sha256(equivalent))
        self.assertEqual(canonical_eval_split("unseen_scene"), "unscene")

    def test_legacy_task_contract_digest_is_unchanged(self):
        legacy = {"version": "fov_front_motion_v1", "camera": "FrontCamera", "image_size": 224,
                  "strip_direction": True, "goal_access": "training_labels_and_offline_scoring_only",
                  "stop_source": "disabled", "stop_timing": "disabled"}
        self.assertEqual(validate_task_protocol(legacy), legacy)
        self.assertEqual(task_protocol_sha256(legacy),
                         "8bb6d3fba778148c37670dff493858b43d8fa6fba0c51bb4eed09b44cee9180d")
        with self.assertRaises(ValueError):
            validate_evaluation_protocol(legacy)


class ObjectMetadataTests(unittest.TestCase):
    def setUp(self):
        self.mark = {"object_name": "intended", "target": {"position": [1.0, 2.0, 3.0]}}
        self.areas = {"Map": [make_entry()]}

    def test_ignores_nearest_anchor_of_another_asset(self):
        # wrong 的区域查询锚点正好命中 target，intended 的实际位置才是正确目标。
        wrong = make_entry("wrong", position=(1, 2, 3), anchor=(0, 1, 2.5))
        intended = make_entry(anchor=(100, 100, 100))
        original = copy.deepcopy((self.mark, [wrong, intended]))
        result = resolve_object_metadata(self.mark, {"Map": [wrong, intended]}, "Map")
        self.assertEqual(result["asset"], "intended")
        self.assertEqual(result["source_entry_indices"], [1])
        self.assertEqual(result["orientation_xyzw"], [0.0, 0.0, 0.0, 2.0])
        self.assertEqual(result["validation_status"], "metadata_intent_only_mesh_unverified")
        self.assertEqual((self.mark, [wrong, intended]), original)

    def test_exact_duplicates_collapse(self):
        entry = make_entry()
        result = resolve_object_metadata(self.mark, {"Map": [entry, copy.deepcopy(entry)]}, "Map")
        self.assertEqual(result["source_entry_indices"], [0, 1])

    def test_different_pose_orientation_or_scale_is_ambiguous(self):
        for field, value in ((9, 1.0000005), (15, 0.2), (17, 2.0)):
            with self.subTest(field=field):
                different = make_entry()
                different[field] = value
                with self.assertRaisesRegex(ObjectMetadataError, "2 种匹配配置"):
                    resolve_object_metadata(self.mark, {"Map": [make_entry(), different]}, "Map")

    def test_does_not_merge_opposite_quaternion_sign(self):
        with self.assertRaisesRegex(ObjectMetadataError, "2 种匹配配置"):
            resolve_object_metadata(self.mark, {"Map": [make_entry(), make_entry(orientation=(0, 0, 0, -2))]}, "Map")

    def test_absolute_tolerance_has_no_relative_component(self):
        mark = {"object_name": "intended", "target": {"position": [1e6, 2, 3]}}
        self.assertEqual(resolve_object_metadata(mark, {"Map": [make_entry(position=(1e6 + 5e-7, 2, 3))]}, "Map")["asset"], "intended")
        with self.assertRaisesRegex(ObjectMetadataError, "未找到"):
            resolve_object_metadata(mark, {"Map": [make_entry(position=(1e6 + 1e-5, 2, 3))]}, "Map")

    def test_no_match_no_alias_no_anchor_fallback(self):
        for rows in ([], [make_entry("INTENDED")], [make_entry(position=(1, 2, 4))], [[0] * 16]):
            with self.subTest(rows=rows):
                with self.assertRaisesRegex(ObjectMetadataError, "未找到"):
                    resolve_object_metadata(self.mark, {"Map": rows}, "Map")
        with self.assertRaisesRegex(ObjectMetadataError, "Map 不存在"):
            resolve_object_metadata(self.mark, {"Other": [make_entry()]}, "Map")

    def test_invalid_fields_rejected(self):
        for field, value in ((9, float("nan")), (10, float("inf")), (12, float("nan")), (17, 0), (17, -1), (17, True)):
            with self.subTest(field=field, value=value):
                invalid = make_entry()
                invalid[field] = value
                with self.assertRaises(ObjectMetadataError):
                    resolve_object_metadata(self.mark, {"Map": [invalid]}, "Map")
        with self.assertRaisesRegex(ObjectMetadataError, "零四元数"):
            resolve_object_metadata(self.mark, {"Map": [make_entry(orientation=(0, 0, 0, 0))]}, "Map")

    def test_invalid_mark_rejected(self):
        for mark in ({}, {"object_name": "intended"}, {"object_name": "intended", "target": {"position": [True, 2, 3]}}, {"object_name": "intended", "target": {"position": [1, 2]}}):
            with self.subTest(mark=mark):
                with self.assertRaises(ObjectMetadataError):
                    resolve_object_metadata(mark, self.areas, "Map")

    def test_archived_13_real_conflicts(self):
        evidence = Path(__file__).resolve().parents[1] / "plan/data_object_audit_20261004.json"
        if not evidence.is_file():
            self.skipTest("尚未归档 13 条真实元数据诊断")
        conflicts = json.loads(evidence.read_text(encoding="utf-8"))["conflicts"]
        self.assertEqual(len(conflicts), 13)
        for conflict in conflicts:
            with self.subTest(trajectory=conflict["trajectory"]):
                # 使用归档的真实元数据值；合成无关字段不影响实际位置/资产/xyzw/尺度。
                candidates = [conflict["official_nearest"]] + conflict["all_same_name_candidates"]
                entries = [make_entry(item["asset"], item["spawn_position"], item["quaternion_xyzw"], item["scale"], [item["selection_anchor"][0] - 1, item["selection_anchor"][1] - 1, item["selection_anchor"][2] - 0.5]) for item in candidates]
                result = resolve_object_metadata(conflict["mark"], {conflict["map"]: entries}, conflict["map"])
                expected = conflict["same_name_nearest_spawn"]
                self.assertEqual(result["asset"], conflict["mark"]["object_name"])
                self.assertEqual(result["position"], conflict["mark"]["target"]["position"])
                self.assertEqual(result["orientation_xyzw"], expected["quaternion_xyzw"])
                self.assertEqual(result["scale"], expected["scale"])

    def test_all_available_dataset_objects(self):
        root = Path(os.environ.get("UAVNAV_METADATA_DATA_ROOT", "/root/rivermind-data/uav_vln_fov"))
        if not (root / "meta/map_spawnarea_info.json").is_file():
            self.skipTest("当前机器未挂载原始对象元数据")
        areas = json.loads((root / "meta/map_spawnarea_info.json").read_text(encoding="utf-8"))
        count = 0
        for split in ("train", "test", "unobject", "unscene"):
            for mark_path in sorted((root / split).glob("*/*/mark.json")):
                with self.subTest(trajectory=str(mark_path.parent)):
                    mark = json.loads(mark_path.read_text(encoding="utf-8"))
                    result = resolve_object_metadata(mark, areas, mark_path.parent.parent.name)
                    self.assertEqual(result["asset"], mark["object_name"])
                    self.assertEqual(result["position"], mark["target"]["position"])
                    count += 1
        self.assertEqual(count, 2717)


class AerialTaskProtocolTests(unittest.TestCase):
    def test_schema2_requires_episode_and_scoring_truth_bindings(self):
        manifest = {"schema_version": 2, "scope": "subset_diagnostic", "split": "val_unseen",
                    "source_sha256": "a" * 64, "evaluation_protocol_sha256": "b" * 64,
                    "episodes": [{"traj_id": "2/one", "split": "val_unseen", "episode_sha256": "c" * 64,
                                  "scoring_truth_sha256": "d" * 64}]}
        self.assertEqual(validate_evaluation_manifest(manifest), manifest)
        for field in ("episode_sha256", "scoring_truth_sha256"):
            changed = copy.deepcopy(manifest)
            changed["episodes"][0].pop(field)
            with self.assertRaises(ValueError):
                validate_evaluation_manifest(changed)
            changed["episodes"][0][field] = "missing"
            with self.assertRaises(ValueError):
                validate_evaluation_manifest(changed)
        with self.assertRaises(ValueError):
            validate_evaluation_manifest({**manifest, "source_sha256": None})
        with self.assertRaises(ValueError):
            validate_evaluation_manifest({**manifest, "schema_version": 1})

    def test_scoring_truth_digest_has_explicit_float_geometry_and_source_contract(self):
        from uavnav.avln.metadata import aerial_scoring_truth_sha256
        truth = {"traj_id": "2/one", "split": "val_unseen", "episode_sha256": "a" * 64,
                 "annotation_sha256": "b" * 64, "goal_position": [5, 0, -10], "start_position": [0, 0, -10],
                 "start_orientation_xyzw": [0, 0, 0, 1], "reference_positions": [[0, 0, -10], [5, 0, -10]]}
        digest = aerial_scoring_truth_sha256(truth)
        equivalent = {**truth, "goal_position": [5., 0., -10.], "unrelated": "ignored"}
        self.assertEqual(aerial_scoring_truth_sha256(equivalent), digest)
        self.assertNotEqual(aerial_scoring_truth_sha256({**truth, "goal_position": [6, 0, -10]}), digest)
        self.assertNotEqual(aerial_scoring_truth_sha256({**truth, "annotation_sha256": "c" * 64}), digest)
        for field in truth:
            missing = dict(truth)
            missing.pop(field)
            with self.subTest(field=field), self.assertRaises(ValueError):
                aerial_scoring_truth_sha256(missing)
        with self.assertRaises(ValueError):
            aerial_scoring_truth_sha256({**truth, "start_position": [float("nan"), 0, 0]})

    def test_train_manifest_only_allowed_as_bound_subset_diagnostic(self):
        manifest = {"schema_version": 1, "scope": "subset_diagnostic", "split": "train",
                    "source_sha256": "a" * 64, "evaluation_protocol_sha256": "b" * 64,
                    "episodes": [{"traj_id": "2/episode", "split": "train"}]}
        self.assertEqual(validate_evaluation_manifest(manifest)["split"], "train")
        with self.assertRaises(ValueError):
            canonical_eval_split("train")
        for change in ({"scope": "official_split"}, {"source_sha256": None}, {"evaluation_protocol_sha256": None}):
            with self.assertRaises(ValueError):
                validate_evaluation_manifest({**manifest, **change})

    def test_action_camera_and_goal_permission_are_frozen(self):
        from uavnav.avln.metadata import aerial_task_protocol, validate_aerial_task_protocol
        protocol = aerial_task_protocol(128)
        self.assertEqual(protocol["image_size"], 128)
        for field, value in (("camera", "FrontCamera"), ("goal_access", "policy_input"),
                             ("history_protocol", "position3"), ("distance_dimensions", True),
                             ("success_distance_m", 10), ("image_size", False)):
            changed = {**protocol, field: value}
            with self.assertRaises(ValueError):
                validate_aerial_task_protocol(changed)


class OfficialAerialReleaseTests(unittest.TestCase):
    def test_registration_matches_archived_source_evidence(self):
        from uavnav.avln.metadata import AERIALVLN_S_RELEASE
        rows = json.loads((Path(__file__).resolve().parents[1] / "plan" / "aerialvln_dataset_20261005" /
                           "aerialvln-s-file-manifest.json").read_text(encoding="utf-8"))
        sources = {row["path"]: row["sha256"] for row in rows}
        for split in ("train", "val_seen", "val_unseen", "test"):
            self.assertEqual(AERIALVLN_S_RELEASE[split]["sha256"], sources[f"{split}.json"])

    def test_truncated_or_wrong_source_cannot_be_authenticated_by_count(self):
        from uavnav.avln.metadata import authenticate_aerial_release, AERIALVLN_S_RELEASE
        from unittest.mock import patch
        rows = [{"scene_id": 2, "episode_id": "one", "_annotation_sha256": "a" * 64},
                {"scene_id": 3, "episode_id": "two", "_annotation_sha256": "a" * 64}]
        with patch.dict(AERIALVLN_S_RELEASE, {"val_unseen": {"sha256": "a" * 64, "episodes": 2}}):
            certificate = authenticate_aerial_release("val_unseen", rows)
            self.assertEqual(certificate["episode_count"], 2)
            for bad in (rows[:1], [rows[0], rows[0]], [{**row, "_annotation_sha256": "b" * 64} for row in rows]):
                with self.assertRaises(ValueError):
                    authenticate_aerial_release("val_unseen", bad)
        with self.assertRaises(ValueError):
            authenticate_aerial_release("val_unseen", rows)


if __name__ == "__main__":
    unittest.main()
