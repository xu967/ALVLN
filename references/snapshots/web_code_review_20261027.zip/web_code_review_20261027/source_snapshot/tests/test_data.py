"""Regression tests for actual FOV tail frames and source timestamps."""

from __future__ import annotations

import hashlib
import gzip
import json
import sys
import unittest
from pathlib import Path
from tempfile import TemporaryDirectory
from unittest.mock import patch

import numpy as np
import torch
from PIL import Image
from torch import nn

sys.path.insert(0, str(Path(__file__).resolve().parents[1]))
from uavnav.avln.data import (
    AERIAL_DATA_PROTOCOL, AERIAL_HISTORY_POLICY, Vocab, _frames, add_stop_annotations,
    aerial_episode_sha256, aerial_next_pose, collate, iter_samples, load_aerial_episodes,
    load_aerial_samples, load_aerial_render_passes, validate_aerial_render_protocol,
    load_list, group_aerial_episodes, tokenize, split_aerial_route_groups,
    select_aerial_route_partition,
    preprocess_depth, save_aerial_depth, preprocess_rgb, build_vision_feature_cache,
    load_aerial_dagger_samples, group_aerial_dagger_episodes,
)
from uavnav.avln.fit import (_aerial_sequence_epoch, aerial_transition_weights, aerial_action_priors,
                            sample_content_sha256, load_aerial_training_partitions)
from uavnav.avln.geometry import aerial_pose_transition
from uavnav.avln.simulator import StaticTrajectoryEnv


def trajectory(root, indices, *, yaw90=False, timestamps=None):
    path = root / "Map" / "episode"
    (path / "log").mkdir(parents=True)
    (path / "FrontCamera").mkdir()
    (path / "obj_des.json").write_text('["Find the red car."]', encoding="utf-8")
    quat = [0, 0, 2 ** -0.5, 2 ** -0.5] if yaw90 else [0, 0, 0, 1]
    for index in indices:
        state = {"position": [index, 0, 0], "orientation": quat}
        if timestamps is not None:
            state["timestamp"] = timestamps[index]
        (path / "log" / f"{index:06d}.json").write_text(
            json.dumps({"sensors": {"state": state}}), encoding="utf-8")
        Image.new("RGB", (2, 2)).save(path / "FrontCamera" / f"{index:06d}.png")
    return path


def sha256(path):
    return hashlib.sha256(Path(path).read_bytes()).hexdigest()


def stop_row(path, frame_index, target):
    return {
        "traj_id": f"{path.parent.name}/{path.name}",
        "frame_index": frame_index,
        "stop_target": target,
        "reviewed": True,
        "reviewer": "fixture-reviewer",
        "evidence": "synthetic contract fixture only",
        "image_sha256": sha256(path / "FrontCamera" / f"{frame_index:06d}.png"),
        "log_sha256": sha256(path / "log" / f"{frame_index:06d}.json"),
    }


def aerial_episode(episode_id="episode", *, singleton=False):
    # Independent fixed geometry exercises all eight official actions, including pure yaw.
    path = [[0, 0, -10, 0, 0, 0], [5, 0, -10, 0, 0, 0],
            [5, 0, -10, 0, 0, -np.pi / 12], [5, 0, -10, 0, 0, 0],
            [5, 0, -12, 0, 0, 0], [5, 0, -10, 0, 0, 0],
            [5, -5, -10, 0, 0, 0], [5, 0, -10, 0, 0, 0]]
    actions = [1, 2, 3, 4, 5, 6, 7, 0]
    if singleton:
        path, actions = path[:1], [0]
    return {
        "scene_id": 2, "episode_id": episode_id, "trajectory_id": "route",
        "start_position": path[0][:3], "start_rotation": [1, 0, 0, 0],
        "instruction": {"instruction_text": "Fly forward, turn left, then land."},
        "reference_path": path, "actions": actions, "goals": [{"position": path[-1][:3]}],
    }


def aerial_cache(root, split="train", episodes=None, *, zipped=False):
    episodes = episodes or [aerial_episode()]
    source = root / (f"{split}.json.gz" if zipped else f"{split}.json")
    encoded = json.dumps({"episodes": episodes}).encode("utf-8")
    source.write_bytes(gzip.compress(encoded) if zipped else encoded)
    render = {"protocol_version": "aerialvln_s_pose_rgb_v1",
              "pose_mode": "simSetVehiclePose_ignore_collision", "pixel_order": "RGB",
              "rgb_type": "Scene", "camera_name": "front_0", "width": 3, "height": 2}
    rows = []
    for episode in episodes:
        frames = []
        for index, pose in enumerate(episode.get("reference_path", [])):
            image = root / f"{episode['episode_id']}_{index}.png"
            Image.new("RGB", (3, 2), (index, 10, 20)).save(image)
            frames.append({"frame_index": index, "pose": pose,
                           "rgb": {"path": image.name, "sha256": sha256(image)}})
        rows.append({"scene_id": episode["scene_id"], "episode_id": episode["episode_id"],
                     "episode_sha256": aerial_episode_sha256(episode), "frames": frames})
    payload = {"schema_version": 1, "data_protocol": AERIAL_DATA_PROTOCOL,
               "split": split, "annotation_sha256": sha256(source),
               "render_protocol": render, "episodes": rows}
    manifest = root / "render.json"
    manifest.write_text(json.dumps(payload), encoding="utf-8")
    return source, manifest, payload


def aerial_v2_cache(root, session="session-0", episodes=None):
    source, manifest, payload = aerial_cache(root, episodes=episodes)
    canonical = lambda value: hashlib.sha256(json.dumps(
        value, sort_keys=True, separators=(",", ":"), ensure_ascii=False, allow_nan=False
    ).encode("utf-8")).hexdigest()
    files = [{"path": "scene/scene.pak", "sha256": "a" * 64, "size": 17}]
    settings = {"Vehicles": {"Drone_1": {"Cameras": {"front_0": {
        "X": 0, "Y": 0, "Z": 0, "Pitch": 0, "Roll": 0, "Yaw": 0,
        "CaptureSettings": [{"ImageType": 0, "Width": 3, "Height": 2, "FOV_Degrees": 90}]}}}}}
    payload["render_protocol"].update(protocol_version="aerialvln_s_pose_rgb_v2", provenance={
        "scene_build": {"sha256": canonical(files), "files": files},
        "settings": settings, "settings_sha256": canonical(settings), "camera_fov_degrees": 89.903625,
        "camera_extrinsics": {"position": [0., 0., 0.], "rotation_degrees": [0., 0., 0.]},
        "capture_policy": {"version": "set_pose_unpaused_single_request_v1", "wait_seconds": 0., "pause": False}})
    payload["capture_session_id"] = session
    for row in payload["episodes"]:
        for frame in row["frames"]:
            pose, index = frame["pose"], frame["frame_index"]
            # Sensor timestamp deliberately differs from wall-clock ns.
            frame.update(response_camera_position=pose[:3],
                         response_camera_orientation_xyzw=[0., 0., np.sin(pose[5] / 2), np.cos(pose[5] / 2)],
                         image_timestamp_ns=100 + index,
                         pose_requested_ns=10_000 + index * 10,
                         request_started_ns=10_002 + index * 10,
                         response_received_ns=10_005 + index * 10)
    manifest.write_text(json.dumps(payload), encoding="utf-8")
    return source, manifest, payload


def aerial_rgbd_v2_cache(root):
    source, manifest, payload = aerial_v2_cache(root)
    payload["render_protocol"]["provenance"]["capture_policy"] = {
        "version": "set_pose_unpaused_rgbd_bounded_refresh_v2", "wait_seconds": 0., "pause": False,
        "max_refresh_attempts": 3, "clock_advance": "simContinueForFrames", "timestamp_skew_policy": "measure_only"}
    for frame in payload["episodes"][0]["frames"]:
        frame.update(depth_timestamp_ns=frame["image_timestamp_ns"] + 7,
                     rgb_depth_timestamp_skew_ns=7,
                     depth_response_camera_position=list(frame["response_camera_position"]),
                     depth_response_camera_orientation_xyzw=list(frame["response_camera_orientation_xyzw"]),
                     capture_paused_before=False, capture_paused_after=False, image_refresh_attempts=0,
                     image_refresh_audit=[{
                         "attempt_index": 0, "image_timestamp_ns": frame["image_timestamp_ns"],
                         "depth_timestamp_ns": frame["image_timestamp_ns"] + 7,
                         "rgb_fresh": True, "depth_fresh": True, "rejection_reasons": [],
                         "request_started_ns": frame["request_started_ns"],
                         "response_received_ns": frame["response_received_ns"]}])
    manifest.write_text(json.dumps(payload), encoding="utf-8")
    return source, manifest, payload


class DataContractTests(unittest.TestCase):
    def test_complete_train_plan_independent_dev_subset_merge_and_fit_partition(self):
        import copy
        from scripts.verify_stage2 import _aerial_main
        from uavnav.avln.metadata import AERIALVLN_S_RELEASE
        from uavnav.avln.data import load_aerial_development_split
        with TemporaryDirectory() as tmp:
            root = Path(tmp)
            episodes = []
            for scene in (2, 3):
                for route in range(4):
                    ep = aerial_episode(f"s{scene}_r{route}")
                    ep["scene_id"] = scene
                    for pose in ep["reference_path"]:
                        pose[0] += route * 20
                    ep["start_position"] = ep["reference_path"][0][:3]
                    ep["goals"][0]["position"] = ep["reference_path"][-1][:3]
                    episodes.append(ep)
            duplicate = copy.deepcopy(episodes[0])
            duplicate.update(episode_id="same_route_other_instruction",
                             instruction={"instruction_text": "Follow this route and stop."})
            episodes.append(duplicate)
            episodes.append(aerial_episode("quarantined", singleton=True))
            annotation = root / "train.json"
            annotation.write_text(json.dumps({"episodes": episodes}), encoding="utf-8")
            annotation_sha = sha256(annotation)
            def child(scene, selected, role):
                folder = root / f"{role}_{scene}"
                folder.mkdir()
                _, path, payload = aerial_v2_cache(folder, f"{role}-scene-{scene}", selected)
                payload["annotation_sha256"] = annotation_sha
                path.write_text(json.dumps(payload), encoding="utf-8")
                return path, payload
            train_children = [child(scene, [ep for ep in episodes if ep["scene_id"] == scene and len(ep["actions"]) > 1], "train")[0]
                              for scene in (2, 3)]
            base = ["--dataset", "aerialvln_s_v1", "--annotation-root", str(root), "--split", "train"]
            with patch.dict(AERIALVLN_S_RELEASE, {"train": {"sha256": annotation_sha, "episodes": len(episodes)}}):
                full = root / "full.json"
                _aerial_main(base + ["--mode", "merge", "--output", str(full), "--merge-caches",
                                    *map(str, train_children)])
                frozen = root / "development.json"
                _aerial_main(base + ["--mode", "plan-development", "--cache-manifest", str(full),
                                    "--development-fraction", ".75", "--output", str(frozen)])
                manifest, frozen_sha = load_aerial_development_split(frozen, load_aerial_episodes(root, "train"))
                dev_keys = {(row["scene_id"], row["episode_id"]) for row in manifest["dev_episode_keys"]}
                dev_children = []
                import importlib.util
                spec = importlib.util.spec_from_file_location("avln_scene_capture_fixture", Path(__file__).with_name("test_stage2.py"))
                fixtures = importlib.util.module_from_spec(spec)
                spec.loader.exec_module(fixtures)
                build = root / "scene_build"
                build.mkdir()
                (build / "scene.pak").write_bytes(b"synthetic scene build for SDK contract only")
                for scene in (2, 3):
                    selected = [ep for ep in episodes if (scene, str(ep["episode_id"])) in dev_keys and ep["scene_id"] == scene]
                    self.assertTrue(selected)
                    path = root / f"dev_{scene}" / "cache.json"
                    env, _, _ = fixtures.AerialRouteContractTests().provenance_environment()
                    env.scene_id = scene
                    with patch("uavnav.avln.airsim_env.AerialRouteEnv", return_value=env):
                        _aerial_main(base + ["--mode", "collect", "--scene-id", str(scene), "--sampling", "all", "--min-free-gib", "0",
                            "--resume-collection", "--development-split-manifest", str(frozen),
                            "--scene-build-dir", str(build), "--capture-session-id", f"independent-dev-{scene}",
                            "--output", str(path)])
                    payload = json.loads(path.read_text(encoding="utf-8"))
                    self.assertEqual({str(row["episode_id"]) for row in payload["episodes"]},
                                     {str(ep["episode_id"]) for ep in selected})
                    self.assertEqual(payload["development_split_manifest_sha256"], frozen_sha)
                    with patch("uavnav.avln.airsim_env.AerialRouteEnv") as factory:
                        _aerial_main(base + ["--mode", "collect", "--scene-id", str(scene), "--sampling", "all",
                            "--resume-collection", "--development-split-manifest", str(frozen),
                            "--scene-build-dir", str(build), "--capture-session-id", f"independent-dev-{scene}",
                            "--output", str(path)])
                        factory.assert_not_called()
                    dev_children.append(path)
                index = root / "dev.json"
                merge = ["--mode", "merge", "--development-split-manifest", str(frozen), "--merge-caches", *map(str, dev_children)]
                _aerial_main(base + merge + ["--output", str(index)])
                samples = load_aerial_samples(root, "train", index, include_route_metadata=True)
                self.assertEqual({(s["scene_id"], str(s["episode_id"])) for s in samples}, dev_keys)
                self.assertTrue(all(s["source_split"] == "train" for s in samples))
                from uavnav.avln.fit import load_aerial_training_partitions
                training, validation, checked, source_split = load_aerial_training_partitions(
                    root, full, index, [full], 8, "development_train_grouped", .75, 0, frozen)
                self.assertEqual(source_split, "train")
                self.assertEqual(checked, manifest)
                self.assertFalse({s["capture_session_id"] for s in training[0]} & {s["capture_session_id"] for s in validation})
                self.assertEqual(len(validation), len(samples))
                with self.assertRaises(SystemExit):
                    _aerial_main(base + ["--mode", "plan-development", "--cache-manifest", str(full),
                                        "--output", str(frozen)])
                with self.assertRaises(ValueError):
                    _aerial_main(base + ["--mode", "plan-development", "--cache-manifest", str(full),
                                        "--development-split-seed", "1", "--output", str(root / "bad_seed.json")])
                with self.assertRaises(ValueError):
                    _aerial_main(base + ["--mode", "merge", "--development-split-manifest", str(frozen),
                                        "--merge-caches", str(dev_children[0]), "--output", str(root / "missing.json")])
                with self.assertRaises(ValueError):
                    _aerial_main(base + merge + [str(dev_children[0]), "--output", str(root / "duplicate.json")])
                original = json.loads(index.read_text(encoding="utf-8"))
                for mutation in (lambda p: p["episodes"].pop(),
                                 lambda p: p["episodes"].append(p["episodes"][0]),
                                 lambda p: p.update(scope="official_split_complete"),
                                 lambda p: p.update(cache_index_protocol="unknown"),
                                 lambda p: p["development_split_manifest"].update(sha256="0" * 64)):
                    bad = copy.deepcopy(original)
                    mutation(bad)
                    index.write_text(json.dumps(bad), encoding="utf-8")
                    with self.assertRaises(ValueError):
                        load_aerial_samples(root, "train", index)
                index.write_text(json.dumps(original), encoding="utf-8")
                frozen.write_text(json.dumps({**manifest, "dev_fraction": .5}), encoding="utf-8")
                with self.assertRaises(ValueError):
                    load_aerial_samples(root, "train", index)
                with self.assertRaises(ValueError):
                    _aerial_main(base + merge + ["--output", str(root / "changed.json")])

    def test_rgbd_rerequest_contract_preserves_pair_audit_and_version_boundary(self):
        from uavnav.avln.data import load_aerial_samples, _validate_aerial_capture_frame
        with TemporaryDirectory() as folder:
            root = Path(folder)
            source, manifest, payload = aerial_rgbd_v2_cache(root)
            render = payload["render_protocol"]
            frames = payload["episodes"][0]["frames"]
            previous_v2 = _validate_aerial_capture_frame(frames[0], frames[0]["pose"], render, None)
            policy = render["provenance"]["capture_policy"]
            policy.update(version="set_pose_unpaused_rgbd_bounded_rerequest_v3", clock_advance="none")
            manifest.write_text(json.dumps(payload), encoding="utf-8")
            samples = load_aerial_samples(root, "train", manifest)
            self.assertEqual(len(samples), len(frames))
            with self.assertRaisesRegex(ValueError, "状态合同"):
                _validate_aerial_capture_frame(frames[1], frames[1]["pose"], render, previous_v2)
            for field, value in (("clock_advance", "simContinueForFrames"), ("max_refresh_attempts", 4)):
                before = policy[field]
                policy[field] = value
                manifest.write_text(json.dumps(payload), encoding="utf-8")
                with self.subTest(field=field), self.assertRaises(ValueError):
                    load_aerial_samples(root, "train", manifest)
                policy[field] = before

    def test_rgbd_capture_requires_complete_pair_pose_times_pause_and_audit(self):
        import copy
        with TemporaryDirectory() as tmp:
            root = Path(tmp)
            _, manifest, original = aerial_rgbd_v2_cache(root)
            self.assertEqual(len(load_aerial_samples(root, "train", manifest)), 8)
            for change in ("missing_depth_stamp", "bool_depth_stamp", "stale_depth", "bad_skew", "bad_depth_pose",
                           "bad_depth_quaternion", "paused", "bool_attempts", "missing_audit", "wrong_final_stamp",
                           "wrong_final_time", "wrong_final_fresh"):
                with self.subTest(change=change):
                    payload = copy.deepcopy(original)
                    frame = payload["episodes"][0]["frames"][1]
                    if change == "missing_depth_stamp":
                        frame.pop("depth_timestamp_ns")
                    elif change == "bool_depth_stamp":
                        frame["depth_timestamp_ns"] = True
                    elif change == "stale_depth":
                        frame["depth_timestamp_ns"] -= 1
                        frame["rgb_depth_timestamp_skew_ns"] -= 1
                        frame["image_refresh_audit"][0]["depth_timestamp_ns"] -= 1
                    elif change == "bad_skew":
                        frame["rgb_depth_timestamp_skew_ns"] = 8
                    elif change == "bad_depth_pose":
                        frame["depth_response_camera_position"][0] += 1
                    elif change == "bad_depth_quaternion":
                        frame["depth_response_camera_orientation_xyzw"] = [0, 0, 0, 2]
                    elif change == "paused":
                        frame["capture_paused_after"] = True
                    elif change == "bool_attempts":
                        frame["image_refresh_attempts"] = False
                    elif change == "missing_audit":
                        frame.pop("image_refresh_audit")
                    elif change == "wrong_final_stamp":
                        frame["image_refresh_audit"][0]["image_timestamp_ns"] += 1
                    elif change == "wrong_final_time":
                        frame["image_refresh_audit"][0]["response_received_ns"] += 1
                    else:
                        frame["image_refresh_audit"][0]["depth_fresh"] = False
                    manifest.write_text(json.dumps(payload), encoding="utf-8")
                    with self.assertRaises(ValueError):
                        load_aerial_samples(root, "train", manifest)

    def test_rgbd_refresh_audit_keeps_missing_rejected_sensors_and_accepts_only_valid_final_pair(self):
        import copy
        with TemporaryDirectory() as tmp:
            root = Path(tmp)
            _, manifest, payload = aerial_rgbd_v2_cache(root)
            frame = payload["episodes"][0]["frames"][0]
            frame["image_refresh_attempts"] = 1
            frame["image_refresh_audit"][0]["attempt_index"] = 1
            frame["image_refresh_audit"].insert(0, {
                "attempt_index": 0, "image_timestamp_ns": 0, "depth_timestamp_ns": None,
                "rgb_fresh": False, "depth_fresh": False,
                "rejection_reasons": ["rgb_timestamp_not_advanced", "depth_timestamp_not_advanced"],
                "request_started_ns": frame["pose_requested_ns"],
                "response_received_ns": frame["request_started_ns"] - 1})
            manifest.write_text(json.dumps(payload), encoding="utf-8")
            self.assertEqual(len(load_aerial_samples(root, "train", manifest)), 8)
            for change in ("missing_marked_fresh", "bool_stamp", "false_reason", "backward_wall_time", "false_final", "absent_stamp"):
                with self.subTest(change=change):
                    bad = copy.deepcopy(payload)
                    first, last = bad["episodes"][0]["frames"][0]["image_refresh_audit"]
                    if change == "missing_marked_fresh":
                        first["depth_fresh"] = True
                    elif change == "bool_stamp":
                        first["depth_timestamp_ns"] = False
                    elif change == "false_reason":
                        first["rejection_reasons"] = ["rgb_timestamp_not_advanced"]
                    elif change == "backward_wall_time":
                        last["request_started_ns"] = first["request_started_ns"] - 1
                    elif change == "absent_stamp":
                        first.pop("depth_timestamp_ns")
                    else:
                        last["depth_timestamp_ns"] = None
                    manifest.write_text(json.dumps(bad), encoding="utf-8")
                    with self.assertRaises(ValueError):
                        load_aerial_samples(root, "train", manifest)

    def test_rgbd_skew_is_measured_without_claiming_threshold_synchronization(self):
        with TemporaryDirectory() as tmp:
            root = Path(tmp)
            _, manifest, payload = aerial_rgbd_v2_cache(root)
            for frame in payload["episodes"][0]["frames"]:
                frame["depth_timestamp_ns"] += 1_000_000_000
                frame["rgb_depth_timestamp_skew_ns"] += 1_000_000_000
                frame["image_refresh_audit"][0]["depth_timestamp_ns"] += 1_000_000_000
            manifest.write_text(json.dumps(payload), encoding="utf-8")
            self.assertEqual(len(load_aerial_samples(root, "train", manifest)), 8)
            payload["render_protocol"]["provenance"]["capture_policy"]["timestamp_skew_policy"] = "synchronized"
            manifest.write_text(json.dumps(payload), encoding="utf-8")
            with self.assertRaises(ValueError):
                load_aerial_samples(root, "train", manifest)

    def test_old_capture_policies_keep_legacy_tuple_and_do_not_require_rgbd_fields(self):
        from uavnav.avln.data import _validate_aerial_capture_frame
        with TemporaryDirectory() as tmp:
            root = Path(tmp)
            _, manifest, payload = aerial_v2_cache(root)
            for version in ("set_pose_unpaused_single_request_v1", "set_pose_unpaused_bounded_refresh_v1"):
                with self.subTest(version=version):
                    policy = payload["render_protocol"]["provenance"]["capture_policy"]
                    policy.update(version=version, max_refresh_attempts=3, clock_advance="simContinueForFrames")
                    manifest.write_text(json.dumps(payload), encoding="utf-8")
                    self.assertEqual(len(load_aerial_samples(root, "train", manifest)), 8)
                    previous = None
                    for frame in payload["episodes"][0]["frames"]:
                        previous = _validate_aerial_capture_frame(frame, frame["pose"], payload["render_protocol"], previous)
                        self.assertIsInstance(previous, list)
                        self.assertEqual(len(previous), 4)

    def test_multiscene_cache_index_keeps_scene_sources_and_rejects_incomplete_or_tampered_shards(self):
        import copy
        from uavnav.avln.metadata import AERIALVLN_S_RELEASE, authenticate_aerial_release
        from uavnav.avln.data import aerial_cache_index_children
        with TemporaryDirectory() as tmp:
            root = Path(tmp)
            first, second = aerial_episode("first"), aerial_episode("second")
            quarantine = aerial_episode("suspect", singleton=True)
            second["scene_id"] = 3
            source = root / "train.json"
            source.write_text(json.dumps({"episodes": [first, second, quarantine]}), encoding="utf-8")
            annotation_sha = sha256(source)
            shards, protocols, identities = [], {}, []
            for episode in (first, second):
                folder = root / str(episode["scene_id"])
                folder.mkdir()
                _, manifest, child = aerial_v2_cache(folder, f"scene{episode['scene_id']}", [episode])
                child["annotation_sha256"] = annotation_sha
                manifest.write_text(json.dumps(child), encoding="utf-8")
                shards.append({"path": manifest.relative_to(root).as_posix(), "sha256": sha256(manifest),
                               "scene_id": episode["scene_id"]})
                protocols[str(episode["scene_id"])] = child["render_protocol"]
                identities.append({"scene_id": episode["scene_id"], "episode_id": episode["episode_id"]})
            # Replace only the in-memory release registry in this synthetic regression.
            with patch.dict(AERIALVLN_S_RELEASE, {"train": {"sha256": annotation_sha, "episodes": 3}}):
                official = load_aerial_episodes(root, "train")
                certificate = authenticate_aerial_release("train", official)
                excluded = [{"scene_id": ep["scene_id"], "episode_id": ep["episode_id"],
                             "episode_sha256": ep["_episode_sha256"], "reason": ep["_quarantine_reason"]}
                            for ep in official if ep["_quarantine_reason"]]
                excluded_sha = hashlib.sha256(json.dumps(excluded, sort_keys=True, separators=(",", ":"),
                                                        ensure_ascii=False, allow_nan=False).encode()).hexdigest()
                payload = {"schema_version": 1, "data_protocol": AERIAL_DATA_PROTOCOL, "split": "train",
                           "cache_kind": "scene_shards_v1", "shards": shards, "episodes": identities,
                           "annotation_sha256": annotation_sha, "scope": "official_split_complete", "status": "complete",
                           "official_source_authentication": certificate,
                           "excluded_quarantine": excluded, "excluded_quarantine_sha256": excluded_sha,
                           "render_protocol": {"protocol_version": "aerialvln_s_multiscene_rgb_v1",
                                               "camera_name": "front_0", "scenes": protocols}}
                index = root / "index.json"
                index.write_text(json.dumps(payload), encoding="utf-8")
                samples = load_aerial_samples(root, "train", index)
                self.assertEqual(len(samples), 16)
                self.assertEqual({sample["scene_id"] for sample in samples}, {2, 3})
                self.assertTrue(all(sample["cache_manifest_sha256"] == sha256(index) for sample in samples))
                self.assertEqual(len(aerial_cache_index_children(index)), 2)
                self.assertEqual(aerial_cache_index_children(root / "2" / "render.json"), [])
                for mutate in (lambda p: p.update(status="incomplete"),
                               lambda p: p["episodes"].pop(),
                               lambda p: p["shards"][0].update(sha256="f" * 64),
                               lambda p: p["shards"][0].update(path="../outside.json"),
                               lambda p: p["render_protocol"]["scenes"].pop("3"),
                               lambda p: p["excluded_quarantine"].clear(),
                               lambda p: p["excluded_quarantine"][0].update(reason="arbitrary_bad_episode")):
                    altered = copy.deepcopy(payload)
                    mutate(altered)
                    index.write_text(json.dumps(altered), encoding="utf-8")
                    with self.assertRaises(ValueError):
                        load_aerial_samples(root, "train", index)

    def _dagger_cache(self, root):
        source, _, render_payload = aerial_v2_cache(root)
        kinds = ("on_route_pose_orientation", "off_route_pose", "route_order", "stop_pose", "graph_connectivity")
        review = {"schema_version": 1, "protocol": "airvln_upstream_pose_guard_v1", "scene_id": 2,
                  "source_sha256": {name: "a" * 64 for name in
                                    ("utils/env_utils.py", "utils/shorest_path_sensor.py", "airsim_plugin/airsim_settings.py")},
                  "assets_sha256": {"graph": "b" * 64, "tokens": "c" * 64},
                  "checks": {kind: True for kind in kinds}, "cases": [
                      {"name": kind, "kind": kind, "current_position": [0, 0, -10],
                       "current_orientation_xyzw": [0, 0, 0, 1], "reference_stage": 0,
                       "expected_action": 1, "observed_action": 1} for kind in kinds]}
        # Entirely synthetic contract/poses: exercises validation, never claims real teacher correctness.
        row = render_payload["episodes"][0]
        frames = []
        positions = ([0, 0, -10], [5, 0, -10], [5, 0, -10])
        quaternions = ([0, 0, 0, 1], [0, 0, 0, 1], [0, 0, np.sin(-np.pi / 24), np.cos(-np.pi / 24)])
        for index in range(3):
            frames.append({"frame_index": index, "rgb": row["frames"][index]["rgb"],
                           "observed_position": positions[index], "observed_orientation_xyzw": quaternions[index],
                           "history_actions": [1, 2][:index], "teacher_action": [7, 1, 4][index],
                           "executed_action": [1, 2, None][index], "predicted_action": [1, 2, 0][index],
                           "selected_teacher": False, "teacher_protocol": "airvln_upstream_pose_guard_v1",
                           "reference_stage": index})
            yaw = -np.pi / 12 if index == 2 else 0
            frames[-1].update(pose=[*positions[index], 0, 0, yaw],
                              response_camera_position=list(positions[index]),
                              response_camera_orientation_xyzw=list(quaternions[index]),
                              image_timestamp_ns=100 + index,
                              pose_requested_ns=10_000 + index * 10,
                              request_started_ns=10_002 + index * 10,
                              response_received_ns=10_005 + index * 10)
            if index < 2:
                frames[-1].update(following_position=list(positions[index + 1]),
                                  following_orientation_xyzw=list(quaternions[index + 1]))
        canonical = lambda value: hashlib.sha256(json.dumps(value, sort_keys=True, separators=(",", ":"),
                                               ensure_ascii=False, allow_nan=False).encode()).hexdigest()
        payload = {"schema_version": 1, "data_protocol": AERIAL_DATA_PROTOCOL,
                   "sample_policy": "aerial_dagger_current_state_v1", "split": "train",
                   "annotation_sha256": sha256(source), "collection_id": "fixture", "checkpoint_sha256": "d" * 64,
                   "seed": 0, "beta": 0., "max_steps": 3, "history_frames": 2,
                   "teacher_protocol": "airvln_upstream_pose_guard_v1",
                   "collection_status": "complete", "selected_episode_ids": ["2/episode"], "missing_episode_ids": [],
                   "teacher_contract": review, "teacher_contract_sha256": canonical(review),
                   "render_protocol": render_payload["render_protocol"], "episodes": [
                       {"scene_id": 2, "episode_id": "fixture_episode", "source_episode_id": "episode",
                        "episode_sha256": row["episode_sha256"], "instruction": aerial_episode()["instruction"]["instruction_text"],
                        "termination_reason": "model_stop", "frames": frames}]}
        path = root / "dagger.json"
        path.write_text(json.dumps(payload), encoding="utf-8")
        return path, payload

    def test_dagger_validates_actual_executed_history_and_separate_teacher_labels(self):
        with TemporaryDirectory() as tmp:
            path, _ = self._dagger_cache(Path(tmp))
            samples = load_aerial_dagger_samples(tmp, path, 2)
            self.assertEqual([s["action"] for s in samples], [7, 1, 4])
            self.assertEqual(samples[-1]["history"].argmax(-1).tolist(), [1, 2])
            self.assertEqual(len(group_aerial_dagger_episodes(samples, 2)), 1)
            self.assertTrue(all("reference_pose" not in sample and "observed_position" not in sample for sample in samples))
            batch = collate(samples, Vocab([samples[0]["instruction"]]), 16, 2)
            self.assertEqual(batch["action_target"].tolist(), [7, 1, 4])

    def test_dagger_rejects_fake_teacher_history_pose_source_and_missing_review(self):
        import copy
        with TemporaryDirectory() as tmp:
            path, payload = self._dagger_cache(Path(tmp))
            changes = (
                lambda p: p["episodes"][0]["frames"][1].update(history_actions=[7]),
                lambda p: p["episodes"][0]["frames"][1].update(observed_position=[99, 0, -10]),
                lambda p: p["episodes"][0].update(source_episode_id="unknown_validation_episode"),
                lambda p: p["teacher_contract"]["checks"].update(off_route_pose=False),
                lambda p: p["episodes"][0]["frames"][2].update(executed_action=3),
                lambda p: p.update(teacher_contract_sha256="f" * 64),
                lambda p: p.update(seed=1),
                lambda p: p.update(beta=1.),
                lambda p: p["episodes"][0]["frames"][0].update(selected_teacher=True),
                lambda p: p["episodes"][0]["frames"][0].update(following_position=[999, 0, -10]),
                lambda p: p["episodes"][0]["frames"][1].update(image_timestamp_ns=100),
                lambda p: p["episodes"][0].update(termination_reason="depth_collision_proxy"),
                lambda p: p.update(collection_status="incomplete"),
                lambda p: p.update(missing_episode_ids=["2/episode"]),
                lambda p: p.update(selected_episode_ids=["2/episode", "2/episode"]),
            )
            for index, mutate in enumerate(changes):
                altered = copy.deepcopy(payload)
                mutate(altered)
                path.write_text(json.dumps(altered), encoding="utf-8")
                with self.subTest(tamper=index), self.assertRaises(ValueError):
                    load_aerial_dagger_samples(tmp, path, 2)

    def test_dagger_partial_requires_opt_in_and_exact_frozen_missing_ids(self):
        with TemporaryDirectory() as tmp:
            path, payload = self._dagger_cache(Path(tmp))
            # One selected source episode remains uncollected; only completed frames are verified.
            source = Path(tmp) / "train.json"
            annotation = json.loads(source.read_text(encoding="utf-8"))
            annotation["episodes"].append(aerial_episode("pending"))
            source.write_text(json.dumps(annotation), encoding="utf-8")
            payload.update(annotation_sha256=sha256(source), collection_status="incomplete",
                           selected_episode_ids=["2/episode", "2/pending"], missing_episode_ids=["2/pending"])
            path.write_text(json.dumps(payload), encoding="utf-8")
            with self.assertRaisesRegex(ValueError, "partial"):
                load_aerial_dagger_samples(tmp, path, 2)
            samples = load_aerial_dagger_samples(tmp, path, 2, allow_incomplete=True)
            self.assertEqual(len(samples), 3)
            payload["missing_episode_ids"] = []
            path.write_text(json.dumps(payload), encoding="utf-8")
            with self.assertRaisesRegex(ValueError, "缺失名单"):
                load_aerial_dagger_samples(tmp, path, 2, allow_incomplete=True)

    def test_rgbd_cache_opt_in_sha_shape_and_legacy_samples(self):
        with TemporaryDirectory() as tmp:
            root = Path(tmp)
            _, manifest, payload = aerial_cache(root)
            legacy = load_aerial_samples(root, "train", manifest)
            payload["render_protocol"]["depth_protocol"] = "scene1_7_depthvis255_else_depthperspective100_v1"
            for index, frame in enumerate(payload["episodes"][0]["frames"]):
                path = root / f"depth{index}.npy"
                np.save(path, np.full((256, 256, 1), index / 8, np.float32))
                frame["depth"] = {"path": path.name, "sha256": sha256(path)}
            manifest.write_text(json.dumps(payload), encoding="utf-8")
            rgb = load_aerial_samples(root, "train", manifest)
            self.assertTrue(all("depth" not in sample for sample in legacy + rgb))
            samples = load_aerial_samples(root, "train", manifest, require_depth=True)
            vocab = Vocab([samples[0]["instruction"]])
            batch = collate(samples, vocab, 16, 8)
            self.assertEqual(tuple(batch["depth"].shape), (8, 1, 256, 256))
            self.assertAlmostEqual(float(batch["depth"][-1, 0, 0, 0]), 7 / 8)
            with self.assertRaisesRegex(ValueError, "混入"):
                collate([samples[0], rgb[0]], vocab, 16, 8)
            np.save(samples[0]["depth"], np.zeros((256, 256), np.float32))
            with self.assertRaisesRegex(ValueError, "SHA256"):
                collate(samples[:1], vocab, 16, 8)
            payload["episodes"][0]["frames"][0].pop("depth")
            manifest.write_text(json.dumps(payload), encoding="utf-8")
            with self.assertRaisesRegex(ValueError, "真实深度"):
                load_aerial_samples(root, "train", manifest, require_depth=True)

    def test_normalized_depth_does_not_guess_units_or_resize(self):
        for invalid in (None, np.zeros((224, 224), np.float32), np.ones((256, 256), np.uint8),
                        np.full((256, 256), 2., np.float32), np.full((256, 256), np.nan, np.float32)):
            with self.subTest(shape=getattr(invalid, "shape", None)):
                with self.assertRaises(ValueError):
                    preprocess_depth(invalid)
        depth = np.full((256, 256, 1), .4, np.float32)
        tensor = preprocess_depth(depth)
        depth[:] = 0
        self.assertAlmostEqual(float(tensor[0, 0, 0]), .4, places=6)

    def test_lossless_compressed_depth_preserves_exact_tensor_and_rejects_tampering(self):
        with TemporaryDirectory() as tmp:
            root = Path(tmp)
            array = np.random.default_rng(0).random((256, 256, 1), dtype=np.float32)
            raw, compressed = root / "depth.npy", root / "depth.npy.gz"
            np.save(raw, array)
            with compressed.open("wb") as output:
                with gzip.GzipFile(filename="", fileobj=output, mode="wb", mtime=0) as stream:
                    np.save(stream, array, allow_pickle=False)
            expected = preprocess_depth(raw, sha256(raw))
            actual = preprocess_depth(compressed, sha256(compressed), "npy_gzip_float32_v1")
            self.assertTrue(torch.equal(expected, actual))
            for path, protocol in ((compressed, None), (compressed, "unknown"),
                                   (raw, "npy_gzip_float32_v1")):
                with self.subTest(path=path, protocol=protocol):
                    with self.assertRaisesRegex(ValueError, "protocol"):
                        preprocess_depth(path, sha256(path), protocol)
            original_sha = sha256(compressed)
            compressed.write_bytes(compressed.read_bytes()[:-1] + b"x")
            with self.assertRaisesRegex(ValueError, "SHA256"):
                preprocess_depth(compressed, original_sha, "npy_gzip_float32_v1")
            for array in (np.zeros((256, 256), np.float64), np.zeros((224, 224), np.float32)):
                with gzip.open(compressed, "wb") as stream:
                    np.save(stream, array)
                with self.assertRaises(ValueError):
                    preprocess_depth(compressed, sha256(compressed), "npy_gzip_float32_v1")

    def test_shared_depth_writer_is_lossless_deterministic_and_refuses_overwrite(self):
        with TemporaryDirectory() as tmp:
            root = Path(tmp)
            array = np.random.default_rng(0).random((256, 256), dtype=np.float32)
            first = save_aerial_depth(root / "one.npy.gz", array, "npy_gzip_float32_v1")
            second = save_aerial_depth(root / "two.npy.gz", array, "npy_gzip_float32_v1")
            self.assertEqual(first["sha256"], second["sha256"])
            self.assertEqual(first["storage_protocol"], "npy_gzip_float32_v1")
            actual = preprocess_depth(root / first["path"], first["sha256"], first["storage_protocol"])
            self.assertTrue(torch.equal(actual, preprocess_depth(array)))
            with self.assertRaises(FileExistsError):
                save_aerial_depth(root / first["path"], array, first["storage_protocol"])
            self.assertEqual(first["sha256"], sha256(root / first["path"]))
            legacy = array.astype(np.float64)
            legacy[0, 0] += 1e-12
            raw = save_aerial_depth(root / "legacy.npy", legacy)
            self.assertEqual(set(raw), {"path", "sha256"})
            np.testing.assert_array_equal(np.load(root / raw["path"], allow_pickle=False), legacy)
            for name, protocol, data in (("bad.npy.gz", "npy_gzip_float32_v1", legacy),
                                         ("wrong.npy", "npy_gzip_float32_v1", array),
                                         ("shape.npy", "npy_float_v1", np.zeros((224, 224), np.float32))):
                with self.subTest(name=name):
                    with self.assertRaises(ValueError):
                        save_aerial_depth(root / name, data, protocol)
                    self.assertFalse((root / name).exists())

    def test_compressed_rgbd_cache_loader_and_collate_keep_raw_depth_values(self):
        with TemporaryDirectory() as tmp:
            root = Path(tmp)
            _, manifest, payload = aerial_cache(root)
            payload["render_protocol"]["depth_protocol"] = "scene1_7_depthvis255_else_depthperspective100_v1"
            expected = []
            for index, frame in enumerate(payload["episodes"][0]["frames"]):
                path = root / f"depth{index}.npy.gz"
                array = np.full((256, 256, 1), index / 8, np.float32)
                with gzip.open(path, "wb") as stream:
                    np.save(stream, array, allow_pickle=False)
                frame["depth"] = {"path": path.name, "sha256": sha256(path),
                                  "storage_protocol": "npy_gzip_float32_v1"}
                expected.append(preprocess_depth(array))
            manifest.write_text(json.dumps(payload), encoding="utf-8")
            samples = load_aerial_samples(root, "train", manifest, require_depth=True)
            self.assertTrue(all(sample["depth_storage_protocol"] == "npy_gzip_float32_v1" for sample in samples))
            batch = collate(samples, Vocab([samples[0]["instruction"]]), 16, 8)
            self.assertTrue(torch.equal(batch["depth"], torch.stack(expected)))
            self.assertTrue(all("depth" not in sample for sample in load_aerial_samples(root, "train", manifest)))
            payload["episodes"][0]["frames"][0]["depth"].pop("storage_protocol")
            manifest.write_text(json.dumps(payload), encoding="utf-8")
            with self.assertRaisesRegex(ValueError, "storage_protocol"):
                load_aerial_samples(root, "train", manifest, require_depth=True)

    def test_dagger_compressed_depth_uses_same_actual_state_supervision(self):
        with TemporaryDirectory() as tmp:
            root = Path(tmp)
            path, payload = self._dagger_cache(root)
            payload["render_protocol"]["depth_protocol"] = "scene1_7_depthvis255_else_depthperspective100_v1"
            for index, frame in enumerate(payload["episodes"][0]["frames"]):
                depth = root / f"dagger{index}.npy.gz"
                with gzip.open(depth, "wb") as stream:
                    np.save(stream, np.full((256, 256), .3, np.float32))
                frame["depth"] = {"path": depth.name, "sha256": sha256(depth),
                                  "storage_protocol": "npy_gzip_float32_v1"}
            path.write_text(json.dumps(payload), encoding="utf-8")
            samples = load_aerial_dagger_samples(root, path, 2, require_depth=True)
            self.assertEqual([sample["action"] for sample in samples], [7, 1, 4])
            self.assertTrue(all(sample["depth_storage_protocol"] == "npy_gzip_float32_v1" for sample in samples))
            batch = collate(samples, Vocab([samples[0]["instruction"]]), 16, 2)
            self.assertTrue(torch.equal(batch["depth"], torch.full((3, 1, 256, 256), .3)))

    def test_rgbd_student_depth_gradient_and_chunk_memory(self):
        from uavnav.avln.model import build_model
        torch.manual_seed(0)
        model = build_model(4, {"architecture": "aerial_route_recurrent_rgbd_v3",
                               "hidden": 8, "history_frames": 2, "grid_size": 1}, pretrained=False)
        model.eval()
        batch = {"image": torch.zeros(2, 3, 16, 16), "tokens": torch.tensor([[1], [1]]),
                 "token_mask": torch.ones(2, 1, dtype=torch.bool), "history": torch.zeros(2, 2, 8),
                 "history_length": torch.zeros(2, dtype=torch.long),
                 "depth": torch.full((2, 1, 256, 256), .4, requires_grad=True)}
        # Replace the expensive RGB encoder only; exercise real depth CNN, fusion and GRU.
        model.vision = nn.Sequential(nn.Conv2d(3, 512, 1))
        logits, state = model.forward_sequence(batch)
        logits.sum().backward()
        self.assertGreater(float(batch["depth"].grad.abs().sum()), 0)
        with torch.no_grad():
            left = {key: value[:1] for key, value in batch.items()}
            right = {key: value[1:] for key, value in batch.items()}
            first, carry = model.forward_sequence(left)
            second, following = model.forward_sequence(right, carry)
        torch.testing.assert_close(torch.cat([first, second]), logits.detach())
        torch.testing.assert_close(following, state.detach())
        with self.assertRaisesRegex(ValueError, "RGB-D"):
            model.forward_step({key: value for key, value in left.items() if key != "depth"})

    def test_rgbd_student_preserves_paired_rgb_initialization(self):
        from uavnav.avln.model import build_model
        config = {"hidden": 4, "history_frames": 2, "grid_size": 1}
        torch.manual_seed(0)
        rgb = build_model(3, {**config, "architecture": "aerial_route_recurrent_v2"}, pretrained=False)
        torch.manual_seed(0)
        rgbd = build_model(3, {**config, "architecture": "aerial_route_recurrent_rgbd_v3"}, pretrained=False)
        original = rgb.state_dict()
        augmented = rgbd.state_dict()
        self.assertEqual(set(augmented) - set(original), {name for name in augmented if name.startswith("depth_encoder.")})
        for name, value in original.items():
            torch.testing.assert_close(augmented[name], value, rtol=0, atol=0)

    def test_official_rgbd_adapter_passes_real_nhwc_depth(self):
        from uavnav.avln.model import AirVLNRGBAdapter
        adapter = AirVLNRGBAdapter.__new__(AirVLNRGBAdapter)
        nn.Module.__init__(adapter)
        adapter.input_modality, adapter.history_frames = "rgbd", 2
        depth = torch.linspace(0, 1, 256 * 256).reshape(1, 1, 256, 256)
        batch = {"image": torch.zeros(1, 3, 224, 224), "depth": depth,
                 "tokens": torch.ones(1, 1, dtype=torch.long), "token_mask": torch.ones(1, 1, dtype=torch.bool),
                 "history": torch.zeros(1, 2, 8), "history_length": torch.zeros(1, dtype=torch.long)}
        observations, _, _ = adapter._observations(batch)
        self.assertEqual(tuple(observations["depth"].shape), (1, 256, 256, 1))
        torch.testing.assert_close(observations["depth"].permute(0, 3, 1, 2), depth)
        with self.assertRaisesRegex(ValueError, "RGB-D"):
            adapter._observations({key: value for key, value in batch.items() if key != "depth"})

    def test_rgbd_format7_independent_reload_and_contract_tampering(self):
        import copy
        from test_fusion import AerialRecurrentTests
        from uavnav.avln.model import build_model
        from uavnav.avln.inference import AerialActionPredictor, CheckpointFormatError, _validate_checkpoint
        _, saved = AerialRecurrentTests().checkpoint()
        config = saved["model_config"]
        config.update(checkpoint_format_version=7, architecture="aerial_route_recurrent_rgbd_v3",
                      input_modality="rgbd", depth_input_protocol="front_0_scene_normalized_256_v1",
                      depth_size=256, depth_fusion="conv32_64_128_add_fused_v1")
        for render in config["input_render_protocols"].values():
            render["depth_protocol"] = "scene1_7_depthvis255_else_depthperspective100_v1"
        config["input_render_protocols_sha256"] = hashlib.sha256(json.dumps(
            config["input_render_protocols"], sort_keys=True, separators=(",", ":"),
            ensure_ascii=False, allow_nan=False).encode()).hexdigest()
        model = build_model(3, config, pretrained=False).eval()
        saved["model"] = model.state_dict()
        _validate_checkpoint(saved)
        with TemporaryDirectory() as tmp:
            checkpoint = Path(tmp) / "rgbd.pt"
            torch.save(saved, checkpoint)
            predictor = AerialActionPredictor(checkpoint, device="cpu")
            image, depth = Image.new("RGB", (8, 8)), np.full((256, 256, 1), .3, np.float32)
            expected_batch = predictor._batch(image, "go forward", [])
            expected_batch["depth"] = preprocess_depth(depth).unsqueeze(0)
            with torch.no_grad():
                expected, expected_state = model.forward_step(expected_batch)
            result = predictor.predict_action(image, "go forward", [], depth=depth)
            torch.testing.assert_close(torch.tensor(result["action_probabilities"]), expected.softmax(-1)[0])
            torch.testing.assert_close(torch.from_numpy(predictor.observation_state()), expected_state)
            predictor.reset_episode()
            with self.assertRaisesRegex(ValueError, "真实front_0"):
                predictor.predict_action(image, "go forward", [])
        for key, value in (("checkpoint_format_version", 5), ("depth_size", 224),
                           ("input_modality", "rgb"), ("depth_fusion", "unknown")):
            altered = copy.deepcopy(saved)
            altered["model_config"][key] = value
            with self.subTest(field=key), self.assertRaises(CheckpointFormatError):
                _validate_checkpoint(altered)

    def _grouped_training_caches(self, root):
        one, other = aerial_episode("one"), aerial_episode("other")
        one["instruction"]["instruction_text"] = "Fly forward past trainwordalpha, then land."
        other["instruction"]["instruction_text"] = "Fly forward past devwordbeta, then land."
        for pose in other["reference_path"]:
            pose[0] += 100
        other["start_position"] = other["reference_path"][0][:3]
        other["goals"] = [{"position": other["reference_path"][-1][:3]}]
        roots = [root / str(i) for i in range(2)]
        for directory in roots:
            directory.mkdir()
        manifests = [aerial_v2_cache(directory, f"session-{i}", [one, other])[1]
                     for i, directory in enumerate(roots)]
        return roots, manifests

    def test_grouped_training_integration_discards_dev_trainpass_and_train_only_vocab(self):
        with TemporaryDirectory() as tmp:
            roots, manifests = self._grouped_training_caches(Path(tmp))
            passes, dev, split, source_split = load_aerial_training_partitions(
                roots[0], manifests[0], manifests[1], [manifests[0]], 3,
                "development_train_grouped", .5, 17)
            self.assertEqual(source_split, "train")
            self.assertEqual(len(passes[0]), 8)
            self.assertEqual(len(dev), 8)
            self.assertFalse({s["episode_id"] for s in passes[0]} & {s["episode_id"] for s in dev})
            self.assertTrue(all(s["capture_session_id"] == "session-0" for s in passes[0]))
            self.assertTrue(all(s["capture_session_id"] == "session-1" for s in dev))
            vocab = Vocab([s["instruction"] for s in passes[0]], "route_numeric_v1")
            exclusive = set(tokenize(dev[0]["instruction"], "route_numeric_v1")) - set(
                tokenize(passes[0][0]["instruction"], "route_numeric_v1"))
            self.assertTrue(exclusive)
            for token in exclusive:
                self.assertNotIn(token, vocab.words)
            self.assertGreater(split["coverage"]["dev"]["oov_token_occurrences_against_train"], 0)

    def test_grouped_training_integration_reuses_manifest_and_rejects_same_session_tamper(self):
        with TemporaryDirectory() as tmp:
            roots, manifests = self._grouped_training_caches(Path(tmp))
            with self.assertRaisesRegex(ValueError, "独立的训练/开发采集session"):
                load_aerial_training_partitions(roots[0], manifests[0], manifests[0],
                    [manifests[0]], 3, "development_train_grouped", .5, 17)
            first = load_aerial_training_partitions(roots[0], manifests[0], manifests[1],
                    [manifests[0]], 3, "development_train_grouped", .5, 17)
            frozen = Path(tmp) / "split.json"
            frozen.write_text(json.dumps({"development_route_split": first[2]}), encoding="utf-8")
            second = load_aerial_training_partitions(roots[0], manifests[0], manifests[1],
                    [manifests[0]], 3, "development_train_grouped", .5, 17, frozen)
            self.assertEqual(first[2], second[2])
            altered = dict(first[2], annotation_sha256="a" * 64)
            frozen.write_text(json.dumps(altered), encoding="utf-8")
            with self.assertRaisesRegex(ValueError, "内容SHA"):
                load_aerial_training_partitions(roots[0], manifests[0], manifests[1],
                    [manifests[0]], 3, "development_train_grouped", .5, 17, frozen)

    def test_grouped_split_content_identity_reordering_and_legacy_default(self):
        with TemporaryDirectory() as tmp:
            root = Path(tmp)
            one, two, other = aerial_episode("one"), aerial_episode("two"), aerial_episode("other")
            two["trajectory_id"] = "different_id_same_geometry"
            two["instruction"]["instruction_text"] = "Turn by the bridge, then land."
            # Reusing trajectory_id is deliberately insufficient for geometric identity.
            for pose in other["reference_path"]:
                pose[0] += 100
            other["start_position"] = other["reference_path"][0][:3]
            other["goals"] = [{"position": other["reference_path"][-1][:3]}]
            _, manifest, _ = aerial_cache(root, episodes=[one, two, other])
            historical = load_aerial_samples(root, "train", manifest)
            self.assertNotIn("reference_pose", historical[0])
            self.assertNotIn("source_split", historical[0])
            samples = load_aerial_samples(root, "train", manifest, include_route_metadata=True)
            train, dev, split = split_aerial_route_groups(samples, 0.5, 17)
            reverse_train, reverse_dev, reverse = split_aerial_route_groups(list(reversed(samples)), 0.5, 17)
            self.assertEqual(split, reverse)
            self.assertEqual([(s["episode_id"], s["frame_index"]) for s in train],
                             [(s["episode_id"], s["frame_index"]) for s in reverse_train])
            self.assertEqual([(s["episode_id"], s["frame_index"]) for s in dev],
                             [(s["episode_id"], s["frame_index"]) for s in reverse_dev])
            self.assertEqual(split["route_count"], 2)
            train_keys, dev_keys = {s["episode_id"] for s in train}, {s["episode_id"] for s in dev}
            self.assertFalse(train_keys & dev_keys)
            self.assertEqual("one" in train_keys, "two" in train_keys)
            self.assertEqual(split["coverage"]["train"]["missing_actions"], [])
            self.assertEqual(split["coverage"]["dev"]["stop_states"], len(dev_keys))
            self.assertEqual(split["coverage"]["train"]["oov_token_occurrences_against_train"], 0)

    def test_grouped_split_orientation_is_part_of_full_route(self):
        with TemporaryDirectory() as tmp:
            episodes = []
            for key, action, yaw in [("left", 2, -np.pi / 12), ("right", 3, np.pi / 12)]:
                episode = aerial_episode(key)
                episode["reference_path"] = [[0, 0, -10, 0, 0, 0], [0, 0, -10, 0, 0, yaw]]
                episode["actions"] = [action, 0]
                episode["goals"] = [{"position": [0, 0, -10]}]
                episodes.append(episode)
            _, manifest, _ = aerial_cache(Path(tmp), episodes=episodes)
            samples = load_aerial_samples(tmp, "train", manifest, include_route_metadata=True)
            train, dev, split = split_aerial_route_groups(samples)
            self.assertEqual(split["route_count"], 2)
            self.assertEqual(len(train), 2)
            self.assertEqual(len(dev), 2)

    def test_grouped_split_rejects_unknown_official_validation_incomplete_and_too_few(self):
        with TemporaryDirectory() as tmp:
            _, manifest, _ = aerial_cache(Path(tmp))
            legacy = load_aerial_samples(tmp, "train", manifest)
            with self.assertRaisesRegex(ValueError, "官方train"):
                split_aerial_route_groups(legacy)
            samples = load_aerial_samples(tmp, "train", manifest, include_route_metadata=True)
            with self.assertRaisesRegex(ValueError, "路线不足"):
                split_aerial_route_groups(samples)
            with self.assertRaisesRegex(ValueError, "缺帧或重复"):
                split_aerial_route_groups(samples[1:])
            with self.assertRaisesRegex(ValueError, "末STOP"):
                split_aerial_route_groups(samples[:-1])
            for wrong in ("val_seen", "val_unseen", "test", None):
                with self.subTest(source=wrong), self.assertRaisesRegex(ValueError, "官方train"):
                    split_aerial_route_groups([dict(s, source_split=wrong) for s in samples])

    def test_grouped_split_other_render_pass_and_complete_partition_selection(self):
        with TemporaryDirectory() as tmp:
            root = Path(tmp)
            one, other = aerial_episode("one"), aerial_episode("other")
            for pose in other["reference_path"]:
                pose[0] += 100
            other["start_position"] = other["reference_path"][0][:3]
            other["goals"] = [{"position": other["reference_path"][-1][:3]}]
            roots = [root / str(i) for i in range(2)]
            for directory in roots:
                directory.mkdir()
            manifests = [aerial_v2_cache(directory, f"session-{i}", [one, other])[1]
                         for i, directory in enumerate(roots)]
            passes = load_aerial_render_passes(roots[0], "train", manifests,
                                               include_route_metadata=True)
            _, dev, split = split_aerial_route_groups(passes[0])
            second_dev = select_aerial_route_partition(passes[1], split, "dev")
            self.assertEqual({s["episode_id"] for s in dev}, {s["episode_id"] for s in second_dev})
            self.assertTrue(all(s["capture_session_id"] == "session-1" for s in second_dev))
            self.assertEqual(len(select_aerial_route_partition(second_dev, split, "dev")), len(second_dev))
            with self.assertRaisesRegex(ValueError, "完整原episode名单或完整目标分区"):
                select_aerial_route_partition(second_dev, split, "train")
            with self.assertRaisesRegex(ValueError, "缺帧或重复"):
                select_aerial_route_partition(second_dev[1:], split, "dev")
            with self.assertRaisesRegex(ValueError, "几何/指令原内容改变"):
                select_aerial_route_partition([dict(s, episode_sha256="a" * 64) for s in second_dev], split, "dev")
            with self.assertRaisesRegex(ValueError, "内容SHA"):
                select_aerial_route_partition(passes[1], dict(split, split_seed=99), "dev")

    def test_grouped_manifest_resigned_same_geometry_cannot_cross_partitions(self):
        with TemporaryDirectory() as tmp:
            one, two, other = aerial_episode("one"), aerial_episode("two"), aerial_episode("other")
            two["instruction"]["instruction_text"] = "Follow the bridge and land."
            for pose in other["reference_path"]:
                pose[0] += 100
            other["start_position"] = other["reference_path"][0][:3]
            other["goals"] = [{"position": other["reference_path"][-1][:3]}]
            _, manifest, _ = aerial_cache(Path(tmp), episodes=[one, two, other])
            samples = load_aerial_samples(tmp, "train", manifest, include_route_metadata=True)
            _, _, split = split_aerial_route_groups(samples, .5, 17)
            row = next(row for row in split["routes"] if len(row["episodes"]) == 2)
            duplicate = dict(row, episodes=[row["episodes"][1]],
                             partition="dev" if row["partition"] == "train" else "train")
            row["episodes"] = row["episodes"][:1]
            split["routes"].append(duplicate)
            split["route_count"] = 3
            split["manifest_sha256"] = hashlib.sha256(json.dumps(
                {key: value for key, value in split.items() if key != "manifest_sha256"},
                sort_keys=True, separators=(",", ":"), ensure_ascii=False, allow_nan=False).encode()).hexdigest()
            with self.assertRaisesRegex(ValueError, "重复几何路线"):
                select_aerial_route_partition(samples, split, "dev")

    def test_grouped_manifest_resigned_keys_precision_algorithm_and_assignment_rejected(self):
        with TemporaryDirectory() as tmp:
            roots, manifests = self._grouped_training_caches(Path(tmp))
            samples = load_aerial_samples(roots[0], "train", manifests[0], include_route_metadata=True)
            _, _, split = split_aerial_route_groups(samples, .5, 17)
            changes = [("algorithm", "frame_random_split"), ("geometry_precision", {}),
                       ("route_count", 3), ("dev_route_count", 2), ("split_seed", True),
                       ("dev_fraction", 1), ("schema_version", True)]
            for field, value in changes:
                altered = json.loads(json.dumps(split))
                altered[field] = value
                altered["manifest_sha256"] = hashlib.sha256(json.dumps(
                    {key: val for key, val in altered.items() if key != "manifest_sha256"},
                    sort_keys=True, separators=(",", ":"), ensure_ascii=False).encode()).hexdigest()
                with self.subTest(field=field), self.assertRaises(ValueError):
                    select_aerial_route_partition(samples, altered, "dev")
            for tamper in ("keys", "key_sha", "partition"):
                altered = json.loads(json.dumps(split))
                if tamper == "keys":
                    altered["train_episode_keys"] = altered["dev_episode_keys"]
                    altered["train_episode_keys_sha256"] = hashlib.sha256(json.dumps(
                        altered["train_episode_keys"], sort_keys=True, separators=(",", ":"),
                        ensure_ascii=False).encode()).hexdigest()
                elif tamper == "key_sha":
                    altered["train_episode_keys_sha256"] = "a" * 64
                else:
                    for row in altered["routes"]:
                        row["partition"] = "dev" if row["partition"] == "train" else "train"
                altered["manifest_sha256"] = hashlib.sha256(json.dumps(
                    {key: val for key, val in altered.items() if key != "manifest_sha256"},
                    sort_keys=True, separators=(",", ":"), ensure_ascii=False).encode()).hexdigest()
                with self.subTest(tamper=tamper), self.assertRaises(ValueError):
                    select_aerial_route_partition(samples, altered, "dev")

    def test_v2_camera_source_supports_nonzero_body_relative_extrinsics(self):
        with TemporaryDirectory() as tmp:
            root = Path(tmp)
            _, manifest, payload = aerial_v2_cache(root)
            payload["render_protocol"]["provenance"]["camera_extrinsics"] = {
                "position": [1., 2., 3.], "rotation_degrees": [10., 20., 30.]}
            provenance = payload["render_protocol"]["provenance"]
            provenance["settings"]["Vehicles"]["Drone_1"]["Cameras"]["front_0"].update(
                X=1., Y=2., Z=3., Pitch=10., Roll=20., Yaw=30.)
            provenance["settings_sha256"] = hashlib.sha256(json.dumps(
                provenance["settings"], sort_keys=True, separators=(",", ":"),
                ensure_ascii=False, allow_nan=False).encode("utf-8")).hexdigest()
            # Independent yaw-only body rotation and explicit Euler quaternion oracle.
            for frame in payload["episodes"][0]["frames"]:
                pose = frame["pose"]
                yaw = pose[5]
                frame["response_camera_position"] = [pose[0] + np.cos(yaw) - 2 * np.sin(yaw),
                                                     pose[1] + np.sin(yaw) + 2 * np.cos(yaw), pose[2] + 3]
                pitch, roll, total_yaw = np.deg2rad(10), np.deg2rad(20), yaw + np.deg2rad(30)
                sp, cp = np.sin(pitch / 2), np.cos(pitch / 2)
                sr, cr = np.sin(roll / 2), np.cos(roll / 2)
                sy, cy = np.sin(total_yaw / 2), np.cos(total_yaw / 2)
                frame["response_camera_orientation_xyzw"] = [sr * cp * cy - cr * sp * sy,
                    cr * sp * cy + sr * cp * sy, cr * cp * sy - sr * sp * cy, cr * cp * cy + sr * sp * sy]
            manifest.write_text(json.dumps(payload), encoding="utf-8")
            self.assertEqual(len(load_aerial_samples(root, "train", manifest)), 8)
            payload["episodes"][0]["frames"][2]["response_camera_position"][0] = 6.
            manifest.write_text(json.dumps(payload), encoding="utf-8")
            with self.assertRaisesRegex(ValueError, "response camera"):
                load_aerial_samples(root, "train", manifest)

    def test_render_passes_preserve_complete_episodes_and_legacy_single_pass(self):
        with TemporaryDirectory() as tmp:
            root = Path(tmp)
            _, legacy, _ = aerial_cache(root)
            old = load_aerial_render_passes(root, "train", [legacy], 3)
            self.assertEqual(len(old), 1)
            self.assertNotIn("capture_session_id", old[0][0])
            roots = [root / "pass0", root / "pass1"]
            for directory in roots:
                directory.mkdir()
            manifests = [aerial_v2_cache(directory, f"session-{i}")[1]
                         for i, directory in enumerate(roots)]
            passes = load_aerial_render_passes(roots[0], "train", manifests, 3)
            self.assertEqual([len(samples) for samples in passes], [8, 8])
            self.assertEqual([samples[0]["capture_session_id"] for samples in passes], ["session-0", "session-1"])
            self.assertEqual([len(group_aerial_episodes(samples)) for samples in passes], [1, 1])
            self.assertEqual(passes[0][-1]["action"], 0)
            np.testing.assert_array_equal(passes[0][-1]["history"], passes[1][-1]["history"])

    def test_legacy_pass_preserves_sample_schema_order_and_frozen_digest(self):
        with TemporaryDirectory() as tmp:
            root = Path(tmp)
            _, manifest, _ = aerial_cache(root, episodes=[aerial_episode("z"), aerial_episode("a")])
            samples = load_aerial_render_passes(root, "train", [manifest], 3)[0]
            self.assertEqual([sample["episode_id"] for sample in samples], ["z"] * 8 + ["a"] * 8)
            legacy_fields = {"image", "instruction", "instruction_source", "history", "action", "traj_id",
                             "episode_id", "scene_id", "frame_index", "sample_policy", "data_protocol",
                             "history_policy", "episode_sha256", "image_sha256", "annotation_sha256",
                             "cache_manifest_sha256", "render_protocol"}
            self.assertTrue(all(set(sample) == legacy_fields for sample in samples))
            expected_rows = []
            for sample in samples:
                expected = {key: sample[key] for key in legacy_fields}
                expected["history"] = expected["history"].tolist()
                expected["image"] = str(expected["image"].resolve())
                expected["image_content_sha256"] = sha256(expected["image"])
                expected_rows.append(expected)
            digest = hashlib.sha256(json.dumps(expected_rows, ensure_ascii=False, sort_keys=True,
                separators=(",", ":"), allow_nan=False).encode("utf-8")).hexdigest()
            self.assertEqual(sample_content_sha256(samples), digest)

    def test_single_and_multi_pass_share_pass0_order_digest_and_word_ids(self):
        with TemporaryDirectory() as tmp:
            root = Path(tmp)
            folders = [root / "pass0", root / "pass1"]
            for folder in folders:
                folder.mkdir()
            episodes = [aerial_episode("z"), aerial_episode("a")]
            episodes[0]["instruction"]["instruction_text"] = "Find red tower then land."
            episodes[1]["instruction"]["instruction_text"] = "Pass blue house then fly."
            _, first, _ = aerial_v2_cache(folders[0], "session-0", episodes)
            _, second, payload = aerial_v2_cache(folders[1], "session-1", episodes)
            payload["episodes"].reverse()
            second.write_text(json.dumps(payload), encoding="utf-8")
            single = load_aerial_render_passes(folders[0], "train", [first], 3)[0]
            multi = load_aerial_render_passes(folders[0], "train", [first, second], 3)
            self.assertEqual([sample["episode_id"] for sample in multi[0]], ["z"] * 8 + ["a"] * 8)
            self.assertEqual([sample["episode_id"] for sample in multi[1]], ["z"] * 8 + ["a"] * 8)
            self.assertEqual(sample_content_sha256(single), sample_content_sha256(multi[0]))
            vocabulary = lambda samples: Vocab([sample["instruction"] for sample in samples],
                                                tokenizer_version="route_numeric_v1").words
            self.assertEqual(vocabulary(single), vocabulary(multi[0]))
            self.assertEqual(vocabulary(single), vocabulary(multi[1]))

    def test_v2_build_exclusion_rule_is_explicit_and_rejects_excluded_sources(self):
        with TemporaryDirectory() as tmp:
            _, _, payload = aerial_v2_cache(Path(tmp))
            render = payload["render_protocol"]
            build = render["provenance"]["scene_build"]
            build["exclusion_policy"] = {"version": "unreal_saved_directories_v1", "directory_names": ["Saved"]}
            validate_aerial_render_protocol(render)
            build["files"][0]["path"] = "scene/Saved/Logs/runtime.log"
            build["sha256"] = hashlib.sha256(json.dumps(build["files"], ensure_ascii=False, sort_keys=True,
                separators=(",", ":"), allow_nan=False).encode("utf-8")).hexdigest()
            with self.assertRaisesRegex(ValueError, "排除规则冲突"):
                validate_aerial_render_protocol(render)
            build["exclusion_policy"]["version"] = "unknown"
            with self.assertRaisesRegex(ValueError, "排除规则不支持"):
                validate_aerial_render_protocol(render)

    def test_multi_pass_rejects_invalid_sources_sessions_identity_and_contracts(self):
        for case in ("duplicate_manifest", "duplicate_session", "legacy", "different_episode",
                     "missing_frame", "changed_image", "different_contract", "shared_rgb"):
            with self.subTest(case=case), TemporaryDirectory() as tmp:
                root = Path(tmp)
                folders = [root / "pass0", root / "pass1"]
                for folder in folders:
                    folder.mkdir()
                episodes = [aerial_episode("one"), aerial_episode("two")]
                _, first, _ = aerial_v2_cache(folders[0], "session-0", episodes)
                _, second, payload = aerial_v2_cache(folders[1], "session-1", episodes)
                if case == "duplicate_manifest":
                    second = first
                elif case == "duplicate_session":
                    payload["capture_session_id"] = "session-0"
                elif case == "legacy":
                    payload["render_protocol"]["protocol_version"] = "aerialvln_s_pose_rgb_v1"
                elif case == "different_episode":
                    payload["episodes"].pop()
                elif case == "missing_frame":
                    payload["episodes"][0]["frames"].pop()
                elif case == "changed_image":
                    Image.new("RGB", (3, 2), "red").save(folders[1] / payload["episodes"][0]["frames"][0]["rgb"]["path"])
                elif case == "different_contract":
                    payload["render_protocol"]["provenance"]["camera_fov_degrees"] = 80.
                elif case == "shared_rgb":
                    second = folders[0] / "render-session1.json"
                if case != "duplicate_manifest":
                    second.write_text(json.dumps(payload), encoding="utf-8")
                with self.assertRaises(ValueError):
                    load_aerial_render_passes(folders[0], "train", [first, second], 3)

    def test_v2_source_protocol_rejects_tampered_provenance_and_capture_metadata(self):
        for case in ("settings_hash", "build_hash", "build_path", "fov_nan", "policy", "camera_source",
                     "missing_session", "wall_clock", "sensor_clock", "camera_position", "camera_rotation"):
            with self.subTest(case=case), TemporaryDirectory() as tmp:
                root = Path(tmp)
                _, manifest, payload = aerial_v2_cache(root)
                provenance = payload["render_protocol"]["provenance"]
                frame = payload["episodes"][0]["frames"][1]
                if case == "settings_hash":
                    provenance["settings"]["SimMode"] = "changed"
                elif case == "build_hash":
                    provenance["scene_build"]["files"][0]["sha256"] = "0" * 64
                elif case == "build_path":
                    provenance["scene_build"]["files"][0]["path"] = "../scene.pak"
                elif case == "fov_nan":
                    provenance["camera_fov_degrees"] = float("nan")
                elif case == "policy":
                    provenance["capture_policy"]["pause"] = True
                elif case == "camera_source":
                    payload["render_protocol"]["camera_name"] = "wrong_camera"
                elif case == "missing_session":
                    payload.pop("capture_session_id")
                elif case == "wall_clock":
                    frame["request_started_ns"] = frame["response_received_ns"] + 1
                elif case == "sensor_clock":
                    frame["image_timestamp_ns"] = payload["episodes"][0]["frames"][0]["image_timestamp_ns"]
                elif case == "camera_position":
                    frame["response_camera_position"][0] += 1
                else:
                    frame["response_camera_orientation_xyzw"] = [0, 0, 1, 0]
                manifest.write_text(json.dumps(payload), encoding="utf-8")
                with self.assertRaises(ValueError):
                    load_aerial_samples(root, "train", manifest, 3)

    def test_batched_action_transition_preserves_scalar_ned_pose_and_rotation_rules(self):
        actions = np.arange(8, dtype=np.int64)
        poses = np.tile([1., 2., -3., .1, -.2, np.pi / 2], (8, 1))
        expected = poses.copy()
        expected[1, :3] = [1, 7, -3]
        expected[2, 3:] = [0, 0, np.pi / 2 - np.pi / 12]
        expected[3, 3:] = [0, 0, np.pi / 2 + np.pi / 12]
        expected[4, 2] = -5
        expected[5, 2] = -1
        expected[6, :3] = [6, 2, -3]
        expected[7, :3] = [-4, 2, -3]
        original = poses.copy()
        actual = aerial_pose_transition(poses, actions)
        np.testing.assert_allclose(actual, expected, atol=1e-12, rtol=0)
        np.testing.assert_array_equal(poses, original)
        for index, action in enumerate(actions):
            scalar = aerial_pose_transition(poses[index], int(action))
            self.assertEqual(scalar.shape, (6,))
            np.testing.assert_array_equal(actual[index], scalar)
        turning = np.array([[1, 2, -3, .3, -.4, np.deg2rad(-179)],
                            [1, 2, -3, .3, -.4, np.deg2rad(179)]])
        wrapped = aerial_pose_transition(turning, [2, 3])
        np.testing.assert_allclose(wrapped[:, 5], np.deg2rad([166, -166]), atol=1e-12)
        np.testing.assert_array_equal(wrapped[:, 3:5], np.zeros((2, 2)))

    def test_batched_action_transition_rejects_shape_noninteger_and_nonfinite_inputs(self):
        poses = np.zeros((2, 6))
        for actions in ([1, True], [np.bool_(False), 1], [1., 2.], [True, False], [1], [[1], [2]],
                        [1, 8], [-1, 0], np.array([1, 2], dtype=object), 1):
            with self.subTest(actions=actions), self.assertRaises(ValueError):
                aerial_pose_transition(poses, actions)
        for pose in (np.zeros((2, 5)), np.zeros((2, 1, 6)), [[0, 0, 0, 0, 0, np.nan]]):
            with self.subTest(pose=pose), self.assertRaises(ValueError):
                aerial_pose_transition(pose, [1, 2])
        for action in (True, np.bool_(False), 1., [1]):
            with self.subTest(scalar_action=action), self.assertRaises(ValueError):
                aerial_pose_transition(np.zeros(6), action)

    def test_vectorized_whole_split_audit_reports_first_bad_transition_and_rejects_pose_bool(self):
        with TemporaryDirectory() as tmp:
            root = Path(tmp)
            healthy, wrong = aerial_episode("healthy"), aerial_episode("wrong")
            # Multiple bad later states must report the earliest original frame.
            wrong["reference_path"][3][0] += .001
            wrong["reference_path"][6][2] += .01
            source = root / "train.json"
            source.write_text(json.dumps({"episodes": [healthy, wrong]}), encoding="utf-8")
            with self.assertRaisesRegex(ValueError, "wrong.*frame 2"):
                load_aerial_episodes(root, "train")
            wrong = aerial_episode("boolpose")
            wrong["reference_path"][2][3] = False
            source.write_text(json.dumps({"episodes": [healthy, wrong]}), encoding="utf-8")
            with self.assertRaisesRegex(ValueError, "有限数值列表"):
                load_aerial_episodes(root, "train")

    def test_route_numeric_tokens_preserve_counts_and_legacy_vocab_semantics(self):
        text = "Fly 2 blocks then turn 15 degrees, descend 2.5 meters."
        old = Vocab([text])
        route = Vocab([text], tokenizer_version="route_numeric_v1")
        self.assertEqual(old.tokenizer_version, "fov_numeric_v1")
        self.assertEqual(tokenize(text).count("<num>"), 3)
        self.assertNotIn("<num>", route.words)
        self.assertTrue(all(number in route.words for number in ("2", "15", "2.5")))
        self.assertNotEqual(route.encode("2"), route.encode("15"))
        self.assertEqual(old.encode("2"), old.encode("15"))
        with self.assertRaises(ValueError):
            Vocab([text], tokenizer_version="unknown")

    def test_sequences_preserve_multi_instruction_episode_and_reject_gaps_future_history(self):
        with TemporaryDirectory() as tmp:
            root = Path(tmp)
            one, two = aerial_episode("one"), aerial_episode("two")
            two["instruction"]["instruction_text"] = "First turn to the tree, then land."
            _, manifest, _ = aerial_cache(root, episodes=[one, two])
            samples = load_aerial_samples(root, "train", manifest, history_frames=3)
            groups = group_aerial_episodes(list(reversed(samples)), 3)
            self.assertEqual(len(groups), 2)
            self.assertEqual([g[0]["episode_id"] for g in groups], ["one", "two"])
            self.assertEqual(groups[0][0]["traj_id"], groups[1][0]["traj_id"])
            self.assertNotEqual(groups[0][0]["instruction"], groups[1][0]["instruction"])
            self.assertTrue(all([s["frame_index"] for s in group] == list(range(8)) for group in groups))
            with self.assertRaisesRegex(ValueError, "缺帧或重复"):
                group_aerial_episodes(samples[1:], 3)
            with self.assertRaisesRegex(ValueError, "缺帧或重复"):
                group_aerial_episodes(samples + [samples[0]], 3)
            tampered = [dict(s) for s in samples]
            tampered[1]["history"] = np.eye(8, dtype=np.float32)[[tampered[1]["action"]]]
            with self.assertRaisesRegex(ValueError, "不得含当前或未来"):
                group_aerial_episodes(tampered, 3)

    def test_transition_stop_weights_use_previous_label_and_max_without_double_count(self):
        protocol = {"version": "transition_weighted_ce_v1", "inflection_weight": 1.9,
                    "stop_weight": 2.5, "normalization": "sum_weights"}
        np.testing.assert_allclose(aerial_transition_weights([1, 1, 2, 2, 0], protocol), [1, 1, 1.9, 1, 2.5])
        protocol["stop_weight"] = 1.
        np.testing.assert_allclose(aerial_transition_weights([1, 0], protocol), [1, 1.9])
        protocol["inflection_weight"] = 1.
        np.testing.assert_array_equal(aerial_transition_weights([1, 2, 0], protocol), [1, 1, 1])

    def test_sequence_chunks_carry_detached_state_reset_episode_and_report_unweighted_ce(self):
        class CountSequence(nn.Module):
            def __init__(self):
                super().__init__()
                self.bias = nn.Parameter(torch.zeros(8))
                self.received = []

            def forward_sequence(self, batch, state=None):
                self.received.append(None if state is None else (float(state.detach().item()), state.requires_grad))
                prior = 0 if state is None else state.reshape(())
                count = len(batch["image"])
                increments = torch.arange(1, count + 1, dtype=torch.float32) + prior
                logits = self.bias.unsqueeze(0).expand(count, 8).clone()
                logits[:, 1] += increments / 8
                following = (prior + count + self.bias.sum() * 0).reshape(1, 1, 1)
                return logits, following

        with TemporaryDirectory() as tmp:
            root = Path(tmp)
            _, manifest, _ = aerial_cache(root, episodes=[aerial_episode("one"), aerial_episode("two")])
            samples = load_aerial_samples(root, "train", manifest, 3)
            episodes = group_aerial_episodes(samples, 3)
            vocab = Vocab([s["instruction"] for s in samples], tokenizer_version="route_numeric_v1")
            model = CountSequence()
            protocol = {"version": "transition_weighted_ce_v1", "inflection_weight": 1.9,
                        "stop_weight": 1.9, "normalization": "sum_weights"}
            args = dict(model=model, episodes=episodes, vocab=vocab, imgsz=8, history_frames=3,
                        device=torch.device("cpu"), loss_protocol=protocol)
            whole = _aerial_sequence_epoch(chunk_size=8, **args)
            model.received.clear()
            pieces = _aerial_sequence_epoch(chunk_size=2, **args)
            self.assertEqual(model.received, [None, (2., False), (4., False), (6., False)] * 2)
            self.assertAlmostEqual(pieces["loss"], whole["loss"], places=6)
            self.assertAlmostEqual(pieces["objective_loss"], whole["objective_loss"], places=6)
            self.assertNotAlmostEqual(pieces["loss"], pieces["objective_loss"], places=5)
            self.assertEqual(pieces["samples"], 16)
            self.assertEqual(pieces["episodes"], 2)
            self.assertEqual(pieces["confusion_matrix"], whole["confusion_matrix"])
            model.received.clear()
            trained = _aerial_sequence_epoch(chunk_size=2, optimizer=torch.optim.SGD(model.parameters(), lr=0), **args)
            self.assertEqual(trained["optimizer_updates"], 8)
            self.assertEqual(model.received, [None, (2., False), (4., False), (6., False)] * 2)

    def test_empirical_class_prior_records_unseen_class_as_unknown_finite_number(self):
        train = [{"action": a} for a in [1, 1, 0]]
        val = [{"action": a} for a in [1, 5, 0]]
        prior = aerial_action_priors(train, val)
        self.assertEqual(prior["training_majority_action"], 1)
        self.assertEqual(prior["train_empirical_prior_status"], "infinite_unseen_class")
        self.assertIsNone(prior["train_empirical_prior_validation_ce"])
        self.assertEqual(prior["validation_classes_absent_in_train"], [5])
        self.assertTrue(np.isfinite(prior["laplace_plus1_train_prior_validation_ce"]))
        json.dumps(prior, allow_nan=False)

    def test_list_cannot_escape_split_or_alias_duplicate_resolved_path(self):
        with TemporaryDirectory() as tmp:
            base = Path(tmp)
            trajectory(base / "train", [0, 5])
            trajectory(base / "test", [0, 5])
            listing = base / "train" / "train.json"
            for rows, error in ((["../test/Map/episode"], "越出当前 split"),
                                ([str((base / "test" / "Map" / "episode").resolve())], "必须相对"),
                                (["Map/episode", "Map/../Map/episode"], "重复轨迹")):
                with self.subTest(rows=rows):
                    listing.write_text(json.dumps(rows), encoding="utf-8")
                    with self.assertRaisesRegex(ValueError, error):
                        load_list(base / "train", listing)

    def test_mark_list_is_a_reported_schema_error_without_aborting_audit(self):
        from scripts.audit_dataset import inspect_trajectory

        with TemporaryDirectory() as tmp:
            path = trajectory(Path(tmp), [0, 5])
            (path / "mark.json").write_text("[]", encoding="utf-8")
            report = inspect_trajectory(("train", "Map/episode", path, "none"))
            errors = [row for row in report["issues"] if row["kind"] == "invalid_metadata"]
            self.assertEqual(len(errors), 1)
            self.assertEqual(errors[0]["file"], "mark.json")
            self.assertIn("JSON object", errors[0]["error"])

    def test_aerial_action_before_state_including_turn_and_terminal_stop(self):
        for zipped in (False, True):
            with self.subTest(zipped=zipped), TemporaryDirectory() as tmp:
                root = Path(tmp)
                source, manifest, _ = aerial_cache(root, zipped=zipped)
                episodes = load_aerial_episodes(root, "train")
                self.assertEqual(episodes[0]["_annotation_sha256"], sha256(source))
                samples = load_aerial_samples(root, "train", manifest, history_frames=3)
                self.assertEqual([row["action"] for row in samples], [1, 2, 3, 4, 5, 6, 7, 0])
                self.assertEqual(samples[0]["history"].shape, (0, 8))
                np.testing.assert_array_equal(samples[3]["history"], np.eye(8)[[1, 2, 3]])
                np.testing.assert_array_equal(samples[-1]["history"], np.eye(8)[[5, 6, 7]])
                self.assertTrue(all("reference_path" not in row and "goals" not in row for row in samples))
                self.assertTrue(all(row["history_policy"] == AERIAL_HISTORY_POLICY for row in samples))
                batch = collate(samples, Vocab(row["instruction"] for row in samples), 8, 3)
                self.assertNotIn("offset", batch)
                self.assertEqual(tuple(batch["history"].shape), (8, 3, 8))
                self.assertEqual(str(batch["action_target"].dtype), "torch.int64")
                self.assertEqual(batch["action_target"].tolist(), [1, 2, 3, 4, 5, 6, 7, 0])
                self.assertEqual(batch["history_length"].tolist(), [0, 1, 2, 3, 3, 3, 3, 3])
                zero_history = collate(samples, Vocab([samples[0]["instruction"]]), 8, 0)
                self.assertEqual(tuple(zero_history["history"].shape), (8, 0, 8))
                self.assertEqual(zero_history["history_length"].tolist(), [0] * 8)

    def test_aerial_collate_rejects_changed_rgb_after_loading_and_missing_digest(self):
        with TemporaryDirectory() as tmp:
            root = Path(tmp)
            _, manifest, _ = aerial_cache(root)
            samples = load_aerial_samples(root, "train", manifest)
            vocab = Vocab([samples[0]["instruction"]])
            path = Path(samples[0]["image"])
            Image.new("RGB", (3, 2), "red").save(path)
            with self.assertRaisesRegex(ValueError, "image_sha256"):
                collate(samples, vocab, 8, 3)
            samples[0].pop("image_sha256")
            with self.assertRaisesRegex(ValueError, "image_sha256"):
                collate(samples, vocab, 8, 3)

    def test_aerial_collate_verified_bytes_preserve_preprocessing_and_avoid_reopen(self):
        with TemporaryDirectory() as tmp:
            root = Path(tmp)
            _, manifest, _ = aerial_cache(root)
            sample = load_aerial_samples(root, "train", manifest)[0]
            vocab = Vocab([sample["instruction"]])
            path = Path(sample["image"])
            with Image.open(path) as raw:
                expected = preprocess_rgb(raw, 8)
            self.assertTrue(torch.equal(collate([sample], vocab, 8, 3)["image"][0], expected))
            read_bytes = Path.read_bytes

            def replace_after_read(current_path):
                data = read_bytes(current_path)
                Image.new("RGB", (3, 2), "red").save(current_path)
                return data

            with patch.object(Path, "read_bytes", replace_after_read):
                actual = collate([sample], vocab, 8, 3)["image"][0]
            self.assertTrue(torch.equal(actual, expected))
            with self.assertRaisesRegex(ValueError, "image_sha256"):
                collate([sample], vocab, 8, 3)

    def test_aerial_feature_cache_checks_decoded_bytes_and_preserves_preprocessing(self):
        class FrozenVisionFixture(nn.Module):
            def __init__(self):
                super().__init__()
                self.vision = nn.Identity()
                self.vision_train_policy = "frozen"
                self.backbone, self.grid_size = "fixture", 1
                self.vision_batchnorm_protocol = "fixture"

            def vision_summary(self, images):
                return images.mean((2, 3)), images.flatten(2).transpose(1, 2)

        with TemporaryDirectory() as tmp:
            root = Path(tmp)
            _, manifest, _ = aerial_cache(root)
            sample = load_aerial_samples(root, "train", manifest)[0]
            model = FrozenVisionFixture()
            with Image.open(sample["image"]) as raw:
                expected = preprocess_rgb(raw, 8)
            expected_mean, expected_regions = model.vision_summary(torch.stack([expected]))
            payload = build_vision_feature_cache(model, [[sample]], 8, "cpu", root / "cache.pt")
            self.assertTrue(torch.equal(payload["mean"][sample["image_sha256"]], expected_mean[0]))
            self.assertTrue(torch.equal(payload["regions"][sample["image_sha256"]],
                                        expected_regions[0]))
            Image.new("RGB", (3, 2), "red").save(sample["image"])
            with self.assertRaisesRegex(ValueError, "image_sha256"):
                build_vision_feature_cache(model, [[sample]], 8, "cpu", root / "rejected.pt")
            self.assertFalse((root / "rejected.pt").exists())
            self.assertFalse((root / "rejected.pt.pending").exists())

    def test_aerial_data_rejects_missing_frame_changed_image_pose_and_source(self):
        cases = ("missing_frame", "changed_image", "changed_pose", "changed_annotation", "changed_episode_hash")
        for case in cases:
            with self.subTest(case=case), TemporaryDirectory() as tmp:
                root = Path(tmp)
                source, manifest, payload = aerial_cache(root)
                row = payload["episodes"][0]
                if case == "missing_frame":
                    row["frames"].pop(2)
                elif case == "changed_image":
                    Image.new("RGB", (3, 2), "red").save(root / row["frames"][1]["rgb"]["path"])
                elif case == "changed_pose":
                    row["frames"][2]["pose"][5] = 0
                elif case == "changed_annotation":
                    official = json.loads(source.read_text())
                    official["episodes"][0]["instruction"]["instruction_text"] = "Changed instruction."
                    source.write_text(json.dumps(official), encoding="utf-8")
                else:
                    row["episode_sha256"] = "0" * 64
                manifest.write_text(json.dumps(payload), encoding="utf-8")
                with self.assertRaises(ValueError):
                    load_aerial_samples(root, "train", manifest)

    def test_aerial_labels_reject_wrong_yaw_action_alignment_and_float_class(self):
        for case in ("turn", "forward", "float_action", "early_stop", "bad_start_wxyz"):
            with self.subTest(case=case), TemporaryDirectory() as tmp:
                root = Path(tmp)
                episode = aerial_episode()
                if case == "turn":
                    episode["reference_path"][2][5] = np.pi / 12
                elif case == "forward":
                    episode["reference_path"][1][0] = 4
                elif case == "float_action":
                    episode["actions"][0] = 1.0
                elif case == "early_stop":
                    episode["actions"][0] = 0
                else:
                    episode["start_rotation"] = [0, 0, 0, 1]
                (root / "train.json").write_text(json.dumps({"episodes": [episode]}), encoding="utf-8")
                with self.assertRaises(ValueError):
                    load_aerial_episodes(root, "train")

    def test_aerial_train_singleton_is_quarantined_without_changing_original(self):
        with TemporaryDirectory() as tmp:
            root = Path(tmp)
            source, manifest, _ = aerial_cache(root, episodes=[aerial_episode(), aerial_episode("suspect", singleton=True)])
            before = source.read_bytes()
            episodes = load_aerial_episodes(root, "train")
            self.assertIsNone(episodes[0]["_quarantine_reason"])
            self.assertEqual(episodes[1]["_quarantine_reason"], "singleton_stop_requires_semantic_review")
            samples = load_aerial_samples(root, "train", manifest)
            self.assertEqual(len(samples), 8)
            self.assertEqual({row["episode_id"] for row in samples}, {"episode"})
            self.assertEqual(source.read_bytes(), before)

    def test_aerial_test_hidden_truth_cannot_become_training_labels(self):
        with TemporaryDirectory() as tmp:
            root = Path(tmp)
            episode = aerial_episode()
            for field in ("reference_path", "actions", "goals"):
                episode.pop(field)
            _, manifest, _ = aerial_cache(root, split="test", episodes=[episode])
            loaded = load_aerial_episodes(root, "test")
            self.assertFalse(loaded[0]["_labels_available"])
            self.assertNotIn("actions", loaded[0])
            with self.assertRaisesRegex(ValueError, "无动作监督"):
                load_aerial_samples(root, "test", manifest)

    def test_aerial_turn_wrap_and_body_sideways_are_preserved(self):
        left = aerial_next_pose([1, 2, -3, 0, 0, np.deg2rad(-179)], 2)
        right = aerial_next_pose([1, 2, -3, 0, 0, np.deg2rad(179)], 3)
        np.testing.assert_allclose(left, [1, 2, -3, 0, 0, np.deg2rad(166)], atol=1e-12)
        np.testing.assert_allclose(right, [1, 2, -3, 0, 0, np.deg2rad(-166)], atol=1e-12)
        np.testing.assert_allclose(aerial_next_pose([1, 2, -3, 0, 0, np.pi / 2], 6)[:3], [6, 2, -3], atol=1e-12)
        np.testing.assert_allclose(aerial_next_pose([1, 2, -3, 0, 0, np.pi / 2], 7)[:3], [-4, 2, -3], atol=1e-12)

    def test_reviewed_stop_annotations_add_terminal_sample_without_changing_motion(self):
        with TemporaryDirectory() as tmp:
            path = trajectory(Path(tmp), [0, 5, 10])
            original = list(iter_samples([path], 8))
            protocol = {"stop_source": "reviewed_annotations", "stop_timing": "before_action"}
            labels = Path(tmp) / "stop.json"
            labels.write_text(json.dumps({
                "schema_version": 1,
                "task_protocol": protocol,
                "rows": [stop_row(path, 0, 0), stop_row(path, 10, 1)],
            }), encoding="utf-8")

            samples = add_stop_annotations(original, [path], labels, protocol)
            self.assertEqual(len(samples), 3)
            self.assertNotIn("motion_valid", original[0])
            by_frame = {sample["frame_index"]: sample for sample in samples}
            self.assertTrue(by_frame[0]["motion_valid"])
            self.assertTrue(by_frame[0]["stop_valid"])
            self.assertEqual(by_frame[0]["stop_target"], 0)
            np.testing.assert_array_equal(by_frame[0]["offset"], original[0]["offset"])
            self.assertTrue(by_frame[5]["motion_valid"])
            self.assertFalse(by_frame[5]["stop_valid"])
            terminal = by_frame[10]
            self.assertFalse(terminal["motion_valid"])
            self.assertTrue(terminal["stop_valid"])
            self.assertEqual(terminal["stop_target"], 1)
            self.assertIsNone(terminal["target_frame_index"])
            np.testing.assert_array_equal(terminal["offset"], np.zeros(3))
            np.testing.assert_allclose(terminal["history"], [[-10, 0, 0], [-5, 0, 0]])
            self.assertEqual(terminal["instruction"], original[0]["instruction"])

            legacy = collate(original, Vocab(sample["instruction"] for sample in original), 8, 8)
            self.assertEqual(set(legacy), {"tokens", "token_mask", "image", "history", "history_length", "offset"})
            batch = collate(samples, Vocab(sample["instruction"] for sample in samples), 8, 8)
            self.assertEqual(batch["motion_valid"].tolist(), [True, True, False])
            self.assertEqual(batch["stop_valid"].tolist(), [True, False, True])
            self.assertEqual(batch["stop_target"].tolist(), [0.0, 0.0, 1.0])

    def test_stop_annotations_reject_unreviewed_duplicate_unknown_and_changed_sources(self):
        with TemporaryDirectory() as tmp:
            path = trajectory(Path(tmp), [0, 5, 10])
            samples = list(iter_samples([path], 8))
            protocol = {"stop_source": "reviewed_annotations", "stop_timing": "before_action"}
            labels = Path(tmp) / "stop.json"
            valid_rows = [stop_row(path, 0, 0), stop_row(path, 10, 1)]

            cases = []
            unreviewed = json.loads(json.dumps(valid_rows))
            unreviewed[0]["reviewed"] = False
            cases.append((unreviewed, "未经人工复核"))
            duplicate = json.loads(json.dumps(valid_rows))
            duplicate.append(json.loads(json.dumps(valid_rows[0])))
            cases.append((duplicate, "键重复"))
            unknown = json.loads(json.dumps(valid_rows))
            unknown[0]["traj_id"] = "Map/unknown"
            cases.append((unknown, "非有效运动轨迹"))
            changed = json.loads(json.dumps(valid_rows))
            changed[0]["image_sha256"] = "0" * 64
            cases.append((changed, "与源文件不一致"))
            noninteger = json.loads(json.dumps(valid_rows))
            noninteger[0]["stop_target"] = 0.0
            cases.append((noninteger, "必须是 0 或 1"))
            one_class = [json.loads(json.dumps(valid_rows[0]))]
            cases.append((one_class, "同时包含 0 和 1"))

            for rows, message in cases:
                with self.subTest(message=message):
                    labels.write_text(json.dumps({
                        "schema_version": 1, "task_protocol": protocol, "rows": rows,
                    }), encoding="utf-8")
                    with self.assertRaisesRegex(ValueError, message):
                        add_stop_annotations(samples, [path], labels, protocol)

            labels.write_text(json.dumps({
                "schema_version": 1, "task_protocol": protocol, "rows": valid_rows,
            }), encoding="utf-8")
            (path / "FrontCamera" / "000010.png").unlink()
            with self.assertRaisesRegex(FileNotFoundError, "缺少对应前视图或日志"):
                add_stop_annotations(samples, [path], labels, protocol)

    def test_stop_annotations_require_exact_protocol_and_terminal_for_nonmotion_row(self):
        with TemporaryDirectory() as tmp:
            path = trajectory(Path(tmp), [0, 3, 5, 10])
            samples = list(iter_samples([path], 8))
            protocol = {"stop_source": "reviewed_annotations", "stop_timing": "before_action"}
            labels = Path(tmp) / "stop.json"
            labels.write_text(json.dumps({
                "schema_version": 1,
                "task_protocol": protocol,
                "rows": [stop_row(path, 3, 0), stop_row(path, 10, 1)],
            }), encoding="utf-8")
            with self.assertRaisesRegex(ValueError, "只允许轨迹末帧"):
                add_stop_annotations(samples, [path], labels, protocol)
            with self.assertRaisesRegex(ValueError, "task_protocol 与当前任务协议不一致"):
                add_stop_annotations(samples, [path], labels, {**protocol, "protocol_version": 2})

    def test_short_tail_cannot_replace_fixed_step_label(self):
        for remainder in (1, 2, 3, 4):
            with self.subTest(remainder=remainder), TemporaryDirectory() as tmp:
                path = trajectory(Path(tmp), [90, 95, 95 + remainder], yaw90=True)
                samples = list(iter_samples([path], 8))
                self.assertEqual(len(samples), 1)
                self.assertEqual((samples[0]["frame_index"], samples[0]["target_frame_index"]), (90, 95))
                np.testing.assert_allclose(samples[0]["offset"], [0, -5, 0], atol=1e-6)
                self.assertEqual(samples[0]["frame_gap"], 5)
                self.assertEqual(samples[0]["history"].shape, (0, 3))
                frames, gap = _frames(path)
                self.assertEqual([x[2] for x in frames], [90, 95, 95 + remainder])
                self.assertEqual(gap, 5)

    def test_only_short_tail_is_not_a_training_step(self):
        with TemporaryDirectory() as tmp:
            path = trajectory(Path(tmp), [90, 94])
            self.assertEqual(list(iter_samples([path], 8)), [])
            env = StaticTrajectoryEnv(path)
            env.reset()
            final = env.step([100, 0, 0])
            self.assertTrue(final.done)
            self.assertEqual(final.info["actual_frame_gap"], 4)
            np.testing.assert_array_equal(final.position, [94, 0, 0])

    def test_history_uses_past_observations_in_current_body_frame(self):
        with TemporaryDirectory() as tmp:
            path = trajectory(Path(tmp), [0, 5, 10, 13], yaw90=True)
            samples = list(iter_samples([path], 8))
            self.assertEqual(len(samples), 2)
            np.testing.assert_allclose(samples[1]["history"], [[0, 5, 0]], atol=1e-6)
            np.testing.assert_allclose(samples[1]["offset"], [0, -5, 0], atol=1e-6)
            self.assertTrue(all(s["target_frame_index"] - s["frame_index"] == 5 for s in samples))

    def test_missing_pose_for_image_stops_loading(self):
        with TemporaryDirectory() as tmp:
            path = trajectory(Path(tmp), [0, 5])
            # Synthetic input deliberately lacks this observation's pose.
            Image.new("RGB", (2, 2)).save(path / "FrontCamera" / "000010.png")
            with self.assertRaises(FileNotFoundError):
                list(iter_samples([path], 8))

    def test_corrupt_or_nonfinite_pose_is_not_silently_skipped(self):
        for bad in ('{"broken": true}', '{invalid json',
                    '{"sensors":{"state":{"position":[NaN,0,0],"orientation":[0,0,0,1]}}}'):
            with self.subTest(bad=bad), TemporaryDirectory() as tmp:
                path = trajectory(Path(tmp), [0, 5])
                (path / "log" / "000005.json").write_text(bad, encoding="utf-8")
                with self.assertRaises((KeyError, ValueError)):
                    list(iter_samples([path], 8))

    def test_singleton_is_a_known_missing_step(self):
        with TemporaryDirectory() as tmp:
            path = trajectory(Path(tmp), [95])
            self.assertEqual(list(iter_samples([path], 8)), [])

    def test_missing_instruction_stops_loading(self):
        with TemporaryDirectory() as tmp:
            path = trajectory(Path(tmp), [0, 5])
            (path / "obj_des.json").write_text('[""]', encoding="utf-8")
            with self.assertRaises(ValueError):
                list(iter_samples([path], 8))

    def test_nonpadded_numeric_paths_work_in_replay_and_training(self):
        with TemporaryDirectory() as tmp:
            path = trajectory(Path(tmp), [0, 5], timestamps={0: "123", 5: "124"})
            for directory, extension in (("log", "json"), ("FrontCamera", "png")):
                for index in (0, 5):
                    (path / directory / f"{index:06d}.{extension}").rename(path / directory / f"{index}.{extension}")
            self.assertEqual(len(list(iter_samples([path], 8))), 1)
            self.assertEqual(StaticTrajectoryEnv(path).reset().timestamp, 123)

    def test_reference_endpoint_includes_last_log_without_an_image(self):
        from evaluate import _reference

        with TemporaryDirectory() as tmp:
            path = trajectory(Path(tmp), [0, 5])
            last = {"sensors": {"state": {"position": [7, 0, 0], "orientation": [0, 0, 0, 1]}}}
            (path / "log" / "000007.json").write_text(json.dumps(last), encoding="utf-8")
            self.assertEqual(_reference(path)[-1], [7, 0, 0])
            self.assertEqual([f[2] for f in _frames(path)[0]], [0, 5])

    def test_duplicate_or_missing_list_entry_stops_loading(self):
        with TemporaryDirectory() as tmp:
            root = Path(tmp)
            trajectory(root, [0, 5])
            listing = root / "train.json"
            listing.write_text('["Map/episode", "Map/episode"]', encoding="utf-8")
            with self.assertRaises(ValueError):
                load_list(root, listing)
            listing.write_text('["Map/episode", "Map/missing"]', encoding="utf-8")
            with self.assertRaises(FileNotFoundError):
                load_list(root, listing)

    def test_string_timestamp_survives_without_precision_or_unit_conversion(self):
        with TemporaryDirectory() as tmp:
            stamps = {0: "1700000000000000001", 5: "1700000000000000002"}
            path = trajectory(Path(tmp), [0, 5], timestamps=stamps)
            env = StaticTrajectoryEnv(path)
            first = env.reset()
            self.assertIsInstance(first.timestamp, int)
            self.assertEqual(first.timestamp, 1700000000000000001)
            self.assertEqual(first.info["source_timestamp_raw"], stamps[0])
            self.assertEqual(first.info["timestamp_units"], "source_native")
            last = env.step([5, 0, 0])
            self.assertEqual(last.timestamp - first.timestamp, 1)

    def test_invalid_timestamp_stays_unknown(self):
        for stamp in ("not-a-time", "NaN", "Infinity", True, None):
            with self.subTest(stamp=stamp), TemporaryDirectory() as tmp:
                path = trajectory(Path(tmp), [0, 5], timestamps={0: stamp, 5: stamp})
                observation = StaticTrajectoryEnv(path).reset()
                self.assertIsNone(observation.timestamp)
                self.assertIsNone(observation.info["timestamp_units"])


class DatasetAuditReportingTests(unittest.TestCase):
    def test_missing_split_lists_return_incomplete_structured_report(self):
        import importlib.util
        script = Path(__file__).resolve().parents[1] / "scripts/audit_dataset.py"
        spec = importlib.util.spec_from_file_location("avln_dataset_audit_reporting", script)
        module = importlib.util.module_from_spec(spec)
        spec.loader.exec_module(module)
        with TemporaryDirectory() as folder:
            report = module.audit(Path(folder), workers=1, image_check="none")
        self.assertFalse(report["coverage_complete"])
        self.assertEqual({row["split"] for row in report["root_issues"]}, set(module.SPLITS))
        self.assertTrue(all(row["kind"] == "unreadable_split_list" for row in report["root_issues"]))
        self.assertEqual(report["flagged_trajectories"], [])


if __name__ == "__main__":
    unittest.main()
