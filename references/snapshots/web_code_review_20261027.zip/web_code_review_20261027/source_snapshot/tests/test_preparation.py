"""采集事务和教师信息边界回归；合成环境不产生导航成绩。"""

import copy
import hashlib
import json
import os
import sys
import unittest
from pathlib import Path
from tempfile import TemporaryDirectory
from types import SimpleNamespace
from unittest.mock import patch

import numpy as np
from PIL import Image
from scipy.spatial.transform import Rotation

sys.path.insert(0, str(Path(__file__).resolve().parents[1]))
from uavnav.avln.airsim_env import aerial_action_pose
from uavnav.avln.closed_loop import collect_aerial_dagger_episode
from uavnav.avln.geometry import AirVLNDaggerTeacher, validate_aerial_teacher_review
from uavnav.avln.rollout import Observation


def teacher_review():
    kinds = ("on_route_pose_orientation", "off_route_pose", "route_order", "stop_pose", "graph_connectivity")
    return {"schema_version": 1, "protocol": "airvln_upstream_pose_guard_v1", "scene_id": 2,
            "source_sha256": {key: "a" * 64 for key in
                              ("utils/env_utils.py", "utils/shorest_path_sensor.py", "airsim_plugin/airsim_settings.py")},
            "assets_sha256": {key: "b" * 64 for key in ("graph", "tokens")},
            "checks": dict.fromkeys(kinds, True),
            "cases": [{"name": key, "kind": key, "current_position": [0., 0., 0.],
                       "current_orientation_xyzw": [0., 0., 0., 1.], "reference_stage": 0,
                       "expected_action": 1, "observed_action": 1} for key in kinds]}


class CaptureEnv:
    replay = False
    actions_executed = True

    def __init__(self, step_error=False, cleanup_error=False):
        self.step_error, self.cleanup_error = step_error, cleanup_error
        self.finished = 0
        self.index = 0

    def observe(self):
        timestamp = 10_000_000_000 + self.index * 1_000_000_000
        return Observation(image=Image.new("RGB", (224, 224)), position=self.position,
                           orientation=self.orientation, timestamp=timestamp / 1e9,
                           info={"depth_normalized": np.full((256, 256), .5, dtype=np.float32),
                                 "response_camera_position": self.position.tolist(),
                                 "response_camera_orientation_xyzw": self.orientation.tolist(),
                                 "image_timestamp_ns": timestamp, "request_started_ns": timestamp - 200,
                                 "response_received_ns": timestamp + 200, "pose_requested_ns": timestamp - 300})

    def reset(self):
        self.position, self.orientation = np.zeros(3), np.array([0., 0., 0., 1.])
        self.index = 0
        return self.observe()

    def step(self, action):
        if self.step_error:
            raise RuntimeError("dispatch_unknown")
        self.position, self.orientation = aerial_action_pose(self.position, self.orientation, action)
        self.index += 1
        return self.observe()

    def finish(self):
        self.finished += 1
        if self.cleanup_error:
            raise OSError("cleanup_failed")


class CapturePolicy:
    config = {"architecture": "aerial_route_recurrent_rgbd_v3", "input_modality": "rgbd"}
    checkpoint_sha256 = "c" * 64

    def __init__(self):
        self.inputs = []

    def reset_episode(self):
        self.inputs = []

    def predict_action(self, image, instruction, past, *, depth):
        self.inputs.append((instruction, list(past), depth.copy()))
        action = (1, 2, 0)[len(self.inputs) - 1]
        return {"action": action, "action_probabilities": np.eye(8)[action].tolist()}


class CaptureTeacher:
    contract_sha256 = "d" * 64

    def reset_episode(self, episode):
        self.history = []

    def label(self, observation, step, executed_actions):
        self.history.append(list(executed_actions))
        return {"action": (7, 1, 4)[step], "teacher_protocol": "airvln_upstream_pose_guard_v1",
                "teacher_contract_sha256": self.contract_sha256, "reference_stage": step}


class PreparationContracts(unittest.TestCase):
    def episode(self):
        return {"scene_id": 2, "actions": [1, 0], "instruction": {"instruction_text": "follow route"},
                "source_split": "train"}

    def test_dagger_uses_actual_past_and_records_real_depth(self):
        with TemporaryDirectory() as folder:
            env, policy, teacher = CaptureEnv(), CapturePolicy(), CaptureTeacher()
            result = collect_aerial_dagger_episode(env, policy, teacher, self.episode(),
                                                   Path(folder) / "attempt", beta=0., save_depth=True)
            self.assertEqual(result["termination_reason"], "model_stop")
            self.assertEqual([row["teacher_action"] for row in result["frames"]], [7, 1, 4])
            self.assertEqual([row["history_actions"] for row in result["frames"]], [[], [1], [1, 2]])
            self.assertEqual(teacher.history, [[], [1], [1, 2]])
            self.assertEqual([row[1] for row in policy.inputs], [[], [1], [1, 2]])
            self.assertEqual(result["student_decisions"], 3)
            self.assertEqual(env.finished, 1)
            for frame in result["frames"]:
                path = Path(folder) / "attempt" / frame["depth"]["path"]
                self.assertEqual(hashlib.sha256(path.read_bytes()).hexdigest(), frame["depth"]["sha256"])
                np.testing.assert_array_equal(np.load(path, allow_pickle=False), np.full((256, 256), .5, np.float32))

    def test_unknown_dispatch_preserves_original_error_and_cleanup_failure(self):
        with TemporaryDirectory() as folder:
            target = Path(folder) / "attempt"
            env = CaptureEnv(step_error=True, cleanup_error=True)
            with self.assertRaisesRegex(RuntimeError, "dispatch_unknown"):
                collect_aerial_dagger_episode(env, CapturePolicy(), CaptureTeacher(), self.episode(), target, beta=0.)
            error = json.loads((target / "error.json").read_text(encoding="utf-8"))
            self.assertEqual(error["known_executed_actions"], [])
            self.assertEqual(error["pending_dispatch"]["execution_state"], "unknown_until_step_returns")
            self.assertTrue((target / "cleanup_error.json").exists())
            self.assertFalse((target / "result.json").exists())
            self.assertEqual(env.finished, 1)

    def test_cleanup_failure_does_not_seal_collection(self):
        with TemporaryDirectory() as folder:
            target = Path(folder) / "attempt"
            with self.assertRaisesRegex(OSError, "cleanup_failed"):
                collect_aerial_dagger_episode(CaptureEnv(cleanup_error=True), CapturePolicy(), CaptureTeacher(),
                                              self.episode(), target, beta=0.)
            self.assertFalse((target / "result.json").exists())

    def test_reject_full_teacher_multiseed_and_nontrain(self):
        with TemporaryDirectory() as folder:
            for options in ({"beta": 1.}, {"beta": 0., "seed": 1}, {"beta": 0., "seed": False},
                            {"beta": 0., "history_frames": -1}):
                with self.subTest(options=options), self.assertRaises(ValueError):
                    collect_aerial_dagger_episode(CaptureEnv(), CapturePolicy(), CaptureTeacher(), self.episode(),
                                                  Path(folder) / "rejected", **options)
            episode = {**self.episode(), "source_split": "val_seen"}
            with self.assertRaises(ValueError):
                collect_aerial_dagger_episode(CaptureEnv(), CapturePolicy(), CaptureTeacher(), episode,
                                              Path(folder) / "rejected", beta=0.)

    def test_teacher_requires_reviewed_cases_and_hashes(self):
        review = teacher_review()
        validate_aerial_teacher_review(review, 2)
        for field in ("cases", "checks", "source_sha256"):
            broken = copy.deepcopy(review)
            broken[field] = {} if field != "cases" else []
            with self.subTest(field=field), self.assertRaises(ValueError):
                validate_aerial_teacher_review(broken, 2)
        broken = copy.deepcopy(review)
        broken["cases"][0]["observed_action"] = 7
        with self.assertRaises(ValueError):
            validate_aerial_teacher_review(broken, 2)

    def test_actual_upstream_teacher_pose_guard_and_readonly_cache(self):
        """原函数体在fake SDK/graph下运行，只验证导入、朝向与来源边界。"""
        class Vector:
            def __init__(self, x=0., y=0., z=0.):
                self.x_val, self.y_val, self.z_val = x, y, z

        class Quaternion:
            def __init__(self, x=0., y=0., z=0., w=1.):
                self.x_val, self.y_val, self.z_val, self.w_val = x, y, z, w

        class Pose:
            def __init__(self, position=None, orientation=None):
                self.position, self.orientation = position or Vector(), orientation or Quaternion()

        decorators = []

        def njit(**kwargs):
            decorators.append(kwargs)
            return lambda function: function

        upstream = Path(os.environ.get("UAVNAV_TEST_UPSTREAM_ROOT",
                                      Path(__file__).resolve().parents[2] / "idea" / "AirVLN"))
        if not (upstream / "utils/env_utils.py").is_file():
            self.skipTest("当前机器未挂载冻结AirVLN源码；需指定UAVNAV_TEST_UPSTREAM_ROOT")
        review = teacher_review()
        review["source_sha256"] = {key: hashlib.sha256((upstream / key).read_bytes()).hexdigest()
                                   for key in review["source_sha256"]}
        sdk = SimpleNamespace(Pose=Pose, Vector3r=Vector, Quaternionr=Quaternion)
        with TemporaryDirectory() as folder:
            root = Path(folder)
            graph, tokens = root / "nav_graph_dict_2.pkl", root / "TokenDict_2.json"
            graph.write_bytes(b"fixture")
            tokens.write_text(json.dumps({str(i): [i * 5., 0., 0.] for i in range(61)}), encoding="utf-8")
            review["assets_sha256"] = {"graph": hashlib.sha256(graph.read_bytes()).hexdigest(),
                                      "tokens": hashlib.sha256(tokens.read_bytes()).hexdigest()}
            review_path = root / "review.json"
            review_path.write_text(json.dumps(review), encoding="utf-8")
            graph_stub = SimpleNamespace(vcount=lambda: 61, ecount=lambda: 60, is_connected=lambda: True,
                                         vs={"name": [str(i) for i in range(61)]}, es={"weight": [5.] * 60})
            with patch.dict(sys.modules, {"airsim": sdk, "numba": SimpleNamespace(njit=njit),
                                          "igraph": SimpleNamespace(Graph=SimpleNamespace(Read_Pickle=lambda _: graph_stub))}):
                teacher = AirVLNDaggerTeacher(upstream, root, root, 2, review_path)
            teacher.sensor.get_shortest_paths = lambda source, target, scene_id: [0, 1] if source != target else [0]
            episode = {"scene_id": 2, "reference_path": [[0., 0., 0., 0., 0., 0.], [5., 0., 0., 0., 0., 0.]],
                       "actions": [1, 0], "goals": [{"position": [5., 0., 0.]}], "start_position": [0., 0., 0.]}
            teacher.reset_episode(episode)
            obs = CaptureEnv().reset()
            self.assertEqual(teacher.label(obs, 0, [])["action"], 1)
            obs.orientation = Rotation.from_euler("z", 15, degrees=True).as_quat()
            with self.assertRaisesRegex(ValueError, "朝向"):
                teacher.label(obs, 0, [])
            with self.assertRaisesRegex(ValueError, "时序"):
                teacher.label(obs, 1, [])
            self.assertTrue(decorators)
            self.assertTrue(all(options["cache"] is False for options in decorators))
            # 原上游函数实际更新20步carrot；图接口是stub，不形成导航成绩。
            episode["reference_path"] = [[i * 5., 0., 0., 0., 0., 0.] for i in range(61)]
            episode["actions"] = [1] * 60 + [0]
            episode["goals"] = [{"position": [300., 0., 0.]}]
            teacher.reset_episode(episode)
            for step in range(20):
                obs.position = np.array([step * 5., 0., 0.])
                obs.orientation = np.array([0., 0., 0., 1.])
                self.assertEqual(teacher.label(obs, step, [1] * step)["action"], 1)
            self.assertGreater(teacher.state.pre_carrot_idx, 20)
            obs.position = np.array([100., 5., 0.])
            teacher.state.pose = Pose(Vector(*obs.position), Quaternion())
            teacher.state.step = 20
            target, state = teacher.namespace["find_waypoint_at"](0, teacher.state)
            self.assertEqual(target, [150., 0., 0.])
            self.assertEqual(state.pre_carrot_idx, 30)


if __name__ == "__main__":
    unittest.main()
