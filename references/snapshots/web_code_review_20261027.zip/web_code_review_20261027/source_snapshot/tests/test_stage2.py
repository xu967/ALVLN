"""Stage 2 contract regression tests using synthetic data and a fake SDK.

Run from code/: python -m unittest discover -s tests -v
The fake AirSim client checks adapter calls only; it is not an AirSim scene test.
"""

from __future__ import annotations

import copy
import contextlib
import io
import json
import sys
import unittest
from pathlib import Path
from tempfile import TemporaryDirectory
from types import SimpleNamespace
from unittest.mock import patch

import numpy as np
from PIL import Image

sys.path.insert(0, str(Path(__file__).resolve().parents[1]))
try:
    from uavnav.avln.airsim_env import AirSimEnv
    from uavnav.avln.closed_loop import ClosedLoopAuditError, read_rollout_metrics, write_metrics
    from uavnav.avln.rollout import Observation, rollout_episode
    from uavnav.avln.simulator import StaticTrajectoryEnv
except (ImportError, OSError) as error:
    IMPORT_FAILURE = f"runtime dependencies unavailable: {error}"
else:
    IMPORT_FAILURE = None


IDENTITY = [0.0, 0.0, 0.0, 1.0]
YAW_90 = [0.0, 0.0, float(np.sin(np.pi / 4)), float(np.cos(np.pi / 4))]


def make_trajectory(root: Path, positions, orientation=IDENTITY, metadata=None):
    (root / "log").mkdir(parents=True)
    (root / "FrontCamera").mkdir()
    for index, position in enumerate(positions):
        state = {"position": list(position), "orientation": list(orientation)}
        state.update((metadata or {}).get(index, {}))
        path = root / "log" / f"{index:06d}.json"
        path.write_text(json.dumps({"sensors": {"state": state}}), encoding="utf-8")
        Image.new("RGB", (2, 2), (index, 0, 0)).save(root / "FrontCamera" / f"{index:06d}.png")


class SequenceEnv:
    """Synthetic state sequence for rollout causality and stopping tests."""

    replay = False
    actions_executed = True

    def __init__(self, positions, *, terminal=True, goal=None):
        self.positions = positions
        self.terminal = terminal
        self.goal = goal
        self.finish_calls = 0
        self.step_calls = 0

    def _observation(self):
        last = self.index == len(self.positions) - 1
        return Observation(
            image=f"frame-{self.index}",
            position=np.asarray(self.positions[self.index]),
            orientation=np.asarray(IDENTITY),
            timestamp=None,
            collision=None,
            done=self.terminal and last,
            termination_reason="sequence_end" if self.terminal and last else None,
            goal_position=self.goal,
        )

    def reset(self):
        self.index = 0
        return self._observation()

    def step(self, action_body):
        self.step_calls += 1
        self.index += 1
        return self._observation()

    def finish(self):
        self.finish_calls += 1


class FakeVector:
    def __init__(self, x=0.0, y=0.0, z=0.0):
        self.x_val, self.y_val, self.z_val = float(x), float(y), float(z)


class FakeQuaternion:
    def __init__(self, x=0.0, y=0.0, z=0.0, w=1.0):
        self.x_val, self.y_val, self.z_val, self.w_val = float(x), float(y), float(z), float(w)


class FakeYawMode:
    def __init__(self, *, is_rate, yaw_or_rate=0.0):
        self.is_rate, self.yaw_or_rate = is_rate, yaw_or_rate


class FakeSdk:
    Vector3r = FakeVector
    Quaternionr = FakeQuaternion
    KinematicsState = SimpleNamespace
    YawMode = FakeYawMode
    DrivetrainType = SimpleNamespace(MaxDegreeOfFreedom="MaxDegreeOfFreedom")
    ImageType = SimpleNamespace(Scene="Scene")

    @staticmethod
    def ImageRequest(camera_name, image_type, pixels_as_float, compress):
        return SimpleNamespace(
            camera_name=camera_name,
            image_type=image_type,
            pixels_as_float=pixels_as_float,
            compress=compress,
        )


class FakeClient:
    """SDK-shaped fixture following the API calls in the local AeroVLA client."""

    def __init__(self):
        self.calls = []
        self.position = FakeVector()
        self.orientation = FakeQuaternion()
        self.timestamp = 1_000_000_000
        self.collision = SimpleNamespace(has_collided=True, time_stamp=100)
        self.next_collision_timestamp = None
        self.collision_after_sample = 1
        self.collision_during_reset = None
        self.motion_sample_count = 0
        self.command = None
        self.fail_continue = False
        self.paused = True

    def confirmConnection(self):
        self.calls.append(("confirmConnection",))

    def simPause(self, paused):
        self.calls.append(("simPause", paused))
        self.paused = paused

    def enableApiControl(self, enabled, *, vehicle_name):
        self.calls.append(("enableApiControl", enabled, vehicle_name))

    def armDisarm(self, armed, *, vehicle_name):
        self.calls.append(("armDisarm", armed, vehicle_name))

    def simSetKinematics(self, kinematics, *, ignore_collision, vehicle_name):
        self.calls.append(("simSetKinematics", ignore_collision, vehicle_name))
        self.position = copy.copy(kinematics.position)
        self.orientation = copy.copy(kinematics.orientation)
        self.reset_velocity = kinematics.linear_velocity

    def simContinueForFrames(self, frames):
        self.calls.append(("simContinueForFrames", frames))
        self.timestamp += frames * 1_000_000
        self.paused = True
        if self.collision_during_reset is not None:
            self.collision = SimpleNamespace(has_collided=True, time_stamp=self.collision_during_reset)

    def simContinueForTime(self, seconds):
        self.calls.append(("simContinueForTime", seconds))
        if self.fail_continue:
            raise RuntimeError("synthetic command failure")
        if self.command is not None:
            vx, vy, vz = self.command["velocity"]
            self.position = FakeVector(
                self.position.x_val + vx * seconds,
                self.position.y_val + vy * seconds,
                self.position.z_val + vz * seconds,
            )
            self.motion_sample_count += 1
        self.timestamp += round(seconds * 1e9)
        if self.next_collision_timestamp is not None and self.motion_sample_count >= self.collision_after_sample:
            self.collision = SimpleNamespace(has_collided=True, time_stamp=self.next_collision_timestamp)
        self.paused = True

    def simIsPause(self):
        self.calls.append(("simIsPause",))
        return self.paused

    def cancelLastTask(self, *, vehicle_name):
        self.calls.append(("cancelLastTask", vehicle_name))
        self.command = None

    def simGetCollisionInfo(self, *, vehicle_name):
        self.calls.append(("simGetCollisionInfo", vehicle_name))
        return self.collision

    def simGetImages(self, requests, *, vehicle_name):
        self.calls.append(("simGetImages", requests, vehicle_name))
        return [SimpleNamespace(width=1, height=1, image_data_uint8=bytes([1, 2, 3]), time_stamp=self.timestamp)]

    def getMultirotorState(self, *, vehicle_name):
        self.calls.append(("getMultirotorState", vehicle_name))
        return SimpleNamespace(
            timestamp=self.timestamp,
            kinematics_estimated=SimpleNamespace(position=self.position, orientation=self.orientation),
        )

    def moveByVelocityAsync(self, vx, vy, vz, *, duration, drivetrain, yaw_mode, vehicle_name):
        self.command = {
            "velocity": [vx, vy, vz], "duration": duration, "drivetrain": drivetrain,
            "yaw_mode": yaw_mode, "vehicle_name": vehicle_name,
        }
        self.last_command = dict(self.command)
        self.calls.append(("moveByVelocityAsync",))

        def join():
            self.calls.append(("join",))

        return SimpleNamespace(join=join)


def valid_episode_payload():
    return {
        "status": "closed_loop", "replay": False, "actions_executed": True, "done": True,
        "termination_reason": "max_steps", "collision": False, "final_position": [10.0, 0.0, 0.0],
        "records": [{
            "position": [0.0, 0.0, 0.0], "next_position": [10.0, 0.0, 0.0],
            "timestamp": 1.0, "next_timestamp": 2.0,
            "commanded_action_body": [10.0, 0.0, 0.0], "actual_displacement_body": [10.0, 0.0, 0.0],
            "action_executed": True, "collision": False,
        }],
    }


def episode_metadata():
    return {
        "goal_position": [10.0, 0.0, 0.0], "reference_positions": [[0.0, 0.0, 0.0], [10.0, 0.0, 0.0]],
        "success_distance": 1.0, "spl_definition": "standard", "split": "test",
        "success_basis": "final_within_success_distance_and_no_collision",
    }


def write_episode(path: Path, rollout=None, metadata=None):
    path.mkdir(parents=True)
    (path / "rollout.json").write_text(json.dumps(valid_episode_payload() if rollout is None else rollout), encoding="utf-8")
    (path / "ori_info.json").write_text(json.dumps(episode_metadata() if metadata is None else metadata), encoding="utf-8")


@unittest.skipIf(IMPORT_FAILURE is not None, IMPORT_FAILURE or "")
class SimulatorReplayTests(unittest.TestCase):
    def test_action_is_logged_but_recorded_pose_is_preserved(self):
        with TemporaryDirectory() as temporary:
            root = Path(temporary) / "trajectory"
            make_trajectory(root, [[10, 20, 30], [11, 22, 33]], YAW_90)
            env = StaticTrajectoryEnv(root)
            first = env.reset()
            following = env.step([1, 0, 0])
            np.testing.assert_allclose(following.info["world_target"], [10, 21, 30], atol=1e-6)
            np.testing.assert_allclose(following.position, [11, 22, 33])
            np.testing.assert_allclose(following.orientation, YAW_90)
            self.assertEqual(following.image.name, "000001.png")
            self.assertIsNone(first.timestamp)
            self.assertIsNone(following.collision)
            self.assertFalse(following.info["collision_known"])
            self.assertFalse(following.info["action_applied"])
            self.assertTrue(following.info["replay"])
            self.assertTrue(following.done)
            self.assertEqual(following.termination_reason, "trajectory_end")
            with self.assertRaises(RuntimeError):
                env.step([0, 0, 0])

    def test_source_metadata_is_preserved_and_replay_has_no_navigation_metrics(self):
        with TemporaryDirectory() as temporary:
            root = Path(temporary)
            trajectory = root / "trajectory"
            make_trajectory(trajectory, [[0, 0, 0], [1, 0, 0]], metadata={
                0: {"timestamp": 123, "collision": {"has_collided": False}},
                1: {"timestamp": 124, "collision": {"has_collided": False}},
            })
            result = rollout_episode(StaticTrajectoryEnv(trajectory), lambda **kwargs: [9, 9, 9], "test")
            self.assertEqual(result["status"], "replay_only")
            self.assertFalse(result["actions_executed"])
            self.assertEqual(result["records"][0]["timestamp"], 123)
            self.assertEqual(result["final_position"], [1, 0, 0])
            episode = root / "episode"
            write_episode(episode, result)
            scores = read_rollout_metrics(episode)
            self.assertEqual(scores["status"], "replay_only")
            self.assertTrue(all(scores[key] is None for key in ("ne", "sr", "osr", "spl")))


@unittest.skipIf(IMPORT_FAILURE is not None, IMPORT_FAILURE or "")
class RolloutTests(unittest.TestCase):
    def test_resource_failure_is_infrastructure_not_policy_error(self):
        from uavnav.avln.closed_loop import AerialPolicyError, aerial_error_category
        oom_type = type("OutOfMemoryError", (RuntimeError,), {})
        oom_type.__module__ = "torch"
        wrapped = AerialPolicyError("predict failed")
        wrapped.__cause__ = oom_type("out of memory")
        self.assertEqual(aerial_error_category(wrapped, "rollout"), "infrastructure_error")
        self.assertEqual(aerial_error_category(MemoryError("oom"), "rollout"), "infrastructure_error")
        self.assertEqual(aerial_error_category(AerialPolicyError("bad output"), "rollout"), "policy_error")

    def test_stop_before_action_and_zero_step_metrics(self):
        for stop_at in (0, 1):
            with self.subTest(stop_at=stop_at), TemporaryDirectory() as temporary:
                env = SequenceEnv([[0, 0, 0], [10, 0, 0], [20, 0, 0]], terminal=False)
                original = env._observation

                def observation():
                    value = original()
                    value.timestamp, value.collision = float(env.index), False
                    return value

                env._observation = observation

                def predictor(**kwargs):
                    self.assertEqual(set(kwargs), {"image", "instruction", "history"})
                    return {"body_displacement": [10, 0, 0], "stop_enabled": True,
                            "stop_probability": 0.9 if env.index == stop_at else 0.1}

                result = rollout_episode(env, predictor, "object", stop_threshold=0.8)
                self.assertEqual(env.step_calls, stop_at)
                self.assertEqual(len(result["records"]), stop_at)
                self.assertEqual(result["actions_executed_count"], stop_at)
                self.assertEqual(result["termination_reason"], "model_stop")
                self.assertEqual(result["terminal_decision"]["observation"]["position"], [10 * stop_at, 0, 0])
                metadata = episode_metadata()
                metadata.update(goal_position=[10 * stop_at, 0, 0],
                                success_basis="final_within_success_distance_and_predicted_stop_and_no_collision")
                episode = Path(temporary) / "valid"
                write_episode(episode, result, metadata)
                scores = read_rollout_metrics(episode)
                self.assertEqual(scores["sr"], 100)
                self.assertEqual(len(scores["latency_samples_ms"]), stop_at + 1)
                for field, value in (("position", [99, 0, 0]), ("orientation", [0, 0, 1, 0]), ("timestamp", 99)):
                    damaged = copy.deepcopy(result)
                    damaged["terminal_decision"]["observation"][field] = value
                    bad = Path(temporary) / field
                    write_episode(bad, damaged, metadata)
                    with self.assertRaises(ClosedLoopAuditError):
                        read_rollout_metrics(bad)

    def test_invalid_stop_probability_or_threshold_rejected_before_action(self):
        for probability, threshold in ((None, 0.5), (float("nan"), 0.5), (1.1, 0.5), (-0.1, 0.5),
                                       (True, 0.5), (0.9, None), (0.9, float("inf")), (0.9, -0.1), (0.9, True)):
            with self.subTest(probability=probability, threshold=threshold):
                env = SequenceEnv([[0, 0, 0], [1, 0, 0]])
                predictor = lambda **kwargs: {"body_displacement": [1, 0, 0], "stop_enabled": True,
                                               "stop_probability": probability}
                with self.assertRaises(ValueError):
                    rollout_episode(env, predictor, "object", stop_threshold=threshold)
                self.assertEqual(env.step_calls, 0)

    def test_horizon_at_goal_is_not_predicted_stop_success(self):
        env = SequenceEnv([[0, 0, 0], [10, 0, 0]], terminal=False)
        original = env._observation

        def observation():
            value = original()
            value.timestamp, value.collision = float(env.index), False
            return value

        env._observation = observation
        result = rollout_episode(env, lambda **kwargs: {"body_displacement": [10, 0, 0],
                                 "stop_enabled": True, "stop_probability": 0.1}, "object",
                                 stop_threshold=0.8, max_steps=1)
        self.assertEqual(result["termination_kind"], "horizon")
        metadata = episode_metadata()
        metadata["success_basis"] = "final_within_success_distance_and_predicted_stop_and_no_collision"
        with TemporaryDirectory() as temporary:
            path = Path(temporary) / "horizon"
            write_episode(path, result, metadata)
            scores = read_rollout_metrics(path)
            self.assertEqual(scores["ne"], 0)
            self.assertEqual(scores["osr"], 100)
            self.assertEqual(scores["sr"], 0)
            self.assertEqual(scores["spl"], 0)
            result.pop("initial_observation")
            damaged = Path(temporary) / "missing_initial"
            write_episode(damaged, result, metadata)
            with self.assertRaises(ClosedLoopAuditError):
                read_rollout_metrics(damaged)

    def test_disabled_stop_preserves_old_execution_and_replay_stop_metrics_null(self):
        env = SequenceEnv([[0, 0, 0], [1, 0, 0]])
        result = rollout_episode(env, lambda **kwargs: {"body_displacement": [1, 0, 0],
                                  "stop_enabled": False, "stop_probability": None}, "object")
        self.assertNotIn("schema_version", result)
        self.assertEqual(env.step_calls, 1)
        env = SequenceEnv([[0, 0, 0], [1, 0, 0]])
        env.replay = True
        result = rollout_episode(env, lambda **kwargs: {"body_displacement": [1, 0, 0],
                                  "stop_enabled": True, "stop_probability": 1.0}, "object", stop_threshold=0.5)
        with TemporaryDirectory() as temporary:
            path = Path(temporary) / "replay"
            write_episode(path, result)
            scores = read_rollout_metrics(path)
            self.assertTrue(all(scores[key] is None for key in ("ne", "sr", "osr", "spl")))

    def test_numpy_collision_boolean_is_serializable(self):
        observation = Observation(image="unused", position=np.zeros(3), orientation=np.asarray(IDENTITY),
                                  collision=np.bool_(False), timestamp=None)
        self.assertIs(observation.collision, False)
        json.dumps({"collision": observation.collision})

    def test_history_contains_only_past_poses_and_unknown_metadata_survives(self):
        env = SequenceEnv([[0, 0, 0], [1, 0, 0], [2, 0, 0], [3, 0, 0]])
        seen = []

        def predictor(**kwargs):
            self.assertEqual(set(kwargs), {"image", "instruction", "history"})
            seen.append((kwargs["image"], kwargs["history"].copy()))
            return [1, 0, 0]

        result = rollout_episode(env, predictor, "test", history_frames=2)
        self.assertEqual([image for image, _ in seen], ["frame-0", "frame-1", "frame-2"])
        self.assertEqual(seen[0][1].shape, (0, 3))
        np.testing.assert_array_equal(seen[1][1], [[-1, 0, 0]])
        np.testing.assert_array_equal(seen[2][1], [[-2, 0, 0], [-1, 0, 0]])
        self.assertIsNone(result["collision"])
        self.assertTrue(all(record["timestamp"] is None and record["collision"] is None for record in result["records"]))
        json.dumps(result, allow_nan=False)

    def test_max_steps_stops_without_goal_leakage(self):
        env = SequenceEnv([[0, 0, 0], [1, 0, 0], [2, 0, 0], [3, 0, 0]], terminal=False, goal=[3, 0, 0])
        calls = []

        def predictor(**kwargs):
            calls.append(kwargs)
            self.assertEqual(set(kwargs), {"image", "instruction", "history"})
            return {"body_displacement": [1, 0, 0]}

        result = rollout_episode(env, predictor, "test", max_steps=2)
        self.assertEqual(env.step_calls, 2)
        self.assertEqual(env.finish_calls, 1)
        self.assertEqual(len(calls), 2)
        self.assertEqual(result["termination_reason"], "max_steps")
        self.assertTrue(result["done"])
        self.assertTrue(result["records"][-1]["done"])
        self.assertEqual(result["records"][-1]["termination_reason"], "max_steps")
        self.assertEqual(result["final_distance"], 1.0)

    def test_unproven_action_execution_is_rejected(self):
        env = SequenceEnv([[0, 0, 0], [1, 0, 0]])
        env.actions_executed = False
        with self.assertRaises(ValueError):
            rollout_episode(env, lambda **kwargs: [1, 0, 0], "test")


@unittest.skipIf(IMPORT_FAILURE is not None, IMPORT_FAILURE or "")
class EvaluateEntrypointTests(unittest.TestCase):
    def test_development_route_binds_checkpoint_and_rejects_training_member_or_stale_source(self):
        import evaluate
        import hashlib
        with TemporaryDirectory() as temporary:
            root = Path(temporary)
            checkpoint = root / "weights" / "best.pt"
            checkpoint.parent.mkdir()
            checkpoint.write_bytes(b"fixture")
            frozen = {"manifest_sha256": "d" * 64,
                      "train_episode_keys": [{"scene_id": 2, "episode_id": "train"}],
                      "dev_episode_keys": [{"scene_id": 2, "episode_id": "dev"}]}
            training = {"data_protocol": "aerialvln_s_v1", "validation_purpose": "development_train_grouped",
                        "validation_source_split": "train", "development_route_split": frozen,
                        "development_route_split_sha256": "d" * 64,
                        "train_episode_ids": ["2/train"], "validation_episode_ids": ["2/dev"],
                        "train_annotation_sha256": "a" * 64, "validation_annotation_sha256": "a" * 64}
            source = root / "split_manifest.json"
            source.write_text(json.dumps(training), encoding="utf-8")
            config = {"split_manifest_sha256": hashlib.sha256(source.read_bytes()).hexdigest(),
                      "development_route_split_sha256": "d" * 64}
            episode = {"scene_id": 2, "episode_id": "dev", "_annotation_sha256": "a" * 64}
            with patch("uavnav.avln.data.load_aerial_development_split", return_value=(frozen, "e" * 64)) as gate:
                self.assertEqual(evaluate._authenticate_development_route(
                    checkpoint, config, [episode], [episode], root / "development.json"),
                    (config["split_manifest_sha256"], "d" * 64))
                gate.assert_called_once()
                with self.assertRaisesRegex(ValueError, "独立开发路线"):
                    evaluate._authenticate_development_route(checkpoint, config, [episode],
                        [{**episode, "episode_id": "train"}], root / "development.json")
                training["train_episode_ids"].append("2/dev")
                source.write_text(json.dumps(training), encoding="utf-8")
                with self.assertRaisesRegex(ValueError, "SHA不一致"):
                    evaluate._authenticate_development_route(checkpoint, config, [episode], [episode], root / "development.json")
                config["split_manifest_sha256"] = hashlib.sha256(source.read_bytes()).hexdigest()
                with self.assertRaisesRegex(ValueError, "成员不一致"):
                    evaluate._authenticate_development_route(checkpoint, config, [episode], [episode], root / "development.json")

    def test_development_route_rejects_training_diagnostic_and_unbound_manifest(self):
        import evaluate
        args = ["--dataset", "aerialvln_s_v1", "--backend", "airsim", "--data-root", "fixture",
                "--split", "train", "--scene-id", "2", "--episode-id", "dev", "--output", "fixture_out",
                "--metric-protocol", "eval_adapter_v2", "--development-route-diagnostic"]
        for extra in ([], ["--development-split-manifest", "fixture", "--training-route-diagnostic"],
                      ["--development-split-manifest", "fixture", "--require-formal-protocol"]):
            with contextlib.redirect_stderr(io.StringIO()), self.assertRaises(SystemExit):
                evaluate.main(args + extra)

    def test_preflight_reports_missing_down_view_and_does_not_construct_simulator(self):
        import evaluate

        with TemporaryDirectory() as temporary:
            root = Path(temporary)
            trajectory, arguments = self.arguments(root)
            make_trajectory(trajectory, [[0, 0, 0], [1, 0, 0]])
            (trajectory / "obj_des.json").write_text(json.dumps(["the target"]), encoding="utf-8")
            with patch("evaluate._object_config", return_value={"position": [10, 0, 0], "validation_status": "metadata_intent_only_mesh_unverified"}), \
                    patch("uavnav.avln.airsim_env.AirSimEnv") as construct, \
                    patch("uavnav.avln.inference.WaypointPredictor") as predictor, \
                    contextlib.redirect_stdout(io.StringIO()):
                evaluate.main(arguments + ["--preflight-only"])
            construct.assert_not_called()
            predictor.assert_not_called()
            report = json.loads((root / "output/preflight.json").read_text(encoding="utf-8"))
            self.assertFalse(report["ready_for_formal_evaluation"])
            self.assertFalse(report["real_simulator_executed"])
            self.assertEqual(report["episodes"][0]["missing_down_frame_indices"], [0, 1])
            self.assertEqual(report["episodes"][0]["coordinate_mapping"], "not_verified")
            self.assertFalse((root / "output/metrics.json").exists())
            with contextlib.redirect_stdout(io.StringIO()), self.assertRaises(FileExistsError):
                evaluate.main(arguments + ["--preflight-only"])

    def test_formal_contract_is_rejected_before_simulator_or_checkpoint_loading(self):
        import evaluate
        from test_metadata import evaluation_protocol

        with TemporaryDirectory() as temporary:
            root = Path(temporary)
            _, arguments = self.arguments(root)
            contract = root / "protocol.json"
            contract.write_text(json.dumps(evaluation_protocol()), encoding="utf-8")
            with patch("uavnav.avln.airsim_env.AirSimEnv") as construct, \
                    patch("uavnav.avln.inference.WaypointPredictor") as predictor, \
                    contextlib.redirect_stderr(io.StringIO()), self.assertRaises(SystemExit):
                evaluate.main(arguments + ["--evaluation-protocol", str(contract)])
            construct.assert_not_called()
            predictor.assert_not_called()
            self.assertFalse((root / "output").exists())

    def test_preflight_matches_nonpadded_down_indices_and_rejects_duplicates(self):
        import evaluate

        with TemporaryDirectory() as temporary:
            root = Path(temporary)
            trajectory, arguments = self.arguments(root)
            make_trajectory(trajectory, [[0, 0, 0], [1, 0, 0]])
            (trajectory / "obj_des.json").write_text(json.dumps(["the target"]), encoding="utf-8")
            (trajectory / "DownCamera").mkdir()
            for number in (0, 1):
                Image.new("RGB", (2, 2)).save(trajectory / "DownCamera" / f"{number}.png")
            with patch("evaluate._object_config", return_value={"position": [10, 0, 0]}), contextlib.redirect_stdout(io.StringIO()):
                evaluate.main(arguments + ["--preflight-only"])
                report = json.loads((root / "output/preflight.json").read_text(encoding="utf-8"))
                self.assertEqual(report["episodes"][0]["missing_down_frame_indices"], [])
                Image.new("RGB", (2, 2)).save(trajectory / "DownCamera/000000.png")
                other_arguments = list(arguments)
                other_arguments[other_arguments.index("--output") + 1] = str(root / "duplicate")
                with self.assertRaisesRegex(ValueError, "重复帧索引"):
                    evaluate.main(other_arguments + ["--preflight-only"])

    def predictor(self):
        return SimpleNamespace(
            config={"history_frames": 8, "stop_enabled": True,
                    "task_protocol": {"camera": "FrontCamera", "success_distance_m": 1.0}},
            device=SimpleNamespace(type="cpu"),
            checkpoint_sha256=__import__("hashlib").sha256(b"synthetic checkpoint identity only").hexdigest(),
            predict=lambda **kwargs: {"body_displacement": [10, 0, 0], "stop_enabled": True,
                                      "stop_probability": 1.0},
        )

    def arguments(self, root):
        trajectory = root / "Map_test" / "trajectory"
        checkpoint = root / "mock.pt"
        checkpoint.write_bytes(b"synthetic checkpoint identity only")
        return trajectory, ["--backend", "airsim", "--trajectory", str(trajectory),
                            "--split", "test", "--checkpoint", str(checkpoint), "--device", "cpu",
                            "--output", str(root / "output"), "--scene-ready", "--scene-map-name", "Map_test",
                            "--rgb-order", "RGB", "--max-steps", "1"]

    def test_camera_and_radius_rejected_before_environment_construction(self):
        import evaluate

        with TemporaryDirectory() as temporary:
            _, arguments = self.arguments(Path(temporary))
            for extra in (["--camera-name", "DownCamera", "--stop-threshold", "0.8"],
                          ["--success-distance", "2", "--stop-threshold", "0.8"]):
                with self.subTest(extra=extra), patch("uavnav.avln.inference.WaypointPredictor", return_value=self.predictor()), \
                        patch("uavnav.avln.airsim_env.AirSimEnv") as construct, contextlib.redirect_stderr(io.StringIO()):
                    with self.assertRaises(SystemExit) as error:
                        evaluate.main(arguments + extra)
                    self.assertEqual(error.exception.code, 2)
                    construct.assert_not_called()

    def test_fixed_stop_model_retains_object_goal_and_radius_and_executes(self):
        import evaluate

        with TemporaryDirectory() as temporary:
            root = Path(temporary)
            trajectory, arguments = self.arguments(root)
            make_trajectory(trajectory, [[0, 0, 0], [1, 0, 0]])
            (trajectory / "obj_des.json").write_text(json.dumps(["the target"]), encoding="utf-8")
            env = SequenceEnv([[0, 0, 0], [10, 0, 0], [20, 0, 0]], terminal=False)
            original = env._observation

            def observation():
                value = original()
                value.timestamp, value.collision = float(env.index), False
                return value

            env._observation = observation
            with patch("uavnav.avln.inference.WaypointPredictor", return_value=self.predictor()), \
                    patch("evaluate._object_config", return_value={"position": [10, 0, 0]}), \
                    patch("uavnav.avln.airsim_env.AirSimEnv", return_value=env), contextlib.redirect_stdout(io.StringIO()):
                evaluate.main(arguments + ["--stop-mode", "fixed"])
            self.assertEqual(env.step_calls, 1)  # STOP probability 1 must be ignored in this control.
            episode = root / "output" / "episodes" / "Map_test_trajectory"
            metadata = json.loads((episode / "ori_info.json").read_text(encoding="utf-8"))
            rollout = json.loads((episode / "rollout.json").read_text(encoding="utf-8"))
            self.assertEqual(metadata["goal_position"], [10, 0, 0])
            self.assertEqual(metadata["success_distance"], 1.0)
            self.assertEqual(metadata["stop_protocol"], "fixed_horizon_stop_head_ignored")
            self.assertEqual(metadata["success_basis"], "final_within_success_distance_and_no_collision")
            self.assertEqual(rollout["termination_reason"], "max_steps")
            self.assertNotIn("terminal_decision", rollout)
            self.assertEqual(read_rollout_metrics(episode)["sr"], 100)


@unittest.skipIf(IMPORT_FAILURE is not None, IMPORT_FAILURE or "")
class FakeAirSimAdapterTests(unittest.TestCase):
    def make_env(self, client=None, **kwargs):
        client = client or FakeClient()
        env = AirSimEnv([10, 20, 30], YAW_90, rgb_order="RGB", action_duration=2, speed_limit=1,
                        sample_interval=0.1, vehicle_name="drone", client=client, sdk=FakeSdk, **kwargs)
        return env, client

    def test_reset_and_yaw_rotation_with_fixed_duration_speed_limit(self):
        env, client = self.make_env()
        first = env.reset()
        self.assertFalse(first.collision)  # Stale collision at reset is not a new event.
        self.assertEqual(client.calls[:2], [("confirmConnection",), ("simPause", True)])
        self.assertIn(("enableApiControl", True, "drone"), client.calls)
        self.assertIn(("armDisarm", True, "drone"), client.calls)
        self.assertIn(("simContinueForFrames", 1), client.calls)
        np.testing.assert_allclose([client.reset_velocity.x_val, client.reset_velocity.y_val, client.reset_velocity.z_val], [0, 0, 0])
        following = env.step([10, 0, 0])
        command = client.last_command
        np.testing.assert_allclose(command["velocity"], [0, 1, 0], atol=1e-6)
        self.assertEqual(command["duration"], 2)
        self.assertLessEqual(np.linalg.norm(command["velocity"]), 1 + 1e-10)
        self.assertAlmostEqual(command["yaw_mode"].yaw_or_rate, 90)
        self.assertFalse(command["yaw_mode"].is_rate)
        np.testing.assert_allclose(following.info["commanded_world_target"], [10, 30, 30], atol=1e-6)
        np.testing.assert_allclose(following.info["clipped_world_target"], [10, 22, 30], atol=1e-6)
        np.testing.assert_allclose(following.position, [10, 22, 30], atol=1e-6)
        self.assertTrue(following.info["action_clipped"])
        names = [call[0] for call in client.calls]
        self.assertIn("simContinueForTime", names)
        self.assertIn("simIsPause", names)
        self.assertIn("cancelLastTask", names)
        self.assertTrue(client.paused)
        self.assertAlmostEqual(sum(call[1] for call in client.calls if call[0] == "simContinueForTime"), 2)
        self.assertGreater(len(following.info["motion_samples"]), 1)
        self.assertEqual(len(following.info["motion_samples"]), 21)
        self.assertAlmostEqual(following.info["actual_sim_duration_s"], 2)
        samples = following.info["motion_samples"]
        np.testing.assert_allclose(samples[0]["position"], [10, 20, 30])
        np.testing.assert_allclose(samples[-1]["position"], following.position)
        self.assertTrue(all(a["timestamp"] < b["timestamp"] for a, b in zip(samples, samples[1:])))
        self.assertTrue(all(sample["collision"] is False for sample in samples))

    def test_collision_timestamp_filter_and_termination(self):
        env, client = self.make_env()
        env.reset()
        self.assertFalse(env.step([0, 0, 0]).collision)
        client.next_collision_timestamp = 101
        client.collision_after_sample = client.motion_sample_count + 3
        following = env.step([0, 0, 0])
        self.assertTrue(following.collision)
        self.assertTrue(following.done)
        self.assertEqual(following.termination_reason, "collision")
        self.assertLess(len(following.info["motion_samples"]), 20)
        self.assertEqual(len(following.info["motion_samples"]), 4)
        self.assertAlmostEqual(following.info["actual_sim_duration_s"], 0.3)
        self.assertTrue(following.info["motion_samples"][-1]["collision"])
        self.assertTrue(client.paused)
        with self.assertRaises(RuntimeError):
            env.step([1, 0, 0])

    def test_pause_restored_when_command_fails(self):
        env, client = self.make_env()
        env.reset()
        client.fail_continue = True
        with self.assertRaisesRegex(RuntimeError, "synthetic command failure"):
            env.step([1, 0, 0])
        self.assertEqual(client.calls[-2:], [("simPause", True), ("cancelLastTask", "drone")])

    def test_collision_during_reset_is_not_filtered_as_stale(self):
        client = FakeClient()
        client.collision_during_reset = 101
        env, _ = self.make_env(client)
        initial = env.reset()
        self.assertTrue(initial.collision)
        self.assertTrue(initial.done)
        self.assertEqual(initial.termination_reason, "collision")
        with self.assertRaises(RuntimeError):
            env.step([1, 0, 0])


@unittest.skipIf(IMPORT_FAILURE is not None, IMPORT_FAILURE or "")
class ClosedLoopMetricsTests(unittest.TestCase):
    def test_frozen_manifest_keeps_failed_episode_and_rejects_incomplete_or_duplicate_runs(self):
        from uavnav.avln.metadata import evaluation_manifest_sha256

        with TemporaryDirectory() as temporary:
            root = Path(temporary)
            evaluation = root / "evaluation/episodes"
            manifest = {"schema_version": 1, "scope": "subset_diagnostic", "split": "test",
                        "source_sha256": "a" * 64, "evaluation_protocol_sha256": None,
                        "episodes": [{"traj_id": "Map/success", "split": "test"},
                                     {"traj_id": "Map/failure", "split": "test"}]}
            digest = evaluation_manifest_sha256(manifest)
            success_metadata = {**episode_metadata(), "traj_id": "Map/success",
                                "evaluation_manifest_sha256": digest, "evaluation_protocol_sha256": None}
            failure_metadata = {**success_metadata, "traj_id": "Map/failure"}
            write_episode(evaluation / "first", metadata=success_metadata)
            incomplete = write_metrics(root / "incomplete", evaluation, evaluation_manifest=manifest)
            self.assertEqual(incomplete["status"], "closed_loop_invalid")
            self.assertIsNone(incomplete["metrics"]["sr"])
            failure = valid_episode_payload()
            failure["collision"] = True
            failure["records"][0]["collision"] = True
            write_episode(evaluation / "second", failure, failure_metadata)
            complete = write_metrics(root / "complete", evaluation, evaluation_manifest=manifest)
            self.assertEqual(complete["status"], "closed_loop")
            self.assertEqual(complete["metrics"]["sr"], 50)
            self.assertEqual(complete["evaluation_manifest"]["expected_episodes"], 2)
            self.assertEqual(complete["evaluation_scope"], "subset_diagnostic")
            write_episode(evaluation / "duplicate", metadata=success_metadata)
            duplicate = write_metrics(root / "duplicate", evaluation, evaluation_manifest=manifest)
            self.assertEqual(duplicate["status"], "closed_loop_invalid")
            self.assertIsNone(duplicate["metrics"]["spl"])

    def test_saved_manifest_detects_extra_wrong_split_hash_and_formal_claims(self):
        from uavnav.avln.metadata import evaluation_manifest_sha256

        for mutation in ("extra", "split", "hash", "protocol", "official"):
            with self.subTest(mutation=mutation), TemporaryDirectory() as temporary:
                root = Path(temporary)
                evaluation = root / "episodes"
                manifest = {"schema_version": 1, "scope": "subset_diagnostic", "split": "test",
                            "source_sha256": None, "evaluation_protocol_sha256": None,
                            "episodes": [{"traj_id": "Map/one", "split": "test"}]}
                if mutation == "official":
                    manifest.update(scope="official_split", source_sha256="a" * 64)
                metadata = {**episode_metadata(), "traj_id": "Map/one",
                            "evaluation_manifest_sha256": evaluation_manifest_sha256(manifest),
                            "evaluation_protocol_sha256": None}
                if mutation == "extra":
                    metadata["traj_id"] = "Map/extra"
                elif mutation == "split":
                    metadata["split"] = "unobject"
                elif mutation == "hash":
                    metadata["evaluation_manifest_sha256"] = "b" * 64
                elif mutation == "protocol":
                    metadata["evaluation_protocol_sha256"] = "c" * 64
                write_episode(evaluation / "one", metadata=metadata)
                (root / "evaluation_manifest.json").write_text(json.dumps(manifest), encoding="utf-8")
                result = write_metrics(root / "run", evaluation)
                self.assertEqual(result["status"], "closed_loop_invalid")
                self.assertIsNone(result["metrics"]["sr"])
                self.assertEqual(result["audit"]["issues"][0]["code"], "invalid_evaluation_manifest")

    def test_bound_episode_cannot_be_scored_without_manifest(self):
        with TemporaryDirectory() as temporary:
            root = Path(temporary)
            write_episode(root / "episodes/one", metadata={**episode_metadata(), "traj_id": "Map/one",
                          "evaluation_manifest_sha256": "a" * 64})
            result = write_metrics(root / "run", root / "episodes")
            self.assertEqual(result["status"], "closed_loop_invalid")
            self.assertIsNone(result["metrics"]["sr"])

    def test_rollout_only_bindings_require_manifest_and_single_episode_finds_saved_manifest(self):
        from uavnav.avln.metadata import evaluation_manifest_sha256

        for binding in ({"evaluation_manifest_sha256": "a" * 64},
                        {"evaluation_protocol_sha256": "b" * 64},
                        {"evaluation_scope": "official_split"}):
            with self.subTest(binding=binding), TemporaryDirectory() as temporary:
                root = Path(temporary)
                write_episode(root / "episodes/one", rollout={**valid_episode_payload(), **binding})
                result = write_metrics(root / "run", root / "episodes")
                self.assertEqual(result["status"], "closed_loop_invalid")
                self.assertIsNone(result["metrics"]["sr"])
        with TemporaryDirectory() as temporary:
            root = Path(temporary)
            manifest = {"schema_version": 1, "scope": "subset_diagnostic", "split": "test",
                        "source_sha256": None, "evaluation_protocol_sha256": None,
                        "episodes": [{"traj_id": "Map/one", "split": "test"}]}
            metadata = {**episode_metadata(), "traj_id": "Map/one",
                        "evaluation_manifest_sha256": evaluation_manifest_sha256(manifest)}
            write_episode(root / "episodes/one", metadata=metadata)
            (root / "evaluation_manifest.json").write_text(json.dumps(manifest), encoding="utf-8")
            result = write_metrics(root / "run", root / "episodes/one")
            self.assertEqual(result["status"], "closed_loop")
            self.assertEqual(result["metrics"]["sr"], 100)

    def test_zero_step_stop_is_sampling_neutral_but_other_definitions_are_strict(self):
        with TemporaryDirectory() as temporary:
            root = Path(temporary)
            metadata = episode_metadata()
            metadata.update(success_basis="final_within_success_distance_and_predicted_stop_and_no_collision",
                            stop_protocol="predicted_stop_before_action", stop_threshold=0.8)
            for name, positions, stop_at in (("zero", [[10, 0, 0], [20, 0, 0]], 0),
                                             ("moving", [[0, 0, 0], [10, 0, 0], [20, 0, 0]], 1)):
                env = SequenceEnv(positions, terminal=False)
                original = env._observation

                def observation():
                    value = original()
                    value.timestamp, value.collision = float(env.index), False
                    return value

                env._observation = observation
                result = rollout_episode(env, lambda **kwargs: {"body_displacement": [10, 0, 0],
                                         "stop_enabled": True, "stop_probability": 0.9 if env.index == stop_at else 0.1},
                                         "object", stop_threshold=0.8)
                if name == "moving":
                    result["records"][0]["info"] = {"motion_samples": [
                        {"position": [0, 0, 0], "orientation": IDENTITY, "timestamp": 0.0, "collision": False},
                        {"position": [10, 0, 0], "orientation": IDENTITY, "timestamp": 1.0, "collision": False},
                    ]}
                    moving = copy.deepcopy(result)
                per_episode_metadata = {**metadata, "reference_positions": [[10, 0, 0]]} if name == "zero" else metadata
                write_episode(root / "evaluation" / name, result, per_episode_metadata)
            scores = write_metrics(root / "run", eval_dir=root / "evaluation")
            self.assertEqual(scores["status"], "closed_loop")
            self.assertEqual(scores["metrics"]["sr"], 100)
            self.assertEqual(scores["audit"]["valid_rollouts"], 2)
            self.assertEqual({item["definition"]["position_sampling"] for item in scores["rollouts"]},
                             {"no_motion_stop", "sim_step_pose_samples"})
            conflicting = copy.deepcopy(metadata)
            conflicting["stop_protocol"] = "different_protocol"
            write_episode(root / "evaluation" / "different_protocol", result, conflicting)
            scores = write_metrics(root / "conflict", eval_dir=root / "evaluation")
            self.assertEqual(scores["status"], "closed_loop_invalid")
            moving["records"][0].pop("info")
            write_episode(root / "mixed_motion" / "endpoints", moving, metadata)
            write_episode(root / "mixed_motion" / "samples", result, metadata)
            scores = write_metrics(root / "motion_conflict", eval_dir=root / "mixed_motion")
            self.assertEqual(scores["status"], "closed_loop_invalid")

    def test_stop_threshold_metadata_tampering_is_rejected(self):
        with TemporaryDirectory() as temporary:
            rollout, metadata = valid_episode_payload(), episode_metadata()
            rollout["stop_threshold"] = 0.8
            metadata["stop_threshold"] = 0.7
            path = Path(temporary) / "tampered_threshold"
            write_episode(path, rollout, metadata)
            with self.assertRaisesRegex(ClosedLoopAuditError, "stop_threshold"):
                read_rollout_metrics(path)

    def test_motion_samples_measure_curved_path_and_mid_action_collision(self):
        with TemporaryDirectory() as temporary:
            rollout = valid_episode_payload()
            record = rollout["records"][0]
            record["info"] = {"motion_samples": [
                {"timestamp": 1.0, "position": [0, 0, 0], "orientation": IDENTITY, "collision": False},
                {"timestamp": 1.5, "position": [0, 10, 0], "orientation": IDENTITY, "collision": False},
                {"timestamp": 2.0, "position": [10, 0, 0], "orientation": IDENTITY, "collision": False},
            ]}
            record["inference_ms"] = 7.0
            path = Path(temporary) / "curved"
            write_episode(path, rollout)
            scores = read_rollout_metrics(path)
            self.assertAlmostEqual(scores["spl"], 100 * 10 / (10 + np.sqrt(200)))
            self.assertEqual(scores["details"]["position_samples"], 3)
            self.assertEqual(scores["definition"]["position_sampling"], "sim_step_pose_samples")
            record["info"]["motion_samples"][1]["collision"] = True
            collision_path = Path(temporary) / "mid_collision"
            write_episode(collision_path, rollout)
            collision_scores = read_rollout_metrics(collision_path)
            self.assertEqual(collision_scores["sr"], 0)
            self.assertEqual(collision_scores["spl"], 0)
            self.assertTrue(collision_scores["collision"])
            record["info"]["motion_samples"][1]["collision"] = False
            intermediate_goal = episode_metadata()
            intermediate_goal.update(goal_position=[0, 10, 0], reference_positions=[[0, 0, 0], [0, 10, 0]])
            oracle_path = Path(temporary) / "intermediate_goal"
            write_episode(oracle_path, rollout, intermediate_goal)
            oracle_scores = read_rollout_metrics(oracle_path)
            self.assertEqual(oracle_scores["sr"], 0)
            self.assertEqual(oracle_scores["osr"], 100)
            self.assertAlmostEqual(oracle_scores["ne"], np.sqrt(200))

    def test_motion_sample_endpoint_mismatch_or_time_reversal_is_rejected(self):
        with TemporaryDirectory() as temporary:
            for name, end_position, end_timestamp in [
                ("endpoint_mismatch", [9, 0, 0], 2.0),
                ("time_reversal", [10, 0, 0], 0.5),
            ]:
                with self.subTest(name=name):
                    rollout = valid_episode_payload()
                    rollout["records"][0]["info"] = {"motion_samples": [
                        {"timestamp": 1.0, "position": [0, 0, 0], "orientation": IDENTITY, "collision": False},
                        {"timestamp": end_timestamp, "position": end_position, "orientation": IDENTITY, "collision": False},
                    ]}
                    path = Path(temporary) / name
                    write_episode(path, rollout)
                    with self.assertRaises(ClosedLoopAuditError):
                        read_rollout_metrics(path)

    def test_mixed_sampling_or_stop_definitions_keep_full_metrics_unknown(self):
        with TemporaryDirectory() as temporary:
            for name in ("sampling", "stop_protocol"):
                with self.subTest(name=name):
                    root = Path(temporary) / name
                    evaluation = root / "evaluation"
                    metadata = episode_metadata()
                    metadata["stop_protocol"] = "max_steps"
                    write_episode(evaluation / "one", metadata=metadata)
                    other_rollout, other_metadata = valid_episode_payload(), copy.deepcopy(metadata)
                    if name == "sampling":
                        other_rollout["records"][0]["info"] = {"motion_samples": [
                            {"timestamp": 1.0, "position": [0, 0, 0], "orientation": IDENTITY, "collision": False},
                            {"timestamp": 2.0, "position": [10, 0, 0], "orientation": IDENTITY, "collision": False},
                        ]}
                    else:
                        other_metadata["stop_protocol"] = "model_stop"
                    write_episode(evaluation / "two", other_rollout, other_metadata)
                    payload = write_metrics(root / "run", eval_dir=evaluation)
                    self.assertEqual(payload["status"], "closed_loop_invalid")
                    self.assertEqual(payload["audit"]["valid_rollouts"], 2)
                    self.assertIn("mixed_metric_definitions", [issue["code"] for issue in payload["audit"]["issues"]])
                    self.assertTrue(all(value is None for value in payload["by_split"]["full"].values()))

    def test_valid_episode_and_parent_full_metrics(self):
        with TemporaryDirectory() as temporary:
            root = Path(temporary)
            evaluation = root / "evaluation"
            write_episode(evaluation / "one")
            scores = read_rollout_metrics(evaluation / "one")
            for key, expected in {"ne": 0.0, "sr": 100.0, "osr": 100.0, "spl": 100.0}.items():
                self.assertAlmostEqual(scores[key], expected)
            payload = write_metrics(root / "run", eval_dir=evaluation)
            self.assertEqual(payload["status"], "closed_loop")
            self.assertEqual(payload["audit"]["valid_rollouts"], 1)
            self.assertEqual({key: payload["metrics"][key] for key in ("ne", "sr", "osr", "spl")}, payload["by_split"]["full"])
            self.assertEqual(payload["by_split"]["full"], payload["by_split"]["test"])
            saved = json.loads((root / "run" / "metrics.json").read_text(encoding="utf-8"))
            self.assertEqual(saved, payload)

    def test_empty_or_missing_fields_are_audited(self):
        cases = {
            "empty_records": lambda rollout, metadata: rollout.update(records=[]),
            "missing_position": lambda rollout, metadata: rollout["records"][0].pop("position"),
            "missing_collision": lambda rollout, metadata: rollout.pop("collision"),
            "missing_goal": lambda rollout, metadata: metadata.pop("goal_position"),
            "not_done": lambda rollout, metadata: rollout.update(done=False),
            "unexecuted": lambda rollout, metadata: (rollout.update(actions_executed=False), rollout["records"][0].update(action_executed=False)),
        }
        with TemporaryDirectory() as temporary:
            for name, change in cases.items():
                with self.subTest(name=name):
                    rollout, metadata = valid_episode_payload(), episode_metadata()
                    change(rollout, metadata)
                    path = Path(temporary) / name
                    write_episode(path, rollout, metadata)
                    with self.assertRaises(ClosedLoopAuditError):
                        read_rollout_metrics(path)

    def test_replay_or_invalid_episode_cannot_improve_full_metrics(self):
        with TemporaryDirectory() as temporary:
            root = Path(temporary)
            evaluation = root / "evaluation"
            write_episode(evaluation / "valid")
            replay = valid_episode_payload()
            replay.update(status="replay_only", replay=True)
            write_episode(evaluation / "replay", replay)
            payload = write_metrics(root / "run", eval_dir=evaluation)
            self.assertEqual(payload["status"], "closed_loop_invalid")
            self.assertEqual(payload["audit"]["valid_rollouts"], 1)
            self.assertEqual(payload["audit"]["valid_replays"], 1)
            self.assertEqual(payload["audit"]["rejected_rollouts"], 0)
            self.assertIn("mixed_replay_and_closed_loop", [issue["code"] for issue in payload["audit"]["issues"]])
            self.assertTrue(all(payload["metrics"][key] is None for key in ("ne", "sr", "osr", "spl")))
            self.assertTrue(all(value is None for value in payload["by_split"]["full"].values()))

    def test_inconsistent_replay_status_is_rejected(self):
        with TemporaryDirectory() as temporary:
            path = Path(temporary) / "episode"
            rollout = valid_episode_payload()
            rollout.update(status="closed_loop", replay=True)
            write_episode(path, rollout)
            with self.assertRaises(ClosedLoopAuditError):
                read_rollout_metrics(path)

    def test_empty_evaluation_and_empty_legacy_log_are_rejected(self):
        with TemporaryDirectory() as temporary:
            root = Path(temporary)
            evaluation = root / "empty"
            evaluation.mkdir()
            payload = write_metrics(root / "run", eval_dir=evaluation)
            self.assertEqual(payload["status"], "closed_loop_invalid")
            self.assertEqual(payload["audit"]["issues"][0]["code"], "empty_eval_dir")
            legacy = root / "legacy"
            legacy.mkdir()
            info = {**episode_metadata(), "status": "closed_loop", "done": True, "actions_executed": True,
                    "termination_reason": "max_steps", "success": True, "oracle_success": True}
            (legacy / "ori_info.json").write_text(json.dumps(info), encoding="utf-8")
            with self.assertRaises(ClosedLoopAuditError):
                read_rollout_metrics(legacy)


@unittest.skipIf(IMPORT_FAILURE is not None, IMPORT_FAILURE)
class AerialRouteContractTests(unittest.TestCase):
    def provenance_environment(self):
        env, client = self.environment()
        camera = dict(X=0, Y=0, Z=0, Pitch=0, Roll=0, Yaw=0,
                      CaptureSettings=[{"ImageType": 0, "Width": 1, "Height": 1}])
        settings = {"Vehicles": {"Drone_1": {"Cameras": {"front_0": camera}}}}
        client.simGetSettingsString = lambda: json.dumps(settings)
        client.simGetCameraInfo = lambda *args, **kwargs: SimpleNamespace(fov=89.903625)
        client.paused = False
        original = client.simGetImages
        def images(*args, **kwargs):
            rgb, depth = original(*args, **kwargs)
            for response in (rgb, depth):
                response.camera_position = client.position
                response.camera_orientation = client.orientation
            depth.time_stamp = rgb.time_stamp + 1
            return [rgb, depth]
        client.simGetImages = images
        return env, client, settings

    def test_capture_provenance_requires_actual_camera_settings_fov_and_unpaused_scene(self):
        import hashlib
        env, client, settings = self.provenance_environment()
        scene_build = {"files": [{"path": "scene.pak", "size": 1, "sha256": "a" * 64}], "sha256": "b" * 64}
        provenance = env.capture_provenance(scene_build)
        canonical = json.dumps(settings, sort_keys=True, separators=(",", ":"), ensure_ascii=False, allow_nan=False)
        self.assertEqual(provenance["settings_sha256"], hashlib.sha256(canonical.encode()).hexdigest())
        self.assertEqual(provenance["camera_fov_degrees"], 89.903625)
        self.assertFalse(provenance["capture_policy"]["pause"])
        self.assertEqual(provenance["capture_policy"]["version"], "set_pose_unpaused_rgbd_bounded_rerequest_v3")
        self.assertEqual(provenance["capture_policy"]["clock_advance"], "none")
        self.assertEqual(provenance["capture_policy"]["timestamp_skew_policy"], "measure_only")
        self.assertEqual(provenance["camera_extrinsics"]["rotation_degrees"], [0, 0, 0])
        camera = settings["Vehicles"]["Drone_1"]["Cameras"]["front_0"]
        del camera["Pitch"]
        with self.assertRaisesRegex(ValueError, "外参"):
            env.capture_provenance(scene_build)
        camera["Pitch"] = 0
        for fov in (None, float("nan"), 0, 180):
            client.simGetCameraInfo = lambda *args, **kwargs: SimpleNamespace(fov=fov)
            with self.assertRaisesRegex(ValueError, "FOV"):
                env.capture_provenance(scene_build)
        client.simIsPause = lambda: True
        with self.assertRaisesRegex(RuntimeError, "暂停"):
            env.capture_provenance(scene_build)

    def test_capture_provenance_prefers_real_get_settings_string_and_requires_api(self):
        env, client, settings = self.provenance_environment()
        scene_build = {"files": [{"path": "scene.pak", "size": 1, "sha256": "a" * 64}], "sha256": "b" * 64}
        client.getSettingsString = lambda: json.dumps(settings)
        client.simGetSettingsString = lambda: self.fail("应优先调用真实getSettingsString方法")
        self.assertEqual(env.capture_provenance(scene_build)["settings"], settings)
        del client.getSettingsString
        del client.simGetSettingsString
        with self.assertRaisesRegex(RuntimeError, "设置API"):
            env.capture_provenance(scene_build)

    def test_scene_build_fingerprint_is_sorted_content_bound_and_rejects_links(self):
        import hashlib
        from uavnav.avln.airsim_env import aerial_scene_build
        with TemporaryDirectory() as temporary:
            root = Path(temporary)
            (root / "z.pak").write_bytes(b"last")
            (root / "nested").mkdir()
            (root / "nested" / "a.pak").write_bytes(b"first")
            build = aerial_scene_build(root)
            self.assertEqual([row["path"] for row in build["files"]], ["nested/a.pak", "z.pak"])
            self.assertEqual(build["files"][0]["size"], 5)
            self.assertEqual(build["files"][0]["sha256"], hashlib.sha256(b"first").hexdigest())
            canonical = json.dumps(build["files"], sort_keys=True, separators=(",", ":"), ensure_ascii=False, allow_nan=False)
            self.assertEqual(build["sha256"], hashlib.sha256(canonical.encode()).hexdigest())
            saved = root / "nested" / "Saved" / "Logs"
            saved.mkdir(parents=True)
            (saved / "runtime.log").write_bytes(b"mutable log")
            self.assertEqual(aerial_scene_build(root), build)
            self.assertEqual(build["exclusion_policy"]["directory_names"], ["Saved"])
            (root / "z.pak").write_bytes(b"modified")
            self.assertNotEqual(aerial_scene_build(root)["sha256"], build["sha256"])
            with patch.object(Path, "lstat", return_value=SimpleNamespace(st_mode=0o120777)):
                with self.assertRaisesRegex(ValueError, "链接"):
                    aerial_scene_build(root)

    def test_v2_collect_requires_declared_build_and_session_before_loading_data(self):
        from scripts.verify_stage2 import _aerial_main
        with TemporaryDirectory() as temporary:
            base = ["--dataset", "aerialvln_s_v1", "--mode", "collect", "--annotation-root", temporary,
                    "--output", str(Path(temporary) / "manifest.json"), "--scene-id", "2"]
            for extra in ([], ["--scene-build-dir", temporary], ["--capture-session-id", "one"],
                          ["--scene-build-dir", temporary, "--capture-session-id", " "]):
                with patch("uavnav.avln.data.load_aerial_episodes") as loader, contextlib.redirect_stderr(io.StringIO()):
                    with self.assertRaises(SystemExit):
                        _aerial_main(base + extra)
                    loader.assert_not_called()

    def test_v2_collect_records_sources_single_request_and_rejects_changed_fov(self):
        from scripts.verify_stage2 import _aerial_main
        from uavnav.avln.data import validate_aerial_render_protocol
        episode = {"scene_id": 2, "episode_id": "one", "actions": [1, 0], "start_rotation": [1, 0, 0, 0],
                   "start_position": [0, 0, -10], "reference_path": [[0, 0, -10, 0, 0, 0], [5, 0, -10, 0, 0, 0]],
                   "_annotation_sha256": "a" * 64, "_episode_sha256": "b" * 64, "_quarantine_reason": None}
        with TemporaryDirectory() as temporary:
            root = Path(temporary)
            build = root / "build"
            build.mkdir()
            (build / "scene.pak").write_bytes(b"scene")
            base = ["--dataset", "aerialvln_s_v1", "--mode", "collect", "--annotation-root", temporary,
                    "--scene-id", "2", "--episodes", "1", "--scene-build-dir", str(build), "--capture-session-id", "scene2-start-1"]
            env, client, _ = self.provenance_environment()
            with patch("uavnav.avln.data.load_aerial_episodes", return_value=[episode]), \
                 patch("uavnav.avln.data.load_aerial_samples", return_value=[1, 2]), \
                 patch("uavnav.avln.airsim_env.AerialRouteEnv", return_value=env):
                _aerial_main(base + ["--output", str(root / "good.json")])
            payload = json.loads((root / "good.json").read_text(encoding="utf-8"))
            self.assertEqual(payload["capture_session_id"], "scene2-start-1")
            self.assertEqual(payload["render_protocol"]["protocol_version"], "aerialvln_s_pose_rgb_v2")
            validate_aerial_render_protocol(payload["render_protocol"])
            self.assertEqual(sum(call[0] == "images" for call in client.calls), 16)  # 7 reset/step pairs + 2 frames.
            self.assertFalse(any(call[0] == "simPause" for call in client.calls))
            for frame in payload["episodes"][0]["frames"]:
                self.assertLessEqual(frame["pose_requested_ns"], frame["request_started_ns"])
                self.assertLessEqual(frame["request_started_ns"], frame["response_received_ns"])
                self.assertEqual(frame["response_camera_position"], frame["observed_position"])
                self.assertGreater(frame["image_timestamp_ns"], 0)
            env, client, _ = self.provenance_environment()
            fovs = iter((89.903625, 80.))
            client.simGetCameraInfo = lambda *args, **kwargs: SimpleNamespace(fov=next(fovs))
            with patch("uavnav.avln.data.load_aerial_episodes", return_value=[episode]), \
                 patch("uavnav.avln.airsim_env.AerialRouteEnv", return_value=env):
                with self.assertRaisesRegex(RuntimeError, "前后"):
                    _aerial_main(base + ["--output", str(root / "changed.json")])
            self.assertFalse((root / "changed.json").exists())

    def test_legacy_collect_keeps_environment_without_new_provenance_apis(self):
        from scripts.verify_stage2 import _aerial_main
        episode = {"scene_id": 2, "episode_id": "one", "actions": [1, 0], "start_rotation": [1, 0, 0, 0],
                   "start_position": [0, 0, -10], "reference_path": [[0, 0, -10, 0, 0, 0], [5, 0, -10, 0, 0, 0]],
                   "_annotation_sha256": "a" * 64, "_episode_sha256": "b" * 64, "_quarantine_reason": None}
        with TemporaryDirectory() as temporary:
            output = Path(temporary) / "legacy.json"
            env, client = self.environment()
            self.assertFalse(hasattr(client, "simGetSettingsString"))
            with patch("uavnav.avln.data.load_aerial_episodes", return_value=[episode]), \
                 patch("uavnav.avln.data.load_aerial_samples", return_value=[1, 2]), \
                 patch("uavnav.avln.airsim_env.AerialRouteEnv", return_value=env):
                _aerial_main(["--dataset", "aerialvln_s_v1", "--mode", "collect", "--annotation-root", temporary,
                              "--output", str(output), "--scene-id", "2", "--episodes", "1", "--render-protocol", "legacy-v1"])
            payload = json.loads(output.read_text(encoding="utf-8"))
            self.assertEqual(payload["render_protocol"]["protocol_version"], "aerialvln_s_pose_rgb_v1")
            self.assertNotIn("provenance", payload["render_protocol"])
            self.assertNotIn("capture_session_id", payload)

    def test_resumable_collection_reuses_sealed_routes_preserves_partial_attempt_and_instruction_ids(self):
        import argparse
        import hashlib
        import scripts.verify_stage2 as verification
        episode = {"scene_id": 2, "episode_id": "one", "actions": [1, 0], "start_rotation": [1, 0, 0, 0],
                   "start_position": [0, 0, -10], "reference_path": [[0, 0, -10, 0, 0, 0], [5, 0, -10, 0, 0, 0]],
                   "_annotation_sha256": "a" * 64, "_episode_sha256": "b" * 64, "_quarantine_reason": None}
        duplicate = {**copy.deepcopy(episode), "episode_id": "one_instruction2", "_episode_sha256": "c" * 64}
        other = {**copy.deepcopy(episode), "episode_id": "two", "actions": [1, 1, 0], "_episode_sha256": "d" * 64,
                 "reference_path": episode["reference_path"] + [[10, 0, -10, 0, 0, 0]]}
        with patch("shutil.disk_usage", return_value=SimpleNamespace(free=20 * 1024 ** 3)), TemporaryDirectory() as temporary:
            root = Path(temporary)
            build = root / "build"
            build.mkdir()
            (build / "scene.pak").write_bytes(b"scene")
            args = SimpleNamespace(scene_id=2, episodes=2, render_protocol="v2", scene_build_dir=build,
                capture_session_id="one-running-scene", annotation_root=root, split="train", sampling="representative",
                save_depth=False, port=41451, output=root / "train.json")
            selected = [episode, duplicate, other]
            env, _, _ = self.provenance_environment()
            original_capture = verification._capture_collection_frame
            captures = 0
            def capture(*values):
                nonlocal captures
                captures += 1
                if captures == 4:
                    raise RuntimeError("temporary_rgb_rpc_failure")
                return original_capture(*values)
            with patch("uavnav.avln.data.load_aerial_episodes", return_value=selected), \
                 patch("uavnav.avln.data.load_aerial_samples", return_value=[1]), \
                 patch("uavnav.avln.airsim_env.AerialRouteEnv", return_value=env), \
                 patch.object(env, "finish", wraps=env.finish) as finish, \
                 patch.object(verification, "_capture_collection_frame", side_effect=capture):
                with self.assertRaisesRegex(RuntimeError, "temporary_rgb_rpc_failure"):
                    verification._collect_aerial_resumable(args, argparse.ArgumentParser())
                finish.assert_called_once()
            self.assertFalse(args.output.exists())
            partial = json.loads((root / "train.partial.json").read_text(encoding="utf-8"))
            self.assertEqual(partial["status"], "incomplete")
            self.assertEqual(partial["completed_route_count"], 1)
            evidence = root / "train.collection"
            sealed_route = json.loads(next(evidence.rglob("route.json")).read_text(encoding="utf-8"))
            self.assertEqual(sealed_route["episode_ids"], ["one", "one_instruction2"])
            preserved = {path: hashlib.sha256(path.read_bytes()).hexdigest() for path in evidence.rglob("*")
                         if path.is_file() and path.name != "collection_journal.jsonl"}
            rgb_path = root / sealed_route["frames"][0]["rgb"]["path"]
            original_rgb = rgb_path.read_bytes()
            rgb_path.write_bytes(b"tampered")
            with patch("uavnav.avln.data.load_aerial_episodes", return_value=selected), \
                 patch("uavnav.avln.airsim_env.AerialRouteEnv") as factory:
                with self.assertRaisesRegex(ValueError, "SHA256"):
                    verification._collect_aerial_resumable(args, argparse.ArgumentParser())
                factory.assert_not_called()
            rgb_path.write_bytes(original_rgb)
            env, _, _ = self.provenance_environment()
            with patch("uavnav.avln.data.load_aerial_episodes", return_value=selected), \
                 patch("uavnav.avln.data.load_aerial_samples", return_value=[1]), \
                 patch("uavnav.avln.airsim_env.AerialRouteEnv", return_value=env), \
                 patch.object(verification, "_capture_collection_frame", wraps=original_capture) as capture:
                verification._collect_aerial_resumable(args, argparse.ArgumentParser())
                self.assertEqual(capture.call_count, 3)
            value = json.loads(args.output.read_text(encoding="utf-8"))
            self.assertEqual(len(value["episodes"]), 3)
            self.assertEqual(value["collection_status"], "complete")
            self.assertEqual(value["scope"], "development_scene_subset")
            self.assertTrue(all(result is None for result in value["metrics"].values()))
            for path, digest in preserved.items():
                self.assertEqual(hashlib.sha256(path.read_bytes()).hexdigest(), digest)
            starts = [row for row in verification._collection_journal(evidence, []) if row["event"] == "started"]
            self.assertEqual(len(starts), 3)
            with patch("uavnav.avln.data.load_aerial_episodes", return_value=selected), \
                 patch("uavnav.avln.data.load_aerial_samples", return_value=[1]), \
                 patch("uavnav.avln.airsim_env.AerialRouteEnv") as factory:
                verification._collect_aerial_resumable(args, argparse.ArgumentParser())
                factory.assert_not_called()

    def resumable_preflight_fixture(self, root):
        episode = {"scene_id": 2, "episode_id": "one", "actions": [1, 0], "start_rotation": [1, 0, 0, 0],
                   "start_position": [0, 0, -10], "reference_path": [[0, 0, -10, 0, 0, 0], [5, 0, -10, 0, 0, 0]],
                   "_annotation_sha256": "a" * 64, "_episode_sha256": "b" * 64, "_quarantine_reason": None}
        build = root / "build"
        build.mkdir()
        (build / "scene.pak").write_bytes(b"scene")
        args = SimpleNamespace(scene_id=2, episodes=1, render_protocol="v2", scene_build_dir=build,
            capture_session_id="preflight-scene", annotation_root=root, split="train", sampling="representative",
            save_depth=False, port=41451, output=root / "train.json")
        return args, episode

    def test_resumable_preflight_failure_keeps_each_attempt_audit_and_success_checks(self):
        import argparse
        import scripts.verify_stage2 as verification
        with TemporaryDirectory() as temporary:
            root = Path(temporary)
            args, episode = self.resumable_preflight_fixture(root)
            records = []
            with patch("uavnav.avln.data.load_aerial_episodes", return_value=[episode]), \
                 patch("uavnav.avln.data.load_aerial_samples", return_value=[1]), \
                 patch("shutil.disk_usage", return_value=SimpleNamespace(free=20 * 1024 ** 3)):
                for ordinal in (1, 2):
                    env, _, _ = self.provenance_environment()
                    error = RuntimeError("fixture_refresh_rpc_failure")
                    error.capture_audit = {"refresh_error": "rpc unsupported", "capture_paused_after": False}
                    with patch("uavnav.avln.airsim_env.AerialRouteEnv", return_value=env), \
                         patch.object(env, "reset", side_effect=error):
                        with self.assertRaisesRegex(RuntimeError, "fixture_refresh_rpc_failure"):
                            verification._collect_aerial_resumable(args, argparse.ArgumentParser())
                    path = root / "train.collection" / f"preflight_attempt_{ordinal:04d}.json"
                    record = json.loads(path.read_text(encoding="utf-8"))
                    self.assertEqual(record["stage"], "action_reset")
                    self.assertEqual(record["action"], 1)
                    self.assertEqual(record["status"], "failed")
                    self.assertEqual(record["capture_audit"], error.capture_audit)
                    self.assertEqual(record["capture_session_id"], args.capture_session_id)
                    self.assertEqual(record["annotation_sha256"], episode["_annotation_sha256"])
                    self.assertEqual(verification._collection_journal(path.parent, []), [])
                    records.append((path, path.read_bytes()))
                env, _, _ = self.provenance_environment()
                with patch("uavnav.avln.airsim_env.AerialRouteEnv", return_value=env):
                    verification._collect_aerial_resumable(args, argparse.ArgumentParser())
                passed = json.loads((root / "train.collection/preflight_attempt_0003.json").read_text(encoding="utf-8"))
                self.assertEqual(passed["status"], "passed")
                self.assertEqual(passed["min_free_gib"], 12)
                self.assertEqual([row["action"] for row in passed["simulator_action_checks"]], list(range(1, 8)))
                self.assertTrue(all(row["position_error_m"] <= .02 and row["rotation_error_rad"] <= 1e-4
                                    for row in passed["simulator_action_checks"]))
                self.assertTrue(all(row["capture_audit"] is not None for row in passed["simulator_action_checks"]))
                for path, contents in records:
                    self.assertEqual(path.read_bytes(), contents)

    def test_resumable_disk_gate_stops_before_frame_save_and_preserves_partial_route(self):
        import argparse
        import scripts.verify_stage2 as verification
        with TemporaryDirectory() as temporary:
            root = Path(temporary)
            args, episode = self.resumable_preflight_fixture(root)
            env, _, _ = self.provenance_environment()
            high = SimpleNamespace(free=20 * 1024 ** 3)
            low = SimpleNamespace(free=11 * 1024 ** 3)
            with patch("uavnav.avln.data.load_aerial_episodes", return_value=[episode]), \
                 patch("uavnav.avln.airsim_env.AerialRouteEnv", return_value=env), \
                 patch("shutil.disk_usage", side_effect=[high] * 4 + [low]):
                with self.assertRaisesRegex(RuntimeError, "空间不足"):
                    verification._collect_aerial_resumable(args, argparse.ArgumentParser())
            folder = root / "train.collection"
            failure = json.loads(next(folder.rglob("failure.json")).read_text(encoding="utf-8"))
            self.assertEqual(failure["completed_frames"], 1)
            self.assertEqual(failure["active_frame_index"], 1)
            self.assertEqual(failure["disk_space_audit"]["free_bytes"], low.free)
            self.assertEqual(len(list(folder.rglob("*.png"))), 1)
            self.assertFalse(args.output.exists())
            self.assertEqual([row["event"] for row in verification._collection_journal(folder, [])], ["started", "failed"])

    def test_resumable_initial_disk_gate_persists_failure_without_constructing_environment(self):
        import argparse
        import scripts.verify_stage2 as verification
        with TemporaryDirectory() as temporary:
            root = Path(temporary)
            args, episode = self.resumable_preflight_fixture(root)
            with patch("uavnav.avln.data.load_aerial_episodes", return_value=[episode]), \
                 patch("uavnav.avln.airsim_env.AerialRouteEnv") as factory, \
                 patch("shutil.disk_usage", return_value=SimpleNamespace(free=11 * 1024 ** 3)):
                with self.assertRaisesRegex(RuntimeError, "空间不足"):
                    verification._collect_aerial_resumable(args, argparse.ArgumentParser())
                factory.assert_not_called()
            record = json.loads((root / "train.collection/preflight_attempt_0001.json").read_text(encoding="utf-8"))
            self.assertEqual(record["stage"], "disk_space")
            self.assertEqual(record["status"], "failed")
            self.assertIsNone(record["capture_audit"])

    def test_resumable_disk_gate_rechecks_before_rgb_and_depth_writes(self):
        import argparse
        import scripts.verify_stage2 as verification
        for high_checks, expected_rgb in ((3, 0), (4, 1)):
            with self.subTest(high_checks=high_checks), TemporaryDirectory() as temporary:
                root = Path(temporary)
                args, episode = self.resumable_preflight_fixture(root)
                args.save_depth = True
                env, _, _ = self.provenance_environment()
                high = SimpleNamespace(free=20 * 1024 ** 3)
                low = SimpleNamespace(free=11 * 1024 ** 3)
                with patch("uavnav.avln.data.load_aerial_episodes", return_value=[episode]), \
                     patch("uavnav.avln.airsim_env.AerialRouteEnv", return_value=env), \
                     patch("shutil.disk_usage", side_effect=[high] * high_checks + [low]):
                    with self.assertRaisesRegex(RuntimeError, "空间不足"):
                        verification._collect_aerial_resumable(args, argparse.ArgumentParser())
                folder = root / "train.collection"
                failure = json.loads(next(folder.rglob("failure.json")).read_text(encoding="utf-8"))
                self.assertEqual(failure["completed_frames"], 0)
                self.assertEqual(failure["active_frame_index"], 0)
                self.assertEqual(len(list(folder.rglob("*.png"))), expected_rgb)
                self.assertEqual(len(list(folder.rglob("*.npy"))), 0)

    def test_collection_space_threshold_rejects_invalid_cli_and_programmatic_values(self):
        import argparse
        import scripts.verify_stage2 as verification
        for value in (True, False, float("nan"), float("inf"), -1):
            with self.subTest(value=value), patch("shutil.disk_usage") as disk:
                with self.assertRaises(ValueError):
                    verification._check_collection_space(Path("."), value)
                disk.assert_not_called()
        with TemporaryDirectory() as temporary:
            root = Path(temporary)
            args, _ = self.resumable_preflight_fixture(root)
            for value in (True, float("nan"), float("inf"), -1):
                args.min_free_gib = value
                with self.subTest(value=value), patch("uavnav.avln.data.load_aerial_episodes") as source, \
                     contextlib.redirect_stderr(io.StringIO()):
                    with self.assertRaises(SystemExit):
                        verification._collect_aerial_resumable(args, argparse.ArgumentParser())
                    source.assert_not_called()
            for value in ("nan", "inf", "-1", "true"):
                with self.subTest(cli=value), contextlib.redirect_stderr(io.StringIO()):
                    with self.assertRaises(SystemExit):
                        verification._aerial_main(["--dataset", "aerialvln_s_v1", "--mode", "collect",
                            "--annotation-root", str(root), "--output", str(root / "cli.json"),
                            "--min-free-gib", value])

    def dagger_cli_fixture(self, root, *, train_ids=None, validation_ids=None, seed=0):
        """CPU事务集成fixture；网络/图教师为stub，像素、动作、来源审计运行真实代码。"""
        import hashlib
        import importlib.util
        spec = importlib.util.spec_from_file_location("uavnav_data_contract_fixture", Path(__file__).with_name("test_data.py"))
        fixtures = importlib.util.module_from_spec(spec)
        spec.loader.exec_module(fixtures)
        source = root / "train.json"
        source.write_text(json.dumps({"episodes": [fixtures.aerial_episode("trained"), fixtures.aerial_episode("heldout")]}), encoding="utf-8")
        source_sha = hashlib.sha256(source.read_bytes()).hexdigest()
        run = root / "run"
        (run / "weights").mkdir(parents=True)
        checkpoint = run / "weights" / "last.pt"
        checkpoint.write_bytes(b"cpu_stub_checkpoint_not_real_weights")
        partition = {"data_protocol": "aerialvln_s_v1", "train_annotation_sha256": source_sha,
                     "train_episode_ids": train_ids if train_ids is not None else ["2/trained"],
                     "validation_episode_ids": validation_ids if validation_ids is not None else ["2/heldout"]}
        split_path = run / "split_manifest.json"
        split_path.write_text(json.dumps(partition), encoding="utf-8")
        split_sha = hashlib.sha256(split_path.read_bytes()).hexdigest()
        build = root / "build"
        build.mkdir()
        (build / "scene.pak").write_bytes(b"fixture_scene_build")
        kinds = ("on_route_pose_orientation", "off_route_pose", "route_order", "stop_pose", "graph_connectivity")
        review = {"schema_version": 1, "protocol": "airvln_upstream_pose_guard_v1", "scene_id": 2,
                  "source_sha256": {name: "a" * 64 for name in
                                    ("utils/env_utils.py", "utils/shorest_path_sensor.py", "airsim_plugin/airsim_settings.py")},
                  "assets_sha256": {"graph": "b" * 64, "tokens": "c" * 64},
                  "checks": {kind: True for kind in kinds}, "cases": [
                      {"name": kind, "kind": kind, "current_position": [0, 0, -10],
                       "current_orientation_xyzw": [0, 0, 0, 1], "reference_stage": 0,
                       "expected_action": 7, "observed_action": 7} for kind in kinds]}
        contract_sha = hashlib.sha256(json.dumps(review, sort_keys=True, separators=(",", ":"),
                                               ensure_ascii=False, allow_nan=False).encode()).hexdigest()
        review_path = root / "review.json"
        review_path.write_text(json.dumps(review), encoding="utf-8")
        class Policy:
            def __init__(self, checkpoint, device):
                self.checkpoint_sha256 = hashlib.sha256(Path(checkpoint).read_bytes()).hexdigest()
                self.config = {"data_protocol": "aerialvln_s_v1", "history_policy": "action_onehot8_v1",
                    "seed": seed, "split_manifest_sha256": split_sha, "history_frames": 2,
                    "architecture": "aerial_route_recurrent_rgbd_v3", "input_modality": "rgbd"}
            def reset_episode(self):
                self.actions = iter((1, 2, 0))
            def predict_action(self, image, instruction, history, *, depth):
                if np.asarray(depth).shape != (256, 256, 1) or not np.allclose(depth, .5):
                    raise ValueError("fixture当前真实深度没有进入策略")
                action = next(self.actions)
                return {"action": action, "action_probabilities": np.eye(8)[action].tolist()}
        class Teacher:
            def __init__(self, *unused):
                self.review, self.contract_sha256 = copy.deepcopy(review), contract_sha
            def reset_episode(self, episode):
                self.episode = episode
            def label(self, obs, step, history):
                return {"action": (7, 1, 4)[step], "reference_stage": step,
                        "teacher_protocol": "airvln_upstream_pose_guard_v1", "teacher_contract_sha256": contract_sha}
        env, client, settings = self.provenance_environment()
        settings["Vehicles"]["Drone_1"]["Cameras"]["front_0"]["CaptureSettings"][0].update(Width=224, Height=224)
        original_images = client.simGetImages
        def images(*args, **kwargs):
            rgb, depth = original_images(*args, **kwargs)
            rgb.width = rgb.height = 224
            rgb.image_data_uint8 = bytes((10, 20, 30)) * (224 * 224)
            depth.width = depth.height = 256
            depth.image_data_float = [.5 * 100] * (256 * 256)
            return [rgb, depth]
        client.simGetImages = images
        args = ["--dataset", "aerialvln_s_v1", "--mode", "dagger", "--annotation-root", str(root),
                "--output", str(root / "dagger.json"), "--split", "train", "--scene-id", "2",
                "--sampling", "all", "--episodes", "1", "--device", "cpu", "--checkpoint", str(checkpoint),
                "--scene-build-dir", str(build), "--capture-session-id", "fixture_scene_session",
                "--collection-id", "fixture_round1", "--beta", "0", "--max-steps", "3", "--save-depth",
                "--teacher-upstream-root", str(root), "--teacher-nav-graph", str(root),
                "--teacher-token-dict", str(root), "--teacher-review", str(review_path)]
        return args, Policy, Teacher, env, source_sha

    def test_dagger_cli_collects_actual_rgbd_and_history_then_resume_validates_without_environment(self):
        import hashlib
        import scripts.verify_stage2 as verification
        from uavnav.avln.metadata import AERIALVLN_S_RELEASE
        from uavnav.avln.data import load_aerial_dagger_samples
        with TemporaryDirectory() as temporary:
            root = Path(temporary)
            args, Policy, Teacher, env, source_sha = self.dagger_cli_fixture(root)
            with patch.dict(AERIALVLN_S_RELEASE, {"train": {"sha256": source_sha, "episodes": 2}}), \
                 patch("uavnav.avln.inference.AerialActionPredictor", Policy), \
                 patch("uavnav.avln.geometry.AirVLNDaggerTeacher", Teacher), \
                 patch("uavnav.avln.airsim_env.AerialRouteEnv", return_value=env) as factory:
                samples = verification._aerial_main(args)
                self.assertEqual(factory.call_count, 1)
                self.assertEqual([sample["action"] for sample in samples], [7, 1, 4])
                self.assertEqual(samples[-1]["history"].argmax(-1).tolist(), [1, 2])
                self.assertTrue(all(sample["source_episode_id"] == "trained" for sample in samples))
                self.assertTrue(all("depth" in sample for sample in samples))
                output = root / "dagger.json"
                original_manifest = output.read_bytes()
                self.assertEqual(len(load_aerial_dagger_samples(root, output, 2, True)), 3)
                factory.reset_mock()
                verification._aerial_main(args + ["--resume-collection"])
                factory.assert_not_called()
                self.assertEqual(output.read_bytes(), original_manifest)
                receipt = next((root / "dagger.dagger").rglob("receipt.json"))
                manifest = json.loads(original_manifest)
                rgb = root / manifest["episodes"][0]["frames"][0]["rgb"]["path"]
                checkpoint = root / "run" / "weights" / "last.pt"
                for target, replacement, error_text in ((checkpoint, b"changed_checkpoint", "续采"),
                        (receipt, b"{}", "receipt"), (rgb, b"modified_sensor", "SHA256")):
                    original = target.read_bytes()
                    target.write_bytes(replacement)
                    with self.subTest(target=target.name), self.assertRaisesRegex(ValueError, error_text):
                        verification._aerial_main(args + ["--resume-collection"])
                    factory.assert_not_called()
                    target.write_bytes(original)
                verification._aerial_main(args + ["--resume-collection"])
                factory.assert_not_called()
                self.assertEqual(hashlib.sha256(output.read_bytes()).hexdigest(), hashlib.sha256(original_manifest).hexdigest())

    def test_dagger_cli_rejects_nontrain_members_development_overlap_and_nonzero_seed_before_environment(self):
        import scripts.verify_stage2 as verification
        from uavnav.avln.metadata import AERIALVLN_S_RELEASE
        for train_ids, val_ids, seed in ((["2/not_in_source"], [], 0), (["2/heldout"], ["2/heldout"], 0), (["2/trained"], [], 1)):
            with self.subTest(train_ids=train_ids, seed=seed), TemporaryDirectory() as temporary:
                args, Policy, Teacher, _, source_sha = self.dagger_cli_fixture(Path(temporary),
                                      train_ids=train_ids, validation_ids=val_ids, seed=seed)
                with patch.dict(AERIALVLN_S_RELEASE, {"train": {"sha256": source_sha, "episodes": 2}}), \
                     patch("uavnav.avln.inference.AerialActionPredictor", Policy), \
                     patch("uavnav.avln.geometry.AirVLNDaggerTeacher", Teacher), \
                     patch("uavnav.avln.airsim_env.AerialRouteEnv") as factory:
                    with self.assertRaisesRegex(ValueError, "训练成员|seed0"):
                        verification._aerial_main(args)
                    factory.assert_not_called()

    def test_duplicate_sensor_frame_rejected_and_response_metadata_preserved(self):
        env, client = self.environment()
        original = client.simGetImages
        def response(requests, **kwargs):
            rgb, depth = original(requests, **kwargs)
            rgb.camera_position = FakeVector(.5, 0, -10)
            rgb.camera_orientation = FakeQuaternion(0, 0, 0, 1)
            depth.time_stamp = rgb.time_stamp + 1
            return [rgb, depth]
        client.simGetImages = response
        first = env.reset()
        self.assertEqual(first.info["response_camera_position"], [.5, 0, -10])
        self.assertEqual(first.info["depth_timestamp_ns"], first.info["image_timestamp_ns"] + 1)
        # 模拟场景无法推进仿真时钟：有限重试后仍必须拒绝重复传感器帧。
        client.simContinueForFrames = lambda frames: setattr(client, "paused", True)
        client.simSetVehiclePose = lambda pose, **kw: None
        with self.assertRaisesRegex(RuntimeError, "时间戳"):
            env.step(2)

    def strict_capture_environment(self, policy_version="set_pose_unpaused_rgbd_bounded_refresh_v2"):
        env, client, _ = self.provenance_environment()
        env.capture_provenance({"sha256": "b" * 64, "files": []})
        # 原刷新合同回归显式固定旧路径；新合同测试单独选择v3。
        env.capture_policy_version = policy_version
        env.reset()
        return env, client

    def test_rgbd_rerequest_v3_recovers_without_clock_advance_or_pause_api_calls(self):
        env, client = self.strict_capture_environment("set_pose_unpaused_rgbd_bounded_rerequest_v3")
        original = client.simGetImages
        stamps = (env.last_image_timestamp_ns, env.last_depth_timestamp_ns)
        count = 0
        def images(*args, **kwargs):
            nonlocal count
            count += 1
            rgb, depth = original(*args, **kwargs)
            if count == 1:
                rgb.time_stamp, depth.time_stamp = stamps
            return [rgb, depth]
        client.simGetImages = images
        # 当前真实ComputerVision构建不支持推进接口；缺方法亦不能影响重请求。
        client.simContinueForFrames = None
        client.simContinueForTime = None
        with patch.object(client, "simPause", side_effect=AssertionError("new capture must not pause")), \
             patch("uavnav.avln.airsim_env.time.sleep", side_effect=AssertionError("must not sleep")):
            obs = env.step(2)
        self.assertEqual(count, 2)
        self.assertEqual(obs.info["image_refresh_attempts"], 1)
        self.assertEqual(obs.info["image_refresh_protocol"], "bounded_rgbd_rerequest_v3")
        self.assertFalse(client.paused)
        self.assertFalse(obs.info["capture_paused_after"])
        first, final = obs.info["image_refresh_audit"]
        self.assertEqual(set(first["rejection_reasons"]), {"rgb_timestamp_not_advanced", "depth_timestamp_not_advanced"})
        self.assertTrue(final["rgb_fresh"] and final["depth_fresh"])
        self.assertEqual(final["rejection_reasons"], [])

    def test_rgbd_rerequest_v3_rejects_repeated_rgb_or_depth_at_limit(self):
        for stale in ("both", "depth"):
            with self.subTest(stale=stale):
                env, client = self.strict_capture_environment("set_pose_unpaused_rgbd_bounded_rerequest_v3")
                original = client.simGetImages
                stamps = (env.last_image_timestamp_ns, env.last_depth_timestamp_ns)
                def images(*args, **kwargs):
                    rgb, depth = original(*args, **kwargs)
                    depth.time_stamp = stamps[1]
                    if stale == "both":
                        rgb.time_stamp = stamps[0]
                    return [rgb, depth]
                client.simGetImages = images
                with patch.object(client, "simContinueForFrames", side_effect=AssertionError("no clock advance")), \
                     patch.object(client, "simPause", side_effect=AssertionError("no pause")), \
                     patch("uavnav.avln.airsim_env.time.sleep", side_effect=AssertionError("no sleep")):
                    with self.assertRaisesRegex(RuntimeError, "重新请求3次") as caught:
                        env.step(2)
                audit = caught.exception.capture_audit
                self.assertEqual(audit["image_refresh_attempts"], 3)
                self.assertEqual(len(audit["image_refresh_audit"]), 4)
                self.assertTrue(all(not item["depth_fresh"] for item in audit["image_refresh_audit"]))
                self.assertEqual((env.last_image_timestamp_ns, env.last_depth_timestamp_ns), stamps)
                self.assertFalse(client.paused)
                json.dumps(audit, allow_nan=False)

    def test_rgbd_rerequest_v3_rejects_response_after_total_deadline_with_audit(self):
        env, client = self.strict_capture_environment("set_pose_unpaused_rgbd_bounded_rerequest_v3")
        env.timeout = .01
        stamps = (env.last_image_timestamp_ns, env.last_depth_timestamp_ns)
        with patch("uavnav.avln.airsim_env.time.perf_counter", side_effect=[0., 0., .011]), \
             patch.object(client, "simPause", side_effect=AssertionError("no pause")):
            with self.assertRaisesRegex(RuntimeError, "总timeout") as caught:
                env.step(2)
        audit = caught.exception.capture_audit
        self.assertEqual(audit["capture_timeout_seconds"], env.timeout)
        self.assertEqual(len(audit["image_refresh_audit"]), 1)
        self.assertIn("capture_timeout", audit["image_refresh_audit"][0]["rejection_reasons"])
        self.assertEqual((env.last_image_timestamp_ns, env.last_depth_timestamp_ns), stamps)
        self.assertFalse(client.paused)

    def test_rgbd_refresh_waits_for_async_completion_and_restores_unpaused(self):
        env, client = self.strict_capture_environment()
        # setPose更新位姿但不推进时钟；推进请求在第三次状态查询时完成。
        def set_pose(pose, **kwargs):
            client.position, client.orientation = pose.position, pose.orientation
        client.simSetVehiclePose = set_pose
        pending = [None]
        def advance(frames):
            client.calls.append(("refresh_start", frames))
            pending[0] = 3
        def is_paused():
            if pending[0] is not None:
                pending[0] -= 1
                if pending[0] == 0:
                    client.timestamp += 1_000_000
                    client.paused = True
                    pending[0] = None
                    client.calls.append(("refresh_complete",))
            return client.paused
        client.simContinueForFrames = advance
        client.simIsPause = is_paused
        obs = env.step(2)
        self.assertFalse(client.paused)
        self.assertEqual(obs.info["image_refresh_attempts"], 1)
        attempts = obs.info["image_refresh_audit"]
        self.assertEqual([row["attempt_index"] for row in attempts], [0, 1])
        self.assertFalse(attempts[0]["rgb_fresh"])
        self.assertTrue(attempts[-1]["depth_fresh"])
        self.assertEqual(attempts[-1]["rejection_reasons"], [])
        self.assertEqual(obs.info["rgb_depth_timestamp_skew_ns"], 1)
        self.assertFalse(obs.info["capture_paused_before"])
        self.assertFalse(obs.info["capture_paused_after"])
        names = [row[0] for row in client.calls]
        self.assertLess(names.index("refresh_complete"), names.index("simPause"))

    def test_fresh_rgb_with_stale_depth_exhausts_bounded_refresh_and_keeps_audit(self):
        env, client = self.strict_capture_environment()
        old_depth = env.last_depth_timestamp_ns
        original = client.simGetImages
        def images(*args, **kwargs):
            rgb, depth = original(*args, **kwargs)
            depth.time_stamp = old_depth
            return [rgb, depth]
        client.simGetImages = images
        with self.assertRaisesRegex(RuntimeError, "时间戳") as caught:
            env.step(2)
        audit = caught.exception.capture_audit
        self.assertEqual(audit["image_refresh_attempts"], 3)
        self.assertEqual(len(audit["image_refresh_audit"]), 4)
        self.assertTrue(all(row["rgb_fresh"] for row in audit["image_refresh_audit"]))
        self.assertTrue(all(not row["depth_fresh"] for row in audit["image_refresh_audit"]))
        self.assertEqual(env.last_depth_timestamp_ns, old_depth)
        self.assertFalse(client.paused)
        json.dumps(audit, allow_nan=False)

    def test_refresh_accepts_recovered_sensor_timestamp_with_missing_first_attempt_audit(self):
        env, client = self.strict_capture_environment()
        original = client.simGetImages
        requests = [0]
        def images(*args, **kwargs):
            rgb, depth = original(*args, **kwargs)
            requests[0] += 1
            if requests[0] == 1:
                rgb.time_stamp = 0
                del depth.time_stamp
            return [rgb, depth]
        client.simGetImages = images
        obs = env.step(2)
        first, accepted = obs.info["image_refresh_audit"]
        self.assertEqual(first["image_timestamp_ns"], 0)
        self.assertIsNone(first["depth_timestamp_ns"])
        self.assertFalse(first["rgb_fresh"])
        self.assertFalse(first["depth_fresh"])
        self.assertTrue(accepted["rgb_fresh"])
        self.assertTrue(accepted["depth_fresh"])
        self.assertFalse(client.paused)

    def test_rgbd_capture_rejects_missing_depth_timestamp_and_wrong_depth_camera(self):
        for bad_field in ("time_stamp", "camera_position", "camera_orientation"):
            with self.subTest(field=bad_field):
                env, client = self.strict_capture_environment()
                original = client.simGetImages
                def images(*args, **kwargs):
                    rgb, depth = original(*args, **kwargs)
                    if bad_field == "time_stamp":
                        del depth.time_stamp
                    elif bad_field == "camera_position":
                        depth.camera_position = FakeVector(99, 0, -10)
                    else:
                        depth.camera_orientation = FakeQuaternion(0, 0, 1, 0)
                    return [rgb, depth]
                client.simGetImages = images
                with self.assertRaises(RuntimeError) as caught:
                    env.step(2)
                self.assertIsNotNone(caught.exception.capture_audit)
                self.assertTrue(caught.exception.capture_audit["image_refresh_audit"][-1]["rejection_reasons"])

    def test_refresh_timeout_unpauses_and_rejects_unfinished_clock_advance(self):
        env, client = self.strict_capture_environment()
        env.timeout = .003
        client.simSetVehiclePose = lambda pose, **kwargs: None
        client.simContinueForFrames = lambda frames: None
        with self.assertRaisesRegex(RuntimeError, "timeout") as caught:
            env.step(2)
        self.assertFalse(client.paused)
        self.assertIn("refresh_error", caught.exception.capture_audit)

    def test_refresh_rejects_failed_unpause_with_auditable_failure(self):
        env, client = self.strict_capture_environment()
        client.simSetVehiclePose = lambda pose, **kwargs: None
        client.simPause = lambda paused: None
        with self.assertRaisesRegex(RuntimeError, "仍暂停") as caught:
            env.step(2)
        self.assertTrue(client.paused)
        audit = caught.exception.capture_audit
        self.assertIn("pause_restore_error", audit)
        self.assertEqual(audit["image_refresh_attempts"], 1)
        json.dumps(audit, allow_nan=False)

    def test_rgbd_capture_audits_rpc_error_without_advancing_last_timestamps(self):
        env, client = self.strict_capture_environment()
        previous = (env.last_image_timestamp_ns, env.last_depth_timestamp_ns)
        def images(*args, **kwargs):
            raise OSError("fixture_rpc_failure")
        client.simGetImages = images
        with self.assertRaisesRegex(RuntimeError, "fixture_rpc_failure") as caught:
            env.step(2)
        self.assertEqual(previous, (env.last_image_timestamp_ns, env.last_depth_timestamp_ns))
        self.assertIn("rpc_error", caught.exception.capture_audit)
        self.assertIs(caught.exception.capture_audit, env.last_capture_audit)

    def test_rejected_camera_audit_preserves_actual_pose_and_sanitizes_invalid_components(self):
        for x_value in (99., float("nan"), float("inf")):
            with self.subTest(camera_x=x_value):
                env, client = self.strict_capture_environment()
                original = client.simGetImages
                def images(*args, **kwargs):
                    rgb, depth = original(*args, **kwargs)
                    depth.camera_position = FakeVector(x_value, .25, -10)
                    depth.camera_orientation = FakeQuaternion(0, 0, 0, 1)
                    return [rgb, depth]
                client.simGetImages = images
                with self.assertRaises(RuntimeError) as caught:
                    env.step(2)
                audit = caught.exception.capture_audit
                attempt = audit["image_refresh_audit"][-1]
                self.assertEqual(attempt["requested_position"], [0, 0, -10])
                self.assertEqual(attempt["requested_orientation_xyzw"], env.requested_orientation.tolist())
                self.assertEqual(attempt["response_camera_position"], [0, 0, -10])
                self.assertEqual(attempt["depth_response_camera_orientation_xyzw"], IDENTITY)
                if np.isfinite(x_value):
                    self.assertEqual(attempt["depth_response_camera_position"], [99., .25, -10])
                    self.assertEqual(attempt["depth_response_camera_invalid_fields"], [])
                else:
                    self.assertEqual(attempt["depth_response_camera_position"], [None, .25, -10])
                    self.assertEqual(attempt["depth_response_camera_invalid_fields"], ["camera_position.x_val"])
                self.assertIn("response_camera_pose_invalid", attempt["rejection_reasons"])
                json.dumps(audit, allow_nan=False)

    def test_capture_nonzero_camera_extrinsics_allow_measured_rgbd_skew(self):
        from scipy.spatial.transform import Rotation
        env, client, settings = self.provenance_environment()
        camera = settings["Vehicles"]["Drone_1"]["Cameras"]["front_0"]
        camera.update(X=.5, Y=.2, Z=-.1, Pitch=5, Roll=2, Yaw=10)
        original = client.simGetImages
        def images(*args, **kwargs):
            rgb, depth = original(*args, **kwargs)
            body = Rotation.from_quat([client.orientation.x_val, client.orientation.y_val,
                                       client.orientation.z_val, client.orientation.w_val])
            offset = body.apply([.5, .2, -.1])
            camera_q = (body * Rotation.from_euler("xyz", [2, 5, 10], degrees=True)).as_quat()
            p = client.position
            for response in (rgb, depth):
                response.camera_position = FakeVector(*(np.asarray([p.x_val, p.y_val, p.z_val]) + offset))
                response.camera_orientation = FakeQuaternion(*camera_q)
            depth.time_stamp = rgb.time_stamp + 20_000
            return [rgb, depth]
        client.simGetImages = images
        env.capture_provenance({"sha256": "b" * 64, "files": []})
        env.reset()
        obs = env.step(3)
        self.assertEqual(obs.info["image_refresh_attempts"], 0)
        self.assertEqual(obs.info["rgb_depth_timestamp_skew_ns"], 20_000)
        self.assertEqual(obs.info["response_camera_position"], obs.info["depth_response_camera_position"])

    def test_actual_rgb_and_recurrent_state_saved_including_stop_without_future_labels(self):
        from uavnav.avln.closed_loop import rollout_aerial_episode
        env, _ = self.environment()
        class Policy:
            config = {"architecture": "aerial_route_recurrent_v2"}
            checkpoint_sha256 = "a" * 64
            def reset_episode(self):
                self.count = 0
            def observation_state(self):
                return None if self.count == 0 else np.array([[[self.count]]], dtype=np.float32)
            def predict_action(self, image, instruction, history):
                action = 1 if self.count == 0 else 0
                self.count += 1
                return {"action": action, "action_probabilities": np.eye(8)[action].tolist()}
        with TemporaryDirectory() as temporary:
            folder = Path(temporary) / "observations"
            result = rollout_aerial_episode(env, Policy(), "fly then stop", max_steps=2, observation_dir=folder)
            manifest = json.loads((folder / "manifest.json").read_text())
            self.assertEqual(result["termination_reason"], "model_stop")
            self.assertEqual(len(manifest["frames"]), 2)
            self.assertEqual(manifest["frames"][1]["history_actions"], [1])
            self.assertEqual(manifest["frames"][1]["prediction"]["action"], 0)
            self.assertNotIn("state_before", manifest["frames"][0])
            self.assertEqual(np.load(folder / manifest["frames"][1]["state_before"], allow_pickle=False).item(), 1)
            for frame in manifest["frames"]:
                import hashlib
                self.assertEqual(hashlib.sha256((folder / frame["rgb"]).read_bytes()).hexdigest(), frame["rgb_sha256"])
                self.assertNotIn("reference", frame)
                self.assertNotIn("target", frame)
            from uavnav.avln.closed_loop import replay_recorded_observations
            replay = replay_recorded_observations(Policy(), folder / "manifest.json")
            self.assertEqual(replay["changed_actions"], 0)
            self.assertEqual(replay["max_probability_error"], 0)
            self.assertEqual(replay["max_memory_error"], 0)
            saved_manifest = (folder / "manifest.json").read_text()
            manifest["instruction"] = "changed instruction"
            (folder / "manifest.json").write_text(json.dumps(manifest))
            with self.assertRaisesRegex(ValueError, "指令摘要"):
                replay_recorded_observations(Policy(), folder / "manifest.json")
            (folder / "manifest.json").write_text(saved_manifest)
            terminal_state = folder / manifest["frames"][-1]["state_after"]
            state_bytes = terminal_state.read_bytes()
            terminal_state.write_bytes(b"changed")
            with self.assertRaisesRegex(ValueError, "摘要"):
                replay_recorded_observations(Policy(), folder / "manifest.json")
            terminal_state.write_bytes(state_bytes)
            frame = manifest["frames"][0]
            (folder / frame["rgb"]).write_bytes(b"changed")
            with self.assertRaisesRegex(ValueError, "摘要"):
                replay_recorded_observations(Policy(), folder / "manifest.json")
            with self.assertRaises(FileExistsError):
                rollout_aerial_episode(env, Policy(), "fly then stop", observation_dir=folder)

    def environment(self, scene=2, depth=.5):
        from uavnav.avln.airsim_env import AerialRouteEnv
        sdk = SimpleNamespace(Vector3r=FakeVector, Quaternionr=FakeQuaternion,
            Pose=lambda position_val, orientation_val: SimpleNamespace(position=position_val, orientation=orientation_val),
            ImageRequest=FakeSdk.ImageRequest,
            ImageType=SimpleNamespace(Scene="Scene", DepthPerspective="DepthPerspective", DepthVis="DepthVis"))
        client = FakeClient()
        def set_pose(pose, *, ignore_collision, vehicle_name):
            client.calls.append(("set_pose", ignore_collision, vehicle_name))
            client.position, client.orientation = pose.position, pose.orientation
            client.timestamp += 1_000_000
        def images(requests, *, vehicle_name):
            client.calls.append(("images", requests, vehicle_name))
            rgb = SimpleNamespace(width=1, height=1, image_data_uint8=bytes([1, 2, 3]), time_stamp=client.timestamp)
            if scene in (1, 7):
                stream = io.BytesIO()
                Image.new("RGB", (1, 1), (128, round(depth * 255), 128)).save(stream, format="PNG")
                raw = SimpleNamespace(width=1, height=1, image_data_uint8=stream.getvalue())
            else:
                raw = SimpleNamespace(width=1, height=1, image_data_float=[depth * 100])
            return [rgb, raw]
        client.simSetVehiclePose = set_pose
        client.simGetImages = images
        client.simGetVehiclePose = lambda **kwargs: SimpleNamespace(position=client.position, orientation=client.orientation)
        return AerialRouteEnv([0, 0, -10], IDENTITY, scene, client=client, sdk=sdk), client

    def test_turn_then_sideways_preserves_yaw_and_ned_vertical(self):
        from scipy.spatial.transform import Rotation
        from uavnav.avln.airsim_env import aerial_action_pose
        p, q = aerial_action_pose([0, 0, -10], YAW_90, 6)
        np.testing.assert_allclose(p, [5, 0, -10], atol=1e-12)
        np.testing.assert_allclose(q, YAW_90)
        p, q = aerial_action_pose(p, q, 4)
        self.assertEqual(p[2], -12)
        tilted = Rotation.from_euler("xyz", [.1, .2, np.pi / 2]).as_quat()
        _, turned = aerial_action_pose(p, tilted, 2)
        np.testing.assert_allclose(Rotation.from_quat(turned).as_euler("xyz"), [0, 0, np.pi / 2 - np.pi / 12], atol=1e-12)
        vertical = Rotation.from_euler("xyz", [0, 90, 90], degrees=True)
        matrix = vertical.as_matrix()
        yaw = np.arctan2(matrix[1, 0], matrix[0, 0])
        moved, unchanged = aerial_action_pose([0, 0, -10], vertical.as_quat(), 1)
        np.testing.assert_allclose(moved, [5 * np.cos(yaw), 5 * np.sin(yaw), -10])
        np.testing.assert_allclose(unchanged, vertical.as_quat())
        for action in (True, -1, 8, 1.0):
            with self.assertRaises(ValueError):
                aerial_action_pose(p, q, action)

    def test_depthvis_special_scenes_and_contact_are_distinct(self):
        for scene in (1, 2, 7):
            env, client = self.environment(scene, 0)
            obs = env.reset()
            self.assertTrue(obs.done)
            self.assertEqual(obs.termination_reason, "depth_collision_proxy")
            self.assertFalse(obs.collision)
            self.assertTrue(obs.info["depth_collision_proxy"])
            requested = next(call for call in client.calls if call[0] == "images")[1]
            self.assertEqual(requested[1].image_type, "DepthVis" if scene in (1, 7) else "DepthPerspective")
            self.assertEqual(requested[0].camera_name, "front_0")
            self.assertNotIn(("moveByVelocityAsync",), client.calls)

    def rollout(self, actions=(3, 1, 0), max_steps=5):
        from uavnav.avln.closed_loop import rollout_aerial_episode
        env, client = self.environment()
        seen = []
        sequence = iter(actions)
        def predict_action(image, instruction, history):
            seen.append(list(history))
            action = next(sequence)
            return {"action": action, "action_probabilities": np.eye(8)[action].tolist()}
        result = rollout_aerial_episode(env, SimpleNamespace(predict_action=predict_action), "Fly ahead", max_steps, 8)
        return result, seen, client

    def metadata(self, result):
        return {"task_version": "aerialvln_s_v1", "split": "val_unseen", "traj_id": "2/1",
            "goal_position": [5, 0, 999], "reference_positions": [[0, 0, -10], [5, 0, -10]],
            "execution_config": {"checkpoint_sha256": "a" * 64, "policy": "aerial_route_v1_argmax",
                "control_protocol": "airsim_set_pose_ignore_collision", "action_protocol": "aerial_action8_v1", "max_steps": 5}}

    def test_baseline_policies_are_legal_seeded_and_ignore_inputs(self):
        from uavnav.avln.closed_loop import AerialBaselinePolicy, rollout_aerial_episode
        forward = AerialBaselinePolicy("forward")
        self.assertEqual([forward.predict_action(None, "x", [])["action"] for _ in range(3)], [1, 1, 1])
        a, b = AerialBaselinePolicy("random", seed=3), AerialBaselinePolicy("random", seed=3)
        first = [a.predict_action("img", "left", [1])["action"] for _ in range(20)]
        self.assertEqual(first, [b.predict_action(None, "right", [])["action"] for _ in range(20)])
        self.assertTrue(set(first) <= set(range(1, 8)) and len(set(first)) > 3)
        a.reset_episode()
        self.assertEqual(first, [a.predict_action(None, "", [])["action"] for _ in range(20)])
        for bad in (("other",), ("random", "0")):
            with self.assertRaises(ValueError):
                AerialBaselinePolicy(*bad)
        env, _ = self.environment()
        result = rollout_aerial_episode(env, AerialBaselinePolicy("forward", stop_after=2), "go", 5, 8)
        self.assertEqual((result["steps"], result["termination_reason"]), (2, "model_stop"))

    def test_stop_before_motion_and_turn_action_history(self):
        result, seen, client = self.rollout()
        self.assertEqual(seen, [[], [3], [3, 1]])
        self.assertEqual(result["steps"], 2)
        self.assertEqual(result["termination_reason"], "model_stop")
        self.assertEqual(sum(call[0] == "set_pose" for call in client.calls), 3)
        zero, _, zero_client = self.rollout((0,))
        self.assertEqual(zero["steps"], 0)
        self.assertEqual(sum(call[0] == "set_pose" for call in zero_client.calls), 1)

    def test_rollout_progress_mid_dispatch_preserves_unknown_and_finish_error(self):
        from uavnav.avln.closed_loop import rollout_aerial_episode
        env, _ = self.environment()
        original_step = env.step
        calls = 0
        def step(action):
            nonlocal calls
            calls += 1
            if calls == 2:
                raise RuntimeError("primary_rpc_error")
            return original_step(action)
        env.step = step
        events = []
        policy = SimpleNamespace(predict_action=lambda *a: {"action": 1, "action_probabilities": np.eye(8)[1].tolist()})
        with self.assertRaisesRegex(RuntimeError, "primary_rpc_error"):
            rollout_aerial_episode(env, policy, "move", max_steps=3, progress_callback=events.append)
        self.assertEqual(events[-1]["event"], "error")
        self.assertEqual(events[-1]["known_completed_steps"], 1)
        self.assertEqual(events[-1]["validated_decisions"], 2)
        self.assertEqual(events[-1]["pending_dispatch"]["execution_state"], "unknown_until_step_returns")
        self.assertNotIn("goal_position", events[-1])
        self.assertNotIn("reference_positions", events[-1])

    def test_rollout_progress_callback_cannot_mutate_records(self):
        from uavnav.avln.closed_loop import rollout_aerial_episode
        env, _ = self.environment()
        actions = iter((1, 0))
        policy = SimpleNamespace(predict_action=lambda *a: {"action": (action := next(actions)), "action_probabilities": np.eye(8)[action].tolist()})
        def progress(event):
            if event["event"] == "action_completed":
                event["record"]["action"] = 7
                event["record"]["following"]["position"][0] = 999
        result = rollout_aerial_episode(env, policy, "move then stop", progress_callback=progress)
        self.assertEqual(result["records"][0]["action"], 1)
        self.assertEqual(result["terminal_observation"]["position"], [5, 0, -10])

    def aerial_resume_fixture(self, root):
        import torch
        from uavnav.avln.metadata import aerial_task_protocol
        checkpoint = root / "fixture.pt"
        checkpoint.write_bytes(b"fixture_only_not_real_checkpoint")
        predictor = SimpleNamespace(device=torch.device("cpu"), config={"architecture": "aerial_route_v1",
            "task_protocol": aerial_task_protocol(), "history_frames": 8}, instruction=None)
        predictor.checkpoint_sha256 = __import__("hashlib").sha256(checkpoint.read_bytes()).hexdigest()
        predictor.reset_episode = lambda: setattr(predictor, "actions", None)
        def predict(image, instruction, history):
            if predictor.actions is None:
                predictor.actions = iter((0,) if instruction == "stop now" else (1, 1, 0))
            action = next(predictor.actions)
            return {"action": action, "action_probabilities": np.eye(8)[action].tolist()}
        predictor.predict_action = predict
        base_episode = {"scene_id": 2, "episode_id": "one", "start_position": [0, 0, -10],
            "start_rotation": [1, 0, 0, 0], "instruction": {"instruction_text": "stop now"},
            "goals": [{"position": [100, 0, -10]}], "reference_path": [[0, 0, -10, 0, 0, 0], [5, 0, -10, 0, 0, 0]],
            "_episode_sha256": "b" * 64, "_annotation_sha256": "a" * 64, "_quarantine_reason": None}
        episodes = [base_episode, {**copy.deepcopy(base_episode), "episode_id": "two",
                                 "instruction": {"instruction_text": "move then stop"}, "_episode_sha256": "c" * 64}]
        args = ["--dataset", "aerialvln_s_v1", "--backend", "airsim", "--data-root", str(root),
            "--split", "val_unseen", "--scene-id", "2", "--scene-ready", "--checkpoint", str(checkpoint),
            "--device", "cpu", "--metric-protocol", "eval_adapter_v2", "--output", str(root / "evaluation")]
        return episodes, predictor, args

    def test_aerial_resume_preserves_policy_failure_retries_only_rpc_error_and_counts_attempts(self):
        import evaluate
        import hashlib
        with TemporaryDirectory() as temporary:
            root = Path(temporary)
            episodes, predictor, args = self.aerial_resume_fixture(root)
            first = self.environment()[0]
            broken = self.environment()[0]
            old_step, calls = broken.step, 0
            def step(action):
                nonlocal calls
                calls += 1
                if calls == 2:
                    raise ConnectionError("midstep_rpc")
                return old_step(action)
            broken.step = step
            broken.finish = lambda: (_ for _ in ()).throw(RuntimeError("cleanup_error"))
            with patch("uavnav.avln.data.load_aerial_episodes", return_value=episodes), \
                 patch("uavnav.avln.inference.load_predictor", return_value=predictor), \
                 patch("uavnav.avln.airsim_env.AerialRouteEnv", side_effect=[first, broken]) as factory, \
                 patch.dict(sys.modules, {"fastdtw": SimpleNamespace(fastdtw=lambda *a, **k: (0., None))}):
                with self.assertRaisesRegex(ConnectionError, "midstep_rpc"):
                    evaluate.main(args)
                self.assertEqual(factory.call_count, 2)
            output = root / "evaluation"
            original = {str(path.relative_to(output)): hashlib.sha256(path.read_bytes()).hexdigest()
                        for path in (output / "attempts").rglob("*") if path.is_file()}
            failed = json.loads((output / "attempts" / "2_two" / "attempt_0001" / "error.json").read_text(encoding="utf-8"))
            self.assertEqual(failed["known_completed_steps"], 1)
            self.assertEqual(failed["validated_decisions"], 2)
            self.assertEqual(failed["pending_action_execution"], "unknown")
            self.assertIn("cleanup_error", failed["cleanup_error"])
            self.assertIn("midstep_rpc", failed["error"])
            before = json.loads((output / "metrics.json").read_text(encoding="utf-8"))
            self.assertEqual(before["attempt_audit"]["infrastructure_attempts"], 1)
            self.assertEqual(before["status"], "incomplete")
            fresh = self.environment()[0]
            with patch("uavnav.avln.data.load_aerial_episodes", return_value=episodes), \
                 patch("uavnav.avln.inference.load_predictor", return_value=predictor), \
                 patch("uavnav.avln.airsim_env.AerialRouteEnv", return_value=fresh) as factory, \
                 patch.dict(sys.modules, {"fastdtw": SimpleNamespace(fastdtw=lambda *a, **k: (0., None))}):
                evaluate.main(args + ["--resume"])
                self.assertEqual(factory.call_count, 1)
                factory.reset_mock()
                # Canonical publication crash: source was sealed, only target file is absent.
                canonical_roll = output / "episodes" / "2_one" / "rollout.json"
                saved_roll = canonical_roll.read_bytes()
                canonical_roll.unlink()
                evaluate.main(args + ["--resume"])
                factory.assert_not_called()
                self.assertEqual(canonical_roll.read_bytes(), saved_roll)
                with self.assertRaises(FileExistsError):
                    evaluate.main(args)
            for relative, digest in original.items():
                self.assertEqual(hashlib.sha256((output / relative).read_bytes()).hexdigest(), digest)
            result = json.loads((output / "metrics.json").read_text(encoding="utf-8"))
            self.assertEqual(result["status"], "closed_loop")
            self.assertEqual(result["metrics"]["sr"], 0)
            self.assertEqual(result["attempt_audit"]["total_attempts"], 3)
            self.assertEqual(result["attempt_audit"]["completed_attempts"], 2)
            self.assertEqual(result["attempt_audit"]["infrastructure_attempts"], 1)
            self.assertFalse(result["attempt_audit"]["formal_navigation_verified"])

    def test_formal_multiscene_shards_keep_full_manifest_and_publish_only_after_complete(self):
        import evaluate
        from uavnav.avln.metadata import AERIALVLN_S_RELEASE
        with TemporaryDirectory() as temporary:
            root = Path(temporary)
            episodes, predictor, args = self.aerial_resume_fixture(root)
            episodes[1]["scene_id"] = 3
            args += ["--require-formal-protocol", "--scene-endpoints", str(root / "endpoints.json")]
            expected = {"scene_build": {"sha256": "d" * 64}, "settings": {"fixture": True}}
            endpoints = {scene: {"scene_id": scene, "ip": "127.0.0.1", "port": 41450 + scene,
                                "build_dir": str(root), "expected_provenance": expected} for scene in (2, 3)}
            first, second = self.environment()[0], self.environment()[0]
            for env in (first, second):
                env.capture_provenance = lambda build: copy.deepcopy(expected)
            with patch.dict(AERIALVLN_S_RELEASE, {"val_unseen": {"sha256": "a" * 64, "episodes": 2}}), \
                 patch("evaluate._load_scene_endpoints", return_value=endpoints), \
                 patch("uavnav.avln.data.load_aerial_episodes", return_value=episodes), \
                 patch("uavnav.avln.inference.load_predictor", return_value=predictor), \
                 patch("uavnav.avln.airsim_env.AerialRouteEnv", side_effect=[first, second]) as factory, \
                 patch.dict(sys.modules, {"fastdtw": SimpleNamespace(fastdtw=lambda *a, **k: (0., None))}):
                with patch("uavnav.avln.closed_loop.write_metrics") as scorer:
                    evaluate.main(args)
                    scorer.assert_not_called()
                output = root / "evaluation"
                manifest_before = (output / "evaluation_manifest.json").read_bytes()
                manifest = json.loads(manifest_before)
                self.assertEqual(manifest["scope"], "official_split")
                self.assertEqual(len(manifest["episodes"]), 2)
                partial = json.loads((output / "metrics.json").read_text(encoding="utf-8"))
                self.assertEqual(partial["status"], "incomplete")
                self.assertIsNone(partial["metrics"]["sr"])
                self.assertEqual(partial["completion"]["missing_episode_ids"], ["3/two"])
                resumed = args.copy()
                resumed[resumed.index("--scene-id") + 1] = "3"
                evaluate.main(resumed + ["--resume"])
                self.assertEqual(factory.call_count, 2)
                self.assertEqual(factory.call_args.kwargs["port"], 41453)
                self.assertEqual((output / "evaluation_manifest.json").read_bytes(), manifest_before)
                complete = json.loads((output / "metrics.json").read_text(encoding="utf-8"))
                self.assertEqual(complete["status"], "closed_loop")
                self.assertEqual(complete["completion"]["status"], "complete")
                self.assertEqual(complete["official_source_authentication"]["episode_count"], 2)
                evaluate.main(resumed + ["--resume"])
                self.assertEqual(factory.call_count, 2)

    def test_scene_endpoint_config_requires_exact_coverage_unique_addresses_and_real_build(self):
        import evaluate
        from uavnav.avln.airsim_env import aerial_scene_build
        with TemporaryDirectory() as temporary:
            root = Path(temporary)
            build = root / "build"
            build.mkdir()
            (build / "scene.pak").write_bytes(b"immutable scene")
            provenance = {"scene_build": aerial_scene_build(build), "settings": {},
                          "settings_sha256": evaluate._json_sha256({}), "camera_fov_degrees": 90.,
                          "camera_extrinsics": {"position": [.5, 0., 0.], "rotation_degrees": [0., 0., 0.]},
                          "capture_policy": {"version": "set_pose_unpaused_single_request_v1", "wait_seconds": 0., "pause": False}}
            row = {"scene_id": 2, "ip": "127.0.0.1", "port": 41451,
                   "build_dir": str(build), "expected_provenance": provenance}
            path = root / "endpoints.json"
            def save(rows):
                path.write_text(json.dumps({"schema_version": 1, "scenes": rows}), encoding="utf-8")
            save([row])
            self.assertEqual(set(evaluate._load_scene_endpoints(path, {2})), {2})
            with self.assertRaisesRegex(ValueError, "覆盖"):
                evaluate._load_scene_endpoints(path, {2, 3})
            save([row, {**row, "scene_id": 3}])
            with self.assertRaisesRegex(ValueError, "重复"):
                evaluate._load_scene_endpoints(path, {2, 3})
            save([row])
            (build / "scene.pak").write_bytes(b"changed")
            with self.assertRaisesRegex(ValueError, "构建"):
                evaluate._load_scene_endpoints(path, {2})

    def test_same_run_concurrent_writer_rejected_and_operating_system_lock_released(self):
        import evaluate
        with TemporaryDirectory() as temporary:
            args = SimpleNamespace(output=Path(temporary))
            def while_locked(*unused):
                with self.assertRaisesRegex(RuntimeError, "并发"):
                    evaluate._run_aerial_attempts(args, [], None, {}, {}, None, None, None, None)
                return "one_writer"
            with patch("evaluate._run_aerial_attempts_locked", side_effect=while_locked):
                self.assertEqual(evaluate._run_aerial_attempts(args, [], None, {}, {}, None, None, None, None), "one_writer")
            with patch("evaluate._run_aerial_attempts_locked", return_value="released"):
                self.assertEqual(evaluate._run_aerial_attempts(args, [], None, {}, {}, None, None, None, None), "released")

    def test_resume_rejects_changed_checkpoint_source_canonical_or_unknown_attempt_before_environment(self):
        import evaluate
        for changed in ("checkpoint", "annotation", "goal", "canonical", "attempt", "budget", "source", "duplicate"):
            with self.subTest(changed=changed), TemporaryDirectory() as temporary:
                root = Path(temporary)
                episodes, predictor, args = self.aerial_resume_fixture(root)
                fixture_envs = [self.environment()[0], self.environment()[0]]
                with patch("uavnav.avln.data.load_aerial_episodes", return_value=episodes), \
                     patch("uavnav.avln.inference.load_predictor", return_value=predictor), \
                     patch("uavnav.avln.airsim_env.AerialRouteEnv", side_effect=fixture_envs), \
                     patch.dict(sys.modules, {"fastdtw": SimpleNamespace(fastdtw=lambda *a, **k: (0., None))}):
                    evaluate.main(args)
                output = root / "evaluation"
                resumed = args + ["--resume"]
                if changed == "checkpoint":
                    (root / "fixture.pt").write_bytes(b"changed_weight")
                    # Mock the newly loaded snapshot, not the stale predictor from the first run.
                    predictor.checkpoint_sha256 = __import__("hashlib").sha256(b"changed_weight").hexdigest()
                elif changed == "annotation":
                    episodes[0]["_annotation_sha256"] = "e" * 64
                elif changed == "goal":
                    episodes[0]["goals"][0]["position"][0] = 5
                elif changed == "canonical":
                    (output / "episodes" / "2_one" / "rollout.json").write_bytes(b"{}")
                elif changed == "attempt":
                    (output / "attempts" / "2_one" / "attempt_0001" / "journal.jsonl").write_bytes(b"{}\n")
                elif changed == "budget":
                    resumed += ["--max-steps", "200", "--episode-id", "one"]
                elif changed == "source":
                    run_path = output / "evaluation_run.json"
                    run = json.loads(run_path.read_text(encoding="utf-8"))
                    run["source_sha256"]["evaluate.py"] = "0" * 64
                    run_path.write_text(json.dumps(run))
                else:
                    (output / "attempts" / "2_one" / "attempt_0003").mkdir()
                with patch("uavnav.avln.data.load_aerial_episodes", return_value=episodes), \
                     patch("uavnav.avln.inference.load_predictor", return_value=predictor), \
                     patch("uavnav.avln.airsim_env.AerialRouteEnv") as factory, \
                     patch.dict(sys.modules, {"fastdtw": SimpleNamespace(fastdtw=lambda *a, **k: (0., None))}):
                    with self.assertRaises((ValueError, ClosedLoopAuditError)):
                        evaluate.main(resumed)
                    factory.assert_not_called()

    def test_resume_and_formal_flags_reject_legacy_replay_preflight_or_nonfull(self):
        import evaluate
        base = ["--dataset", "aerialvln_s_v1", "--backend", "airsim", "--data-root", ".",
                "--split", "val_unseen", "--output", "unused"]
        for extra in (["--resume"], ["--resume", "--preflight-only", "--metric-protocol", "eval_adapter_v2"],
                      ["--require-formal-protocol"], ["--require-formal-protocol", "--metric-protocol", "eval_adapter_v2", "--max-steps", "200"]):
            with patch("uavnav.avln.data.load_aerial_episodes") as loader, contextlib.redirect_stderr(io.StringIO()):
                with self.assertRaises(SystemExit):
                    evaluate.main(base + extra)
                loader.assert_not_called()

    def test_policy_nan_first_or_midroute_is_not_infrastructure_and_cannot_resume(self):
        import evaluate
        for fail_index in (0, 1):
            with self.subTest(fail_index=fail_index), TemporaryDirectory() as temporary:
                root = Path(temporary)
                episodes, predictor, args = self.aerial_resume_fixture(root)
                calls = 0
                def predict(*unused):
                    nonlocal calls
                    index = calls
                    calls += 1
                    return {"action": 1, "action_probabilities": [float("nan")] * 8 if index == fail_index else np.eye(8)[1].tolist()}
                predictor.predict_action = predict
                args += ["--record-observations"]
                with patch("uavnav.avln.data.load_aerial_episodes", return_value=episodes), \
                     patch("uavnav.avln.inference.load_predictor", return_value=predictor), \
                     patch("uavnav.avln.airsim_env.AerialRouteEnv", return_value=self.environment()[0]):
                    with self.assertRaisesRegex(ValueError, "合法概率"):
                        evaluate.main(args)
                output = root / "evaluation"
                error = json.loads((output / "attempts/2_one/attempt_0001/error.json").read_text(encoding="utf-8"))
                self.assertEqual(error["status"], "policy_error")
                self.assertEqual(error["known_completed_steps"], fail_index)
                result = json.loads((output / "metrics.json").read_text(encoding="utf-8"))
                self.assertIsNone(result["metrics"]["sr"])
                self.assertEqual(result["attempt_audit"]["policy_error_attempts"], 1)
                self.assertEqual(result["attempt_audit"]["infrastructure_attempts"], 0)
                with patch("uavnav.avln.data.load_aerial_episodes", return_value=episodes), \
                     patch("uavnav.avln.inference.load_predictor", return_value=predictor), \
                     patch("uavnav.avln.airsim_env.AerialRouteEnv") as factory:
                    with self.assertRaisesRegex(ValueError, "禁止自动"):
                        evaluate.main(args + ["--resume"])
                    factory.assert_not_called()

    def test_resume_rejects_old_failure_classification_contract(self):
        import evaluate
        with TemporaryDirectory() as temporary:
            root = Path(temporary)
            episodes, predictor, args = self.aerial_resume_fixture(root)
            with patch("uavnav.avln.data.load_aerial_episodes", return_value=episodes), \
                 patch("uavnav.avln.inference.load_predictor", return_value=predictor), \
                 patch("uavnav.avln.airsim_env.AerialRouteEnv", side_effect=[self.environment()[0], self.environment()[0]]), \
                 patch.dict(sys.modules, {"fastdtw": SimpleNamespace(fastdtw=lambda *a, **k: (0., None))}):
                evaluate.main(args)
            path = root / "evaluation/evaluation_run.json"
            run = json.loads(path.read_text(encoding="utf-8"))
            run["execution_config"].pop("error_classification_protocol")
            path.write_text(json.dumps(run), encoding="utf-8")
            with patch("uavnav.avln.data.load_aerial_episodes", return_value=episodes), \
                 patch("uavnav.avln.inference.load_predictor", return_value=predictor), \
                 patch("uavnav.avln.airsim_env.AerialRouteEnv") as factory:
                with self.assertRaisesRegex(ValueError, "冻结合同"):
                    evaluate.main(args + ["--resume"])
                factory.assert_not_called()

    def test_untyped_environment_exception_requires_review(self):
        import evaluate
        with TemporaryDirectory() as temporary:
            root = Path(temporary)
            episodes, predictor, args = self.aerial_resume_fixture(root)
            with patch("uavnav.avln.data.load_aerial_episodes", return_value=episodes), \
                 patch("uavnav.avln.inference.load_predictor", return_value=predictor), \
                 patch("uavnav.avln.airsim_env.AerialRouteEnv", side_effect=RuntimeError("untyped_rpc_claim")):
                with self.assertRaisesRegex(RuntimeError, "untyped_rpc_claim"):
                    evaluate.main(args)
            result = json.loads((root / "evaluation/metrics.json").read_text(encoding="utf-8"))
            self.assertEqual(result["attempt_audit"]["unknown_error_attempts"], 1)
            self.assertEqual(result["attempt_audit"]["infrastructure_attempts"], 0)
            with patch("uavnav.avln.data.load_aerial_episodes", return_value=episodes), \
                 patch("uavnav.avln.inference.load_predictor", return_value=predictor), \
                 patch("uavnav.avln.airsim_env.AerialRouteEnv") as factory:
                with self.assertRaisesRegex(ValueError, "禁止自动"):
                    evaluate.main(args + ["--resume"])
                factory.assert_not_called()

    def test_resume_does_not_retry_policy_terminal_after_finish_failure(self):
        import evaluate
        with TemporaryDirectory() as temporary:
            root = Path(temporary)
            episodes, predictor, args = self.aerial_resume_fixture(root)
            env = self.environment()[0]
            env.finish = lambda: (_ for _ in ()).throw(RuntimeError("finish_failed"))
            with patch("uavnav.avln.data.load_aerial_episodes", return_value=episodes), \
                 patch("uavnav.avln.inference.load_predictor", return_value=predictor), \
                 patch("uavnav.avln.airsim_env.AerialRouteEnv", return_value=env), \
                 patch.dict(sys.modules, {"fastdtw": SimpleNamespace(fastdtw=lambda *a, **k: (0., None))}):
                with self.assertRaisesRegex(RuntimeError, "finish_failed"):
                    evaluate.main(args)
            error = json.loads((root / "evaluation" / "attempts" / "2_one" / "attempt_0001" / "error.json").read_text(encoding="utf-8"))
            self.assertTrue(error["policy_terminal_recorded"])
            with patch("uavnav.avln.data.load_aerial_episodes", return_value=episodes), \
                 patch("uavnav.avln.inference.load_predictor", return_value=predictor), \
                 patch("uavnav.avln.airsim_env.AerialRouteEnv") as factory:
                with self.assertRaisesRegex(ValueError, "策略终止"):
                    evaluate.main(args + ["--resume"])
                factory.assert_not_called()

    def test_resume_unsealed_journal_truncation_is_reported_and_corruption_or_result_rejected(self):
        import evaluate
        for kind in ("truncated", "corrupt", "bad_hash_no_newline", "result"):
            with self.subTest(kind=kind), TemporaryDirectory() as temporary:
                root = Path(temporary)
                episodes, predictor, args = self.aerial_resume_fixture(root)
                broken = self.environment()[0]
                broken.reset = lambda: (_ for _ in ()).throw(ConnectionError("reset_failed"))
                with patch("uavnav.avln.data.load_aerial_episodes", return_value=episodes), \
                     patch("uavnav.avln.inference.load_predictor", return_value=predictor), \
                     patch("uavnav.avln.airsim_env.AerialRouteEnv", return_value=broken):
                    with self.assertRaisesRegex(ConnectionError, "reset_failed"):
                        evaluate.main(args)
                output = root / "evaluation"
                attempt = output / "attempts" / "2_one" / "attempt_0001"
                # Model a crash before seal: retain registered progress and its SHA chain.
                ledger = output / "attempt_ledger.jsonl"
                lines = ledger.read_bytes().splitlines(keepends=True)
                self.assertEqual(json.loads(lines[-1])["event"], "finished")
                ledger.write_bytes(b"".join(lines[:-1]))
                (attempt / "error.json").unlink()
                if kind in ("truncated", "corrupt", "bad_hash_no_newline"):
                    with (attempt / "journal.jsonl").open("ab") as stream:
                        stream.write(b'{"sha256":"wrong"}' if kind == "bad_hash_no_newline" else b'{"unsealed"' + (b"\n" if kind == "corrupt" else b""))
                else:
                    (attempt / "rollout.json").write_text("{}", encoding="utf-8")
                fresh = [self.environment()[0], self.environment()[0]]
                with patch("uavnav.avln.data.load_aerial_episodes", return_value=episodes), \
                     patch("uavnav.avln.inference.load_predictor", return_value=predictor), \
                     patch("uavnav.avln.airsim_env.AerialRouteEnv", side_effect=fresh) as factory, \
                     patch.dict(sys.modules, {"fastdtw": SimpleNamespace(fastdtw=lambda *a, **k: (0., None))}):
                    if kind == "truncated":
                        evaluate.main(args + ["--resume"])
                        self.assertEqual(factory.call_count, 2)
                        summary = json.loads((output / "metrics.json").read_text(encoding="utf-8"))
                        self.assertEqual(summary["attempt_audit"]["infrastructure_attempts"], 1)
                        old = summary["attempt_audit"]["attempts"][0]
                        self.assertEqual(old["journal_status"], "truncated_last_line")
                        self.assertEqual(old["pending_action_execution"], "unknown")
                        self.assertFalse(old["valid_prefix_is_navigation_score"])
                    else:
                        with self.assertRaisesRegex(ValueError, "损坏|未封口完整"):
                            evaluate.main(args + ["--resume"])
                        factory.assert_not_called()

    def test_environment_constructor_failure_is_sealed_and_formal_subset_rejected(self):
        import evaluate
        with TemporaryDirectory() as temporary:
            root = Path(temporary)
            episodes, predictor, args = self.aerial_resume_fixture(root)
            with patch("uavnav.avln.data.load_aerial_episodes", return_value=episodes), \
                 patch("uavnav.avln.inference.load_predictor", return_value=predictor), \
                 patch("uavnav.avln.airsim_env.AerialRouteEnv", side_effect=RuntimeError("constructor_failed")):
                with self.assertRaisesRegex(RuntimeError, "constructor_failed"):
                    evaluate.main(args)
            error = json.loads((root / "evaluation" / "attempts" / "2_one" / "attempt_0001" / "error.json").read_text(encoding="utf-8"))
            self.assertFalse(error["environment_constructed"])
            self.assertEqual(error["validated_decisions"], 0)
            with patch("uavnav.avln.data.load_aerial_episodes", return_value=episodes), \
                 patch("uavnav.avln.inference.load_predictor") as loader, contextlib.redirect_stderr(io.StringIO()):
                with self.assertRaises(SystemExit):
                    evaluate.main(args + ["--episode-id", "one", "--require-formal-protocol"])
                loader.assert_not_called()

    def save_v2_episode(self, root, result, info=None, max_steps=5, scope="subset_diagnostic"):
        import hashlib
        from uavnav.avln.closed_loop import aerial_evaluation_protocol
        from uavnav.avln.metadata import aerial_scoring_truth_sha256, aerial_task_protocol, evaluation_manifest_sha256
        task = aerial_task_protocol()
        protocol = aerial_evaluation_protocol(task, max_steps, scope)
        digest = hashlib.sha256(json.dumps(protocol, sort_keys=True, separators=(",", ":"), ensure_ascii=False).encode()).hexdigest()
        info = copy.deepcopy(info if info is not None else self.metadata(result))
        info.update(episode_sha256="d" * 64, annotation_sha256="c" * 64,
                    start_position=result["initial_observation"]["position"],
                    start_orientation_xyzw=result["initial_observation"]["orientation"])
        manifest = {"schema_version": 2, "scope": scope, "split": info["split"], "source_sha256": "c" * 64,
                    "evaluation_protocol_sha256": digest, "episodes": [{"traj_id": "2/1", "split": info["split"],
                        "episode_sha256": info["episode_sha256"], "scoring_truth_sha256": aerial_scoring_truth_sha256(info)}]}
        info.update(metric_protocol="eval_adapter_v2", evaluation_protocol_sha256=digest,
                    evaluation_scope=scope, evaluation_manifest_sha256=evaluation_manifest_sha256(manifest))
        info["execution_config"].update(metric_protocol="eval_adapter_v2", max_steps=max_steps,
            evaluation_protocol_sha256=digest, task_protocol_sha256=hashlib.sha256(json.dumps(task,
                sort_keys=True, separators=(",", ":"), ensure_ascii=False).encode()).hexdigest())
        result = copy.deepcopy(result)
        result["metric_protocol"] = "eval_adapter_v2"
        root.mkdir(parents=True, exist_ok=True)
        (root / "evaluation_protocol.json").write_text(json.dumps(protocol), encoding="utf-8")
        (root / "evaluation_manifest.json").write_text(json.dumps(manifest), encoding="utf-8")
        episode = root / "episodes" / "one"
        write_episode(episode, result, info)
        return episode, result, info

    def test_v2_zero_step_stop_and_initial_turn_dedup_sampling(self):
        # Controlled cost checks sampler/boundaries only, not real fastdtw numbers.
        seen = []
        def cost(actual, reference, dist):
            seen.append(np.asarray(actual).tolist())
            return 0., None
        for actions, expected in (((0,), [[0, 0, -10]]), ((3, 1, 0), [[0, 0, -10], [5 * np.cos(np.pi / 12), 5 * np.sin(np.pi / 12), -10]])):
            with self.subTest(actions=actions), TemporaryDirectory() as temporary, \
                 patch.dict(sys.modules, {"fastdtw": SimpleNamespace(fastdtw=cost)}):
                result, _, _ = self.rollout(actions)
                path, _, _ = self.save_v2_episode(Path(temporary), result)
                scores = read_rollout_metrics(path)
                np.testing.assert_allclose(seen[-1], expected, atol=1e-12)
                self.assertEqual(scores["autonomous_stop_success"], 100)
                self.assertEqual(scores["sdtw"], 100)
                self.assertEqual(scores["definition"]["metric_protocol"], "eval_adapter_v2")

    def test_v2_initial_osr_differs_from_legacy_without_changing_default(self):
        result, _, _ = self.rollout((1,), max_steps=1)
        self.assertNotIn("metric_protocol", result)
        info = self.metadata(result)
        info["goal_position"] = [-20, 0, -10]
        info["execution_config"]["max_steps"] = 1
        with TemporaryDirectory() as temporary, patch.dict(sys.modules, {"fastdtw": SimpleNamespace(fastdtw=lambda a, b, dist: (0., None))}):
            root = Path(temporary)
            write_episode(root / "legacy", result, info)
            legacy = read_rollout_metrics(root / "legacy")
            self.assertEqual(legacy["osr"], 0)
            self.assertEqual(legacy["definition"]["metric_protocol"], "airvln_xy20_fastdtw_v1")
            path, _, _ = self.save_v2_episode(root / "v2", result, info, max_steps=1)
            updated = read_rollout_metrics(path)
            self.assertEqual(updated["osr"], 100)
            self.assertEqual(updated["sr"], 0)
            self.assertEqual(updated["sdtw"], 0)

    def test_v2_budget_last_action_and_depth_priority_before_scoring(self):
        from uavnav.avln.closed_loop import rollout_aerial_episode
        for depth_done in (False, True):
            with self.subTest(depth_done=depth_done):
                env, _ = self.environment()
                original = env.step
                def step(action):
                    observation = original(action)
                    if depth_done:
                        observation.info["depth_collision_proxy"] = True
                        observation.done = True
                        observation.termination_reason = "depth_collision_proxy"
                    return observation
                env.step = step
                predictor = SimpleNamespace(predict_action=lambda *args: {"action": 1, "action_probabilities": np.eye(8)[1].tolist()})
                result = rollout_aerial_episode(env, predictor, "move", max_steps=1, metric_protocol="eval_adapter_v2")
                expected = "depth_collision_proxy" if depth_done else "max_steps"
                self.assertEqual(result["termination_reason"], expected)
                self.assertEqual(result["steps"], 1)
                with TemporaryDirectory() as temporary, patch.dict(sys.modules, {"fastdtw": SimpleNamespace(fastdtw=lambda a, b, dist: (0., None))}):
                    path, saved, info = self.save_v2_episode(Path(temporary), result, max_steps=1)
                    scores = read_rollout_metrics(path)
                    self.assertEqual(scores["sr"], 100)
                    self.assertEqual(scores["autonomous_stop_success"], 0)
                    if depth_done:
                        saved["termination_reason"] = "max_steps"
                        (path / "rollout.json").write_text(json.dumps(saved), encoding="utf-8")
                        with self.assertRaisesRegex(ClosedLoopAuditError, "时序"):
                            read_rollout_metrics(path)

    def test_v2_contract_budget_and_scope_reject_illegal_or_changed_values(self):
        from uavnav.avln.closed_loop import aerial_evaluation_protocol
        from uavnav.avln.metadata import aerial_task_protocol
        for budget, scope in ((200, "official_split"), (501, "subset_diagnostic"), (True, "subset_diagnostic"), (500, "unknown")):
            with self.assertRaises(ValueError):
                aerial_evaluation_protocol(aerial_task_protocol(), budget, scope)
        self.assertEqual(aerial_evaluation_protocol(aerial_task_protocol(), 500, "official_split")["max_steps"], 500)
        result, _, _ = self.rollout()
        with TemporaryDirectory() as temporary, patch.dict(sys.modules, {"fastdtw": SimpleNamespace(fastdtw=lambda a, b, dist: (0., None))}):
            root = Path(temporary)
            path, _, _ = self.save_v2_episode(root, result)
            self.assertEqual(write_metrics(root, root / "episodes")["status"], "closed_loop")
            protocol_path = root / "evaluation_protocol.json"
            protocol = json.loads(protocol_path.read_text(encoding="utf-8"))
            protocol["max_steps"] = 200
            protocol_path.write_text(json.dumps(protocol), encoding="utf-8")
            summary = write_metrics(root, root / "episodes")
            self.assertEqual(summary["status"], "closed_loop_invalid")
            self.assertIsNone(summary["metrics"]["sr"])
            self.assertIn("invalid_evaluation_manifest", [issue["code"] for issue in summary["audit"]["issues"]])

    def test_v2_rejects_missing_or_mixed_rollout_scoring_contract(self):
        result, _, _ = self.rollout()
        with TemporaryDirectory() as temporary, patch.dict(sys.modules, {"fastdtw": SimpleNamespace(fastdtw=lambda a, b, dist: (0., None))}):
            path, saved, _ = self.save_v2_episode(Path(temporary), result)
            saved.pop("metric_protocol")
            (path / "rollout.json").write_text(json.dumps(saved), encoding="utf-8")
            with self.assertRaisesRegex(ClosedLoopAuditError, "评分协议"):
                read_rollout_metrics(path)
        with TemporaryDirectory() as temporary, patch.dict(sys.modules, {"fastdtw": SimpleNamespace(fastdtw=lambda a, b, dist: (0., None))}):
            root = Path(temporary)
            self.save_v2_episode(root, result)
            info = self.metadata(result)
            info["traj_id"] = "2/2"
            write_episode(root / "episodes" / "two", result, info)
            summary = write_metrics(root, root / "episodes")
            self.assertEqual(summary["status"], "closed_loop_invalid")
            self.assertIsNone(summary["metrics"]["sdtw"])
            self.assertIn("mixed_metric_definitions", [issue["code"] for issue in summary["audit"]["issues"]])

    def test_v2_official_200_budget_rejected_before_output_and_model_loading(self):
        import evaluate
        episode = {"scene_id": 2, "episode_id": "one"}
        with TemporaryDirectory() as temporary:
            output = Path(temporary) / "invalid"
            with patch("uavnav.avln.data.load_aerial_episodes", return_value=[episode]), \
                 patch("uavnav.avln.metadata.authenticate_aerial_release", return_value={"release": "cpu_fixture_only"}), \
                 patch("uavnav.avln.inference.load_predictor") as loader, contextlib.redirect_stderr(io.StringIO()):
                with self.assertRaises(SystemExit):
                    evaluate.main(["--dataset", "aerialvln_s_v1", "--backend", "airsim", "--data-root", temporary,
                        "--split", "val_unseen", "--metric-protocol", "eval_adapter_v2", "--max-steps", "200",
                        "--output", str(output), "--preflight-only"])
                loader.assert_not_called()
            self.assertFalse(output.exists())

    def test_v2_actual_fastdtw_identical_path(self):
        try:
            import fastdtw
        except ImportError:
            self.skipTest("本机缺fastdtw；受控边界测试不代替真实指标数值验收")
        result, _, _ = self.rollout((1, 0))
        with TemporaryDirectory() as temporary:
            path, _, _ = self.save_v2_episode(Path(temporary), result)
            scores = read_rollout_metrics(path)
            self.assertEqual(scores["ndtw"], 100)
            self.assertEqual(scores["sdtw"], 100)

    def test_v2_scoring_truth_mutations_rejected_even_with_declared_hashes(self):
        result, _, _ = self.rollout()
        for field in ("goal_position", "reference_positions", "annotation_sha256", "episode_sha256", "start_orientation_xyzw"):
            with self.subTest(field=field), TemporaryDirectory() as temporary, \
                 patch.dict(sys.modules, {"fastdtw": SimpleNamespace(fastdtw=lambda a, b, dist: (0., None))}):
                root = Path(temporary)
                path, _, info = self.save_v2_episode(root, result)
                if field == "goal_position":
                    info[field][0] += 100
                elif field == "reference_positions":
                    info[field][-1][0] += 100
                elif field == "start_orientation_xyzw":
                    info[field] = YAW_90
                else:
                    info[field] = "e" * 64
                (path / "ori_info.json").write_text(json.dumps(info), encoding="utf-8")
                summary = write_metrics(root, root / "episodes")
                self.assertEqual(summary["status"], "closed_loop_invalid")
                self.assertIsNone(summary["metrics"]["sr"])
                self.assertIn("invalid_evaluation_manifest", [issue["code"] for issue in summary["audit"]["issues"]])
                with self.assertRaises(ClosedLoopAuditError):
                    read_rollout_metrics(path)

    def test_v1_config_and_rollout_reject_explicit_v2_metadata(self):
        result, _, _ = self.rollout()
        result["metric_protocol"] = "airvln_xy20_fastdtw_v1"
        info = self.metadata(result)
        info["execution_config"]["metric_protocol"] = "airvln_xy20_fastdtw_v1"
        info["metric_protocol"] = "eval_adapter_v2"
        with TemporaryDirectory() as temporary:
            root = Path(temporary) / "one"
            write_episode(root, result, info)
            with self.assertRaisesRegex(ClosedLoopAuditError, "metric_protocol|评分协议"):
                read_rollout_metrics(root)
            result.pop("metric_protocol")
            (root / "rollout.json").write_text(json.dumps(result), encoding="utf-8")
            with self.assertRaisesRegex(ClosedLoopAuditError, "评分协议"):
                read_rollout_metrics(root)

    def test_xy_success_budget_success_and_hidden_test_rejection(self):
        result, _, _ = self.rollout((1,), max_steps=1)
        metadata = self.metadata(result)
        metadata["execution_config"]["max_steps"] = 1
        # Known fixture DTW cost 5: deployed locations [[5,0,-10]], reference length2.
        fake_dtw = SimpleNamespace(fastdtw=lambda a, b, dist: (5., None))
        with TemporaryDirectory() as temporary, patch.dict(sys.modules, {"fastdtw": fake_dtw}):
            root = Path(temporary) / "one"
            write_episode(root, result, metadata)
            scores = read_rollout_metrics(root)
            self.assertEqual(scores["ne"], 0)
            self.assertEqual(scores["sr"], 100)
            self.assertEqual(scores["autonomous_stop_success"], 0)
            self.assertIsNone(scores["spl"])
            self.assertAlmostEqual(scores["ndtw"], 100 * np.exp(-5 / 40))
            metadata["split"] = "test"
            (root / "ori_info.json").write_text(json.dumps(metadata), encoding="utf-8")
            with self.assertRaisesRegex(ClosedLoopAuditError, "隐藏真值"):
                read_rollout_metrics(root)

    def test_mixed_checkpoints_or_budget_reject_aggregation(self):
        fake_dtw = SimpleNamespace(fastdtw=lambda a, b, dist: (0., None))
        for field, value in (("checkpoint_sha256", "b" * 64), ("max_steps", 6)):
            with TemporaryDirectory() as temporary, patch.dict(sys.modules, {"fastdtw": fake_dtw}):
                root = Path(temporary)
                result, _, _ = self.rollout()
                info = self.metadata(result)
                write_episode(root / "episodes" / "one", result, info)
                info = copy.deepcopy(info)
                info["execution_config"][field] = value
                write_episode(root / "episodes" / "two", result, info)
                summary = write_metrics(root, root / "episodes")
                self.assertEqual(summary["status"], "closed_loop_invalid")
                self.assertIsNone(summary["metrics"]["sr"])

    def test_changed_action_pose_and_wrong_reference_start_rejected(self):
        result, _, _ = self.rollout()
        result["records"][0]["action"] = 2
        with TemporaryDirectory() as temporary:
            root = Path(temporary) / "one"
            write_episode(root, result, self.metadata(result))
            with self.assertRaises(ClosedLoopAuditError):
                read_rollout_metrics(root)
        with TemporaryDirectory() as temporary:
            root = Path(temporary) / "legacy"
            metadata = episode_metadata()
            metadata["reference_positions"].insert(0, [-100, 0, 0])
            write_episode(root, metadata=metadata)
            with self.assertRaisesRegex(ClosedLoopAuditError, "reset"):
                read_rollout_metrics(root)

    def test_aerial_frozen_manifest_and_protocol_pass_and_tampering_fails(self):
        import hashlib
        from uavnav.avln.metadata import aerial_task_protocol, evaluation_manifest_sha256
        protocol = aerial_task_protocol()
        digest = hashlib.sha256(json.dumps(protocol, sort_keys=True, separators=(",", ":"), ensure_ascii=False).encode()).hexdigest()
        manifest = {"schema_version": 1, "scope": "subset_diagnostic", "split": "val_unseen",
                    "source_sha256": "c" * 64, "evaluation_protocol_sha256": digest,
                    "episodes": [{"traj_id": "2/1", "split": "val_unseen"}]}
        result, _, _ = self.rollout()
        info = self.metadata(result)
        info.update(evaluation_manifest_sha256=evaluation_manifest_sha256(manifest),
                    evaluation_protocol_sha256=digest, evaluation_scope="subset_diagnostic")
        fake_dtw = SimpleNamespace(fastdtw=lambda a, b, dist: (0., None))
        with TemporaryDirectory() as temporary, patch.dict(sys.modules, {"fastdtw": fake_dtw}):
            root = Path(temporary)
            write_episode(root / "episodes" / "one", result, info)
            (root / "evaluation_manifest.json").write_text(json.dumps(manifest), encoding="utf-8")
            (root / "evaluation_protocol.json").write_text(json.dumps(protocol), encoding="utf-8")
            scores = write_metrics(root, root / "episodes")
            self.assertEqual(scores["status"], "closed_loop")
            self.assertEqual(scores["metrics"]["sr"], 100)
            protocol["image_size"] = 128
            (root / "evaluation_protocol.json").write_text(json.dumps(protocol), encoding="utf-8")
            scores = write_metrics(root, root / "episodes")
            self.assertEqual(scores["status"], "closed_loop_invalid")
            self.assertIsNone(scores["metrics"]["sr"])

    def test_malformed_probabilities_are_audited_without_crashing(self):
        result, _, _ = self.rollout()
        result["records"][0]["action_probabilities"] = "bad"
        with TemporaryDirectory() as temporary:
            root = Path(temporary)
            write_episode(root / "episodes" / "one", result, self.metadata(result))
            scores = write_metrics(root, root / "episodes")
            self.assertEqual(scores["status"], "closed_loop_invalid")
            self.assertEqual(scores["audit"]["rejected_rollouts"], 1)

    def test_route_arguments_reject_fov_overrides_before_loading(self):
        import evaluate
        for extra in (("--camera-name", "0"), ("--success-distance", "10"), ("--vehicle-name", "other"),
                      ("--action-duration", "1"), ("--list-json", "test.json"), ("--spl-definition", "standard")):
            with patch("uavnav.avln.data.load_aerial_episodes") as loader, contextlib.redirect_stderr(io.StringIO()):
                with self.assertRaises(SystemExit):
                    evaluate.main(["--dataset", "aerialvln_s_v1", "--backend", "airsim", "--data-root", ".",
                                   "--split", "val_unseen", "--output", "unused", *extra])
                loader.assert_not_called()

    def test_recurrent_rollout_resets_state_once_per_episode(self):
        from uavnav.avln.closed_loop import rollout_aerial_episode
        for architecture in ("aerial_route_recurrent_v2", "airvln_seq2seq_rgb_v1", "airvln_cma_rgb_v1"):
            with self.subTest(architecture=architecture):
                predictor = SimpleNamespace(config={"architecture": architecture}, resets=0, hidden=99, seen=[])
                def reset():
                    predictor.resets += 1
                    predictor.hidden = 0
                def predict_action(image, instruction, history):
                    predictor.seen.append((predictor.hidden, list(history)))
                    action = 3 if predictor.hidden == 0 else 0
                    predictor.hidden += 1
                    return {"action": action, "action_probabilities": np.eye(8)[action].tolist()}
                predictor.reset_episode, predictor.predict_action = reset, predict_action
                for _ in range(2):
                    env, _ = self.environment()
                    result = rollout_aerial_episode(env, predictor, "turn then stop")
                    self.assertEqual(result["steps"], 1)
                    self.assertTrue(result["policy_state_reset"])
                self.assertEqual(predictor.resets, 2)
                self.assertEqual(predictor.seen, [(0, []), (1, [3]), (0, []), (1, [3])])
                predictor.reset_episode = None
                with self.assertRaisesRegex(ValueError, "reset_episode"):
                    rollout_aerial_episode(self.environment()[0], predictor, "turn")

    def test_official_rgb_adapter_scoring_requires_sources_reset_and_environment_depth(self):
        """合成闭环合同；fake DTW只检查审核权限，不作为导航指标证据。"""
        fake_dtw = SimpleNamespace(fastdtw=lambda a, b, dist: (0., None))
        for architecture, layers in (("airvln_seq2seq_rgb_v1", 1), ("airvln_cma_rgb_v1", 2)):
            result, _, _ = self.rollout()
            result["policy_state_reset"] = True
            info = self.metadata(result)
            info["execution_config"].update(architecture=architecture, policy=f"{architecture}_argmax",
                memory_protocol="airvln_recurrent_gru_v1", memory_mode="carry", vision_batchnorm_protocol="causal_fixed_bn_v1",
                sequence_policy="episode_contiguous_tbptt_v1", tokenizer_version="route_numeric_v1",
                baseline_protocol="official_network_matched_training_adapter_v1", memory_layers=layers, memory_hidden_size=512,
                raw_rgb_adapter="imagenet_denormalize_round_uint8_v1",
                depth_policy="official_ablate_depth_true_environment_depth_retained_v1",
                upstream_source_sha256={"Model/policy.py": "c" * 64}, ddppo_checkpoint_sha256="d" * 64)
            with TemporaryDirectory() as temporary, patch.dict(sys.modules, {"fastdtw": fake_dtw}):
                root = Path(temporary) / "one"
                write_episode(root, result, info)
                self.assertEqual(read_rollout_metrics(root)["status"], "closed_loop")
                changed_result = copy.deepcopy(result)
                changed_result["policy_state_reset"] = False
                (root / "rollout.json").write_text(json.dumps(changed_result), encoding="utf-8")
                with self.assertRaisesRegex(ClosedLoopAuditError, "官方网络"):
                    read_rollout_metrics(root)
                (root / "rollout.json").write_text(json.dumps(result), encoding="utf-8")
                changes = (("upstream_source_sha256", {}), ("upstream_source_sha256", {"Model/policy.py": "bad"}),
                           ("ddppo_checkpoint_sha256", None), ("memory_layers", 2 if layers == 1 else 1),
                           ("memory_hidden_size", 128), ("memory_protocol", "fused_gru_v1"),
                           ("depth_policy", "remove_environment_depth"), ("raw_rgb_adapter", "normalized_float_direct"))
                for field, value in changes:
                    changed = copy.deepcopy(info)
                    changed["execution_config"][field] = value
                    (root / "ori_info.json").write_text(json.dumps(changed), encoding="utf-8")
                    with self.subTest(architecture=architecture, field=field, value=value), self.assertRaisesRegex(ClosedLoopAuditError, "官方网络"):
                        read_rollout_metrics(root)

    def test_recurrent_scoring_requires_state_reset_and_versioned_memory(self):
        result, _, _ = self.rollout()
        info = self.metadata(result)
        info["execution_config"].update(architecture="aerial_route_recurrent_v2", policy="aerial_route_recurrent_v2_argmax",
            memory_protocol="fused_gru_v1", sequence_policy="episode_contiguous_tbptt_v1", tokenizer_version="route_numeric_v1",
            memory_mode="carry", vision_batchnorm_protocol="frozen_running_stats_v1")
        fake_dtw = SimpleNamespace(fastdtw=lambda a, b, dist: (0., None))
        with TemporaryDirectory() as temporary, patch.dict(sys.modules, {"fastdtw": fake_dtw}):
            root = Path(temporary) / "one"
            write_episode(root, result, info)
            with self.assertRaisesRegex(ClosedLoopAuditError, "重置"):
                read_rollout_metrics(root)
            result["policy_state_reset"] = True
            (root / "rollout.json").write_text(json.dumps(result), encoding="utf-8")
            self.assertEqual(read_rollout_metrics(root)["sr"], 100)
            for field, value in (("memory_protocol", "none"), ("memory_mode", "other"),
                                 ("vision_batchnorm_protocol", "future_stats")):
                changed = copy.deepcopy(info)
                changed["execution_config"][field] = value
                (root / "ori_info.json").write_text(json.dumps(changed), encoding="utf-8")
                with self.assertRaisesRegex(ClosedLoopAuditError, "记忆"):
                    read_rollout_metrics(root)

    def test_training_route_scoring_requires_explicit_seen_diagnostic(self):
        import hashlib
        from uavnav.avln.metadata import aerial_task_protocol, evaluation_manifest_sha256
        result, _, _ = self.rollout()
        info = self.metadata(result)
        info["split"] = "train"
        task = aerial_task_protocol()
        task_hash = hashlib.sha256(json.dumps(task, sort_keys=True, separators=(",", ":"), ensure_ascii=False).encode()).hexdigest()
        manifest = {"schema_version": 1, "scope": "subset_diagnostic", "split": "train",
                    "source_sha256": "b" * 64, "evaluation_protocol_sha256": task_hash,
                    "episodes": [{"traj_id": "2/1", "split": "train"}]}
        info.update(evaluation_manifest_sha256=evaluation_manifest_sha256(manifest),
                    evaluation_protocol_sha256=task_hash, evaluation_scope="subset_diagnostic",
                    evaluation_purpose="training_route_completion", seen_in_training=True)
        info["execution_config"].update(evaluation_purpose="training_route_completion", seen_in_training=True,
                                       training_split_manifest_sha256="c" * 64)
        fake_dtw = SimpleNamespace(fastdtw=lambda a, b, dist: (0., None))
        with TemporaryDirectory() as temporary, patch.dict(sys.modules, {"fastdtw": fake_dtw}):
            root = Path(temporary)
            write_episode(root / "episodes" / "one", result, info)
            (root / "evaluation_manifest.json").write_text(json.dumps(manifest), encoding="utf-8")
            (root / "evaluation_protocol.json").write_text(json.dumps(task), encoding="utf-8")
            summary = write_metrics(root, root / "episodes")
            self.assertEqual(summary["status"], "closed_loop")
            self.assertEqual(summary["evaluation_purpose"], "training_route_completion")
            self.assertFalse(summary["generalization_evidence"])
            info["seen_in_training"] = False
            (root / "episodes" / "one" / "ori_info.json").write_text(json.dumps(info), encoding="utf-8")
            with self.assertRaisesRegex(ClosedLoopAuditError, "已训练"):
                read_rollout_metrics(root / "episodes" / "one")

    def test_development_route_scoring_preserves_holdout_label_and_rejects_seen_flag(self):
        result, _, _ = self.rollout()
        info = self.metadata(result)
        info.update(split="train", evaluation_purpose="development_route_completion", seen_in_training=False)
        info["execution_config"].update(evaluation_purpose="development_route_completion", seen_in_training=False,
                                       training_split_manifest_sha256="a" * 64, development_route_split_sha256="b" * 64)
        with TemporaryDirectory() as temporary, patch.dict(sys.modules, {"fastdtw": SimpleNamespace(fastdtw=lambda *a, **k: (0., None))}):
            root = Path(temporary)
            episode, result, info = self.save_v2_episode(root, result, info)
            summary = write_metrics(root, root / "episodes")
            self.assertEqual(summary["status"], "closed_loop")
            self.assertEqual(summary["evaluation_purpose"], "development_route_completion")
            self.assertFalse(summary["seen_in_training"])
            self.assertTrue(summary["generalization_evidence"])
            self.assertFalse(summary["official_generalization_evidence"])
            info["seen_in_training"] = True
            (episode / "ori_info.json").write_text(json.dumps(info), encoding="utf-8")
            with self.assertRaisesRegex(ClosedLoopAuditError, "独立开发"):
                read_rollout_metrics(episode)

    def test_training_route_requires_flag_and_single_episode_before_loading(self):
        import evaluate
        base = ["--dataset", "aerialvln_s_v1", "--backend", "airsim", "--data-root", ".", "--split", "train", "--output", "unused"]
        for extra in ([], ["--training-route-diagnostic"], ["--training-route-diagnostic", "--scene-id", "2"]):
            with patch("uavnav.avln.data.load_aerial_episodes") as loader, contextlib.redirect_stderr(io.StringIO()):
                with self.assertRaises(SystemExit):
                    evaluate.main(base + extra)
                loader.assert_not_called()

    def test_training_route_entrypoint_checks_frozen_membership_and_labels_scope(self):
        import evaluate
        import hashlib
        import torch
        from uavnav.avln.metadata import aerial_task_protocol
        with TemporaryDirectory() as temporary:
            root = Path(temporary)
            run = root / "run"
            (run / "weights").mkdir(parents=True)
            checkpoint = run / "weights" / "last.pt"
            checkpoint.write_bytes(b"fixture_checkpoint")
            frozen = {"data_protocol": "aerialvln_s_v1", "train_episode_ids": ["2/known"], "train_annotation_sha256": "a" * 64}
            manifest_path = run / "split_manifest.json"
            manifest_path.write_text(json.dumps(frozen), encoding="utf-8")
            predictor = SimpleNamespace(device=torch.device("cpu"), config={"architecture": "aerial_route_v1",
                "task_protocol": aerial_task_protocol(), "history_frames": 8,
                "split_manifest_sha256": hashlib.sha256(manifest_path.read_bytes()).hexdigest()})
            def reset():
                predictor.calls = 0
            def predict(image, instruction, history):
                action = 1 if predictor.calls == 0 else 0
                predictor.calls += 1
                return {"action": action, "action_probabilities": np.eye(8)[action].tolist()}
            predictor.checkpoint_sha256 = __import__("hashlib").sha256(checkpoint.read_bytes()).hexdigest()
            predictor.reset_episode, predictor.predict_action = reset, predict
            episode = {"scene_id": 2, "episode_id": "known", "start_position": [0, 0, -10],
                "start_rotation": [1, 0, 0, 0], "instruction": {"instruction_text": "forward then stop"},
                "goals": [{"position": [5, 0, -10]}], "reference_path": [[0, 0, -10, 0, 0, 0], [5, 0, -10, 0, 0, 0]],
                "_episode_sha256": "b" * 64, "_annotation_sha256": "a" * 64, "_quarantine_reason": None}
            base = ["--dataset", "aerialvln_s_v1", "--backend", "airsim", "--data-root", str(root),
                    "--split", "train", "--training-route-diagnostic", "--scene-id", "2", "--episode-id", "known",
                    "--scene-ready", "--checkpoint", str(checkpoint), "--device", "cpu"]
            fake_dtw = SimpleNamespace(fastdtw=lambda a, b, dist: (0., None))
            fixture_env = self.environment()[0]
            with patch("uavnav.avln.data.load_aerial_episodes", return_value=[episode]), \
                 patch("uavnav.avln.inference.load_predictor", return_value=predictor), \
                 patch("uavnav.avln.airsim_env.AerialRouteEnv", return_value=fixture_env), \
                 patch.dict(sys.modules, {"fastdtw": fake_dtw}):
                evaluate.main(base + ["--output", str(root / "valid")])
                summary = json.loads((root / "valid" / "metrics.json").read_text(encoding="utf-8"))
                self.assertEqual(summary["status"], "closed_loop")
                self.assertEqual(summary["evaluation_scope"], "subset_diagnostic")
                self.assertFalse(summary["generalization_evidence"])
                self.assertEqual(summary["metrics"]["autonomous_stop_success"], 100)
                # Same real-entrypoint control path, fake SDK and controlled DTW only.
                evaluate.main(base + ["--output", str(root / "v2"), "--metric-protocol", "eval_adapter_v2", "--max-steps", "200"])
                updated = json.loads((root / "v2" / "metrics.json").read_text(encoding="utf-8"))
                protocol = json.loads((root / "v2" / "evaluation_protocol.json").read_text(encoding="utf-8"))
                manifest = json.loads((root / "v2" / "evaluation_manifest.json").read_text(encoding="utf-8"))
                roll = json.loads((root / "v2" / "episodes" / "2_known" / "rollout.json").read_text(encoding="utf-8"))
                digest = hashlib.sha256(json.dumps(protocol, sort_keys=True, separators=(",", ":"), ensure_ascii=False).encode()).hexdigest()
                self.assertEqual(protocol["schema_version"], 2)
                self.assertEqual(protocol["metric_protocol"], "eval_adapter_v2")
                self.assertEqual(protocol["max_steps"], 200)
                self.assertEqual(manifest["evaluation_protocol_sha256"], digest)
                self.assertEqual(manifest["schema_version"], 2)
                self.assertEqual(manifest["episodes"][0]["episode_sha256"], episode["_episode_sha256"])
                self.assertRegex(manifest["episodes"][0]["scoring_truth_sha256"], r"^[a-f0-9]{64}$")
                self.assertEqual(roll["execution_config"]["evaluation_protocol_sha256"], digest)
                self.assertEqual(roll["metric_protocol"], "eval_adapter_v2")
                self.assertEqual(updated["status"], "closed_loop")
                self.assertFalse(updated["generalization_evidence"])
                self.assertEqual(updated["metrics"]["autonomous_stop_success"], 100)
                frozen["train_episode_ids"] = []
                manifest_path.write_text(json.dumps(frozen), encoding="utf-8")
                predictor.config["split_manifest_sha256"] = hashlib.sha256(manifest_path.read_bytes()).hexdigest()
                with self.assertRaisesRegex(ValueError, "已训练episode"):
                    evaluate.main(base + ["--output", str(root / "invalid")])

    def test_teacher_replay_sorts_frames_and_resets_different_instructions(self):
        from uavnav.avln.closed_loop import replay_aerial_teacher_samples
        predictor = SimpleNamespace(config={"architecture": "aerial_route_recurrent_v2"}, resets=0, seen=[], hidden=99)
        def reset():
            predictor.resets += 1
            predictor.hidden = 0
        def predict(image, instruction, history):
            predictor.seen.append((image, instruction, predictor.hidden, list(history)))
            predictor.hidden += 1
            # Teacher replay must still reach end when predicted STOP at first frame.
            return {"action": 0, "action_probabilities": np.eye(8)[0].tolist()}
        predictor.reset_episode, predictor.predict_action = reset, predict
        rows = []
        for episode, instruction in (("a", "left"), ("b", "right")):
            for index, action in enumerate((2, 0)):
                rows.append({"scene_id": 2, "episode_id": episode, "frame_index": index,
                    "traj_id": "same/route", "episode_sha256": episode * 64,
                    "instruction": instruction, "image": f"{episode}-{index}", "action": action,
                    "history": np.eye(8)[[2]] if index else np.zeros((0, 8))})
        results = replay_aerial_teacher_samples(predictor, list(reversed(rows)))
        self.assertEqual(predictor.resets, 2)
        self.assertEqual(predictor.seen, [("a-0", "left", 0, []), ("a-1", "left", 1, [2]),
                                       ("b-0", "right", 0, []), ("b-1", "right", 1, [2])])
        self.assertEqual([row["frame_index"] for row in results], [0, 1, 0, 1])
        with self.assertRaisesRegex(ValueError, "frame0"):
            replay_aerial_teacher_samples(predictor, rows[1:2])

    def test_majority_prior_is_from_training_and_missing_classes_explicit(self):
        from scripts.audit_training import action_classification_summary
        matrix = np.zeros((8, 8), dtype=int)
        matrix[0, 1] = 1
        matrix[1, 1] = 25
        matrix[2, 1] = 2
        summary = action_classification_summary(matrix, [{"action": 2}, {"action": 2}, {"action": 1}])
        self.assertEqual(summary["training_majority_action"], 2)
        self.assertAlmostEqual(summary["training_majority_prior_accuracy"], 2 / 28)
        self.assertAlmostEqual(summary["accuracy"], 25 / 28)
        self.assertAlmostEqual(summary["balanced_accuracy_present_classes"], 1 / 3)
        self.assertEqual(summary["missing_classes"], [3, 4, 5, 6, 7])
        self.assertIsNone(summary["class_recall"][7])
        self.assertEqual(summary["stop_recall"], 0)
        self.assertIsNone(summary["stop_precision"])

    def test_representative_route_selection_preserves_instructions_and_action_coverage(self):
        from scripts.verify_stage2 import _select_aerial_routes
        def episode(identifier, actions, offset=0, scene=2, quarantine=None):
            return {"episode_id": identifier, "scene_id": scene, "actions": actions,
                    "reference_path": [[offset + index, 0, -10, 0, 0, 0] for index in range(len(actions))],
                    "start_rotation": [1, 0, 0, 0], "instruction": {"instruction_text": identifier},
                    "_quarantine_reason": quarantine}
        straight = episode("a", [1, 1, 1, 1, 0])
        duplicate = {**copy.deepcopy(straight), "episode_id": "b", "instruction": {"instruction_text": "another route description"}}
        turn_side = episode("c", [3, 1, 7, 4, 5, 6, 2, 0], offset=100)
        other_scene = episode("d", [3, 0], scene=7)
        quarantine = episode("e", [0], quarantine="singleton")
        rows = [straight, duplicate, turn_side, other_scene, quarantine]
        representative = _select_aerial_routes(rows, 2, 1, "representative")
        self.assertEqual({row[1]["episode_id"] for row in representative}, {"c"})
        shortest = _select_aerial_routes(rows, 2, 1, "integration_shortest")
        self.assertEqual({row[1]["episode_id"] for row in shortest}, {"a", "b"})
        self.assertEqual(len({key for key, _ in shortest}), 1)
        all_rows = _select_aerial_routes(rows, 2, 1, "all")
        self.assertEqual({row[1]["episode_id"] for row in all_rows}, {"a", "b", "c"})
        bad = {**copy.deepcopy(duplicate), "actions": [2, 1, 1, 1, 0]}
        with self.assertRaisesRegex(ValueError, "动作"):
            _select_aerial_routes([straight, bad], 2, 1, "all")


class TrainingAuditDiagnosticsTests(unittest.TestCase):
    """仅验离线诊断数学与来源合同，不构成真实训练/导航成绩。"""

    def test_teacher_replay_checks_and_decodes_identical_rgb_bytes(self):
        import hashlib
        from scripts.audit_training import replay_verified_teacher_samples
        with TemporaryDirectory() as folder:
            path = Path(folder) / "frame.png"
            Image.new("RGB", (2, 2), (20, 30, 40)).save(path)
            original_bytes = path.read_bytes()
            replacement = io.BytesIO()
            Image.new("RGB", (2, 2), (200, 210, 220)).save(replacement, format="PNG")
            samples = [{"scene_id": 2, "episode_id": "test", "frame_index": 0, "action": 0,
                        "instruction": "stop", "image": str(path),
                        "image_sha256": hashlib.sha256(original_bytes).hexdigest(),
                        "history": np.zeros((0, 8), dtype=np.float32)}]
            seen = []
            predictor = SimpleNamespace(reset_episode=lambda: None)
            def predict(image, instruction, history):
                seen.append(image.getpixel((0, 0)))
                return {"action": 0, "action_probabilities": np.eye(8)[0].tolist()}
            predictor.predict_action = predict
            real_read = Path.read_bytes
            def read_then_replace(source):
                data = real_read(source)
                source.write_bytes(replacement.getvalue())
                return data
            with patch.object(Path, "read_bytes", autospec=True, side_effect=read_then_replace) as reads:
                result = replay_verified_teacher_samples(predictor, samples)
            self.assertEqual(reads.call_count, 1)
            self.assertEqual(seen, [(20, 30, 40)])
            self.assertEqual(result[0]["teacher_action"], 0)
            with self.assertRaisesRegex(ValueError, "image_sha256"):
                replay_verified_teacher_samples(predictor, samples)
            self.assertEqual(len(seen), 1)

    def test_actual_loss_scale_matches_sequence_objective_for_both_protocols(self):
        import math
        import torch
        from scripts.audit_training import loss_scale_summary
        from uavnav.avln.fit import _aerial_sequence_epoch

        class ZeroLogits(torch.nn.Module):
            def forward_sequence(self, batch, state):
                return torch.zeros(len(batch["history_length"]), 8), torch.zeros(1)

        for length in (1, 16, 17, 31, 32, 33):
            actions = [0] if length == 1 else [1] * (length - 2) + [5, 0]
            samples = [{"scene_id": 2, "episode_id": "test", "frame_index": i, "action": action,
                        "instruction": "synthetic"} for i, action in enumerate(actions)]
            for version, normalization in (("transition_weighted_ce_v1", "sum_weights"),
                                            ("episode_normalized_ce_v2", "episode_sum_weights")):
                protocol = {"version": version, "normalization": normalization,
                            "inflection_weight": 1.9, "stop_weight": 1.9}
                with self.subTest(length=length, version=version):
                    report = loss_scale_summary([{"actions": actions}], 16, protocol)
                    def fake_collate(selected, *unused):
                        return {"action_target": torch.tensor([row["action"] for row in selected]),
                                "history_length": torch.zeros(len(selected), dtype=torch.long)}
                    with patch("uavnav.avln.fit.collate", side_effect=fake_collate):
                        actual = _aerial_sequence_epoch(ZeroLogits(), [samples], None, 16, 8, 16,
                                                       torch.device("cpu"), loss_protocol=protocol)
                    formulas = [chunk["formulas"]["actual_training_formula"] for chunk in report["chunks"]]
                    self.assertAlmostEqual(actual["chunk_objective_mean_diagnostic"],
                        sum(row["synthetic_uniform_logit_loss"] for row in formulas) / len(formulas), places=6)
                    expected_mass = 1 if normalization == "episode_sum_weights" else math.ceil(length / 16)
                    self.assertAlmostEqual(report["actual_coefficient_mass_over_updates"], expected_mass, places=6)
                    for row in formulas:
                        self.assertAlmostEqual(row["synthetic_uniform_logit_gradient_l1"],
                                               1.75 * row["coefficient_sum"], places=5)
                        self.assertTrue(row["synthetic_uniform_logit_gradients_finite_nonzero"])

    def test_teacher_replay_releases_each_rgb_before_loading_next_and_preserves_memory(self):
        import hashlib
        from scripts.audit_training import replay_verified_teacher_samples
        from uavnav.avln.closed_loop import replay_aerial_teacher_samples
        with TemporaryDirectory() as folder:
            samples = []
            for index, action in enumerate((1, 5, 0)):
                path = Path(folder) / f"{index}.png"
                Image.new("RGB", (2, 2), (index, 0, 0)).save(path)
                samples.append({"scene_id": 2, "episode_id": "test", "frame_index": index,
                    "action": action, "instruction": "synthetic", "image": str(path),
                    "image_sha256": hashlib.sha256(path.read_bytes()).hexdigest(),
                    "history": np.eye(8, dtype=np.float32)[[1, 5][:index]] if index else np.zeros((0, 8))})
            seen, retained = [], []
            predictor = SimpleNamespace(reset_episode=lambda: seen.append("reset"))
            real_read = Path.read_bytes
            def read(source):
                if retained:
                    with self.assertRaises(ValueError):
                        retained[-1].getpixel((0, 0))
                seen.append(f"read{source.stem}")
                return real_read(source)
            def predict(image, instruction, history):
                retained.append(image)
                seen.append(f"predict{image.getpixel((0, 0))[0]}")
                return {"action": 0}
            predictor.predict_action = predict
            with patch.object(Path, "read_bytes", autospec=True, side_effect=read):
                result = replay_verified_teacher_samples(predictor, samples)
            self.assertEqual(seen, ["reset", "read0", "predict0", "read1", "predict1", "read2", "predict2"])
            self.assertEqual([row["teacher_history"] for row in result], [[], [1], [1, 5]])
            with self.assertRaises(ValueError):
                retained[-1].getpixel((0, 0))
            seen.clear()
            predictor.predict_action = lambda image, instruction, history: {"action": 0, "source": image}
            default_result = replay_aerial_teacher_samples(predictor, samples)
            self.assertEqual(seen, ["reset"])
            self.assertEqual([row["prediction"]["source"] for row in default_result], [sample["image"] for sample in samples])

    def test_candidate_update_evidence_requires_committed_records_and_epoch_prefix(self):
        from scripts.audit_training import candidate_update_evidence
        with TemporaryDirectory() as folder:
            run = Path(folder)
            rows = [{"epoch": epoch, "optimizer_updates_in_epoch": 4, "optimizer_updates_total": 4 * epoch}
                    for epoch in (1, 2, 3)]
            content = ("\n".join(json.dumps(row) for row in rows) + "\n").encode()
            (run / "training_diagnostics.jsonl").write_bytes(content)
            committed = {"training_diagnostics.jsonl": content}
            for epoch in (1, 2, 3):
                self.assertEqual(candidate_update_evidence(run, epoch, 3, committed), 4 * epoch)
            for epoch in (0, 4):
                with self.assertRaises(ValueError):
                    candidate_update_evidence(run, epoch, 3, committed)
            with self.assertRaisesRegex(ValueError, "缺已提交"):
                candidate_update_evidence(run, 1, 3, {})
            with self.assertRaisesRegex(ValueError, "render pass"):
                candidate_update_evidence(run, 1, 3, committed, ledger_context={})
            rows[1]["optimizer_updates_total"] = 999999999
            incorrect = ("\n".join(json.dumps(row) for row in rows) + "\n").encode()
            (run / "training_diagnostics.jsonl").write_bytes(incorrect)
            with self.assertRaisesRegex(ValueError, "缺已提交"):
                candidate_update_evidence(run, 2, 3, committed)
            with self.assertRaisesRegex(ValueError, "累计值"):
                candidate_update_evidence(run, 2, 3, {"training_diagnostics.jsonl": incorrect})
            for malformed in (rows[:1] + rows[2:], [rows[0], rows[0], rows[2]],
                              [{**row, "optimizer_updates_in_epoch": 0} for row in rows]):
                content = ("\n".join(json.dumps(row) for row in malformed) + "\n").encode()
                (run / "training_diagnostics.jsonl").write_bytes(content)
                with self.assertRaises(ValueError):
                    candidate_update_evidence(run, 2, 3, {"training_diagnostics.jsonl": content})

    def test_candidate_update_evidence_verifies_actual_ledger_and_excludes_later_epochs(self):
        from scripts.audit_training import candidate_update_evidence
        with TemporaryDirectory() as folder:
            run = Path(folder)
            context = {"episodes": [[{"scene_id": 2, "episode_id": "test"}]], "pass_count": 1,
                       "pass_seed": 0, "shuffle_seed": 0, "chunk_size": 16}
            rows = [{"epoch": epoch, "seed": 0, "policy": "episode_uniform_pass_v1", "pass_count": 1,
                     "selections": [{"scene_id": 2, "episode_id": "test", "pass_index": 0}],
                     "samples": 1, "optimizer_updates": 1} for epoch in (1, 2, 3)]
            def commit(selected):
                content = ("\n".join(json.dumps(row) for row in selected) + "\n").encode()
                (run / "render_pass_selections.jsonl").write_bytes(content)
                return {"render_pass_selections.jsonl": content}
            committed = commit(rows)
            for epoch in (1, 2, 3):
                self.assertEqual(candidate_update_evidence(run, epoch, 3, committed, ledger_context=context), epoch)
            for malformed in (rows[:2], [rows[0], rows[0], rows[2]],
                              [{**row, "optimizer_updates": 0} for row in rows],
                              [{**row, "optimizer_updates": True} for row in rows],
                              [{**row, "optimizer_updates": 999999999} for row in rows]):
                with self.assertRaises(ValueError):
                    candidate_update_evidence(run, 2, 3, commit(malformed), ledger_context=context)

    def test_teacher_strata_geometry_macro_and_train_only_history_lookup(self):
        from scripts.audit_training import training_history_lookup, stratified_teacher_diagnostics
        def samples(identifier, actions):
            return [{"scene_id": 2, "episode_id": identifier, "frame_index": i, "action": action}
                    for i, action in enumerate(actions)]
        train = samples("train", [1, 1, 5, 0])
        lookup = training_history_lookup(train)
        self.assertEqual(lookup["actions"][(1, 1)], 5)
        self.assertEqual(lookup["fallback_action"], 1)
        rows = []
        for identifier, actions, predictions in (("a", [1, 1, 5, 0], [1, 1, 1, 1]),
                                                  ("b", [6, 0], [6, 0]), ("c", [7, 0], [7, 0])):
            rows.extend({"scene_id": 2, "episode_id": identifier, "frame_index": i,
                         "teacher_action": target, "prediction": {"action": prediction}}
                        for i, (target, prediction) in enumerate(zip(actions, predictions)))
        split = {"routes": [{"route_sha256": route, "episodes": [{"scene_id": 2, "episode_id": member}
                                                                 for member in members]}
                             for route, members in (("route1", ["a"]), ("route2", ["b", "c"]))]}
        result = stratified_teacher_diagnostics(rows, train, split, lookup)["strata"]
        self.assertEqual(result["all"]["frame_micro"]["true_action_counts"], [3, 2, 0, 0, 0, 1, 1, 1])
        self.assertAlmostEqual(result["all"]["geometry_macro_accuracy"], .75)
        self.assertAlmostEqual(result["all"]["episode_macro_accuracy"], 5 / 6)
        self.assertEqual(result["first_step"]["frame_micro"]["accuracy"], 1)
        self.assertEqual(result["stop"]["frame_micro"]["stop_recall"], 2 / 3)
        self.assertEqual(result["all"]["history_lookup"]["accuracy"], 4 / 8)
        self.assertEqual(lookup["training_action_counts"], [1, 2, 0, 0, 0, 1, 0, 0])
        self.assertEqual(result["sideways_action_6"]["frame_micro"]["class_precision"][6], 1)
        with self.assertRaisesRegex(ValueError, "frame0"):
            stratified_teacher_diagnostics(rows[1:], train)

    def test_explicit_candidate_requires_run_adjacent_inventory_and_csv_epoch(self):
        from scripts.audit_training import resolve_teacher_checkpoint, validate_candidate_inventory, validate_logged_checkpoint, sha256
        with TemporaryDirectory() as folder:
            run = Path(folder) / "run"
            weights = run / "weights"
            weights.mkdir(parents=True)
            path = weights / "epoch_003.pt"
            path.write_bytes(b"synthetic fixture, not a real checkpoint")
            choice, resolved = resolve_teacher_checkpoint(run, explicit=path)
            self.assertEqual((choice, resolved), ("candidate", path.resolve()))
            payload = {"epoch": 3, "val_loss": .8}
            hparams = {"candidate_epochs": [1, 3]}
            entry = {"epoch": 3, "optimizer_updates_total": 12, "path": "weights/epoch_003.pt",
                     "sha256": sha256(path), "unweighted_teacher_validation_ce": .8}
            inventory = {"version": "epoch_end_teacher_candidates_v1", "candidate_epochs": [1, 3],
                         "split_manifest_sha256": "f" * 64, "candidates": [entry]}
            (run / "candidate_inventory.json").write_text(json.dumps(inventory), encoding="utf-8")
            self.assertEqual(validate_candidate_inventory(run, path, payload, hparams, "f" * 64, expected_updates=12), entry)
            with self.assertRaisesRegex(ValueError, "累计更新数"):
                validate_candidate_inventory(run, path, payload, hparams, "f" * 64, expected_updates=999999999)
            validate_logged_checkpoint([{"epoch": "3", "val/loss": ".8"}], payload, name="candidate")
            with self.assertRaises(ValueError):
                validate_logged_checkpoint([{"epoch": "2", "val/loss": ".8"}], payload, name="candidate")
            with self.assertRaises(ValueError):
                resolve_teacher_checkpoint(run, explicit=run / "candidate_inventory.json")
            path.write_bytes(b"changed fixture")
            with self.assertRaises(ValueError):
                validate_candidate_inventory(run, path, payload, hparams, "f" * 64, expected_updates=12)


if __name__ == "__main__":
    unittest.main()
