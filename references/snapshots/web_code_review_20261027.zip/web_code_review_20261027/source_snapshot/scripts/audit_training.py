"""Audit one completed waypoint run with its exact saved validation split.

This evaluates recorded teacher observations, not closed-loop navigation.
Input interventions use an already trained model and are not trained ablations.
Writes evidence outside the source dataset and never changes the checkpoint.
"""

from __future__ import annotations

import argparse
import contextlib
import csv
import functools
import hashlib
import io
import json
import math
import random
import re
import time
from pathlib import Path
import sys

sys.path.insert(0, str(Path(__file__).resolve().parents[1]))

import numpy as np
import torch
import yaml
from PIL import Image
from torch.utils.data import DataLoader

from uavnav.avln.data import collate, iter_samples, load_instructions, load_list
from uavnav.avln.fit import _evaluate, _aerial_epoch, sample_content_sha256
from uavnav.avln.inference import load_predictor, WaypointPredictor

AIRVLN_BASELINES = ("airvln_seq2seq_rgb_v1", "airvln_cma_rgb_v1", "airvln_seq2seq_rgbd_v1", "airvln_cma_rgbd_v1")
RGBD_ARCHITECTURES = ("aerial_route_recurrent_rgbd_v3", "airvln_seq2seq_rgbd_v1", "airvln_cma_rgbd_v1")


def sha256(path):
    return hashlib.sha256(path.read_bytes()).hexdigest()


def validate_logged_best(rows, checkpoint, precision="6_significant_digits"):
    """旧6位CSV只约束可证明的舍入区间；不能据并列量化值否定正确best。"""
    return validate_logged_checkpoint(rows, checkpoint, precision, name="best", require_best=True)


def validate_logged_checkpoint(rows, checkpoint, precision="6_significant_digits", *, name, require_best=False):
    """核指定checkpoint对应epoch的CSV舍入区间，last不要求损失最优。"""
    digits = 17 if precision == "17_significant_digits" else 6
    def interval(row):
        value = float(row["val/loss"])
        magnitude = math.floor(math.log10(abs(value))) if value else -6
        tolerance = .5 * 10. ** (magnitude - digits + 1) + 1e-15 * max(1., abs(value))
        return value, tolerance
    matched = [row for row in rows if int(row["epoch"]) == int(checkpoint["epoch"])]
    if len(matched) != 1 or not math.isfinite(float(checkpoint["val_loss"])):
        raise ValueError(f"{name} checkpoint的epoch不存在或损失非有限")
    selected = matched[0]
    selected_value, selected_tolerance = interval(selected)
    actual = float(checkpoint["val_loss"])
    if abs(actual - selected_value) > selected_tolerance:
        raise ValueError(f"{name} checkpoint损失与该epoch日志舍入区间不一致")
    if require_best and any(actual > interval(row)[0] + interval(row)[1] for row in rows):
        raise ValueError(f"{name} checkpoint损失高于可由CSV确认的较优epoch")
    return selected


def validate_render_pass_ledger(entries, episodes, pass_count, pass_seed, shuffle_seed, chunk_size, epochs):
    """Verify the saved whole-episode choices and update budget from fixed seeds."""
    if len(entries) != epochs:
        raise ValueError("render pass选择日志epoch不完整")
    samples = sum(len(episode) for episode in episodes)
    updates = sum(math.ceil(len(episode) / chunk_size) for episode in episodes)
    for epoch, entry in enumerate(entries):
        rng = random.Random(pass_seed + epoch)
        choices = [rng.randrange(pass_count) for _ in episodes]
        order = list(range(len(episodes)))
        random.Random(shuffle_seed + epoch).shuffle(order)
        expected = [{"scene_id": episodes[index][0]["scene_id"],
                     "episode_id": str(episodes[index][0]["episode_id"]),
                     "pass_index": choices[index]} for index in order]
        if (entry.get("epoch") != epoch + 1 or entry.get("seed") != pass_seed
                or entry.get("policy") != "episode_uniform_pass_v1"
                or entry.get("pass_count") != pass_count or entry.get("selections") != expected
                or entry.get("samples") != samples or entry.get("optimizer_updates") != updates):
            raise ValueError("render pass选择、完整episode身份或更新预算与冻结合同不一致")


def resolve_teacher_checkpoint(run, choice="best", explicit=None):
    """候选只接受同run相邻weights/epoch_XXX.pt；best/last原义不变。"""
    run = Path(run).resolve()
    if choice not in ("best", "last"):
        raise ValueError("teacher_checkpoint_choice仅支持best/last")
    path = (Path(explicit) if explicit is not None else run / "weights" / f"{choice}.pt").resolve()
    if path.parent != run / "weights" or not path.is_file():
        raise ValueError("教师checkpoint必须存在于本run的weights目录，不能使用外部或嵌套候选")
    if explicit is not None and re.fullmatch(r"epoch_[0-9]{3,}\.pt", path.name) is None:
        raise ValueError("显式候选必须命名epoch_XXX.pt；best/last使用原choice入口")
    return ("candidate" if explicit is not None else choice), path


def validate_candidate_inventory(run, path, payload, hparams, split_sha, *, expected_updates):
    """候选须由训练开始前登记的epoch清单产生，不认证事后复制的权重。"""
    inventory = json.loads((run / "candidate_inventory.json").read_text(encoding="utf-8"))
    if (inventory.get("version") != "epoch_end_teacher_candidates_v1"
            or inventory.get("candidate_epochs") != hparams.get("candidate_epochs")
            or payload["epoch"] not in hparams.get("candidate_epochs", [])
            or inventory.get("split_manifest_sha256") != split_sha):
        raise ValueError("候选未预登记或冻结来源合同不一致")
    matches = [entry for entry in inventory["candidates"] if entry.get("epoch") == payload["epoch"]]
    if len(matches) != 1:
        raise ValueError("候选清单epoch缺失或重复")
    entry = matches[0]
    if (entry.get("path") != path.relative_to(run).as_posix() or entry.get("sha256") != sha256(path)
            or entry.get("unweighted_teacher_validation_ce") != payload["val_loss"]
            or type(expected_updates) is not int or expected_updates <= 0
            or type(entry.get("optimizer_updates_total")) is not int
            or entry["optimizer_updates_total"] != expected_updates):
        raise ValueError("候选路径、SHA、验证CE或累计更新数不一致")
    return entry


def replay_verified_teacher_samples(predictor, samples):
    """每帧绑定同一次读取的SHA与解码字节，推理后立即释放RGB。"""
    from uavnav.avln.closed_loop import replay_aerial_teacher_samples
    @contextlib.contextmanager
    def verified_rgb(sample):
        raw = Path(sample["image"]).read_bytes()
        if hashlib.sha256(raw).hexdigest() != sample.get("image_sha256"):
            raise ValueError(f"教师回放RGB字节与冻结image_sha256不一致: {sample['image']}")
        with Image.open(io.BytesIO(raw)) as image:
            rgb = image.convert("RGB")
        try:
            yield rgb
        finally:
            rgb.close()
    return replay_aerial_teacher_samples(predictor, samples, rgb_context=verified_rgb)


def candidate_update_evidence(run, epoch, completed_epochs, committed_logs, *, ledger_context=None):
    """只累计已提交的实际更新记录；缺证据时不使用计划预算补数。"""
    if type(epoch) is not int or not 1 <= epoch <= completed_epochs:
        raise ValueError("候选epoch超出已提交训练范围")
    if ledger_context is not None:
        name = "render_pass_selections.jsonl"
        content = committed_logs.get(name)
        if content is None or not (run / name).is_file() or (run / name).read_bytes() != content:
            raise ValueError("候选累计更新认证缺已提交render pass日志")
        rows = [json.loads(line) for line in content.decode("utf-8").splitlines()]
        if any(type(row.get("optimizer_updates")) is not int or row["optimizer_updates"] <= 0 for row in rows):
            raise ValueError("候选render pass日志缺实际正整数更新数")
        validate_render_pass_ledger(rows, **ledger_context, epochs=completed_epochs)
        return sum(row["optimizer_updates"] for row in rows if row["epoch"] <= epoch)
    name = "training_diagnostics.jsonl"
    content = committed_logs.get(name)
    if content is None or not (run / name).is_file() or (run / name).read_bytes() != content:
        raise ValueError("候选累计更新认证缺已提交逐epoch诊断日志")
    rows = [json.loads(line) for line in content.decode("utf-8").splitlines()]
    if [row.get("epoch") for row in rows] != list(range(1, completed_epochs + 1)):
        raise ValueError("候选更新诊断epoch缺失、重复或顺序错误")
    total, selected = 0, None
    for row in rows:
        updates = row.get("optimizer_updates_in_epoch")
        if type(updates) is not int or updates <= 0:
            raise ValueError("候选更新诊断缺实际正整数更新数")
        total += updates
        if row.get("optimizer_updates_total") != total:
            raise ValueError("候选更新诊断累计值与逐epoch更新数不同")
        if row["epoch"] == epoch:
            selected = total
    if selected is None:
        raise ValueError("候选epoch不存在于已提交更新记录")
    return selected


def loss_scale_summary(episodes, chunk_size, protocol):
    """审核真实标签系数及合成零logits导数；不运行网络或模拟优化器更新。"""
    from uavnav.avln.fit import aerial_transition_weights, validate_aerial_loss_protocol
    if type(chunk_size) is not int or chunk_size <= 0 or not episodes:
        raise ValueError("损失尺度审核需要正整数chunk_size和非空episode")
    protocol = validate_aerial_loss_protocol(protocol)
    chunks = []
    for episode in episodes:
        actions = episode["actions"]
        weights = aerial_transition_weights(actions, protocol)
        for begin in range(0, len(actions), chunk_size):
            target = torch.as_tensor(actions[begin:begin + chunk_size], dtype=torch.long)
            selected = weights[begin:begin + len(target)]
            denominators = {"v1_sum_weights": float(selected.sum()),
                            "candidate_fixed_chunk_size_diagnostic": float(chunk_size),
                            "actual_training_formula": float(weights.sum() if
                                protocol["normalization"] == "episode_sum_weights" else selected.sum())}
            formulas = {}
            for name, denominator in denominators.items():
                logits = torch.zeros(len(target), 8, dtype=torch.float32, requires_grad=True)
                ce = torch.nn.functional.cross_entropy(logits, target, reduction="none")
                objective = (ce * selected).sum() / denominator
                gradient, = torch.autograd.grad(objective, logits)
                coefficients = selected / denominator
                formulas[name] = {"denominator": denominator,
                    "per_state_coefficients": coefficients.tolist(),
                    "coefficient_sum": float(coefficients.sum()),
                    "synthetic_uniform_logit_loss": float(objective.detach()),
                    "synthetic_uniform_logit_gradient_l1": float(gradient.abs().sum()),
                    "synthetic_uniform_logit_gradient_l2": float(gradient.norm()),
                    "synthetic_uniform_logit_per_state_gradient_l1": gradient.abs().sum(dim=1).tolist(),
                    "synthetic_uniform_logit_gradients_finite_nonzero": bool(
                        torch.isfinite(gradient).all() and (gradient.abs().sum(dim=1) > 0).all())}
            chunks.append({"scene_id": episode.get("scene_id"), "episode_id": episode.get("episode_id"),
                           "begin_frame_index": begin, "frames": len(target), "actions": target.tolist(),
                           "weights": selected.tolist(), "tail": len(target) < chunk_size,
                           "pure_class_chunk": bool((target == target[0]).all()),
                           "class_coefficient_mass": [float((selected[target == action] /
                               denominators["actual_training_formula"]).sum()) for action in range(8)],
                           "single_frame_stop": len(target) == 1 and int(target[0]) == 0,
                           "formulas": formulas})
    return {"loss_protocol": protocol, "actual_training_normalization": protocol["normalization"],
            "step_contract": {"optimizer_steps_per_chunk": 1, "gradient_accumulation_steps": 1,
                              "state_detached_after_each_chunk": True, "parameter_gradient_clip_norm": 1.0},
            "label_episodes": len(episodes), "label_states": sum(len(ep["actions"]) for ep in episodes),
            "chunks": chunks, "v1_coefficient_mass_over_updates": sum(
                chunk["formulas"]["v1_sum_weights"]["coefficient_sum"] for chunk in chunks),
            "actual_coefficient_mass_over_updates": sum(
                chunk["formulas"]["actual_training_formula"]["coefficient_sum"] for chunk in chunks),
            "candidate_coefficient_mass_over_updates": sum(
                chunk["formulas"]["candidate_fixed_chunk_size_diagnostic"]["coefficient_sum"] for chunk in chunks),
            "gradient_scope": "synthetic independent zero logits, before clipping; not network parameter gradients",
            "candidate_status": "diagnostic only; not a supported training loss or proven navigation benefit"}


def recorded_action_episodes(document, cache_episodes):
    """只接完整有来源序列；逐帧教师记录须连续且与保存缓存身份/长度相符。"""
    if not isinstance(document, dict):
        raise ValueError("监督JSON必须为包含episodes或long82_predictions的对象")
    if "long82_predictions" in document:
        grouped = {}
        for row in document["long82_predictions"]:
            key = (row["scene_id"], str(row["episode_id"]))
            grouped.setdefault(key, []).append(row)
        episodes = []
        for (scene, episode), rows in grouped.items():
            if [row["frame_index"] for row in rows] != list(range(len(rows))):
                raise ValueError("保存教师序列帧必须从0连续，无重复或重排")
            episodes.append({"scene_id": scene, "episode_id": episode,
                             "actions": [row["teacher_action"] for row in rows]})
    else:
        episodes = document.get("episodes")
    if not isinstance(episodes, list) or not episodes:
        raise ValueError("监督JSON无完整episode动作")
    lengths = {(ep["scene_id"], str(ep["episode_id"])): len(ep["frames"]) for ep in cache_episodes}
    seen = set()
    normalized = []
    for episode in episodes:
        key = (episode["scene_id"], str(episode["episode_id"]))
        actions = episode["actions"]
        if key in seen or key not in lengths or not isinstance(actions, list) or len(actions) != lengths[key]:
            raise ValueError("监督episode身份重复、不在缓存或不是完整缓存长度")
        if any(type(action) is not int or not 0 <= action <= 7 for action in actions):
            raise ValueError("动作必须是整数八动作类别")
        if actions[-1] != 0 or 0 in actions[:-1]:
            raise ValueError("完整路线须保留唯一末STOP")
        seen.add(key)
        normalized.append({"scene_id": key[0], "episode_id": key[1], "actions": actions})
    return normalized


def loss_scale_training_cache_partition(cache, manifest, hparams):
    """只按冻结train成员计更新；来源cache可含开发分区，但身份和长度须可核。"""
    from uavnav.avln.data import validate_aerial_route_split_manifest
    episodes = cache["episodes"]
    actual = {}
    for ep in episodes:
        key = (ep["scene_id"], str(ep["episode_id"]))
        if (key in actual or not ep["frames"]
                or [row["frame_index"] for row in ep["frames"]] != list(range(len(ep["frames"])))):
            raise ValueError("缓存episode重复、为空或帧序列不完整")
        actual[key] = ep
    source = {"source_cache_episodes": len(episodes),
              "source_cache_states": sum(len(ep["frames"]) for ep in episodes),
              "source_cache_dev_episodes": 0, "source_cache_dev_states": 0,
              "geometric_group_manifest_verified": False}
    if hparams.get("validation_split") != "development_train_grouped":
        if "development_route_split" in manifest:
            raise ValueError("缓存声明成组开发名单但训练未采用该模式")
        return episodes, source
    split = validate_aerial_route_split_manifest(manifest.get("development_route_split"))
    if split["annotation_sha256"] != cache.get("annotation_sha256") or cache.get("split") != "train":
        raise ValueError("损失审核成组开发标注/训练来源不一致")
    if (manifest.get("development_route_split_sha256") != split["manifest_sha256"]
            or hparams.get("development_route_split_sha256") != split["manifest_sha256"]
            or hparams.get("training_split_protocol") != split["split_protocol"]
            or hparams.get("development_fraction") != split.get("dev_fraction")
            or hparams.get("development_split_seed") != split.get("split_seed")):
        raise ValueError("损失审核成组开发hparams与冻结名单不一致")
    expected, partitions = {}, {"train": set(), "dev": set()}
    for row in split["routes"]:
        length = len(row["identity"]["positions_1e4_m"])
        for member in row["episodes"]:
            key = (member["scene_id"], str(member["episode_id"]))
            expected[key] = (member["episode_sha256"], length)
            partitions[row["partition"]].add(key)
    if (set(actual) not in (set(expected), partitions["train"])
            or manifest.get("train_episode_ids") != sorted(f"{scene}/{episode}" for scene, episode in partitions["train"])):
        raise ValueError("来源缓存含未知成员或缺训练成员，或训练名单不一致")
    for key, ep in actual.items():
        episode_sha, length = expected[key]
        if ep.get("episode_sha256") != episode_sha or len(ep["frames"]) != length:
            raise ValueError("来源缓存episode标注SHA或完整帧数与冻结route不符")
    dev = [ep for key, ep in actual.items() if key in partitions["dev"]]
    source.update(source_cache_dev_episodes=len(dev), source_cache_dev_states=sum(len(ep["frames"]) for ep in dev),
                  geometric_group_manifest_verified=True,
                  development_route_split_sha256=split["manifest_sha256"],
                  raw_annotation_actions_independently_reverified=False)
    return [actual[key] for key in sorted(partitions["train"])], source


def audit_loss_scale(args):
    """CPU审核冻结run长度/更新日志，缺监督时不推断转折和STOP权重。"""
    from uavnav.avln.fit import validate_aerial_loss_protocol
    run = args.run_dir.resolve()
    output = args.output_json.resolve()
    if output.exists():
        raise FileExistsError(f"损失审核输出已存在: {output}")
    if not output.parent.is_dir():
        raise ValueError("损失审核只能写入已存在的证据目录")
    hparams = yaml.safe_load((run / "hparams.yaml").read_text(encoding="utf-8"))
    if hparams.get("episode_batch"):
        raise ValueError("loss-scale仅认证单episode逐chunk更新，暂不支持episode_batch")
    manifest = json.loads((run / "split_manifest.json").read_text(encoding="utf-8"))
    chunk_size = hparams["sequence_chunk_size"]
    protocol = validate_aerial_loss_protocol(hparams["loss_protocol"])
    if (type(chunk_size) is not int or chunk_size <= 0
            or manifest.get("sequence_chunk_size") != chunk_size or manifest.get("loss_protocol") != protocol):
        raise ValueError("hparams与splitmanifest损失或chunk合同不一致")
    annotation_root = Path(hparams["annotation_root"]).resolve()
    if output.is_relative_to(annotation_root) or output.is_relative_to(run):
        raise ValueError("损失审核不得修改原标注或旧run")
    cache_path = run / "train_cache_manifest.json"
    if sha256(cache_path) != manifest["train_cache_manifest_sha256"]:
        raise ValueError("保存训练缓存清单SHA不符")
    cache = json.loads(cache_path.read_text(encoding="utf-8"))
    if cache.get("annotation_sha256") != manifest["train_annotation_sha256"]:
        raise ValueError("缓存与splitmanifest标注来源不一致")
    if cache.get("cache_kind") == "scene_shards_v1":
        from uavnav.avln.fit import load_aerial_training_partitions, aerial_child_source_records
        paths = [Path(hparams["cache_manifest"]), *hparams.get("render_pass_manifests", [])]
        children = aerial_child_source_records(paths, hparams["validation_cache_manifest"])
        if children != manifest.get("child_cache_sources"):
            raise ValueError("多场景损失审核子缓存来源与冻结清单不同")
        for record in children:
            if sha256(run / record["snapshot"]) != record["manifest_sha256"]:
                raise ValueError("多场景损失审核子缓存快照损坏")
        passes, _, route_split, _ = load_aerial_training_partitions(
            annotation_root, paths[0], Path(hparams["validation_cache_manifest"]), paths,
            hparams["history"], hparams["validation_split"], hparams.get("development_fraction", .2),
            hparams.get("development_split_seed", 0), run / "split_manifest.json" if
            hparams["validation_split"] == "development_train_grouped" else None,
            require_depth=hparams["architecture"] in RGBD_ARCHITECTURES)
        from uavnav.avln.data import group_aerial_episodes
        groups = group_aerial_episodes(passes[0], hparams["history"])
        if sample_content_sha256(passes[0]) != manifest["train_sample_content_sha256"]:
            raise ValueError("多场景损失审核实际训练输入/标签改变")
        episodes = [{"scene_id": ep[0]["scene_id"], "episode_id": ep[0]["episode_id"],
                     "frames": [{"frame_index": row["frame_index"]} for row in ep]} for ep in groups]
        source_cache = {"source_cache_episodes": len(cache["episodes"]),
                        "selected_training_episodes": len(groups), "source_cache_dev_states": None,
                        "geometric_group_manifest_verified": route_split is not None,
                        "raw_annotation_actions_independently_reverified": True,
                        "child_cache_sources": children}
    else:
        episodes, source_cache = loss_scale_training_cache_partition(cache, manifest, hparams)
    identities, compact, chunk_lengths = set(), [], []
    for ep in episodes:
        key = (ep["scene_id"], str(ep["episode_id"]))
        if key in identities or not ep["frames"] or [row["frame_index"] for row in ep["frames"]] != list(range(len(ep["frames"]))):
            raise ValueError("缓存episode重复、为空或帧序列不完整")
        identities.add(key)
        compact.append([{"scene_id": key[0], "episode_id": key[1]} for _ in ep["frames"]])
        chunk_lengths.extend(min(chunk_size, len(ep["frames"]) - begin)
                             for begin in range(0, len(ep["frames"]), chunk_size))
    # fit.group_aerial_episodes sorts identity before episode shuffling; cache order is not training order.
    compact.sort(key=lambda ep: (ep[0]["scene_id"], str(ep[0]["episode_id"])))
    states = sum(len(ep) for ep in compact)
    if states != manifest["train_samples"]:
        raise ValueError("保存缓存状态数与训练清单不符")
    if hparams.get("stage", "bc") == "dagger":
        from uavnav.avln.fit import load_training_dagger_groups
        groups, records = load_training_dagger_groups(
            annotation_root, hparams["dagger_manifests"], hparams["history"],
            set(manifest["train_episode_ids"]), hparams["architecture"] in RGBD_ARCHITECTURES)
        if records != manifest.get("dagger_manifests"):
            raise ValueError("损失审核DAgger实际来源与冻结合同不一致")
        source_cache["dagger_sources"] = records
        for group in groups:
            compact.append([{key: row[key] for key in ("scene_id", "episode_id")} for row in group])
            chunk_lengths.extend(min(chunk_size, len(group) - begin) for begin in range(0, len(group), chunk_size))
            episodes.append({"scene_id": group[0]["scene_id"], "episode_id": group[0]["episode_id"],
                             "frames": [{"frame_index": i} for i in range(len(group))]})
        states = sum(len(ep) for ep in compact)
        if states != manifest.get("aggregated_training_samples"):
            raise ValueError("DAgger聚合状态数与冻结清单不同")
    with (run / "results.csv").open(encoding="utf-8") as handle:
        results = list(csv.DictReader(handle))
    epochs = hparams["epochs"]
    if (len(results) != epochs or [int(row["epoch"]) for row in results] != list(range(1, epochs + 1))
            or any(int(row["train/samples"]) != states for row in results)):
        raise ValueError("实际训练日志epoch或逐epoch状态数不一致")
    ledger_path = run / "render_pass_selections.jsonl"
    ledger = [json.loads(line) for line in ledger_path.read_text(encoding="utf-8").splitlines()]
    pass_count = len(manifest["train_render_passes"])
    validate_render_pass_ledger(ledger, compact, pass_count, hparams["render_pass_seed"], hparams["seed"], chunk_size, epochs)
    labels, source = [], None
    if args.supervision_json is not None:
        path = args.supervision_json.resolve()
        labels = recorded_action_episodes(json.loads(path.read_text(encoding="utf-8")), episodes)
        source = {"path": str(path), "sha256": sha256(path),
                  "scope": "partial_recorded_teacher_labels" if len(labels) < len(episodes) else "complete_recorded_teacher_labels",
                  "raw_annotation_actions_independently_reverified": False}
    report = {"schema_version": 2, "audit_protocol": "chunk_loss_scale_audit_v2", "device": "cpu",
        "run_dir": str(run), "loss_protocol": protocol, "sequence_chunk_size": chunk_size,
        "source_cache_partition": source_cache,
        "sources": {name: sha256(run / name) for name in (
            "hparams.yaml", "split_manifest.json", "train_cache_manifest.json", "results.csv", "render_pass_selections.jsonl")},
        "actual_sequence_budget": {"episodes": len(episodes), "states_per_epoch": states,
            "chunks_per_epoch": len(chunk_lengths), "full_chunks_per_epoch": chunk_lengths.count(chunk_size),
            "short_tail_chunks_per_epoch": sum(length < chunk_size for length in chunk_lengths),
            "single_frame_chunks_per_epoch": chunk_lengths.count(1), "completed_epochs": epochs,
            "logged_optimizer_updates_total": sum(row["optimizer_updates"] for row in ledger),
            "ledger_verified": True, "gradient_accumulation": "none, one optimizer update per chunk",
            "parameter_gradient_clip_norm": 1.0, "optimizer_step_executions_independently_instrumented": False},
        "recorded_supervision_source": source,
        "recorded_label_scale": loss_scale_summary(labels, chunk_size, protocol) if labels else None,
        "complete_training_label_scale_status": "available" if len(labels) == len(episodes) else "unavailable_no_complete_actions",
        "synthetic_probes": loss_scale_summary([
            {"episode_id": "synthetic_full_then_single_stop", "actions": [1] * chunk_size + [0]},
            {"episode_id": "synthetic_short_turn_stop", "actions": [1, 5, 0]}], chunk_size, protocol),
        "interpretation": ["v1 weights sum to coefficient mass 1 per optimizer update regardless of chunk length",
            "single-frame STOP weight cancels in v1 denominator, but STOP gradient is nonzero",
            "fixed chunk-size denominator changes full and tail gradient scales, not only STOP importance",
            "independent logit gradient norms do not determine network gradients, Adam updates, or navigation gains"],
        "training_defaults_changed": False, "network_training_performed": False,
        "navigation_metrics": {"SR": None, "sDTW": None, "NE": None}}
    output.write_text(json.dumps(report, ensure_ascii=False, indent=2, allow_nan=False) + "\n", encoding="utf-8")
    print(json.dumps({"report": str(output), "actual_sequence_budget": report["actual_sequence_budget"],
                      "complete_training_label_scale_status": report["complete_training_label_scale_status"]}, ensure_ascii=False))
    return report


def audit_aerial(args, hparams):
    from uavnav.avln.data import load_aerial_samples, load_aerial_render_passes, group_aerial_episodes
    from uavnav.avln.fit import aerial_action_priors
    run, output = args.run_dir.resolve(), args.output_dir.resolve()
    teacher_choice = getattr(args, "teacher_checkpoint_choice", "best")
    teacher_choice, teacher_path = resolve_teacher_checkpoint(run, teacher_choice, getattr(args, "teacher_checkpoint", None))
    if hparams.get("episode_batch"):
        raise ValueError("episode_batch训练路径暂不支持独立审核，请使用单episode路径")
    if output.exists():
        raise FileExistsError(f"Audit output already exists: {output}")
    annotation_root = Path(hparams["annotation_root"]).resolve()
    if output.is_relative_to(annotation_root):
        raise ValueError("审核输出不能写入原始标注目录")
    cache = Path(hparams["cache_manifest"])
    validation_cache = Path(hparams.get("validation_cache_manifest") or cache)
    manifest = json.loads((run / "split_manifest.json").read_text(encoding="utf-8"))
    if sha256(cache) != manifest["train_cache_manifest_sha256"] or sha256(validation_cache) != manifest["validation_cache_manifest_sha256"]:
        raise ValueError("真实渲染缓存清单与训练时内容不一致")
    if "child_cache_sources" in manifest:
        from uavnav.avln.fit import aerial_child_source_records
        children = aerial_child_source_records([cache, *hparams.get("render_pass_manifests", [])], validation_cache)
        if children != manifest["child_cache_sources"]:
            raise ValueError("多场景子缓存实际来源与冻结清单不同")
        for record in children:
            if sha256(run / record["snapshot"]) != record["manifest_sha256"]:
                raise ValueError("多场景子缓存来源快照损坏")
    require_depth = hparams["architecture"] in RGBD_ARCHITECTURES
    pass_records = manifest.get("train_render_passes")
    dagger_groups = []
    development_split = None
    if hparams["validation_split"] == "development_train_grouped":
        from uavnav.avln.fit import load_aerial_training_partitions
        if "development_route_split" not in manifest:
            raise ValueError("独立开发审核缺冻结几何路线名单")
        paths = [cache, *[Path(path) for path in hparams.get("render_pass_manifests", [])]]
        train_passes, val, development_split, validation_source = load_aerial_training_partitions(
            annotation_root, cache, validation_cache, paths, hparams["history"],
            "development_train_grouped", hparams["development_fraction"], hparams["development_split_seed"],
            run / "split_manifest.json", require_depth=require_depth)
        if (development_split != manifest["development_route_split"] or validation_source != "train"
                or manifest.get("development_route_split_sha256") != development_split["manifest_sha256"]
                or manifest.get("validation_source_split") != "train"
                or manifest.get("validation_purpose") != "development_train_grouped"):
            raise ValueError("独立开发审核名单/SHA/训练来源不一致")
    if pass_records is None:
        if development_split is None:
            train_passes = [load_aerial_samples(annotation_root, "train", cache, hparams["history"], require_depth=require_depth)]
    else:
        paths = [cache, *[Path(path) for path in hparams.get("render_pass_manifests", [])]]
        if development_split is None:
            train_passes = load_aerial_render_passes(annotation_root, "train", paths, hparams["history"], require_depth=require_depth)
        actual_records = [{"pass_index": index, "source": str(path.resolve()), "manifest_sha256": sha256(path),
                           "sample_content_sha256": sample_content_sha256(samples),
                           "capture_session_id": samples[0].get("capture_session_id")}
                          for index, (path, samples) in enumerate(zip(paths, train_passes))]
        if actual_records != pass_records or hparams.get("train_render_passes") != pass_records:
            raise ValueError("多次渲染来源、身份或内容与冻结清单不一致")
        for index, path in enumerate(paths):
            snapshot = (run / "train_cache_manifest.json" if len(paths) == 1
                        else run / "render_pass_manifests" / f"pass_{index:03d}.json")
            if sha256(snapshot) != pass_records[index]["manifest_sha256"]:
                raise ValueError("保存的render pass来源快照损坏")
        if (sha256(run / "train_cache_manifest.json") != manifest["train_cache_manifest_sha256"]
                or sha256(run / "validation_cache_manifest.json") != manifest["validation_cache_manifest_sha256"]):
            raise ValueError("顶层训练/验证来源清单副本损坏")
        audit_train_groups = group_aerial_episodes(train_passes[0], hparams["history"])
        if hparams.get("stage", "bc") == "dagger":
            from uavnav.avln.fit import load_training_dagger_groups
            dagger_groups, dagger_records = load_training_dagger_groups(
                annotation_root, hparams["dagger_manifests"], hparams["history"],
                set(manifest["train_episode_ids"]), require_depth)
            if (dagger_records != manifest.get("dagger_manifests") or dagger_records != hparams.get("dagger_sources")):
                raise ValueError("DAgger实际状态来源与冻结训练合同不一致")
            for index, record in enumerate(dagger_records):
                if sha256(run / "dagger_manifests" / f"collection_{index:03d}.json") != record["manifest_sha256"]:
                    raise ValueError("DAgger来源清单快照损坏")
            audit_train_groups += dagger_groups
        if len(paths) > 1:
            ledger = [json.loads(line) for line in (run / "render_pass_selections.jsonl").read_text(encoding="utf-8").splitlines()]
            validate_render_pass_ledger(ledger, audit_train_groups,
                                        len(paths), hparams["render_pass_seed"], hparams["seed"],
                                        hparams["sequence_chunk_size"], hparams["epochs"])
    train = train_passes[0]
    if development_split is None:
        val = load_aerial_samples(annotation_root, hparams["validation_split"], validation_cache, hparams["history"], require_depth=require_depth)
    if ({sample.get("capture_session_id") for samples in train_passes for sample in samples}
            & {sample.get("capture_session_id") for sample in val}) - {None}:
        raise ValueError("训练与验证采集会话重叠")
    if (sample_content_sha256(train) != manifest["train_sample_content_sha256"]
            or sample_content_sha256(val) != manifest["validation_sample_content_sha256"]):
        raise ValueError("真实图像/输入/动作标签内容与冻结样本摘要不一致")
    bc_train = train
    if dagger_groups:
        train = train + [sample for group in dagger_groups for sample in group]
    with (run / "results.csv").open(encoding="utf-8") as handle:
        rows = list(csv.DictReader(handle))
    if len(rows) != hparams["epochs"] or any(int(row["epoch"]) != index for index, row in enumerate(rows, 1)):
        raise ValueError("训练epoch日志不完整或重复")
    if any(not math.isfinite(float(row[key])) for row in rows for key in ("train/loss", "val/loss", "train/accuracy", "val/accuracy")):
        raise ValueError("训练CSV包含非有限指标")
    source_manifest = json.loads((run / "source_manifest.json").read_text(encoding="utf-8"))
    if any(sha256(run / "source_snapshot" / name) != expected for name, expected in source_manifest.items()):
        raise ValueError("保存的训练源码快照损坏")
    records = {}
    payloads = {}
    expected_sha = sha256(run / "split_manifest.json")
    checkpoint_paths = {name: run / "weights" / f"{name}.pt" for name in ("best", "last")}
    if teacher_choice == "candidate":
        checkpoint_paths[teacher_choice] = teacher_path
    for name, path in checkpoint_paths.items():
        payload = torch.load(path, map_location="cpu", weights_only=True)
        if payload["model_config"]["split_manifest_sha256"] != expected_sha:
            raise ValueError("checkpoint未绑定当前冻结数据清单")
        if not all(torch.isfinite(value).all().item() for value in payload["model"].values()):
            raise ValueError("checkpoint包含非有限权重")
        payloads[name] = payload
        records[name] = {"epoch": payload["epoch"], "val_loss": payload["val_loss"], "sha256": sha256(path),
                         "bytes": path.stat().st_size, "state_dict_finite": True}
        if name == "candidate" and path.name != f"epoch_{payload['epoch']:03d}.pt":
            raise ValueError("候选文件名与checkpoint epoch不一致")
        if name == "candidate":
            records[name]["inventory_sha256"] = sha256(run / "candidate_inventory.json")
    state = payloads["last"].get("training_state")
    if teacher_choice == "candidate" and (not state or
            state.get("request", {}).get("candidate_epochs") != hparams.get("candidate_epochs")):
        raise ValueError("候选epoch未绑定训练开始时的checkpoint配置，拒绝事后补登记")
    if state:
        if (state.get("version") != "aerial_epoch_resume_v1" or state.get("best_epoch") != payloads["best"]["epoch"]
                or state.get("best_val") != payloads["best"]["val_loss"]
                or payloads["last"]["scheduler"]["last_epoch"] != payloads["last"]["epoch"]):
            raise ValueError("训练恢复状态与best/优化时间表不一致")
        for name, content in state["logs"].items():
            if content is not None and (run / name).read_bytes() != content:
                raise ValueError("已提交训练日志与last checkpoint不同")
    if teacher_choice == "candidate":
        ledger_context = None
        if hparams["architecture"] != "aerial_route_v1":
            if pass_records is None:
                raise ValueError("循环候选累计更新认证缺冻结render pass合同")
            ledger_context = {"episodes": audit_train_groups, "pass_count": len(paths),
                              "pass_seed": hparams["render_pass_seed"], "shuffle_seed": hparams["seed"],
                              "chunk_size": hparams["sequence_chunk_size"]}
        updates = candidate_update_evidence(run, payloads[teacher_choice]["epoch"], hparams["epochs"],
                                            state["logs"], ledger_context=ledger_context)
        records[teacher_choice]["inventory_entry"] = validate_candidate_inventory(
            run, teacher_path, payloads[teacher_choice], hparams, expected_sha, expected_updates=updates)
        records[teacher_choice]["optimizer_updates_evidence"] = (
            "committed_render_pass_selections" if ledger_context is not None else "committed_training_diagnostics")
    best_row = validate_logged_best(rows, payloads["best"], hparams.get("csv_float_precision"))
    selected_row = validate_logged_checkpoint(rows, payloads[teacher_choice], hparams.get("csv_float_precision"), name=teacher_choice)
    if payloads["last"]["epoch"] != hparams["epochs"]:
        raise ValueError("last checkpoint不是最后训练epoch")
    if payloads["best"]["model_config"] != payloads["last"]["model_config"]:
        raise ValueError("best/last架构、输入或监督协议不一致")
    if payloads[teacher_choice]["model_config"] != payloads["best"]["model_config"]:
        raise ValueError("候选架构、输入或监督协议与本run不一致")
    for field in ("model_selection_basis", "training_precision", "training_stage", "training_seed"):
        mappings = (manifest, hparams, payloads["best"]["model_config"])
        values = [mapping.get(field) for mapping in mappings]
        if any(field in mapping for mapping in mappings) and (values[0] is None or not all(value == values[0] for value in values)):
            raise ValueError(f"冻结训练合同{field}在manifest/hparams/checkpoint不一致")
    device = torch.device(args.device)
    predictor = load_predictor(teacher_path, device=device)
    if predictor.checkpoint_sha256 != records[teacher_choice]["sha256"]:
        raise ValueError("加载策略的实际checkpoint字节与审核权重不一致")
    if development_split is not None:
        expected = {"training_split_protocol": development_split["split_protocol"],
                    "development_route_split_sha256": development_split["manifest_sha256"],
                    "validation_purpose": "development_train_grouped", "validation_source_split": "train"}
        for field, value in expected.items():
            if predictor.config.get(field) != value or hparams.get(field) != value:
                raise ValueError(f"独立开发checkpoint/hparams.{field}与冻结名单不一致")
    for field, value in (("architecture", hparams["architecture"]), ("imgsz", hparams["imgsz"]),
                         ("history_frames", hparams["history"])):
        if predictor.config[field] != value:
            raise ValueError(f"hparams.{field}与checkpoint协议不一致")
    baseline = predictor.config["architecture"] in AIRVLN_BASELINES
    recurrent = predictor.config["architecture"] in (
        "aerial_route_recurrent_v2", "aerial_route_recurrent_rgbd_v3",
        "aerial_route_recurrent_clause_v3", "aerial_route_dino_v5") or baseline
    if baseline:
        for field in ("baseline_protocol", "memory_protocol", "memory_layers", "memory_hidden_size",
                      "raw_rgb_adapter", "prev_action_protocol", "upstream_root", "upstream_project_prefix",
                      "upstream_log_dir", "upstream_source_sha256", "ddppo_checkpoint_sha256", "upstream_adapter", "network_precision"):
            if predictor.config.get(field) != hparams.get(field):
                raise ValueError(f"官方网络checkpoint.{field}与训练适配合同不一致")
        for relative, expected in predictor.config["upstream_source_sha256"].items():
            key = f"upstream/AirVLN/{relative}"
            if source_manifest.get(key) != expected:
                raise ValueError("官方网络上游源码未完整绑定run快照")
    if pass_records is not None:
        for field in ("vision_train_policy", "render_pass_policy", "render_pass_seed", "train_render_passes"):
            if predictor.config.get(field) != manifest.get(field) or predictor.config.get(field) != hparams.get(field):
                raise ValueError(f"checkpoint.{field}与冻结pass来源不一致")
        if predictor.config.get("render_pass_count") != len(train_passes):
            raise ValueError("checkpoint render pass数量与审核来源不一致")
        for field in ("model_init_state_sha256", "vision_init_state_sha256"):
            if field in predictor.config and predictor.config[field] != hparams.get(field):
                raise ValueError("checkpoint与hparams初始化摘要不一致")
    torch.set_float32_matmul_precision("high")
    if recurrent:
        from uavnav.avln.data import group_aerial_episodes
        from uavnav.avln.fit import _aerial_sequence_epoch
        for field in ("sequence_chunk_size", "loss_protocol", "text_control", "tokenizer_version", "memory_mode", "vision_batchnorm_protocol"):
            if predictor.config[field] != hparams[field]:
                raise ValueError(f"hparams.{field}与循环checkpoint协议不一致")
        if predictor.config.get("text_query_mode", "visual_history") != hparams.get("text_query_mode", "visual_history"):
            raise ValueError("hparams.text_query_mode与循环checkpoint协议不一致")
        if predictor.config["architecture"] == "aerial_route_recurrent_clause_v3":
            text_path = hparams.get("text_feature_cache")
            if not text_path or not Path(text_path).is_file():
                raise ValueError("v3审计需要可读的text_feature_cache")
            from uavnav.avln.data import attach_text_features, load_text_feature_cache
            text_payload = load_text_feature_cache(text_path)
            attach_text_features([bc_train, val, *dagger_groups], text_payload)
        kwargs = {"model": predictor.model, "vocab": predictor.vocab, "imgsz": hparams["imgsz"],
                  "history_frames": hparams["history"], "chunk_size": hparams["sequence_chunk_size"],
                  "device": device, "loss_protocol": hparams["loss_protocol"],
                  "text_control": hparams.get("text_control", "original"), "seed": hparams.get("seed", 0)}
        reproduced = _aerial_sequence_epoch(episodes=group_aerial_episodes(val), **kwargs)
        train_reproduced = _aerial_sequence_epoch(episodes=group_aerial_episodes(bc_train) + dagger_groups, **kwargs)
    else:
        def loader(samples):
            return DataLoader(samples, batch_size=args.batch, shuffle=False, num_workers=args.workers,
                              collate_fn=functools.partial(collate, vocab=predictor.vocab, imgsz=hparams["imgsz"],
                                                          history_frames=hparams["history"]))
        reproduced = _aerial_epoch(predictor.model, loader(val), device)
        train_reproduced = _aerial_epoch(predictor.model, loader(train), device)
    tolerance = max(1e-4, abs(payloads[teacher_choice]["val_loss"]) * .005)
    if (not math.isfinite(float(reproduced["loss"]))
            or abs(reproduced["loss"] - payloads[teacher_choice]["val_loss"]) > tolerance):
        raise ValueError("独立重载不能复现冻结验证动作损失")
    torch.set_float32_matmul_precision("highest")
    torch.backends.cudnn.allow_tf32 = False
    torch.backends.cudnn.benchmark = False
    diagnostics = replay_verified_teacher_samples(predictor, val)
    # 同一权重、同一单步FP32路径，训练过程累计预测不能替代这里的冻结权重复算。
    # DAgger偏轨片段含实际执行历史，可能无末STOP，不能重解释为完整BC教师前缀。
    train_diagnostics = replay_verified_teacher_samples(predictor, bc_train)
    history_lookup = training_history_lookup(bc_train, window=2)
    stratified_train = stratified_teacher_diagnostics(train_diagnostics, bc_train, development_split, history_lookup)
    stratified_validation = stratified_teacher_diagnostics(diagnostics, bc_train, development_split, history_lookup)
    del train_diagnostics
    by_key = {(row["scene_id"], str(row["episode_id"]), row["frame_index"]): row for row in diagnostics}
    checks = []
    for index in sorted({0, len(val) - 1}):
        sample = val[index]
        checks.append({"sample_index": index, **by_key[(sample["scene_id"], str(sample["episode_id"]), sample["frame_index"])]})
    teacher_matrix = np.zeros((8, 8), dtype=np.int64)
    for row in diagnostics:
        teacher_matrix[row["teacher_action"], row["prediction"]["action"]] += 1
    train_summary = action_classification_summary(train_reproduced["confusion_matrix"], train)
    validation_summary = action_classification_summary(reproduced["confusion_matrix"], train)
    fp32_summary = action_classification_summary(teacher_matrix, train)
    for name, path in checkpoint_paths.items():
        if sha256(path) != records[name]["sha256"]:
            raise ValueError("审核期间checkpoint变化")
    if teacher_choice == "candidate" and sha256(run / "candidate_inventory.json") != records[teacher_choice]["inventory_sha256"]:
        raise ValueError("审核期间候选清单变化")
    output.mkdir(parents=True)
    report = {"schema_version": 5, "scope": "real rendered teacher observations; action learning diagnostic, not navigation score",
              "architecture": predictor.config["architecture"], "memory_protocol": predictor.config.get("memory_protocol", "none"),
              "memory_mode": predictor.config.get("memory_mode", "not_applicable"),
              "vision_batchnorm_protocol": predictor.config.get("vision_batchnorm_protocol", "legacy_batchnorm_v1"),
              "sequence_policy": predictor.config.get("sequence_policy", "frame_bc_v1"),
              "vision_train_policy": predictor.config.get("vision_train_policy", "finetune"),
              "text_query_mode": predictor.config.get("text_query_mode", "visual_history"),
              "selected_teacher_checkpoint": {"choice": teacher_choice, "path": str(teacher_path), **records[teacher_choice]},
              "logged_selected_teacher_epoch": selected_row,
              "render_pass_sources_verified": pass_records,
              "training_classification_pass_index": 0,
              "model_selection_basis": predictor.config.get("model_selection_basis", "lowest_teacher_action_validation_ce_not_navigation_sr"),
              "training_precision": predictor.config.get("training_precision"),
              "action_priors": aerial_action_priors(train, val),
              "training_scope": manifest["scope"], "run_dir": str(run), "checkpoint": records,
              "split_manifest_sha256": expected_sha, "source_snapshot_verified": True,
              "samples": {"train": len(train), "validation": len(val)}, "completed_epochs": len(rows),
              "logged_best_epoch": best_row, "independent_reload_validation": reproduced,
              "independent_reload_train": train_reproduced,
              "frozen_checkpoint_fp32_stratified": {"train": stratified_train, "validation": stratified_validation},
              "stratified_training_scope": {"dataset": "complete_bc_episodes_pass0", "samples": len(bc_train),
                  "dagger_samples_excluded_from_full_teacher_prefix": sum(len(group) for group in dagger_groups),
                  "dagger_fragment_stratification": "unavailable_requires_actual_executed_history_fragment_protocol" if dagger_groups else "not_applicable",
                  "independent_reload_train_includes_dagger": bool(dagger_groups)},
              "metric_semantics": {"logged_train": "cumulative predictions while parameters update; not final-checkpoint eval",
                  "independent_reload": ("same selected checkpoint in eval mode; online RGB recomputation, training feature-cache numeric path NOT certified"
                      if hparams.get("vision_feature_cache") else "same selected checkpoint in eval mode; online RGB training-compatible numeric path"),
                  "stratified": "same selected checkpoint, one-step full teacher prefix, FP32, TF32 disabled; RGB SHA and decoding use identical bytes per observation",
                  "history_lookup": "fit only on frozen BC training labels; last two executed teacher actions; empty/unseen history uses BC training majority; not a causal modality attribution"},
              "validation_reproduction_boundary": {"training_used_vision_feature_cache": bool(hparams.get("vision_feature_cache")),
                  "audit_uses_training_vision_feature_cache": False,
                  "training_cache_numeric_path_certified": False if hparams.get("vision_feature_cache") else None,
                  "ce_tolerance_comparison": "online_recomputation_regression_only_not_cache_certification" if hparams.get("vision_feature_cache") else "online_training_path_ce_regression",
                  "feature_cache_identity_and_precision_audit": "not_implemented_R18" if hparams.get("vision_feature_cache") else "not_applicable"},
              "classification_diagnostics": {"train": train_summary, "validation": validation_summary,
                  "validation_fp32_full_teacher_prefix": fp32_summary},
              "teacher_prefix_inference": diagnostics, "single_frame_inference_context": "teacher_prefix_from_frame0",
              "validation_loss_absolute_tolerance": tolerance, "single_frame_inference": checks,
              "learning_gate": {"status": "teacher_observations_only_navigation_unverified",
                  "beats_training_majority_on_validation": validation_summary["accuracy"] > validation_summary["training_majority_prior_accuracy"],
                  "validation_stop_recall_positive": (validation_summary["class_recall"][0] or 0.) > 0.,
                  "formal_navigation_success_established": False, "language_causal_benefit_established": False},
              "NE": None, "SR": None, "OSR": None, "nDTW": None, "sDTW": None}
    if baseline:
        report["upstream_network_adapter"] = {key: predictor.config[key] for key in (
            "baseline_protocol", "memory_protocol", "memory_layers", "memory_hidden_size",
            "raw_rgb_adapter", "prev_action_protocol", "upstream_source_sha256", "ddppo_checkpoint_sha256", "upstream_adapter", "network_precision")}
        report["upstream_network_adapter"]["official_training_recipe_reproduced"] = False
    if development_split is not None:
        report["development_route_split"] = {"manifest_sha256": development_split["manifest_sha256"],
            "split_protocol": development_split["split_protocol"], "validation_source_split": "train",
            "official_validation_used": False}
    (output / "audit.json").write_text(json.dumps(report, ensure_ascii=False, indent=2, allow_nan=False) + "\n", encoding="utf-8")
    print(json.dumps({"report": str(output / "audit.json"), "independent_reload_validation": reproduced}, ensure_ascii=False), flush=True)
    return report


def action_classification_summary(matrix, training_samples):
    """多数先验只从训练标签选类；缺类别明确为None，不用总体accuracy冒充八动作能力。"""
    matrix = np.asarray(matrix, dtype=np.int64)
    if matrix.shape != (8, 8) or (matrix < 0).any() or matrix.sum() <= 0:
        raise ValueError("动作混淆矩阵必须是非空8x8非负整数")
    counts = matrix.sum(axis=1)
    predicted = matrix.sum(axis=0)
    training_counts = np.bincount([row["action"] for row in training_samples], minlength=8)
    if not training_counts.sum():
        raise ValueError("多数类先验需要训练标签")
    majority = int(training_counts.argmax())
    recall = [float(matrix[i, i] / counts[i]) if counts[i] else None for i in range(8)]
    output = {"accuracy": float(matrix.trace() / matrix.sum()),
              "balanced_accuracy_present_classes": float(np.mean([value for value in recall if value is not None])),
              "class_recall": recall, "missing_classes": np.flatnonzero(counts == 0).tolist(),
              "class_precision": [float(matrix[i, i] / predicted[i]) if predicted[i] else None for i in range(8)],
              "true_action_counts": counts.tolist(), "predicted_action_counts": matrix.sum(axis=0).tolist(),
              "training_action_counts": training_counts.tolist(), "training_majority_action": majority,
              "training_majority_prior_accuracy": float(counts[majority] / counts.sum()),
              "always_forward_accuracy": float(counts[1] / counts.sum()), "stop_recall": recall[0],
              "stop_precision": float(matrix[0, 0] / matrix[:, 0].sum()) if matrix[:, 0].sum() else None}
    return output


def training_history_lookup(training_samples, window=2):
    """只用训练序列过去动作拟合查表；不读当前图像、目标或验证标签。"""
    from uavnav.avln.data import group_aerial_episodes
    if type(window) is not int or window < 1:
        raise ValueError("查表历史窗口须为正整数")
    counts, total = {}, np.zeros(8, dtype=np.int64)
    for episode in group_aerial_episodes(training_samples):
        past = []
        for sample in episode:
            action = sample["action"]
            total[action] += 1
            if past:
                key = tuple(past[-window:])
                counts.setdefault(key, np.zeros(8, dtype=np.int64))[action] += 1
            past.append(action)
    if not total.sum():
        raise ValueError("查表需要完整非空训练序列")
    return {"window": window, "fallback_action": int(total.argmax()),
            "actions": {key: int(value.argmax()) for key, value in counts.items()},
            "training_action_counts": total.tolist()}


def stratified_teacher_diagnostics(rows, training_samples, route_split=None, history_lookup=None):
    """标签只用于离线分层；宏平均不把同路线多指令当独立几何路线。"""
    grouped = {}
    for row in rows:
        grouped.setdefault((row["scene_id"], str(row["episode_id"])), []).append(row)
    if not grouped:
        raise ValueError("教师分层需要非空完整episode")
    route_ids = ({(member["scene_id"], str(member["episode_id"])): route["route_sha256"]
                  for route in route_split["routes"] for member in route["episodes"]} if route_split else {})
    # 累计计数而不复制逐样本预测，避免为每个分层持有全量记录。
    groups = {}
    for key, episode in sorted(grouped.items()):
        episode.sort(key=lambda row: row["frame_index"])
        if [row["frame_index"] for row in episode] != list(range(len(episode))):
            raise ValueError("教师分层须从frame0连续且无重复")
        actions = [row["teacher_action"] for row in episode]
        if actions[-1] != 0 or 0 in actions[:-1]:
            raise ValueError("教师分层需要唯一末STOP")
        changes = {i for i in range(1, len(actions)) if actions[i] != actions[i - 1]}
        for index, row in enumerate(episode):
            target, predicted = actions[index], row["prediction"]["action"]
            strata = ["all"]
            if index == 0:
                strata.append("first_step")
            if index in changes:
                strata.append("action_change_first")
            if index + 1 in changes:
                strata.append("before_action_change_1")
            if index - 1 in changes:
                strata.append("after_action_change_1")
            if index and target != 0 and target == actions[index - 1]:
                strata.append("repeated_motion")
            if target in (6, 7):
                strata.append(f"sideways_action_{target}")
            if target == 0:
                strata.append("stop")
            if 1 <= len(actions) - 1 - index <= 5:
                strata.append("one_to_five_steps_before_stop")
            lookup_action = None
            if history_lookup is not None:
                prefix = tuple(actions[max(0, index - history_lookup["window"]):index])
                lookup_action = history_lookup["actions"].get(prefix, history_lookup["fallback_action"])
            for name in strata:
                bucket = groups.setdefault(name, {"matrix": np.zeros((8, 8), dtype=np.int64),
                    "lookup_matrix": np.zeros((8, 8), dtype=np.int64), "episodes": {}, "routes": {}})
                bucket["matrix"][target, predicted] += 1
                if lookup_action is not None:
                    bucket["lookup_matrix"][target, lookup_action] += 1
                for unit, identity in (("episodes", key), ("routes", route_ids.get(key))):
                    if identity is not None:
                        totals = bucket[unit].setdefault(identity, [0, 0])
                        totals[0] += int(target == predicted)
                        totals[1] += 1
    result = {}
    for name, bucket in groups.items():
        result[name] = {"frame_micro": action_classification_summary(bucket["matrix"], training_samples),
            "episode_macro_accuracy": float(np.mean([correct / count for correct, count in bucket["episodes"].values()])),
            "episodes": len(bucket["episodes"]), "geometric_routes": len(bucket["routes"]) if route_split else None,
            "geometry_mapped_frames": sum(count for _, count in bucket["routes"].values()) if route_split else None,
            "geometry_macro_accuracy": float(np.mean([correct / count for correct, count in bucket["routes"].values()]))
                if bucket["routes"] else None,
            "history_lookup": action_classification_summary(bucket["lookup_matrix"], training_samples)
                if history_lookup is not None else None}
    return {"strata": result, "definition": {"action_change_first": "teacher action differs from previous, including terminal STOP",
        "neighborhood": "one preceding and one following frame; strata may overlap",
        "near_stop": "one to five teacher actions before unique terminal STOP, excluding STOP",
        "geometry_macro": "pool selected frames within each frozen geometry route, then average routes equally",
        "geometry_status": "frozen_grouped_split" if route_split else "unavailable_no_frozen_geometry_map",
        "lookup_train_scope": "resubstitution on fitting set; not independent performance",
        "tie_break": "smallest action index"}}


def errors(prediction, target):
    prediction = np.asarray(prediction, dtype=np.float64)
    target = np.asarray(target, dtype=np.float64)
    norms = np.linalg.norm(target, axis=1)
    lengths = np.linalg.norm(prediction, axis=1)
    valid = (norms > 1e-6) & (lengths > 1e-6)
    cosine = np.zeros(len(norms))
    cosine[valid] = np.clip(np.sum(prediction[valid] * target[valid], axis=1) / (lengths[valid] * norms[valid]), -1, 1)
    angles = np.full(len(norms), np.nan)
    angles[valid] = np.degrees(np.arccos(cosine[valid]))
    return {"cosine_loss": 1 - cosine, "angle_deg": angles,
            "length_error_m": np.abs(lengths - norms), "vector_error_m": np.linalg.norm(prediction - target, axis=1)}


def summary(prediction, target, trajectory_ids, selected=None):
    selected = np.ones(len(target), dtype=bool) if selected is None else np.asarray(selected)
    if not selected.any():
        return None
    metric = errors(prediction[selected], target[selected])
    identifiers = np.asarray(trajectory_ids)[selected]
    groups = {name: np.flatnonzero(identifiers == name) for name in sorted(set(identifiers))}
    micro = {}
    macro = {}
    for name, values in metric.items():
        finite = np.isfinite(values)
        micro[name] = {"mean": float(np.mean(values[finite])) if finite.any() else None,
                       "median": float(np.median(values[finite])) if finite.any() else None,
                       "p95": float(np.quantile(values[finite], 0.95)) if finite.any() else None,
                       "undefined": int((~finite).sum())}
        means = [float(np.mean(values[index][np.isfinite(values[index])]))
                 for index in groups.values() if np.isfinite(values[index]).any()]
        macro[name] = float(np.mean(means)) if means else None
    return {"samples": int(selected.sum()), "trajectories": len(groups), "sample_average": micro,
            "trajectory_average": macro}


def paired_comparison(model, baseline, target, trajectory_ids, seed, draws):
    model_errors = errors(model, target)
    baseline_errors = errors(baseline, target)
    identifiers = np.asarray(trajectory_ids)
    groups = [np.flatnonzero(identifiers == name) for name in sorted(set(identifiers))]
    output = {}
    rng = np.random.default_rng(seed)
    for metric in model_errors:
        differences = []
        for index in groups:
            values = model_errors[metric][index] - baseline_errors[metric][index]
            finite = np.isfinite(values)
            if finite.any():
                differences.append(float(np.mean(values[finite])))
        if not differences:
            continue
        differences = np.asarray(differences)
        resampled = rng.choice(differences, size=(draws, len(differences)), replace=True).mean(axis=1)
        output[metric] = {"model_minus_baseline_mean": float(differences.mean()),
                          "trajectory_bootstrap_95ci": [float(x) for x in np.quantile(resampled, [0.025, 0.975])],
                          "trajectory_win_fraction": float((differences < 0).mean()),
                          "trajectories": len(differences)}
    return output


def text_batch(texts, vocab, device):
    encoded = [vocab.encode(text) for text in texts]
    width = max(len(row) for row in encoded)
    tokens = torch.zeros(len(texts), width, dtype=torch.long, device=device)
    mask = torch.zeros_like(tokens, dtype=torch.bool)
    for row, ids in enumerate(encoded):
        tokens[row, :len(ids)] = torch.tensor(ids, device=device)
        mask[row, :len(ids)] = True
    return tokens, mask


def permutation_within_map(samples, seed):
    groups = {}
    for index, sample in enumerate(samples):
        groups.setdefault(sample["traj_id"].split("/")[0], {}).setdefault(sample["traj_id"], []).append(index)
    rng = random.Random(seed)
    donors = np.arange(len(samples))
    text_donors = {}
    for trajectories in groups.values():
        ids = sorted(trajectories)
        rng.shuffle(ids)
        if len(ids) == 1:
            raise RuntimeError("Within-map interventions require at least two validation trajectories per map")
        for origin, donor in zip(ids, ids[1:] + ids[:1]):
            text_donors[origin] = donor
            for index in trajectories[origin]:
                donors[index] = rng.choice(trajectories[donor])
    assert all(samples[i]["traj_id"] != samples[j]["traj_id"] for i, j in enumerate(donors))
    return donors, text_donors


def audit(args):
    run = args.run_dir.resolve()
    output = args.output_dir.resolve()
    if output.exists():
        raise FileExistsError(f"Audit output already exists: {output}")
    if getattr(args, "observation_trace", None) is not None:
        from uavnav.avln.closed_loop import replay_recorded_observations
        torch.set_float32_matmul_precision("highest")
        torch.backends.cudnn.allow_tf32 = False
        torch.backends.cudnn.benchmark = False
        predictor = load_predictor(run / "weights" / (args.checkpoint_choice + ".pt"), device=args.device)
        result = replay_recorded_observations(predictor, args.observation_trace)
        output.mkdir(parents=True)
        (output / "observation_replay.json").write_text(json.dumps(result, ensure_ascii=False, indent=2, allow_nan=False), encoding="utf-8")
        return result
    hparams = yaml.safe_load((run / "hparams.yaml").read_text(encoding="utf-8"))
    if hparams.get("architecture") in ("aerial_route_v1", "aerial_route_recurrent_v2", "aerial_route_recurrent_clause_v3", "aerial_route_dino_v5", *RGBD_ARCHITECTURES, *AIRVLN_BASELINES):
        return audit_aerial(args, hparams)
    if hparams["ablate"] != "none":
        raise ValueError("This input-path audit currently requires a full model, ablate=none")
    if hparams.get("stop_enabled", False):
        raise ValueError("本单步动作审核不包含STOP标注/派生样本审计，禁止用它验收STOP性能")
    data_root = Path(hparams["data_root"]).resolve()
    if output.is_relative_to(data_root.parent):
        raise ValueError("Audit output must be outside the original dataset")
    rows = list(csv.DictReader((run / "results.csv").open()))
    assert len(rows) == hparams["epochs"] and int(rows[-1]["epoch"]) == hparams["epochs"]
    assert all(math.isfinite(float(row[key])) for row in rows for key in
               ("train/loss", "val/loss", "train/angle", "val/angle", "train/length", "val/length"))
    manifest = json.loads((run / "split_manifest.json").read_text())
    expected_sha = sha256(run / "split_manifest.json")
    checkpoints = {}
    for name in ("best", "last"):
        path = run / "weights" / f"{name}.pt"
        payload = torch.load(path, map_location="cpu", weights_only=True)
        assert payload["model_config"]["split_manifest_sha256"] == expected_sha
        assert payload["model_config"].get("fusion_mode", "text_context_only") == hparams.get("fusion_mode", "text_context_only")
        assert all(torch.isfinite(value).all().item() for value in payload["model"].values())
        checkpoints[name] = {"epoch": payload["epoch"], "val_loss": payload["val_loss"], "sha256": sha256(path),
                             "state_dict_finite": True, "bytes": path.stat().st_size}
        if name == "best":
            best_payload = payload
        else:
            same_state = all(torch.equal(value, payload["model"][key]) for key, value in best_payload["model"].items())
    best_row = validate_logged_best(rows, checkpoints["best"], hparams.get("csv_float_precision"))
    assert checkpoints["last"]["epoch"] == hparams["epochs"]
    list_path = Path(hparams["list_json"])
    if not list_path.is_absolute():
        list_path = data_root / list_path
    assert sha256(list_path) == manifest["source_list_sha256"]
    assert sha256(Path(hparams["instruction_json"])) == manifest["instruction_json_sha256"]
    paths = load_list(data_root, list_path)
    instructions = load_instructions(hparams["instruction_json"], hparams["strip_direction"])
    samples = list(iter_samples(paths, hparams["history"], instructions, hparams["strip_direction"]))
    if ("effective_sample_content_sha256" in manifest
            and sample_content_sha256(samples) != manifest["effective_sample_content_sha256"]):
        raise ValueError("实际图像/日志/标签内容与冻结样本摘要不一致")
    train_ids = set(manifest["train_trajectory_ids"])
    val_ids = set(manifest["validation_trajectory_ids"])
    assert not train_ids & val_ids
    train = [sample for sample in samples if sample["traj_id"] in train_ids]
    val = [sample for sample in samples if sample["traj_id"] in val_ids]
    assert len(train) == manifest["train_samples"] and len(val) == manifest["validation_samples"]
    assert train_ids | val_ids == {sample["traj_id"] for sample in samples}
    target_train = np.stack([sample["offset"] for sample in train])
    train_lengths = np.linalg.norm(target_train, axis=1)
    scale = float(best_payload["length_scale"])
    assert abs(float(np.median(train_lengths)) - scale) < 1e-6
    unit_train = target_train / np.maximum(train_lengths[:, None], 1e-6)
    direction = unit_train.mean(axis=0)
    constant_3d = scale * direction / np.linalg.norm(direction)
    constant_forward = np.asarray([scale, 0, 0], dtype=np.float32)

    device = torch.device(args.device)
    predictor = WaypointPredictor(run / "weights/best.pt", device=device)
    model = predictor.model
    vocab = predictor.vocab
    make_loader = functools.partial(DataLoader, batch_size=args.batch, shuffle=False, num_workers=args.workers,
        collate_fn=functools.partial(collate, vocab=vocab, imgsz=hparams["imgsz"], history_frames=hparams["history"]),
        pin_memory=device.type == "cuda")
    torch.set_float32_matmul_precision("high")
    torch.backends.cudnn.allow_tf32 = True
    torch.backends.cudnn.benchmark = True
    legacy_precision = _evaluate(model, make_loader(val), device, scale, hparams["ablate"])
    # Training permits nondeterministic cuDNN algorithm selection and BF16.
    # Verify numerical agreement without requiring bitwise-repeatable kernels.
    reproduction_tolerance = max(1e-4, abs(best_payload["val_loss"]) * 0.005)
    assert abs(legacy_precision["loss"] - best_payload["val_loss"]) < reproduction_tolerance, (legacy_precision, best_payload["val_loss"])
    print("Saved validation loss reproduced", json.dumps(legacy_precision), flush=True)
    torch.set_float32_matmul_precision("highest")
    torch.backends.cudnn.allow_tf32 = False
    torch.backends.cudnn.benchmark = False

    print("Caching validation preprocessing", len(val), flush=True)
    batches = list(make_loader(val))
    images = torch.cat([batch["image"] for batch in batches])
    histories = torch.cat([batch["history"] for batch in batches])
    history_lengths = torch.cat([batch["history_length"] for batch in batches])
    target = torch.cat([batch["offset"] for batch in batches]).numpy()
    ids = np.asarray([sample["traj_id"] for sample in val])
    donors, text_donors = permutation_within_map(val, args.seed)
    instructions_by_id = {sample["traj_id"]: sample["instruction"] for sample in val}
    shuffled_text = [instructions_by_id[text_donors[sample["traj_id"]]] for sample in val]
    texts = [sample["instruction"] for sample in val]
    predictions = {name: [] for name in ("model_fp32", "model_bf16", "shuffle_image_within_map", "shuffle_text_within_map",
                  "shuffle_history_within_map", "zero_history_at_inference", "zero_visual_at_inference", "uniform_attention_at_inference")}
    attention = {"normalized_entropy": [], "max_weight": []}
    cached = {}
    handles = [model.query.register_forward_hook(lambda module, inputs, output: cached.update(query=output.detach())),
               model.key.register_forward_hook(lambda module, inputs, output: cached.update(key=output.detach()))]
    with torch.inference_mode():
        for start in range(0, len(val), args.batch):
            end = min(len(val), start + args.batch)
            indices = donors[start:end]
            tokens, mask = text_batch(texts[start:end], vocab, device)
            batch = {"image": images[start:end].to(device), "history": histories[start:end].to(device),
                     "history_length": history_lengths[start:end].to(device), "tokens": tokens, "token_mask": mask}
            full = model(batch).float().cpu().numpy()
            predictions["model_fp32"].append(full)
            score = torch.matmul(cached["query"].unsqueeze(1), cached["key"].transpose(1, 2)) / math.sqrt(model.hidden_size)
            weights = torch.softmax(score.masked_fill(~mask.unsqueeze(1), torch.finfo(score.dtype).min), dim=-1).squeeze(1)
            entropy = -(weights * weights.clamp_min(1e-30).log()).sum(dim=1)
            normalized = entropy / mask.sum(dim=1).float().log().clamp_min(1e-6)
            attention["normalized_entropy"].extend(normalized.cpu().tolist())
            attention["max_weight"].extend(weights.max(dim=1).values.cpu().tolist())
            with torch.autocast(device_type=device.type, dtype=torch.bfloat16, enabled=device.type == "cuda"):
                predictions["model_bf16"].append(model(batch).float().cpu().numpy())
            altered = dict(batch, image=images[indices].to(device))
            predictions["shuffle_image_within_map"].append(model(altered).float().cpu().numpy())
            donor_tokens, donor_mask = text_batch(shuffled_text[start:end], vocab, device)
            predictions["shuffle_text_within_map"].append(model(dict(batch, tokens=donor_tokens, token_mask=donor_mask)).float().cpu().numpy())
            altered = dict(batch, history=histories[indices].to(device), history_length=history_lengths[indices].to(device))
            predictions["shuffle_history_within_map"].append(model(altered).float().cpu().numpy())
            altered = dict(batch, history=torch.zeros_like(batch["history"]), history_length=torch.zeros_like(batch["history_length"]))
            predictions["zero_history_at_inference"].append(model(altered).float().cpu().numpy())
            original_ablate = model.ablate
            try:
                model.ablate = "no_image"
                predictions["zero_visual_at_inference"].append(model(batch).float().cpu().numpy())
            finally:
                model.ablate = original_ablate
            # 仅清零 key 令词权重均匀，保留新融合的直接 query 通路。
            zero_key = model.key.register_forward_hook(lambda module, inputs, output: torch.zeros_like(output))
            try:
                predictions["uniform_attention_at_inference"].append(model(batch).float().cpu().numpy())
            finally:
                zero_key.remove()
            if start % (args.batch * 8) == 0:
                print("Validation interventions", end, "/", len(val), flush=True)
        for handle in handles:
            handle.remove()
    predictions = {name: np.concatenate(values) for name, values in predictions.items()}
    predictions["constant_forward"] = np.tile(constant_forward, (len(val), 1))
    predictions["constant_train_3d"] = np.tile(constant_3d, (len(val), 1))
    predictions["previous_teacher_motion"] = np.stack([-sample["history"][-1] if len(sample["history"]) else constant_forward for sample in val])
    assert all(np.isfinite(prediction).all() for prediction in predictions.values())

    train_predictions = []
    with torch.inference_mode():
        for index, batch in enumerate(make_loader(train)):
            on_device = {key: value.to(device, non_blocking=True) for key, value in batch.items()}
            train_predictions.append(model(on_device).float().cpu().numpy())
            if index % 64 == 0:
                print("Training set in eval mode", index, "/", math.ceil(len(train) / args.batch), flush=True)
    train_predictions = np.concatenate(train_predictions)
    target_lengths = np.linalg.norm(target, axis=1)
    has_history = history_lengths.numpy() > 0
    turning = errors(predictions["previous_teacher_motion"], target)["angle_deg"]
    terminal_indices = {sample["traj_id"]: index for index, sample in enumerate(val)}
    at_last = np.zeros(len(val), dtype=bool)
    at_last[list(terminal_indices.values())] = True
    stratification = {"start_without_history": ~has_history, "with_history": has_history,
                      "history_1_to_7": (history_lengths.numpy() > 0) & (history_lengths.numpy() < 8),
                      "history_8": history_lengths.numpy() == 8,
                      "turn_at_least_15deg": has_history & (turning >= 15),
                      "last_fixed_gap_sample": at_last, "target_length_below_1m": target_lengths < 1}
    for map_name in sorted({sample["traj_id"].split("/")[0] for sample in val}):
        stratification["map:" + map_name] = np.array([name.startswith(map_name + "/") for name in ids])
    comparisons = {name: paired_comparison(predictions["model_fp32"], predictions[name], target, ids, args.seed, args.bootstrap)
                   for name in ("constant_forward", "constant_train_3d", "previous_teacher_motion")}
    sensitivity = {}
    for name, prediction in predictions.items():
        if name in ("model_fp32", "constant_forward", "constant_train_3d", "previous_teacher_motion"):
            continue
        changed = errors(prediction, predictions["model_fp32"])
        sensitivity[name] = {key: {"mean": float(np.nanmean(value)), "median": float(np.nanmedian(value)),
                                  "p95": float(np.nanquantile(value, 0.95))} for key, value in changed.items()}
    with torch.inference_mode():
        one_token, one_mask = text_batch(["car", "car"], vocab, device)
        singleton = {"image": images[:2].to(device), "history": histories[:2].to(device).clone(),
                     "history_length": history_lengths[:2].to(device).clone(), "tokens": one_token, "token_mask": one_mask}
        singleton["history"][0] = 0
        singleton["history"][1] = 17
        singleton["history_length"][:] = torch.tensor([0, hparams["history"]], device=device)
        singleton_output = model(singleton).float().cpu().numpy()
    singleton_difference = float(np.max(np.abs(singleton_output[0] - singleton_output[1])))
    if model.fusion_mode == "text_context_only":
        assert singleton_difference < 1e-6
    output.mkdir(parents=True)
    export = {"target": target, "trajectory_ids": ids, "frame_indices": np.asarray([sample["frame_index"] for sample in val]),
              "history_lengths": history_lengths.numpy(), "donor_indices": donors, **predictions}
    np.savez_compressed(output / "validation_predictions.npz", **export)
    with (output / "validation_predictions.csv").open("w", newline="", encoding="utf-8") as handle:
        writer = csv.writer(handle)
        writer.writerow(["trajectory_id", "frame_index", "history_length", "method", "target_x_m", "target_y_m", "target_z_m",
                         "prediction_x_m", "prediction_y_m", "prediction_z_m", "cosine_loss", "angle_deg", "length_error_m", "vector_error_m"])
        for name, prediction in predictions.items():
            metric = errors(prediction, target)
            for index, sample in enumerate(val):
                writer.writerow([sample["traj_id"], sample["frame_index"], int(history_lengths[index]), name,
                                 *target[index].tolist(), *prediction[index].tolist(),
                                 *[float(metric[key][index]) if np.isfinite(metric[key][index]) else "" for key in metric]])
    stats = {name: summary(prediction, target, ids) for name, prediction in predictions.items()}
    train_stats = summary(train_predictions, target_train, [sample["traj_id"] for sample in train])
    report = {"schema_version": 2, "run_dir": str(run), "scope": "recorded teacher-observation one-step prediction; not closed loop",
              "fusion_mode": model.fusion_mode,
              "architecture": predictor.config["architecture"],
              "backbone": predictor.config["backbone"],
              "visual_fusion": predictor.config["visual_fusion"],
              "grid_size": predictor.config["grid_size"],
              "model_config": predictor.config,
              "lr_log_schema": "used_and_next" if "lr_used" in rows[0] else "legacy_next_epoch_lr",
              "checkpoint": checkpoints, "completed_epochs": len(rows), "training_seconds": float(rows[-1]["time"]),
              "best_last_model_state_identical": same_state,
              "split_manifest_sha256": expected_sha, "samples": {"train": len(train), "validation": len(val)},
              "constant_length_m_from_training_only": scale, "constant_3d_from_training_only_m": constant_3d.tolist(),
              "logged_best_epoch": best_row, "legacy_bf16_validation_reproduction": legacy_precision,
              "csv_validation_loss_abs_error": abs(legacy_precision["loss"] - float(best_row["val/loss"])),
              "bf16_reproduction_absolute_tolerance": reproduction_tolerance,
              "bf16_reproduction_note": "cuDNN benchmark algorithms and BF16 are not bitwise deterministic; comparison tolerates max(1e-4, 0.5 percent of saved loss)",
              "inference_precision": "FP32, TF32 disabled; model_bf16 uses separate autocast pass",
              "validation": stats, "training_eval_fp32": train_stats,
              "paired_trajectory_comparisons": comparisons,
              "stratified_validation": {group: {name: summary(predictions[name], target, ids, mask)
                  for name in ("model_fp32", "constant_forward", "constant_train_3d", "previous_teacher_motion")}
                  for group, mask in stratification.items() if mask.any()},
              "input_intervention_output_sensitivity": sensitivity,
              "attention_diagnostic_axis": "instruction_tokens; not visual regions or target grounding",
              "attention_diagnostics": {key: {"mean": float(np.mean(values)), "median": float(np.median(values)),
                                              "p95": float(np.quantile(values, 0.95))} for key, values in attention.items()},
              "single_token_information_path_test": {"input": "car", "different_images_and_history": True,
                  "direct_query_path_present": model.fusion_mode == "query_plus_text",
                  "max_action_absolute_difference_m": singleton_difference, "scope": "structural diagnostic, outside actual instruction distribution"},
              "counterfactual_protocol": {"seed": args.seed, "donor_rule": "same Map, different validation trajectory; cyclic trajectory permutation then seeded donor frame",
                  "interventions_are_retrained_ablations": False, "history_both_values_and_lengths_replaced": True,
                  "attention_only_text_values": model.fusion_mode == "text_context_only",
                  "uniform_attention_rule": "zero key output; preserve query and direct fusion path"},
              "statistics": {"bootstrap_seed": args.seed, "bootstrap_draws": args.bootstrap, "bootstrap_unit": "trajectory", "difference_direction": "model minus baseline; negative is better"},
              "angular_metric": "per-sample arccos; undefined below 1e-6 norm; never arccos of average cosine",
              "near_end_definition": "last fixed-gap sample of each teacher trajectory; diagnostic grouping only",
              "turning_definition": "teacher previous motion versus target at least 15deg; diagnostic grouping only",
              "code_source_sha256": sha256(Path(__file__)), "files": ["validation_predictions.npz", "validation_predictions.csv"]}
    different_text = np.array([texts[i] != texts[j] for i, j in enumerate(donors)])
    report["text_permutation_check"] = {
        "samples": len(val), "different_raw_instructions_samples": int(different_text.sum()),
        "unchanged_raw_instructions_samples": int((~different_text).sum()),
        "changed_text_only": {name: summary(predictions[name], target, ids, different_text)
                              for name in ("model_fp32", "shuffle_text_within_map")} if different_text.any() else None,
    }
    report["paired_input_intervention_comparisons"] = {
        name: paired_comparison(predictions["model_fp32"], predictions[name], target, ids, args.seed, args.bootstrap)
        for name in ("shuffle_text_within_map", "shuffle_image_within_map", "shuffle_history_within_map", "zero_history_at_inference")
    }
    paired_strata = {"start_model_minus_constant": (~has_history, "constant_forward"),
                     "turn_model_minus_previous": (has_history & (turning >= 15), "previous_teacher_motion"),
                     "nonturn_model_minus_previous": (has_history & (turning < 15), "previous_teacher_motion"),
                     "with_history_model_minus_previous": (has_history, "previous_teacher_motion"),
                     "last_model_minus_previous": (at_last, "previous_teacher_motion")}
    report["stratified_paired_trajectory_comparisons"] = {
        name: {"samples": int(mask.sum()), "metrics": paired_comparison(
            predictions["model_fp32"][mask], predictions[baseline][mask], target[mask], ids[mask], args.seed, args.bootstrap)}
        for name, (mask, baseline) in paired_strata.items() if mask.any()
    }
    report["unified_fp32_eval_loss"] = {
        "train": train_stats["sample_average"]["cosine_loss"]["mean"] + train_stats["sample_average"]["length_error_m"]["mean"] / scale,
        "validation": stats["model_fp32"]["sample_average"]["cosine_loss"]["mean"] + stats["model_fp32"]["sample_average"]["length_error_m"]["mean"] / scale,
    }
    single_differences = []
    for index in (0, 1, 2, 100, 1000, len(val) - 1):
        if index >= len(val):
            continue
        sample = val[index]
        action = np.asarray(predictor.predict(sample["image"], sample["instruction"], sample["history"])["body_displacement"])
        single_differences.append({"index": index, "max_abs_m": float(np.max(np.abs(action - predictions["model_fp32"][index])))})
    max_difference = max(row["max_abs_m"] for row in single_differences)
    assert max_difference < 1e-5, single_differences
    report["single_image_inference_vs_batch_fp32"] = {"samples": single_differences, "max_abs_m": max_difference, "passed": True}
    assert sha256(run / "weights/best.pt") == checkpoints["best"]["sha256"]
    report["checkpoint_source_unchanged_after_audit"] = True
    (output / "audit.json").write_text(json.dumps(report, ensure_ascii=False, indent=2, allow_nan=False) + "\n", encoding="utf-8")
    print(json.dumps({"report": str(output / "audit.json"), "validation": {name: value["trajectory_average"] for name, value in stats.items()},
                     "single_token_test": singleton_difference}, ensure_ascii=False, indent=2), flush=True)


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--mode", choices=("checkpoint", "loss-scale"), default="checkpoint")
    parser.add_argument("--run-dir", type=Path, required=True)
    parser.add_argument("--output-dir", type=Path)
    parser.add_argument("--output-json", type=Path, help="loss-scale模式写入已有证据目录中的新JSON")
    parser.add_argument("--supervision-json", type=Path, help="完整有身份episode动作，或已有long82_predictions教师记录")
    parser.add_argument("--device", default="cuda")
    parser.add_argument("--batch", type=int, default=64)
    parser.add_argument("--workers", type=int, default=12)
    parser.add_argument("--seed", type=int, default=20261004)
    parser.add_argument("--bootstrap", type=int, default=2000)
    parser.add_argument("--observation-trace", type=Path, help="重放某次自主闭环的observations/manifest.json，不读教师标签")
    parser.add_argument("--checkpoint-choice", choices=("best", "last"), default="last", help="实际观测重放使用的原权重")
    parser.add_argument("--teacher-checkpoint-choice", choices=("best", "last"), default="best", help="路线教师状态审核使用的权重，与实际观测重放选择独立")
    parser.add_argument("--teacher-checkpoint", type=Path, help="显式路线候选：本run/weights/epoch_XXX.pt；仍核CSV epoch和来源，不改best/last含义")
    args = parser.parse_args()
    if args.batch < 1 or args.workers < 0 or args.bootstrap < 1:
        parser.error("batch/bootstrap must be positive and workers nonnegative")
    if args.mode == "loss-scale":
        if args.output_json is None or args.output_dir is not None or args.observation_trace is not None or args.teacher_checkpoint is not None:
            parser.error("loss-scale须指定output-json，不混用checkpoint输出或观测重放")
        torch.set_num_threads(1)
        audit_loss_scale(args)
        return
    if args.output_dir is None or args.output_json is not None or args.supervision_json is not None:
        parser.error("checkpoint须指定output-dir，不混用loss-scale参数")
    if args.teacher_checkpoint is not None and args.observation_trace is not None:
        parser.error("teacher-checkpoint只用于教师审核，不能与实际观测重放混用")
    started = time.monotonic()
    audit(args)
    print(f"Audit completed in {time.monotonic() - started:.3f} seconds", flush=True)


if __name__ == "__main__":
    main()
