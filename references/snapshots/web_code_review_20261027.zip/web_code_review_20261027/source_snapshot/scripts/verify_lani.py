"""Bounded real LANI simulator smoke test using frozen, unmodified CIFF.

This entry point does not train a model or claim full-benchmark navigation.
"""

import argparse
import hashlib
import json
import math
import os
from pathlib import Path
import random
import signal
import subprocess
import sys
import time


def write_json(path, value):
    temporary = path.with_suffix(path.suffix + ".pending")
    temporary.write_text(json.dumps(value, indent=2, allow_nan=False) + "\n", encoding="utf-8")
    temporary.replace(path)


def ndtw(actual, reference, threshold=5.0):
    """Exact 2D DTW, explicitly a project extension, not LANI's native NED."""
    previous = [0.0] + [math.inf] * len(reference)
    for point in actual:
        current = [math.inf]
        for j, target in enumerate(reference):
            cost = math.hypot(point[0] - target[0], point[1] - target[1])
            current.append(cost + min(previous[j], previous[j + 1], current[-1]))
        previous = current
    return math.exp(-previous[-1] / (threshold * len(reference)))


def run_worker(args):
    import socket
    import resource
    import numpy as np
    from PIL import Image

    root = args.upstream_root.resolve()
    sys.path.insert(0, str(root / "src"))
    from dataset_agreement_nav_drone.action_space import ActionSpace
    from dataset_agreement_nav_drone.nav_drone_dataset_parser import (
        create_segment_data_points, make_vocab_map, parse_resources_json)
    from server_nav_drone.nav_drone_server_py3 import NavDroneServerPy3
    resource.setrlimit(resource.RLIMIT_CORE, (0, 0))

    assets = args.asset_root.resolve()
    config_path = assets / "data/nav_drone/config_localmoves_6000.json"
    config = json.loads(config_path.read_text())
    if config["action_names"] != ["Forward", "TurnRight", "TurnLeft", "Stop"] or config["use_paragraphs"]:
        raise ValueError("This smoke protocol requires official four-action single-instruction tasks")
    config["vocab_file"] = str(assets / config["vocab_file"])
    config["resources_dir"] = str(assets / config["resources_dir"])
    with socket.socket() as probe:
        probe.bind(("127.0.0.1", 0))
        config["port"] = probe.getsockname()[1]
    config["hostname"] = "127.0.0.1"
    vocab = make_vocab_map(config["vocab_file"])
    source = assets / f"data/nav_drone/{args.split}_annotations_6000.json"
    raw = json.loads(source.read_text())
    selected = []
    # Static, predeclared smoke selection, never chosen by observed success.
    for row in raw:
        if not row["valid"]:
            continue
        scene = parse_resources_json(row["config_file"], config)
        scene.setdefault("lakeCoords", [])
        path = parse_resources_json(row["path_file"], config)
        for point in create_segment_data_points(row, scene, path, config, vocab):
            if 0 < len(point.get_trajectory()) <= args.max_steps:
                selected.append(point)
                break  # One segment per paragraph, preserving distinct scene identities.
        if len(selected) == args.episodes:
            break
    if len(selected) != args.episodes:
        raise ValueError("Insufficient eligible complete tasks for registered smoke selection")
    actions = ActionSpace(config["action_names"], config["stop_action"])
    build = assets / "simulators/nav_drone/NavDroneLinuxBuild.x86_64"
    command = [str(build), "--height", str(config["image_height"]), "--width",
               str(config["image_width"]), "--rewardshaping", "goal", "--goalmarker", "hide",
               "--port", str(config["port"]), "-logFile", str(args.output / "unity_player.log")]
    report = {"status": "running", "scope": "real simulator smoke, not full benchmark or learned-policy result",
              "protocol": "lani_segment_smoke_v1", "extended_metrics": "lani_exact_dtw_diagnostic_v1",
              "source_annotation_sha256": hashlib.sha256(source.read_bytes()).hexdigest(),
              "source_config_sha256": hashlib.sha256(config_path.read_bytes()).hexdigest(),
              "config": config, "unity_command": command, "max_movement_steps": args.max_steps,
              "success_threshold": "strict XZ distance < 5 Unity units", "seed": 0,
              "selection": "first valid paragraphs, first complete segment with 1..budget teacher moves",
              "selected_tasks": [p.get_scene_name() for p in selected], "episodes": []}
    write_json(args.output / "result.json", report)
    server = NavDroneServerPy3(config, actions)
    unity = None
    try:
        environment = os.environ.copy()
        environment["XDG_CONFIG_HOME"] = str(assets / ".runtime_config")
        environment["XDG_CACHE_HOME"] = str(assets / ".runtime_cache")
        environment["MESA_SHADER_CACHE_DIR"] = str(assets / ".runtime_cache/mesa")
        with (args.output / "unity_stdout.log").open("xb") as stream:
            unity = subprocess.Popen(command, stdout=stream, stderr=subprocess.STDOUT, cwd=assets, env=environment)
        references = {}
        for policy in ("teacher", "stop", "random", "forward"):
            rng = random.Random(0)
            for point in selected:
                task = point.get_scene_name()
                image, metadata = server.reset_receive_feedback(point)
                records, path, executed = [], [], []
                row = {"task": task, "policy": policy, "teacher_moves": len(point.get_trajectory())}
                for step in range(args.max_steps + 1):
                    pixels = np.asarray(image)
                    if pixels.shape != (3, config["image_height"], config["image_width"]) or not np.isfinite(pixels).all():
                        raise ValueError("Simulator RGB shape or finite-value check failed")
                    path.append([float(metadata["x_pos"]), float(metadata["z_pos"])])
                    record = {"step": step, "xz": path[-1], "yaw": float(metadata["y_angle"]),
                              "rgb_min": float(pixels.min()), "rgb_max": float(pixels.max()),
                              "rgb_std": float(pixels.std()), "rgb_sha256": hashlib.sha256(pixels.tobytes()).hexdigest()}
                    if step == 0 or policy == "teacher":
                        rgb = np.moveaxis(pixels, 0, -1)
                        scale = 255.0 if pixels.max() <= 1.00001 else 1.0
                        frame_path = args.output / f"{policy}_{task}_{step:03d}.png"
                        Image.fromarray(np.clip(rgb * scale, 0, 255).astype(np.uint8)).save(frame_path)
                    if policy == "teacher":
                        action = point.get_trajectory()[step] if step < len(point.get_trajectory()) else actions.get_stop_action_index()
                    elif policy == "stop":
                        action = actions.get_stop_action_index()
                    elif policy == "random":
                        action = rng.randrange(actions.num_actions())
                    else:
                        action = actions.get_action_index("Forward")
                    stop = action == actions.get_stop_action_index()
                    if stop or step == args.max_steps:
                        record["action"] = "Stop"
                        records.append(record)
                        _, _, metadata = server.halt_and_receive_feedback()
                        halt_position = [float(metadata["x_pos"]), float(metadata["z_pos"])]
                        row["halt_position_xz"] = halt_position
                        row["halt_position_changed"] = math.dist(path[-1], halt_position) > 1e-4
                        if row["halt_position_changed"]:
                            path.append(halt_position)
                        row["termination"] = "policy_stop" if stop else "budget_stop"
                        break
                    record["action"] = actions.get_action_name(action)
                    records.append(record)
                    image, _, metadata = server.send_action_receive_feedback(action)
                    executed.append(action)
                goal = point.get_destination_list()[-1]
                sd = float(metadata["stop_dist_error"])
                oracle_distance = min(math.hypot(p[0] - goal[0], p[1] - goal[1]) for p in path)
                row.update(SD=sd, NE=sd, SR=float(sd < 5.0), OSR=float(oracle_distance < 5.0),
                           movement_steps=len(executed), MCD=float(metadata["closest_dist_error"]),
                           NED=float(metadata["edit_dist_error"]), SPL=None, records=records, actual_path_xz=path)
                if policy == "teacher":
                    changes = []
                    for before, after in zip(records, records[1:]):
                        movement = math.dist(before["xz"], after["xz"])
                        turn = abs((after["yaw"] - before["yaw"] + 180) % 360 - 180)
                        changes.append((before["action"] == "Forward" and movement > 1e-4) or
                                       (before["action"] in ("TurnRight", "TurnLeft") and turn > 1e-3))
                    row["teacher_replay_checks"] = {"endpoint_reached": sd < 5.0,
                        "action_changes_pose": any(changes),
                        "all_executed_actions_change_pose": bool(changes) and all(changes),
                        "first_and_last_rgb_nonconstant": min(records[0]["rgb_std"], records[-1]["rgb_std"]) > .001,
                        "rgb_content_changes": len({r["rgb_sha256"] for r in records}) > 1}
                    if not all(row["teacher_replay_checks"].values()):
                        report.update(status="teacher_or_image_gate_failed", comparison_valid=False)
                        report["episodes"].append(row)
                        write_json(args.output / "result.json", report)
                        raise RuntimeError("Teacher endpoint, actual action or RGB gate failed; no baseline comparison published")
                    references[task] = path
                row["nDTW"] = ndtw(path, references[task])
                row["sDTW"] = row["SR"] * row["nDTW"]
                row["autonomous_stop_success"] = row["SR"] * float(row["termination"] == "policy_stop")
                report["episodes"].append(row)
                write_json(args.output / "result.json", report)
                print(json.dumps({k: v for k, v in row.items() if k not in ("records", "actual_path_xz")}), flush=True)
        report.update(teacher_replay_gate=True, comparison_valid=True, status="passed")
        report["summary"] = {}
        for policy in ("teacher", "stop", "random", "forward"):
            group = [r for r in report["episodes"] if r["policy"] == policy]
            report["summary"][policy] = {key: sum(r[key] for r in group) / len(group)
                                          for key in ("SD", "NE", "SR", "OSR", "MCD", "NED", "nDTW", "sDTW",
                                                      "movement_steps", "autonomous_stop_success")}
            report["summary"][policy].update(
                episodes=len(group), SPL=None,
                policy_stop_rate=sum(r["termination"] == "policy_stop" for r in group) / len(group),
                budget_stop_rate=sum(r["termination"] == "budget_stop" for r in group) / len(group))
        write_json(args.output / "result.json", report)
    finally:
        if unity is not None and unity.poll() is None:
            unity.terminate()
            try:
                unity.wait(timeout=10)
            except subprocess.TimeoutExpired:
                unity.kill()
                unity.wait(timeout=10)
        server.kill()
        server.p.join(timeout=10)


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--upstream-root", type=Path, required=True)
    parser.add_argument("--asset-root", type=Path, required=True)
    parser.add_argument("--output", type=Path, required=True)
    parser.add_argument("--mode", choices=("smoke", "collect", "evaluate", "pipeline"), default="smoke")
    parser.add_argument("--pipeline-spec", type=Path)
    parser.add_argument("--split", choices=("train", "dev", "test"), default="train")
    parser.add_argument("--limit", type=int, default=0, help="0 means every official valid segment, with no length filtering")
    parser.add_argument("--resume", action="store_true", help="Reuse sealed complete episodes after source and SHA checks")
    parser.add_argument("--min-free-bytes", type=int, default=2*1024**3)
    parser.add_argument("--checkpoint", type=Path)
    parser.add_argument("--policy", choices=("model", "stop", "random", "forward"), default="model")
    parser.add_argument("--reference-manifest", type=Path)
    parser.add_argument("--device", choices=("cuda", "cpu"), default="cuda")
    parser.add_argument("--episodes", type=int, default=1)
    parser.add_argument("--max-steps", type=int, default=40)
    parser.add_argument("--timeout", type=int, default=300)
    parser.add_argument("--worker", action="store_true", help=argparse.SUPPRESS)
    args = parser.parse_args()
    if min(args.episodes, args.max_steps, args.timeout) < 1:
        parser.error("episodes, max-steps, timeout must be positive")
    args.output = args.output.resolve()
    if args.limit < 0 or args.min_free_bytes < 0:
        parser.error("limit and disk reserve must be nonnegative")
    if args.mode == "evaluate" and ((args.policy == "model" and not args.checkpoint) or not args.reference_manifest):
        parser.error("evaluation requires checkpoint and real teacher reference manifest")
    if args.mode == "evaluate" and args.max_steps != 40:
        parser.error("LANI evaluation v1 fixes a budget of 40 movement actions")
    if args.mode == "pipeline" and not args.pipeline_spec:
        parser.error("pipeline requires a frozen explicit specification")
    if args.mode == "smoke" and args.split == "test":
        parser.error("test is reserved for frozen full evaluation")
    if args.worker:
        args.output.mkdir(parents=True, exist_ok=True)
        if args.mode == "smoke":
            run_worker(args)
        else:
            sys.path.insert(0, str(Path(__file__).resolve().parents[1]))
            from uavnav.lani.runtime import collect, evaluate, pipeline
            {"collect":collect,"evaluate":evaluate,"pipeline":pipeline}[args.mode](args)
        return
    if os.name != "posix":
        parser.error("Official LANI simulator requires Linux; no synthetic fallback")
    if args.output.exists() and not (args.resume and args.mode != "smoke"):
        parser.error("Output must be a new, isolated attempt directory")
    args.output.mkdir(parents=True, exist_ok=args.resume)
    command = [sys.executable, "-B", str(Path(__file__).resolve()), *sys.argv[1:], "--worker"]
    started = time.monotonic()
    attempt = 1
    while (args.output / f"launch_{attempt}.json").exists():
        attempt += 1
    with (args.output / ("worker.log" if attempt == 1 else f"worker_{attempt}.log")).open("xb") as log:
        worker = subprocess.Popen(command, stdout=log, stderr=subprocess.STDOUT, start_new_session=True)
        write_json(args.output / f"launch_{attempt}.json", {"pid": worker.pid, "pgid": worker.pid, "command": command})
        timed_out = False
        try:
            code = worker.wait(timeout=args.timeout)
        except subprocess.TimeoutExpired:
            timed_out, code = True, None
        finally:
            try:
                os.killpg(worker.pid, signal.SIGTERM)
            except ProcessLookupError:
                pass
            deadline = time.monotonic() + 10
            while time.monotonic() < deadline:
                worker.poll()
                try:
                    os.killpg(worker.pid, 0)
                except ProcessLookupError:
                    break
                time.sleep(.1)
            else:
                try:
                    os.killpg(worker.pid, signal.SIGKILL)
                except ProcessLookupError:
                    pass
            if worker.poll() is None:
                worker.wait(timeout=10)
    write_json(args.output / ("execution.json" if attempt == 1 else f"execution_{attempt}.json"), {"exit_code": code, "timed_out": timed_out,
               "elapsed_seconds": time.monotonic() - started})
    if timed_out or code != 0:
        raise SystemExit("LANI real simulator attempt failed; inspect preserved worker and Unity logs")


if __name__ == "__main__":
    main()
