"""Read-only UAV-VLN-FOV audit; never writes inside the dataset directory.

Checks every trajectory, JSON log and camera image. ``decode`` checks PNG CRCs
and fully decodes pixels; ``verify`` checks CRCs without decoding pixels.
The JSON report is evidence about file integrity, not visual label correctness.
"""

from __future__ import annotations

import argparse
import hashlib
import io
import json
import math
import time
from collections import Counter
from concurrent.futures import ThreadPoolExecutor
from pathlib import Path

from PIL import Image


SPLITS = ("train", "test", "unobject", "unscene")


def vector(value, length):
    return (
        isinstance(value, list)
        and len(value) == length
        and all(isinstance(x, (int, float)) and not isinstance(x, bool)
                and math.isfinite(x) for x in value)
    )


def inspect_trajectory(task):
    split, relative, path, image_check = task
    issues = []
    states = {}
    pose_errors = []
    for log in sorted((path / "log").glob("*.json")):
        try:
            index = int(log.stem)
            if index in states:
                raise ValueError(f"duplicate numeric log index {index}")
            state = json.loads(log.read_text(encoding="utf-8"))["sensors"]["state"]
            if not vector(state["position"], 3) or not vector(state["orientation"], 4):
                raise ValueError("invalid/nonfinite position or xyzw")
            qnorm = sum(x * x for x in state["orientation"]) ** 0.5
            if qnorm == 0:
                raise ValueError("zero quaternion")
            states[index] = state
            if abs(qnorm - 1) > 0.001:
                pose_errors.append({"file": str(log.relative_to(path)), "quaternion_norm": qnorm})
        except (OSError, KeyError, TypeError, ValueError) as error:
            issues.append({"kind": "invalid_log", "file": str(log.relative_to(path)), "error": str(error)})
    if pose_errors:
        issues.append({"kind": "quaternion_norm", "items": pose_errors})

    camera_indices = {}
    image_count = Counter()
    formats = Counter()
    for names in (("FrontCamera", "frontcamera"), ("DownCamera", "downcamera")):
        cameras = [path / name for name in names if (path / name).is_dir()]
        if len(cameras) != 1:
            issues.append({"kind": "camera_directory_count", "camera": names[0], "count": len(cameras)})
        indices = set()
        for camera in cameras:
            for image in sorted(camera.glob("*.png")):
                image_count[names[0]] += 1
                try:
                    index = int(image.stem)
                    if index in indices:
                        raise ValueError(f"duplicate numeric image index {index}")
                    indices.add(index)
                    if index not in states:
                        issues.append({"kind": "image_without_valid_log", "file": str(image.relative_to(path))})
                    if image_check != "none":
                        raw = image.read_bytes()
                        with Image.open(io.BytesIO(raw)) as pixels:
                            formats[f"{pixels.format}:{pixels.mode}:{pixels.size[0]}x{pixels.size[1]}"] += 1
                            pixels.verify()
                        if image_check == "decode":
                            with Image.open(io.BytesIO(raw)) as pixels:
                                pixels.load()
                except (OSError, TypeError, ValueError, SyntaxError) as error:
                    issues.append({"kind": "invalid_image", "file": str(image.relative_to(path)), "error": str(error)})
        camera_indices[names[0]] = indices
    if camera_indices["FrontCamera"] != camera_indices["DownCamera"]:
        issues.append({"kind": "camera_indices_differ", "front_only": sorted(camera_indices["FrontCamera"] - camera_indices["DownCamera"]),
                       "down_only": sorted(camera_indices["DownCamera"] - camera_indices["FrontCamera"])})

    indices = sorted(camera_indices["FrontCamera"] & states.keys())
    gaps = [b - a for a, b in zip(indices, indices[1:])]
    counts = Counter(gaps)
    modes = sorted(g for g, n in counts.items() if n == max(counts.values())) if counts else []
    if len(indices) < 2:
        issues.append({"kind": "insufficient_front_frames", "indices": indices})
    if len(modes) > 1:
        issues.append({"kind": "tied_frame_gap", "indices": indices, "gaps": gaps, "modes": modes})
    for name in ("mark.json", "obj_des.json"):
        try:
            payload = json.loads((path / name).read_text(encoding="utf-8"))
            if name == "mark.json":
                if not isinstance(payload, dict):
                    raise ValueError("mark must be a JSON object")
                if not isinstance(payload.get("object_name"), str) or not payload["object_name"].strip():
                    raise ValueError("missing object_name")
                if not vector(payload["target"]["position"], 3):
                    raise ValueError("invalid target position")
            elif not isinstance(payload, list) or not payload or not isinstance(payload[0], str) or not payload[0].strip():
                raise ValueError("missing instruction")
        except (OSError, KeyError, TypeError, ValueError) as error:
            issues.append({"kind": "invalid_metadata", "file": name, "error": str(error)})
    return {"split": split, "trajectory": relative, "logs": len(states), "images": dict(image_count),
            "image_formats": dict(formats), "front_frames": len(indices), "gap_counts": dict(counts), "issues": issues}


def audit(root, workers, image_check):
    started = time.monotonic()
    tasks = []
    split_info = {}
    source_sha256 = {}
    membership = {}
    root_issues = []
    for split in SPLITS:
        list_path = root / split / f"{split}.json"
        try:
            raw = list_path.read_bytes()
        except OSError as error:
            root_issues.append({"kind": "unreadable_split_list", "split": split,
                                "file": str(list_path.relative_to(root)), "error": str(error)})
            split_info[split] = {"listed_trajectories": None, "status": "unreadable_split_list"}
            continue
        source_sha256[str(list_path.relative_to(root))] = hashlib.sha256(raw).hexdigest()
        rows = json.loads(raw)
        listed = [row["dir"] if isinstance(row, dict) else row for row in rows]
        if len(set(listed)) != len(listed):
            root_issues.append({"kind": "duplicate_list_entries", "split": split})
        actual = {f"{m.name}/{p.name}" for m in (root / split).iterdir() if m.is_dir()
                  for p in m.iterdir() if p.is_dir()}
        if actual != set(listed):
            root_issues.append({"kind": "list_directory_difference", "split": split,
                               "missing": sorted(set(listed) - actual), "unlisted": sorted(actual - set(listed))})
        for relative in listed:
            path = root / split / relative
            if not path.resolve().is_relative_to((root / split).resolve()):
                raise ValueError(f"list path escapes split: {relative}")
            if relative in membership:
                root_issues.append({"kind": "cross_split_trajectory", "trajectory": relative,
                                   "splits": [membership[relative], split]})
            membership[relative] = split
            tasks.append((split, relative, path, image_check))
        split_info[split] = {"listed_trajectories": len(listed), "logs": 0, "images": Counter(), "image_formats": Counter(),
                             "gap_counts": Counter(), "issue_counts": Counter()}
    for file in sorted((root / "meta").glob("*.json")):
        raw = file.read_bytes()
        json.loads(raw)
        source_sha256[str(file.relative_to(root))] = hashlib.sha256(raw).hexdigest()
    flagged = []
    with ThreadPoolExecutor(max_workers=workers) as pool:
        for completed, row in enumerate(pool.map(inspect_trajectory, tasks), 1):
            info = split_info[row["split"]]
            info["logs"] += row["logs"]
            info["images"].update(row["images"])
            info["image_formats"].update(row["image_formats"])
            info["gap_counts"].update(row["gap_counts"])
            info["issue_counts"].update(item["kind"] for item in row["issues"])
            if row["issues"]:
                flagged.append(row)
            if completed % 250 == 0:
                print(f"checked {completed}/{len(tasks)} trajectories", flush=True)
    for relative, expected in source_sha256.items():
        if hashlib.sha256((root / relative).read_bytes()).hexdigest() != expected:
            raise RuntimeError(f"source changed during audit: {relative}")
    return {"schema_version": 1, "data_root": str(root), "image_check": image_check, "workers": workers,
            "scope": "all listed trajectories; every JSON log and both camera PNGs; file/pose integrity only",
            "coverage_complete": not any(row["kind"] == "unreadable_split_list" for row in root_issues),
            "pose_validation": {"loader": "finite_nonzero_xyzw_normalized_by_rotation_library",
                                "audit": "also_reports_quaternion_norm_error_above_0.001"},
            "elapsed_seconds": round(time.monotonic() - started, 3), "source_sha256": source_sha256,
            "splits": split_info, "root_issues": root_issues, "flagged_trajectories": flagged}


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--data-root", type=Path, required=True)
    parser.add_argument("--output", type=Path, required=True)
    parser.add_argument("--workers", type=int, default=8)
    parser.add_argument("--images", choices=("none", "verify", "decode"), default="decode")
    args = parser.parse_args()
    if args.workers < 1:
        parser.error("workers must be positive")
    if args.output.resolve().is_relative_to(args.data_root.resolve()):
        parser.error("output must be outside the original dataset")
    if args.output.exists():
        parser.error("output already exists; choose a new evidence path")
    report = audit(args.data_root, args.workers, args.images)
    args.output.parent.mkdir(parents=True, exist_ok=True)
    args.output.write_text(json.dumps(report, ensure_ascii=False, indent=2, allow_nan=False) + "\n", encoding="utf-8")
    print(json.dumps({"output": str(args.output), "elapsed_seconds": report["elapsed_seconds"],
                      "splits": report["splits"], "root_issues": report["root_issues"]}, ensure_ascii=False), flush=True)
    failures = {"tied_frame_gap", "insufficient_front_frames"}
    if report["root_issues"] or any(item["kind"] not in failures for row in report["flagged_trajectories"] for item in row["issues"]):
        raise SystemExit(1)


if __name__ == "__main__":
    main()
