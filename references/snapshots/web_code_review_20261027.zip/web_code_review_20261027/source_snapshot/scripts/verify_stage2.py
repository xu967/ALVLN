"""真实小样本集成验证：训练、独立进程重载和回放，显式选择CPU或CUDA。

仅证明代码链路和数值一致性，不计算真实导航成功率。训练权重、临时列表
和回放产物均置于 TemporaryDirectory，结束后删除；只保留 JSON 验证摘要。
运行时工作目录应为 code，并设置 PYTHONPATH=.。
"""

from __future__ import annotations

import argparse
from collections import Counter
from contextlib import contextmanager
import hashlib
import functools
import json
import os
import platform
import shutil
import subprocess
import sys
from pathlib import Path
from tempfile import TemporaryDirectory
import tempfile
from unittest.mock import patch

import numpy as np
import torch
from PIL import Image

sys.path.insert(0, str(Path(__file__).resolve().parents[1]))

from uavnav.avln.data import collate, iter_samples, load_instructions, load_list
from uavnav.avln.fit import fit
from uavnav.avln.inference import WaypointPredictor
from uavnav.avln.model import FUSION_MODES, ARCHITECTURES, BACKBONES, FUSIONS
from uavnav.avln.rollout import rollout_episode
from uavnav.avln.simulator import StaticTrajectoryEnv


def _select_aerial_routes(episodes, scene_id, route_count, sampling):
    """选择完整路线，复用视觉时保留每条原始指令的独立监督身份。"""
    if sampling not in ("integration_shortest", "representative", "all"):
        raise ValueError("未知路线选择协议")
    if type(route_count) is not int or route_count <= 0:
        raise ValueError("route_count必须是正整数")
    groups = {}
    for episode in sorted(episodes, key=lambda row: str(row["episode_id"])):
        if episode["scene_id"] != scene_id or episode.get("_quarantine_reason"):
            continue
        if sampling == "integration_shortest" and len(episode["actions"]) < 5:
            continue
        raw = json.dumps([scene_id, episode["reference_path"]], sort_keys=True,
                         separators=(",", ":"), ensure_ascii=False, allow_nan=False)
        key = hashlib.sha256(raw.encode("utf-8")).hexdigest()
        group = groups.setdefault(key, [])
        if group and (group[0]["actions"] != episode["actions"]
                      or group[0]["start_rotation"] != episode["start_rotation"]):
            raise ValueError("相同渲染路线存在动作或起始姿态冲突，拒绝复用")
        group.append(episode)
    if not groups or (sampling != "all" and len(groups) < route_count):
        raise RuntimeError("该场景不具备请求数量的完整独立路线")
    ordered = sorted(groups, key=lambda key: (len(groups[key][0]["actions"]), key))
    if sampling == "all":
        chosen = ordered
    elif sampling == "integration_shortest":
        chosen = ordered[:route_count]
    else:
        lengths = np.asarray([len(groups[key][0]["actions"]) for key in ordered])
        bounds = np.quantile(lengths, [1 / 3, 2 / 3])
        bins = {key: int(np.searchsorted(bounds, len(groups[key][0]["actions"]), side="right")) for key in ordered}
        chosen, covered_actions, covered_bins = [], set(), set()
        while len(chosen) < route_count:
            def priority(key):
                actions = groups[key][0]["actions"]
                turns = sum(a != b for a, b in zip(actions, actions[1:]))
                return (len(set(actions) - covered_actions), int(bins[key] not in covered_bins),
                        turns / len(actions), -len(actions), key)
            key = max((key for key in ordered if key not in chosen), key=priority)
            chosen.append(key)
            covered_actions.update(groups[key][0]["actions"])
            covered_bins.add(bins[key])
    return [(key, episode) for key in chosen for episode in groups[key]]


def _aerial_controlled_collate(samples, *, vocab, imgsz, history_frames, text_control):
    """开发验收使用checkpoint记录的训练文本控制，不改原样本指令。"""
    if text_control not in ("original", "constant"):
        raise ValueError("路线验收text_control必须为original/constant")
    if text_control == "constant":
        samples = [{**sample, "instruction": "<unk>"} for sample in samples]
    return collate(samples, vocab, imgsz, history_frames)


def _collection_sha(value):
    return hashlib.sha256(json.dumps(value, sort_keys=True, separators=(",", ":"),
                                      ensure_ascii=False, allow_nan=False).encode("utf-8")).hexdigest()


@contextmanager
def _collection_lock(output):
    """同清单跨进程互斥；OS在进程退出时释放，不依据陈旧PID猜状态。"""
    output.parent.mkdir(parents=True, exist_ok=True)
    with output.with_name(output.stem + ".collection.lock").open("a+b") as stream:
        stream.seek(0, 2)
        if stream.tell() == 0:
            stream.write(b"0")
            stream.flush()
        stream.seek(0)
        if os.name == "nt":
            import msvcrt
            acquire = lambda: msvcrt.locking(stream.fileno(), msvcrt.LK_NBLCK, 1)
            release = lambda: msvcrt.locking(stream.fileno(), msvcrt.LK_UNLCK, 1)
        else:
            import fcntl
            acquire = lambda: fcntl.flock(stream.fileno(), fcntl.LOCK_EX | fcntl.LOCK_NB)
            release = lambda: fcntl.flock(stream.fileno(), fcntl.LOCK_UN)
        try:
            acquire()
        except OSError as error:
            raise RuntimeError("该采集清单正在使用，禁止并发控制或覆盖同一采集事务") from error
        try:
            yield
        finally:
            stream.seek(0)
            release()


def _atomic_collection_json(path, value):
    path.parent.mkdir(parents=True, exist_ok=True)
    name = None
    try:
        with tempfile.NamedTemporaryFile(mode="w", encoding="utf-8", dir=path.parent,
                                         prefix=f".{path.name}.", suffix=".tmp", delete=False) as stream:
            name = stream.name
            stream.write(json.dumps(value, ensure_ascii=False, indent=2, allow_nan=False) + "\n")
            stream.flush()
            os.fsync(stream.fileno())
        os.replace(name, path)
    finally:
        if name is not None and Path(name).exists():
            Path(name).unlink()


def _collection_journal(root, rows, event=None):
    path = root / "collection_journal.jsonl"
    if event is None:
        previous = None
        result = []
        for index, line in enumerate(path.read_bytes().splitlines(keepends=True) if path.exists() else []):
            if not line.endswith(b"\n"):
                raise ValueError("collection journal尾行截断，保留证据并拒绝自动续采")
            entry = json.loads(line)
            if (entry.get("index") != index or entry.get("previous_sha256") != previous
                    or entry.get("sha256") != _collection_sha({k: v for k, v in entry.items() if k != "sha256"})):
                raise ValueError("collection journal身份/顺序/SHA冲突")
            result.append(entry)
            previous = entry["sha256"]
        return result
    entry = {"index": len(rows), "previous_sha256": rows[-1]["sha256"] if rows else None, **event}
    entry["sha256"] = _collection_sha(entry)
    with path.open("a", encoding="utf-8", newline="\n") as stream:
        stream.write(json.dumps(entry, ensure_ascii=False, separators=(",", ":"), allow_nan=False) + "\n")
        stream.flush()
        os.fsync(stream.fileno())
    rows.append(entry)


def _validate_collection_route(receipt, episode, manifest_parent, render, save_depth):
    """复用已有数据审计规则，续采前核源位姿、相机、逐帧SHA与像素。"""
    from uavnav.avln.data import _aerial_cache_file, _validate_aerial_capture_frame, validate_aerial_render_protocol
    from uavnav.avln.data import preprocess_depth
    validate_aerial_render_protocol(render)
    frames = receipt.get("frames")
    if not isinstance(frames, list) or len(frames) != len(episode["reference_path"]):
        raise ValueError("已封口采集路线缺完整参考帧")
    previous = None
    for index, (frame, pose) in enumerate(zip(frames, episode["reference_path"])):
        if frame.get("frame_index") != index or frame.get("pose") != pose:
            raise ValueError("已封口采集路线参考pose/帧序号发生变化")
        previous = _validate_aerial_capture_frame(frame, pose, render, previous)
        rgb = _aerial_cache_file(manifest_parent, frame.get("rgb"), "resume RGB")
        with Image.open(rgb) as image:
            if image.mode != "RGB" or image.size != (render["width"], render["height"]):
                raise ValueError("续采RGB像素/尺寸与冻结来源不一致")
            image.verify()
        if save_depth:
            depth = _aerial_cache_file(manifest_parent, frame.get("depth"), "resume depth")
            preprocess_depth(depth, frame["depth"]["sha256"], frame["depth"].get("storage_protocol"))


def _check_collection_space(directory, min_free_gib):
    if type(min_free_gib) not in (int, float) or not np.isfinite(min_free_gib) or min_free_gib < 0:
        raise ValueError("min-free-gib必须是有限非负数，不能是布尔值")
    usage = shutil.disk_usage(directory)
    if usage.free < min_free_gib * 1024 ** 3:
        error = RuntimeError(f"采集输出盘空间不足: free={usage.free / 1024 ** 3:.3f}GiB, min={min_free_gib}GiB")
        error.disk_space_audit = {"directory": str(directory), "free_bytes": usage.free,
                                  "min_free_gib": min_free_gib}
        raise error


def _capture_collection_frame(env, pose, index, folder, parent, provenance, save_depth,
                              depth_storage="npy_float_v1", min_free_gib=12):
    from scipy.spatial.transform import Rotation
    from uavnav.avln.data import _validate_aerial_capture_frame
    q = Rotation.from_euler("xyz", [pose[4], pose[3], pose[5]]).as_quat()
    env._set_pose(np.asarray(pose[:3]), q)
    obs = env._observe()
    if (np.linalg.norm(obs.position - pose[:3]) > .02
            or float((Rotation.from_quat(obs.orientation).inv() * Rotation.from_quat(q)).magnitude()) > 1e-4):
        raise RuntimeError("实际渲染位姿与教师状态不符")
    folder.mkdir(parents=True, exist_ok=True)
    _check_collection_space(parent, min_free_gib)
    rgb = folder / f"{index:06d}.png"
    if rgb.exists():
        raise FileExistsError("拒绝覆盖已采集RGB")
    obs.image.save(rgb)
    row = {"frame_index": index, "pose": pose,
           "rgb": {"path": rgb.relative_to(parent).as_posix(), "sha256": hashlib.sha256(rgb.read_bytes()).hexdigest()},
           "observed_position": obs.position.tolist(), "observed_orientation_xyzw": obs.orientation.tolist(),
           "image_timestamp_s": obs.timestamp, "depth_collision_proxy": obs.info["depth_collision_proxy"],
           "simulator_contact": obs.info["simulator_contact"]}
    if save_depth:
        _check_collection_space(parent, min_free_gib)
        from uavnav.avln.data import save_aerial_depth
        depth = folder / (f"{index:06d}.npy.gz" if depth_storage == "npy_gzip_float32_v1" else f"{index:06d}.npy")
        row["depth"] = save_aerial_depth(depth, obs.info["depth_normalized"], depth_storage)
        row["depth"]["path"] = depth.relative_to(parent).as_posix()
    for field in _capture_metadata_fields(provenance):
        row[field] = obs.info[field]
    render = {"protocol_version": "aerialvln_s_pose_rgb_v2", "pose_mode": "simSetVehiclePose_ignore_collision",
              "camera_name": "front_0", "rgb_type": "Scene", "pixel_order": "RGB", "width": obs.image.width,
              "height": obs.image.height, "depth_protocol": "scene1_7_depthvis255_else_depthperspective100_v1",
              "provenance": provenance}
    _validate_aerial_capture_frame(row, pose, render, None)
    return row, render


def _capture_metadata_fields(provenance):
    from uavnav.avln.data import AERIAL_CAPTURE_FRAME_FIELDS, AERIAL_RGBD_CAPTURE_FRAME_FIELDS
    if provenance["capture_policy"]["version"] in ("set_pose_unpaused_rgbd_bounded_refresh_v2",
                                                  "set_pose_unpaused_rgbd_bounded_rerequest_v3"):
        return AERIAL_CAPTURE_FRAME_FIELDS + AERIAL_RGBD_CAPTURE_FRAME_FIELDS
    return AERIAL_CAPTURE_FRAME_FIELDS


def _merge_aerial_caches(args):
    from uavnav.avln.data import (load_aerial_samples, load_aerial_episodes,
                                 load_aerial_development_split, select_aerial_route_partition)
    from uavnav.avln.metadata import authenticate_aerial_release
    episodes = load_aerial_episodes(args.annotation_root, args.split)
    certificate = authenticate_aerial_release(args.split, episodes)
    expected = {f"{row['scene_id']}/{row['episode_id']}" for row in episodes if not row.get("_quarantine_reason")}
    development_path = getattr(args, "development_split_manifest", None)
    development = development_path is not None
    if development:
        if args.split != "train" or not development_path.resolve().is_relative_to(args.output.parent.resolve()):
            raise ValueError("开发merge仅接受train来源，冻结名单必须在index父目录内")
        route_split, development_digest = load_aerial_development_split(development_path, episodes)
        expected = {f"{row['scene_id']}/{row['episode_id']}" for row in route_split["dev_episode_keys"]}
    excluded = sorted([{"scene_id": row["scene_id"], "episode_id": row["episode_id"],
                        "episode_sha256": row["_episode_sha256"], "reason": row["_quarantine_reason"]}
                       for row in episodes if row.get("_quarantine_reason")],
                      key=lambda row: (row["scene_id"], str(row["episode_id"])))
    children, seen, scenes, combined_rows, development_samples = [], set(), {}, [], []
    for path in args.merge_caches:
        path = path.resolve()
        if not path.is_relative_to(args.output.parent.resolve()):
            raise ValueError("merge child必须位于index输出父目录内，避免相对路径越界")
        digest = hashlib.sha256(path.read_bytes()).hexdigest()
        child = json.loads(path.read_text(encoding="utf-8"))
        if child.get("cache_index_protocol") is not None or child.get("cache_kind") is not None:
            raise ValueError("merge只接受叶子场景缓存，不接受嵌套index")
        selected = load_aerial_samples(args.annotation_root, args.split, path, require_depth=args.save_depth,
                                      include_route_metadata=development)
        if development:
            if (child.get("development_partition") != "dev"
                    or child.get("development_split_manifest_sha256") != development_digest):
                raise ValueError("开发merge分片未绑定同一冻结名单")
            development_samples.extend(selected)
        keys = {f"{row['scene_id']}/{row['episode_id']}" for row in child["episodes"]}
        if len(keys) != len(child["episodes"]) or keys & seen or keys - expected:
            raise ValueError("merge child任务身份重复、交集或不属于完整官方split")
        if hashlib.sha256(path.read_bytes()).hexdigest() != digest:
            raise RuntimeError("merge期间child被修改")
        child_scenes = {row["scene_id"] for row in child["episodes"]}
        if len(child_scenes) != 1 or str(next(iter(child_scenes))) in scenes:
            raise ValueError("merge要求每scene唯一完整场景child")
        scene = next(iter(child_scenes))
        seen.update(keys)
        children.append({"path": path.relative_to(args.output.parent.resolve()).as_posix(), "sha256": digest, "scene_id": scene})
        scenes[str(scene)] = child["render_protocol"]
        combined_rows.extend({key: row[key] for key in ("scene_id", "episode_id", "episode_sha256")} for row in child["episodes"])
    payload = {"schema_version": 1, "data_protocol": "aerialvln_s_v1", "cache_kind": "scene_shards_v1",
               "split": args.split, "annotation_sha256": certificate["annotation_sha256"],
               "scope": "official_split_complete" if seen == expected else "incomplete_split",
               "official_source_authentication": certificate, "shards": children, "episodes": combined_rows,
               "excluded_quarantine": excluded, "excluded_quarantine_sha256": _collection_sha(excluded),
               "render_protocol": {"protocol_version": "aerialvln_s_multiscene_rgb_v1", "camera_name": "front_0", "scenes": scenes},
               "status": "complete" if seen == expected else "incomplete", "missing_episode_ids": sorted(expected - seen),
               "metrics": {name: None for name in ("sr", "sdtw", "ne", "osr", "ndtw")}}
    if development:
        if seen != expected:
            raise ValueError("开发merge要求完整冻结dev名单，缺场景/路线时不发布index")
        select_aerial_route_partition(development_samples, route_split, "dev")
        if hashlib.sha256(development_path.read_bytes()).hexdigest() != development_digest:
            raise ValueError("开发merge期间冻结名单被修改")
        payload.update(cache_index_protocol="aerial_development_subset_v1",
                       scope="train_source_development_partition_complete",
                       development_split_manifest={"path": development_path.resolve().relative_to(
                           args.output.parent.resolve()).as_posix(), "sha256": development_digest},
                       dev_episode_keys_sha256=route_split["dev_episode_keys_sha256"])
    _atomic_collection_json(args.output, payload)
    print(json.dumps({"status": payload["status"], "episodes": len(seen), "expected": len(expected)}, ensure_ascii=False))


def _plan_aerial_development(args):
    from uavnav.avln.data import load_aerial_samples, load_aerial_episodes, split_aerial_route_groups
    from uavnav.avln.data import load_aerial_development_split
    if args.split != "train" or args.cache_manifest is None or args.development_split_seed != 0:
        raise ValueError("plan-development需要完整train缓存与seed0")
    path = args.cache_manifest.resolve()
    digest = hashlib.sha256(path.read_bytes()).hexdigest()
    source = json.loads(path.read_text(encoding="utf-8"))
    if (source.get("cache_kind") != "scene_shards_v1" or source.get("scope") != "official_split_complete"
            or source.get("status") != "complete" or source.get("cache_index_protocol") is not None):
        raise ValueError("plan-development必须从认证的完整官方train index生成")
    samples = load_aerial_samples(args.annotation_root, "train", path, include_route_metadata=True,
                                  require_depth=args.save_depth)
    _, _, manifest = split_aerial_route_groups(samples, args.development_fraction, args.development_split_seed)
    if hashlib.sha256(path.read_bytes()).hexdigest() != digest:
        raise ValueError("plan-development期间完整train index发生改变")
    _atomic_collection_json(args.output, manifest)
    load_aerial_development_split(args.output, load_aerial_episodes(args.annotation_root, "train"))
    print(json.dumps({"status": "passed", "source": str(path), "source_sha256": digest,
        "development_split_manifest": str(args.output), "development_split_manifest_sha256": hashlib.sha256(
            args.output.read_bytes()).hexdigest(), "train_episodes": len(manifest["train_episode_keys"]),
        "dev_episodes": len(manifest["dev_episode_keys"]), "dev_routes": manifest["dev_route_count"],
        "dev_scenes": sorted({row["scene_id"] for row in manifest["dev_episode_keys"]})}, ensure_ascii=False))


def _collect_aerial_resumable(args, parser):
    """按完整几何路线封口；未封口尝试保留，续采新尝试而不覆盖旧图像。"""
    from scipy.spatial.transform import Rotation
    from uavnav.avln.data import load_aerial_episodes, load_aerial_samples
    from uavnav.avln.airsim_env import AerialRouteEnv, aerial_action_pose, aerial_scene_build
    from uavnav.avln.metadata import authenticate_aerial_release
    min_free_gib = getattr(args, "min_free_gib", 12)
    if type(min_free_gib) not in (int, float) or not np.isfinite(min_free_gib) or min_free_gib < 0:
        parser.error("min-free-gib必须是有限非负数，不能是布尔值")
    if (args.scene_id is None or args.episodes <= 0 or args.render_protocol != "v2"
            or args.scene_build_dir is None or not args.capture_session_id or not args.capture_session_id.strip()):
        parser.error("resume-collection需要v2、scene-id、scene-build-dir和capture-session-id")
    episodes = load_aerial_episodes(args.annotation_root, args.split)
    authentication = authenticate_aerial_release(args.split, episodes) if args.sampling == "all" else None
    development_path = getattr(args, "development_split_manifest", None)
    selected_source = episodes
    development_digest = None
    if development_path is not None:
        from uavnav.avln.data import load_aerial_development_split
        if args.split != "train" or args.sampling != "all":
            raise ValueError("独立开发采集必须是train来源、all冻结开发路线")
        route_split, development_digest = load_aerial_development_split(development_path, episodes)
        dev_keys = {(row["scene_id"], row["episode_id"]) for row in route_split["dev_episode_keys"]}
        selected_source = [ep for ep in episodes if (ep["scene_id"], str(ep["episode_id"])) in dev_keys]
    selected = _select_aerial_routes(selected_source, args.scene_id, args.episodes, args.sampling)
    grouped = {}
    for route, episode in selected:
        grouped.setdefault(route, []).append(episode)
    root = args.output.with_name(args.output.stem + ".collection")
    root.mkdir(parents=True, exist_ok=True)
    first = selected[0][1]
    contract = {"version": "aerial_collection_routes_v1", "split": args.split, "scene_id": args.scene_id,
                "annotation_sha256": first["_annotation_sha256"], "sampling": args.sampling,
                "save_depth": args.save_depth, "capture_session_id": args.capture_session_id,
                "scene_build": aerial_scene_build(args.scene_build_dir), "port": args.port,
                "selected": [{"route_key": route, "episode_id": episode["episode_id"],
                              "episode_sha256": episode["_episode_sha256"]} for route, episode in selected]}
    if getattr(args, "depth_storage", "npy_float_v1") != "npy_float_v1":
        contract["depth_storage_protocol"] = args.depth_storage
    if development_digest is not None:
        contract.update(development_partition="dev", development_split_manifest_sha256=development_digest)
    contract_path = root / "contract.json"
    if contract_path.exists():
        if json.loads(contract_path.read_text(encoding="utf-8")) != contract:
            raise ValueError("续采来源/名单/场景构建/会话/深度配置发生变化")
    else:
        if any(root.iterdir()) or args.output.exists():
            raise ValueError("resume-collection拒绝接管无冻结合同的旧目录")
        _atomic_collection_json(contract_path, contract)
    rows = _collection_journal(root, [])
    attempts, completed = {}, {}
    for entry in rows:
        route, event, relative = entry.get("route_key"), entry.get("event"), entry.get("attempt_path")
        if route not in grouped:
            raise ValueError("collection journal出现未知路线")
        if event == "started":
            ordinal = sum(value["route_key"] == route for value in attempts.values()) + 1
            if relative != f"routes/{route}/attempt_{ordinal:04d}" or relative in attempts or route in completed:
                raise ValueError("collection尝试身份/顺序重复或已完成路线被重采")
            attempts[relative] = {"route_key": route, "status": "started"}
        elif event == "completed":
            if relative not in attempts or attempts[relative]["status"] != "started" or route in completed:
                raise ValueError("collection封口未登记或重复")
            receipt_path = root / relative / "route.json"
            if not receipt_path.is_file() or hashlib.sha256(receipt_path.read_bytes()).hexdigest() != entry.get("receipt_sha256"):
                raise ValueError("已封口路线receipt被修改或缺失")
            receipt = json.loads(receipt_path.read_text(encoding="utf-8"))
            if (receipt.get("route_key") != route or receipt.get("contract_sha256") != _collection_sha(contract)
                    or receipt.get("episode_ids") != [ep["episode_id"] for ep in grouped[route]]):
                raise ValueError("已封口路线身份/合同与当前来源冲突")
            _validate_collection_route(receipt, grouped[route][0], args.output.parent, receipt["render_protocol"], args.save_depth)
            completed[route] = receipt
            attempts[relative]["status"] = "completed"
        elif event == "failed":
            if (relative not in attempts or attempts[relative]["status"] != "started"
                    or attempts[relative]["route_key"] != route):
                raise ValueError("collection失败事件未登记或重复")
            failure_path = root / relative / "failure.json"
            if (not failure_path.is_file()
                    or hashlib.sha256(failure_path.read_bytes()).hexdigest() != entry.get("failure_sha256")):
                raise ValueError("collection失败证据缺失或被修改")
            attempts[relative]["status"] = "failed"
        else:
            raise ValueError("未知collection journal事件")
    actual = set()
    if (root / "routes").exists():
        for route_dir in (root / "routes").iterdir():
            if not route_dir.is_dir() or route_dir.is_symlink() or route_dir.name not in grouped:
                raise ValueError("collection存在未登记路线目录")
            actual.update(path.relative_to(root).as_posix() for path in route_dir.iterdir())
    if actual - set(attempts):
        raise ValueError("collection存在未登记尝试目录，拒绝覆盖")

    def payload():
        if (development_digest is not None
                and hashlib.sha256(development_path.read_bytes()).hexdigest() != development_digest):
            raise ValueError("采集期间冻结开发名单被修改，不发布清单")
        available = []
        render = None
        for route, episode in selected:
            if route not in completed:
                continue
            receipt = completed[route]
            if render is not None and render != receipt["render_protocol"]:
                raise ValueError("封口路线间场景/相机来源冲突")
            render = receipt["render_protocol"]
            available.append({"scene_id": episode["scene_id"], "episode_id": episode["episode_id"],
                              "episode_sha256": episode["_episode_sha256"], "render_route_key": route,
                              "frames": receipt["frames"]})
        value = {"schema_version": 1, "data_protocol": "aerialvln_s_v1", "split": args.split,
                 "scope": "development_scene_subset", "sampling_policy": args.sampling,
                 "annotation_sha256": first["_annotation_sha256"], "official_episode_count": len(episodes),
                 "selected_route_count": len(grouped), "selected_episode_count": len(selected),
                 "capture_session_id": args.capture_session_id, "real_simulator_executed": bool(completed),
                 "episodes": available, "render_protocol": render,
                 "collection_status": "complete" if len(completed) == len(grouped) else "incomplete",
                 "collection_protocol": "aerial_collection_routes_v1", "official_source_authentication": authentication,
                 "missing_route_keys": sorted(set(grouped) - set(completed)),
                 "excluded_scene_episode_ids": sorted(str(ep["episode_id"]) for ep in episodes if
                    ep["scene_id"] == args.scene_id and ep.get("_quarantine_reason")),
                 "metrics": {name: None for name in ("sr", "sdtw", "ne", "osr", "ndtw")}}
        if development_digest is not None:
            value.update(development_partition="dev", development_split_manifest_sha256=development_digest)
        return value
    partial = args.output.with_name(args.output.stem + ".partial.json")
    value = payload()
    if args.output.exists():
        if value["collection_status"] != "complete" or json.loads(args.output.read_text(encoding="utf-8")) != value:
            raise ValueError("完成缓存与冻结journal不一致，禁止覆盖")
        load_aerial_samples(args.annotation_root, args.split, args.output, require_depth=args.save_depth)
        return
    _atomic_collection_json(partial, value)
    if value["collection_status"] == "complete":
        # 末条路线已封口而最终清单未发布的崩溃，不需要重新连接仿真器。
        _atomic_collection_json(args.output, value)
        load_aerial_samples(args.annotation_root, args.split, args.output, require_depth=args.save_depth)
        return
    env = None
    failure = None
    active_attempt = None
    ordinal = max((int(path.stem.rsplit("_", 1)[-1]) for path in root.glob("preflight_attempt_*.json")
                   if path.stem.rsplit("_", 1)[-1].isdigit()), default=0) + 1
    preflight_path = root / f"preflight_attempt_{ordinal:04d}.json"
    preflight = {"version": "aerial_collection_preflight_v1", "status": "started",
                 "contract_sha256": _collection_sha(contract), "capture_session_id": args.capture_session_id,
                 "annotation_sha256": contract["annotation_sha256"], "scene_build_sha256": contract["scene_build"]["sha256"],
                 "min_free_gib": min_free_gib, "stage": "disk_space", "action": None, "simulator_action_checks": []}
    _atomic_collection_json(preflight_path, preflight)
    try:
        _check_collection_space(args.output.parent, min_free_gib)
        preflight["stage"] = "environment"
        env = AerialRouteEnv(first["start_position"], np.asarray(first["start_rotation"])[[1, 2, 3, 0]],
                             args.scene_id, port=args.port, detect_depth_collision=False)
        preflight["stage"] = "provenance"
        provenance = env.capture_provenance(contract["scene_build"])
        preflight["provenance"] = provenance
        for receipt in completed.values():
            if receipt["render_protocol"]["provenance"] != provenance:
                raise ValueError("续采实际settings/FOV/相机与已封口来源不一致")
        for action in range(1, 8):
            preflight.update(stage="action_reset", action=action)
            before = env.reset()
            p, q = aerial_action_pose(before.position, before.orientation, action)
            preflight["stage"] = "action_step"
            after = env.step(action)
            position_error = float(np.linalg.norm(after.position - p))
            rotation_error = float((Rotation.from_quat(after.orientation).inv() * Rotation.from_quat(q)).magnitude())
            preflight["simulator_action_checks"].append({"action": action, "position_error_m": position_error,
                "rotation_error_rad": rotation_error, "capture_audit": env.last_capture_audit})
            if position_error > .02 or rotation_error > 1e-4:
                raise RuntimeError("续采真实动作检查失败")
        preflight.update(status="passed", stage="complete", action=None)
        _atomic_collection_json(preflight_path, preflight)
        for route, group in grouped.items():
            if route in completed:
                continue
            ordinal = sum(value["route_key"] == route for value in attempts.values()) + 1
            relative = f"routes/{route}/attempt_{ordinal:04d}"
            _collection_journal(root, rows, {"event": "started", "route_key": route, "attempt_path": relative})
            attempts[relative] = {"route_key": route, "status": "started"}
            folder = root / relative
            folder.mkdir(parents=True, exist_ok=False)
            active_attempt = (route, relative, folder)
            frames, render, previous = [], None, None
            index = 0
            _check_collection_space(args.output.parent, min_free_gib)
            for index, pose in enumerate(group[0]["reference_path"]):
                _check_collection_space(args.output.parent, min_free_gib)
                frame, current = _capture_collection_frame(env, pose, index, folder, args.output.parent, provenance,
                    args.save_depth, getattr(args, "depth_storage", "npy_float_v1"), min_free_gib)
                if render is not None and render != current:
                    raise RuntimeError("采集期间相机来源发生变化")
                from uavnav.avln.data import _validate_aerial_capture_frame
                previous = _validate_aerial_capture_frame(frame, pose, current, previous)
                render = current
                frames.append(frame)
                _atomic_collection_json(folder / "frames.partial.json", {"frames": frames, "render_protocol": render})
            if env.capture_provenance(contract["scene_build"]) != provenance:
                raise RuntimeError("采集前后场景/相机来源发生变化，路线不封口")
            receipt = {"route_key": route, "contract_sha256": _collection_sha(contract),
                       "episode_ids": [ep["episode_id"] for ep in group], "frames": frames, "render_protocol": render}
            _atomic_collection_json(folder / "route.json", receipt)
            _collection_journal(root, rows, {"event": "completed", "route_key": route, "attempt_path": relative,
                "receipt_sha256": hashlib.sha256((folder / "route.json").read_bytes()).hexdigest()})
            completed[route], attempts[relative]["status"] = receipt, "completed"
            active_attempt = None
            _atomic_collection_json(partial, {"collection_protocol": "aerial_collection_routes_v1", "status": "incomplete",
                                             "completed_route_count": len(completed), "selected_route_count": len(grouped),
                                             "missing_route_keys": sorted(set(grouped) - set(completed)),
                                             "contract_sha256": _collection_sha(contract)})
            print(f"可恢复采集 scene={args.scene_id}: {len(completed)}/{len(grouped)} routes", flush=True)
        if (development_digest is not None
                and hashlib.sha256(development_path.read_bytes()).hexdigest() != development_digest):
            raise ValueError("采集期间冻结开发名单被修改，不发布最终清单")
        _atomic_collection_json(args.output, payload())
        load_aerial_samples(args.annotation_root, args.split, args.output, require_depth=args.save_depth)
    except BaseException as error:
        failure = error
        if preflight["status"] != "passed":
            preflight.update(status="failed", error_type=type(error).__name__, error=str(error),
                capture_audit=getattr(error, "capture_audit", getattr(env, "last_capture_audit", None)),
                disk_space_audit=getattr(error, "disk_space_audit", None))
            _atomic_collection_json(preflight_path, preflight)
        if active_attempt is not None:
            route, relative, folder = active_attempt
            failed = {"route_key": route, "contract_sha256": _collection_sha(contract),
                      "error_type": type(error).__name__, "error": str(error),
                      "completed_frames": len(frames), "active_frame_index": index,
                      "capture_audit": getattr(error, "capture_audit", getattr(env, "last_capture_audit", None))}
            if hasattr(error, "disk_space_audit"):
                failed["disk_space_audit"] = error.disk_space_audit
            _atomic_collection_json(folder / "failure.json", failed)
            _collection_journal(root, rows, {"event": "failed", "route_key": route, "attempt_path": relative,
                "failure_sha256": hashlib.sha256((folder / "failure.json").read_bytes()).hexdigest()})
        raise
    finally:
        if env is not None:
            try:
                env.finish()
            except BaseException as error:
                _atomic_collection_json(root / "cleanup_error.json", {"error": type(error).__name__ + ": " + str(error),
                    "original_error": None if failure is None else type(failure).__name__ + ": " + str(failure)})
                if failure is None:
                    raise


def _collect_aerial_legacy(args, parser):
    from scipy.spatial.transform import Rotation
    from uavnav.avln.data import load_aerial_episodes, load_aerial_samples
    digest = lambda path: hashlib.sha256(Path(path).read_bytes()).hexdigest()
    from uavnav.avln.airsim_env import AerialRouteEnv, aerial_action_pose, aerial_scene_build
    if args.scene_id is None or args.episodes <= 0:
        parser.error("collect需要scene-id与正数episodes，调用前必须启动对应官方场景")
    if args.render_protocol == "v2" and (args.scene_build_dir is None or not args.capture_session_id
                                         or not args.capture_session_id.strip()):
        parser.error("v2 collect需要scene-build-dir与capture-session-id，明确声明已启动场景来源与会话")
    episodes = load_aerial_episodes(args.annotation_root, args.split)
    from uavnav.avln.metadata import authenticate_aerial_release
    authentication = authenticate_aerial_release(args.split, episodes) if args.sampling == "all" else None
    selected = _select_aerial_routes(episodes, args.scene_id, args.episodes, args.sampling)
    for route_key in {key for key, _ in selected}:
        destination = args.output.parent / "frames" / args.output.stem / args.split / str(args.scene_id) / route_key
        if destination.exists():
            raise FileExistsError(f"渲染目录已存在，拒绝覆盖旧缓存或下载残片，请使用独立输出目录: {destination}")
    first = selected[0][1]
    quaternion = lambda pose: Rotation.from_euler("xyz", [pose[4], pose[3], pose[5]]).as_quat()
    start_q = np.asarray(first["start_rotation"])[[1, 2, 3, 0]]
    env = AerialRouteEnv(first["start_position"], start_q, args.scene_id,
                         port=args.port, detect_depth_collision=False)
    active_folder = None
    try:
        provenance = None
        if args.render_protocol == "v2":
            provenance = env.capture_provenance(aerial_scene_build(args.scene_build_dir))
        action_checks = []
        for action in range(1, 8):
            before = env.reset()
            expected_p, expected_q = aerial_action_pose(before.position, before.orientation, action)
            after = env.step(action)
            position_error = float(np.linalg.norm(after.position - expected_p))
            rotation_error = float((Rotation.from_quat(after.orientation).inv()
                                    * Rotation.from_quat(expected_q)).magnitude())
            if position_error > .02 or rotation_error > 1e-4:
                raise RuntimeError(f"实际动作{action}响应与官方位姿不符")
            action_checks.append({"action": action, "position_error_m": position_error,
                                  "rotation_error_rad": rotation_error})
        payload = {"schema_version": 1, "data_protocol": "aerialvln_s_v1", "split": args.split,
                   "scope": "integration_episode_subset" if args.sampling == "integration_shortest" else "development_scene_subset",
                   "sampling_policy": args.sampling, "annotation_sha256": first["_annotation_sha256"],
                   "official_episode_count": len(episodes), "episodes": [],
                   "simulator_action_checks": action_checks, "real_simulator_executed": True}
        if authentication is not None:
            payload["official_source_authentication"] = authentication
        payload["selected_route_count"] = len({key for key, _ in selected})
        if provenance is not None:
            payload["capture_session_id"] = args.capture_session_id
        payload["selected_episode_count"] = len(selected)
        payload["selected_action_counts"] = dict(Counter(a for _, episode in selected for a in episode["actions"]))
        previous_timestamp = None
        previous_capture = None
        rendered_routes = {}
        for route_key, episode in selected:
            row = {"scene_id": episode["scene_id"], "episode_id": episode["episode_id"],
                   "episode_sha256": episode["_episode_sha256"], "render_route_key": route_key, "frames": []}
            if route_key in rendered_routes:
                row["frames"] = rendered_routes[route_key]
                payload["episodes"].append(row)
                continue
            folder = args.output.parent / "frames" / args.output.stem / args.split / str(args.scene_id) / route_key
            active_folder = folder
            for index, pose in enumerate(episode["reference_path"]):
                requested_q = quaternion(pose)
                env._set_pose(np.asarray(pose[:3]), requested_q)
                obs = env._observe()
                position_error = float(np.linalg.norm(obs.position - pose[:3]))
                rotation_error = float((Rotation.from_quat(obs.orientation).inv()
                                        * Rotation.from_quat(requested_q)).magnitude())
                if position_error > .02 or rotation_error > 1e-4:
                    raise RuntimeError("实际渲染位姿与教师状态不符")
                if previous_timestamp is not None and obs.timestamp <= previous_timestamp:
                    raise RuntimeError("真实渲染时间戳未推进，不能冻结为下一状态图像")
                previous_timestamp = obs.timestamp
                if provenance is not None:
                    camera_p = np.asarray(obs.info.get("response_camera_position"), dtype=float)
                    camera_q = np.asarray(obs.info.get("response_camera_orientation_xyzw"), dtype=float)
                    extrinsics = provenance["camera_extrinsics"]
                    expected_camera_p = np.asarray(pose[:3]) + Rotation.from_quat(requested_q).apply(extrinsics["position"])
                    pitch, roll, yaw = extrinsics["rotation_degrees"]
                    expected_camera_q = Rotation.from_quat(requested_q) * Rotation.from_euler("xyz", [roll, pitch, yaw], degrees=True)
                    if camera_p.shape != (3,) or camera_q.shape != (4,) or not np.isfinite(camera_p).all() or not np.isfinite(camera_q).all():
                        raise RuntimeError("v2采集要求实际图像响应相机位置及四元数")
                    if np.linalg.norm(camera_p - expected_camera_p) > .02 or float((expected_camera_q.inv() * Rotation.from_quat(camera_q)).magnitude()) > 1e-4:
                        raise RuntimeError("v2图像响应相机与车辆位姿及实际外参不一致")
                folder.mkdir(parents=True, exist_ok=True)
                image_path, depth_path = folder / f"{index:06d}.png", folder / f"{index:06d}.npy"
                obs.image.save(image_path)
                if args.save_depth:
                    np.save(depth_path, obs.info["depth_normalized"], allow_pickle=False)
                row["frames"].append({"frame_index": index, "pose": pose,
                    "rgb": {"path": image_path.relative_to(args.output.parent).as_posix(), "sha256": digest(image_path)},
                    "observed_position": obs.position.tolist(), "observed_orientation_xyzw": obs.orientation.tolist(),
                    "image_timestamp_s": obs.timestamp, "depth_collision_proxy": obs.info["depth_collision_proxy"],
                    "simulator_contact": obs.info["simulator_contact"]})
                if args.save_depth:
                    row["frames"][-1]["depth"] = {"path": depth_path.relative_to(args.output.parent).as_posix(), "sha256": digest(depth_path)}
                if provenance is not None:
                    for field in _capture_metadata_fields(provenance):
                        row["frames"][-1][field] = obs.info[field]
                render = {"protocol_version": "aerialvln_s_pose_rgb_v1", "pose_mode": "simSetVehiclePose_ignore_collision",
                          "camera_name": "front_0", "rgb_type": "Scene", "pixel_order": "RGB",
                          "width": obs.image.width, "height": obs.image.height,
                          "depth_protocol": "scene1_7_depthvis255_else_depthperspective100_v1"}
                if provenance is not None:
                    render.update(protocol_version="aerialvln_s_pose_rgb_v2", provenance=provenance)
                    from uavnav.avln.data import _validate_aerial_capture_frame
                    previous_capture = _validate_aerial_capture_frame(row["frames"][-1], pose, render, previous_capture)
                if "render_protocol" in payload and payload["render_protocol"] != render:
                    raise RuntimeError("缓存期间相机设置发生变化")
                payload["render_protocol"] = render
            payload["episodes"].append(row)
            rendered_routes[route_key] = row["frames"]
            active_folder = None
            print(f"真实缓存 {args.split} scene={args.scene_id}: {len(payload['episodes'])}/{len(selected)} episodes", flush=True)
        if provenance is not None:
            after = env.capture_provenance(aerial_scene_build(args.scene_build_dir))
            if after != provenance:
                raise RuntimeError("v2采集前后实际settings/FOV/场景构建发生变化，拒绝完成缓存清单")
            from uavnav.avln.data import validate_aerial_render_protocol
            validate_aerial_render_protocol(payload["render_protocol"])
        args.output.write_text(json.dumps(payload, ensure_ascii=False, indent=2), encoding="utf-8")
        samples = load_aerial_samples(args.annotation_root, args.split, args.output)
        print(json.dumps({"status": "passed", "real_frames": len(samples), "manifest": str(args.output)}))
        return
    except BaseException as error:
        if active_folder is not None:
            _atomic_collection_json(active_folder / "failure.json", {
                "route_key": route_key, "episode_id": episode["episode_id"],
                "error_type": type(error).__name__, "error": str(error),
                "completed_frames": len(row["frames"]), "active_frame_index": index,
                "capture_audit": getattr(error, "capture_audit", getattr(env, "last_capture_audit", None))})
        raise
    finally:
        env.finish()


def _collect_aerial_dagger(args, parser):
    """冻结训练成员和偏轨教师，完整episode封口后才能发布训练清单。"""
    from uavnav.avln.data import load_aerial_episodes, load_aerial_dagger_samples, validate_aerial_render_protocol
    from uavnav.avln.airsim_env import AerialRouteEnv, aerial_scene_build
    from uavnav.avln.geometry import AirVLNDaggerTeacher
    from uavnav.avln.inference import AerialActionPredictor
    from uavnav.avln.closed_loop import collect_aerial_dagger_episode
    from uavnav.avln.metadata import authenticate_aerial_release
    paths = (args.checkpoint, args.teacher_upstream_root, args.teacher_nav_graph,
             args.teacher_token_dict, args.teacher_review, args.scene_build_dir)
    if (args.split != "train" or args.scene_id is None or any(path is None for path in paths)
            or not args.collection_id or not args.collection_id.strip() or not args.capture_session_id
            or not args.capture_session_id.strip() or args.render_protocol != "v2"
            or args.beta is None or not np.isfinite(args.beta) or not 0 <= args.beta < 1
            or not 1 <= args.max_steps <= 500):
        parser.error("dagger需要train、scene、checkpoint、collection/session身份、v2构建、显式beta与已审核教师/图资产")
    if args.device == "cuda" and not torch.cuda.is_available():
        raise RuntimeError("DAgger请求CUDA但没有GPU，不回退CPU启动采集")
    episodes = load_aerial_episodes(args.annotation_root, "train")
    authentication = authenticate_aerial_release("train", episodes)
    checkpoint = args.checkpoint.resolve()
    predictor = AerialActionPredictor(checkpoint, device=args.device)
    if (predictor.config.get("data_protocol") != "aerialvln_s_v1"
            or predictor.config.get("history_policy") != "action_onehot8_v1"
            or predictor.config.get("seed") != 0):
        raise ValueError("DAgger学生必须是seed0的版本化路线策略")
    split_path = checkpoint.parent.parent / "split_manifest.json"
    if (not split_path.is_file() or hashlib.sha256(split_path.read_bytes()).hexdigest()
            != predictor.config.get("split_manifest_sha256")):
        raise ValueError("DAgger必须核学生checkpoint邻接冻结训练名单")
    partition = json.loads(split_path.read_text(encoding="utf-8"))
    allowed = partition.get("train_episode_ids")
    official = {f"{ep['scene_id']}/{ep['episode_id']}": ep for ep in episodes if not ep.get("_quarantine_reason")}
    if (partition.get("data_protocol") != "aerialvln_s_v1"
            or partition.get("train_annotation_sha256") != episodes[0]["_annotation_sha256"]
            or not isinstance(allowed, list) or not allowed or len(set(allowed)) != len(allowed)
            or set(allowed) - set(official)
            or set(allowed) & set(partition.get("validation_episode_ids", []))):
        raise ValueError("DAgger训练成员与官方train来源/开发留出不一致")
    selected = _select_aerial_routes([ep for key, ep in official.items() if key in set(allowed)],
                                     args.scene_id, args.episodes, args.sampling)
    teacher = AirVLNDaggerTeacher(args.teacher_upstream_root, args.teacher_nav_graph,
                                  args.teacher_token_dict, args.scene_id, args.teacher_review)
    history_frames = predictor.config["history_frames"]
    depth_required = args.save_depth or predictor.config.get("input_modality") == "rgbd"
    build = aerial_scene_build(args.scene_build_dir)
    header = {"schema_version": 1, "data_protocol": "aerialvln_s_v1", "split": "train",
              "sample_policy": "aerial_dagger_current_state_v1", "collection_id": args.collection_id,
              "annotation_sha256": episodes[0]["_annotation_sha256"], "checkpoint_sha256": predictor.checkpoint_sha256,
              "teacher_protocol": "airvln_upstream_pose_guard_v1", "teacher_contract": teacher.review,
              "teacher_contract_sha256": teacher.contract_sha256, "seed": 0, "beta": args.beta,
              "max_steps": args.max_steps, "history_frames": history_frames,
              "mixing_protocol": "seed0_reset_per_episode_v1", "official_source_authentication": authentication,
              "training_split_manifest_sha256": predictor.config["split_manifest_sha256"],
              "capture_session_id": args.capture_session_id,
              "scope": "checkpoint_training_members_scene_collection"}
    selected_by_id = {f"{ep['scene_id']}/{ep['episode_id']}": ep for _, ep in selected}
    contract = {"protocol": "aerial_dagger_collection_transactions_v1", "header": header,
                "scene_build": build, "port": args.port, "device": args.device, "save_depth": depth_required,
                "source_sha256": {name: hashlib.sha256((Path(__file__).resolve().parents[1] / name).read_bytes()).hexdigest()
                                  for name in ("scripts/verify_stage2.py", "uavnav/avln/geometry.py",
                                               "uavnav/avln/data.py", "uavnav/avln/inference.py", "uavnav/avln/closed_loop.py")},
                "selected": [{"episode_key": key, "episode_sha256": ep["_episode_sha256"]}
                             for key, ep in selected_by_id.items()]}
    contract["depth_storage_protocol"] = getattr(args, "depth_storage", "npy_float_v1")
    root = args.output.with_name(args.output.stem + ".dagger")
    contract_path = root / "contract.json"
    if root.exists() and not args.resume_collection:
        raise FileExistsError("已有DAgger事务，请显式resume-collection；不覆盖旧尝试")
    root.mkdir(parents=True, exist_ok=True)
    if contract_path.exists():
        if json.loads(contract_path.read_text(encoding="utf-8")) != contract:
            raise ValueError("DAgger续采checkpoint/训练成员/教师/场景/配方发生变化")
    else:
        if any(root.iterdir()) or args.output.exists():
            raise ValueError("拒绝接管无冻结合同的DAgger旧目录")
        _atomic_collection_json(contract_path, contract)
    journal = _collection_journal(root, [])
    attempts, completed, render = {}, {}, None

    def manifest(status):
        return {**header, "render_protocol": render, "collection_status": status,
                "selected_episode_ids": list(selected_by_id),
                "missing_episode_ids": sorted(set(selected_by_id) - set(completed)),
                "episodes": [completed[key]["episode"] for key in selected_by_id if key in completed]}

    for entry in journal:
        key, relative = entry.get("episode_key"), entry.get("attempt_path")
        if key not in selected_by_id:
            raise ValueError("DAgger事务出现未授权任务")
        if entry.get("event") == "started":
            ordinal = sum(item["episode_key"] == key for item in attempts.values()) + 1
            prefix = hashlib.sha256(key.encode()).hexdigest()
            if (relative != f"episodes/{prefix}/attempt_{ordinal:04d}"
                    or relative in attempts or key in completed):
                raise ValueError("DAgger尝试顺序/身份冲突或封口任务被重采")
            attempts[relative] = {"episode_key": key, "status": "started"}
        elif entry.get("event") == "completed":
            if relative not in attempts or attempts[relative]["status"] != "started" or key in completed:
                raise ValueError("DAgger封口尝试未登记或重复")
            path = root / relative / "receipt.json"
            if not path.is_file() or hashlib.sha256(path.read_bytes()).hexdigest() != entry.get("receipt_sha256"):
                raise ValueError("DAgger已封口receipt缺失或被修改")
            receipt = json.loads(path.read_text(encoding="utf-8"))
            ep = selected_by_id[key]
            if (receipt.get("contract_sha256") != _collection_sha(contract)
                    or receipt["episode"].get("source_episode_id") != ep["episode_id"]
                    or receipt["episode"].get("scene_id") != ep["scene_id"]
                    or receipt["episode"].get("episode_sha256") != ep["_episode_sha256"]):
                raise ValueError("DAggerreceipt与冻结任务/合同冲突")
            if render is not None and render != receipt["render_protocol"]:
                raise ValueError("DAgger封口任务间相机来源变化")
            render = receipt["render_protocol"]
            completed[key], attempts[relative]["status"] = receipt, "completed"
        else:
            raise ValueError("未知DAgger事务事件")
    if (root / "episodes").exists():
        actual = set()
        for episode_dir in (root / "episodes").iterdir():
            if not episode_dir.is_dir() or episode_dir.is_symlink():
                raise ValueError("DAgger存在非法任务目录")
            for attempt in episode_dir.iterdir():
                if not attempt.is_dir() or attempt.is_symlink():
                    raise ValueError("DAgger存在非法尝试目录")
                actual.add(attempt.relative_to(root).as_posix())
        if actual - set(attempts):
            raise ValueError("DAgger存在未登记尝试，拒绝接管或覆盖")
    partial = args.output.with_name(args.output.stem + ".partial.json")
    if completed:
        _atomic_collection_json(partial, manifest("incomplete"))
        load_aerial_dagger_samples(args.annotation_root, partial, history_frames, depth_required, allow_incomplete=True)
    if args.output.exists():
        if len(completed) != len(selected_by_id) or json.loads(args.output.read_text(encoding="utf-8")) != manifest("complete"):
            raise ValueError("DAgger完成清单与已封口事务冲突")
        return load_aerial_dagger_samples(args.annotation_root, args.output, history_frames, depth_required)
    for key, ep in selected_by_id.items():
        if key in completed:
            continue
        ordinal = sum(item["episode_key"] == key for item in attempts.values()) + 1
        relative = f"episodes/{hashlib.sha256(key.encode()).hexdigest()}/attempt_{ordinal:04d}"
        _collection_journal(root, journal, {"event": "started", "episode_key": key, "attempt_path": relative})
        attempts[relative] = {"episode_key": key, "status": "started"}
        env = AerialRouteEnv(ep["start_position"], np.asarray(ep["start_rotation"])[[1, 2, 3, 0]],
                             args.scene_id, port=args.port)
        try:
            current = {"protocol_version": "aerialvln_s_pose_rgb_v2", "pose_mode": "simSetVehiclePose_ignore_collision",
                       "camera_name": "front_0", "rgb_type": "Scene", "pixel_order": "RGB", "width": 224, "height": 224,
                       "depth_protocol": "scene1_7_depthvis255_else_depthperspective100_v1",
                       "provenance": env.capture_provenance(build)}
            validate_aerial_render_protocol(current)
            if render is not None and render != current:
                raise ValueError("DAgger实际场景/settings/FOV与已封口任务来源不一致")
        except BaseException:
            env.finish()
            raise
        result = collect_aerial_dagger_episode(env, predictor, teacher, ep, root / relative,
                                              beta=args.beta, seed=0, max_steps=args.max_steps,
                                              history_frames=history_frames, save_depth=depth_required,
                                              depth_storage=getattr(args, "depth_storage", "npy_float_v1"))
        if env.capture_provenance(build) != current["provenance"]:
            raise ValueError("DAgger采集前后实际相机来源变化，尝试不封口")
        frames = json.loads(json.dumps(result["frames"], ensure_ascii=False, allow_nan=False))
        previous_timestamp = None
        from uavnav.avln.data import _validate_aerial_capture_frame, preprocess_depth
        for frame in frames:
            previous_timestamp = _validate_aerial_capture_frame(frame, frame["pose"], current, previous_timestamp)
            for sensor in ("rgb", "depth"):
                if sensor in frame:
                    sensor_path = root / relative / frame[sensor]["path"]
                    if hashlib.sha256(sensor_path.read_bytes()).hexdigest() != frame[sensor]["sha256"]:
                        raise ValueError("DAgger封口前传感器文件内容改变")
                    if sensor == "depth":
                        preprocess_depth(sensor_path, frame[sensor]["sha256"], frame[sensor].get("storage_protocol"))
                    frame[sensor]["path"] = sensor_path.relative_to(args.output.parent).as_posix()
        row = {"scene_id": ep["scene_id"], "source_episode_id": ep["episode_id"],
               "episode_id": args.collection_id + "_" + str(ep["episode_id"]), "episode_sha256": ep["_episode_sha256"],
               "instruction": ep["instruction"]["instruction_text"], "termination_reason": result["termination_reason"], "frames": frames}
        render = current
        receipt = {"contract_sha256": _collection_sha(contract), "episode": row, "render_protocol": render}
        completed[key] = receipt
        receipt_path = root / relative / "receipt.json"
        _atomic_collection_json(receipt_path, receipt)
        _collection_journal(root, journal, {"event": "completed", "episode_key": key, "attempt_path": relative,
                                          "receipt_sha256": hashlib.sha256(receipt_path.read_bytes()).hexdigest()})
        attempts[relative]["status"] = "completed"
        _atomic_collection_json(partial, {"status": "incomplete", "collection_id": args.collection_id,
                                         "contract_sha256": _collection_sha(contract), "completed_episode_count": len(completed),
                                         "selected_episode_count": len(selected_by_id),
                                         "missing_episode_ids": sorted(set(selected_by_id) - set(completed))})
        print(f"DAgger scene={args.scene_id}: {len(completed)}/{len(selected_by_id)} episodes", flush=True)
    if aerial_scene_build(args.scene_build_dir) != build:
        raise ValueError("DAgger期间场景构建内容变化，不发布最终清单")
    # 完整读审计只在恢复或最终发布时执行，避免全量采集反复重读旧帧和全库标注。
    _atomic_collection_json(partial, manifest("complete"))
    samples = load_aerial_dagger_samples(args.annotation_root, partial, history_frames, depth_required)
    os.replace(partial, args.output)
    return samples


def _aerial_main(argv):
    """采集完整教师路线或验收其训练重载；子集不作为正式导航成绩。"""
    from scipy.spatial.transform import Rotation
    from uavnav.avln.data import load_aerial_episodes, load_aerial_samples
    parser = argparse.ArgumentParser(description="AerialVLN-S真实场景缓存与GPU集成验收")
    parser.add_argument("--dataset", choices=("aerialvln_s_v1",), required=True)
    parser.add_argument("--mode", choices=("collect", "merge", "dagger", "integration", "learnability", "plan-development"), required=True)
    parser.add_argument("--annotation-root", type=Path, required=True)
    parser.add_argument("--output", type=Path, required=True)
    parser.add_argument("--split", choices=("train", "val_seen", "val_unseen"), default="train")
    parser.add_argument("--scene-id", type=int)
    parser.add_argument("--episodes", type=int, default=3, help="所选独立路线数；每条路线的全部官方指令均保留")
    parser.add_argument("--sampling", choices=("integration_shortest", "representative", "all"), default="representative")
    parser.add_argument("--architecture", choices=("aerial_route_v1", "aerial_route_recurrent_v2", "aerial_route_dino_v5"), default="aerial_route_recurrent_v2")
    parser.add_argument("--dino-repo", type=Path, help="DINOv3源码目录；v5必填或由UAVNAV_DINO_REPO提供")
    parser.add_argument("--dino-weights", type=Path, help="DINOv3预训练权重；v5必填或由UAVNAV_DINO_WEIGHTS提供")
    parser.add_argument("--dino-variant", default="vits16", choices=("vits16", "vits16plus", "vitb16", "vitl16"))
    parser.add_argument("--epochs", type=int, default=20)
    parser.add_argument("--sequence-chunk-size", type=int, default=16)
    parser.add_argument("--min-fit-accuracy", type=float, default=.95)
    parser.add_argument("--min-fit-recall", type=float, default=.90)
    parser.add_argument("--save-depth", action="store_true", help="保存验收所需深度；完整RGB训练缓存默认不保存深度数组")
    parser.add_argument("--depth-storage", choices=("npy_float_v1", "npy_gzip_float32_v1"), default="npy_float_v1",
                        help="可恢复采集/DAgger可用gzip无损保存float32，不改变策略数值")
    parser.add_argument("--render-protocol", choices=("v2", "legacy-v1"), default="v2")
    parser.add_argument("--scene-build-dir", type=Path, help="调用方确认与已启动场景对应的构建目录；v2必填")
    parser.add_argument("--capture-session-id", help="调用方声明的场景启动会话身份；v2必填，不自动推断独立性")
    parser.add_argument("--port", type=int, default=41451)
    parser.add_argument("--cache-manifest", type=Path)
    parser.add_argument("--validation-cache-manifest", type=Path)
    parser.add_argument("--development-split-manifest", type=Path,
                        help="冻结的完整train几何开发名单；collect只采其中dev完整路线，merge核完整dev覆盖")
    parser.add_argument("--development-fraction", type=float, default=.2)
    parser.add_argument("--development-split-seed", type=int, default=0)
    parser.add_argument("--device", choices=("cpu", "cuda"), default="cuda")
    parser.add_argument("--resume-collection", action="store_true", help="启用可恢复采集；首次和续采都填写")
    parser.add_argument("--min-free-gib", type=float, default=12,
                        help="可恢复collect在输出盘保留的最小GiB；不足时保留失败并停止采集")
    parser.add_argument("--merge-caches", nargs="+", type=Path, help="合并各场景已完成缓存，核完整官方有效任务")
    parser.add_argument("--checkpoint", type=Path, help="DAgger当前学生checkpoint，必须邻接冻结训练名单")
    parser.add_argument("--beta", type=float, help="DAgger教师执行概率；显式0<=beta<1，固定seed0")
    parser.add_argument("--collection-id", help="DAgger唯一采集身份；同一身份不可更换checkpoint或配方")
    parser.add_argument("--max-steps", type=int, default=500, help="DAgger最多决策次数，含动作前STOP")
    parser.add_argument("--teacher-upstream-root", type=Path)
    parser.add_argument("--teacher-nav-graph", type=Path, help="nav_graph_dict_<scene>.pkl所在目录")
    parser.add_argument("--teacher-token-dict", type=Path, help="TokenDict_<scene>.json所在目录")
    parser.add_argument("--teacher-review", type=Path, help="已审核实际位姿/偏轨/顺序/STOP/图连通性的合同")
    args = parser.parse_args(argv)
    if not np.isfinite(args.min_free_gib) or args.min_free_gib < 0:
        parser.error("min-free-gib必须是有限非负数")
    if args.output.exists() and not (args.mode in ("collect", "dagger") and args.resume_collection):
        parser.error("输出已存在，拒绝覆盖")
    if args.epochs <= 0 or args.sequence_chunk_size <= 0:
        parser.error("epochs和sequence-chunk-size必须是正数")
    if any(not np.isfinite(value) or not 0 < value <= 1 for value in (args.min_fit_accuracy, args.min_fit_recall)):
        parser.error("开发集拟合阈值必须在(0,1]内")
    args.output.parent.mkdir(parents=True, exist_ok=True)
    digest = lambda path: hashlib.sha256(Path(path).read_bytes()).hexdigest()
    if args.development_split_manifest is not None and not (
            args.mode == "merge" or args.mode == "collect" and args.resume_collection):
        parser.error("development-split-manifest仅用于可恢复collect或merge")
    if args.mode == "plan-development":
        with _collection_lock(args.output):
            return _plan_aerial_development(args)
    if args.mode == "merge":
        if not args.merge_caches:
            parser.error("merge需要merge-caches，填写同一split的各scene缓存")
        with _collection_lock(args.output):
            return _merge_aerial_caches(args)
    if args.mode == "dagger":
        with _collection_lock(args.output):
            return _collect_aerial_dagger(args, parser)
    if args.mode == "collect":
        if args.depth_storage != "npy_float_v1" and (not args.resume_collection or not args.save_depth):
            parser.error("压缩depth需要save-depth和resume-collection，旧采集默认语义不变")
        with _collection_lock(args.output):
            return (_collect_aerial_resumable(args, parser) if args.resume_collection
                    else _collect_aerial_legacy(args, parser))
    from uavnav.avln.fit import _aerial_sequence_epoch, _aerial_epoch
    from train import train
    from uavnav.avln.data import group_aerial_episodes
    from uavnav.avln.inference import AerialActionPredictor
    if args.cache_manifest is None or args.validation_cache_manifest is None:
        parser.error("integration需要训练与官方验证两个真实cache-manifest")
    if args.device == "cuda" and not torch.cuda.is_available():
        raise RuntimeError("GPU集成要求CUDA，拒绝CPU回退")
    overrides = {
        "annotation_root": args.annotation_root, "cache_manifest": args.cache_manifest,
        "validation_cache_manifest": args.validation_cache_manifest, "validation_split": "val_seen",
        "architecture": args.architecture, "sequence_chunk_size": args.sequence_chunk_size,
        "epochs": 1 if args.mode == "integration" else args.epochs, "workers": 0,
        "device": args.device, "name": f"{args.architecture}_{args.mode}_{args.output.stem}",
    }
    if args.architecture == "aerial_route_dino_v5":
        dino_repo = args.dino_repo or os.environ.get("UAVNAV_DINO_REPO")
        dino_weights = args.dino_weights or os.environ.get("UAVNAV_DINO_WEIGHTS")
        if not dino_repo or not dino_weights:
            parser.error("v5集成需要--dino-repo/--dino-weights或对应环境变量")
        overrides.update(dino_repo=str(dino_repo), dino_weights=str(dino_weights),
                         dino_variant=args.dino_variant)
    run = train(dataset="aerialvln_s_v1", overrides=overrides)
    checkpoint = run / ("weights/last.pt" if args.mode == "learnability" else "weights/best.pt")
    torch.set_float32_matmul_precision("highest")
    torch.backends.cudnn.allow_tf32 = False
    torch.backends.cudnn.benchmark = False
    predictor = AerialActionPredictor(checkpoint, device=args.device)
    train_samples = load_aerial_samples(args.annotation_root, "train", args.cache_manifest, predictor.config["history_frames"])
    episodes = group_aerial_episodes(train_samples, history_frames=predictor.config["history_frames"])
    prefix = episodes[0][:min(9, len(episodes[0]))]
    sample = prefix[-1]
    for frame in prefix:
        output = predictor.predict_action(frame["image"], frame["instruction"], frame["history"])
    worker = ("import sys,json,torch\n"
              "from uavnav.avln.inference import AerialActionPredictor\n"
              "torch.set_float32_matmul_precision('highest')\n"
              "torch.backends.cudnn.allow_tf32=False\n"
              "torch.backends.cudnn.benchmark=False\n"
              "p=AerialActionPredictor(sys.argv[1],device=sys.argv[3])\n"
              "for frame in json.loads(sys.argv[2]):\n"
              " result=p.predict_action(frame['image'],frame['instruction'],frame['history'])\n"
              "print(json.dumps(result))\n")
    prefix_json = json.dumps([{"image": str(frame["image"]), "instruction": frame["instruction"],
                               "history": frame["history"].tolist()} for frame in prefix], ensure_ascii=False)
    process = subprocess.run([sys.executable, "-B", "-c", worker, str(checkpoint), prefix_json, args.device],
        cwd=Path(__file__).resolve().parents[1], env=dict(os.environ, PYTHONDONTWRITEBYTECODE="1"),
        capture_output=True, text=True, check=True, encoding="utf-8")
    independent = json.loads(process.stdout)
    error = float(np.max(np.abs(np.asarray(independent["action_probabilities"]) - output["action_probabilities"])))
    if independent["action"] != output["action"] or error > 1e-6:
        raise RuntimeError("独立进程八动作checkpoint重载不一致")
    controlled_collate = functools.partial(_aerial_controlled_collate, vocab=predictor.vocab,
        imgsz=predictor.config["imgsz"], history_frames=predictor.config["history_frames"],
        text_control=predictor.config["text_control"])
    batch = controlled_collate([sample])
    inference_batch = predictor._batch(sample["image"], sample["instruction"], sample["history"])
    if any(not torch.equal(value, inference_batch[key].cpu()) for key, value in batch.items() if key != "action_target"):
        raise RuntimeError("训练与推理预处理不一致")
    report = {"status": "passed", "scope": "real_rgb_teacher_action_training_and_reload_integration",
              "run": str(run), "checkpoint_sha256": digest(checkpoint), "gpu": torch.cuda.get_device_name(0)
              if args.device == "cuda" else None, "independent_process_max_absolute_error": error,
              "preprocessing_identical": True, "independent_reload_prefix_frames": len(prefix),
              "navigation_metrics": {key: None for key in ("ne", "sr", "osr", "ndtw", "sdtw")}}
    if args.mode == "learnability":
        if args.architecture in ("aerial_route_recurrent_v2", "aerial_route_dino_v5"):
            stats = _aerial_sequence_epoch(predictor.model, episodes, predictor.vocab, imgsz=predictor.config["imgsz"],
                history_frames=predictor.config["history_frames"], chunk_size=args.sequence_chunk_size, device=predictor.device,
                loss_protocol=predictor.config["loss_protocol"], text_control=predictor.config["text_control"])
        else:
            from torch.utils.data import DataLoader
            loader = DataLoader(train_samples, batch_size=4, shuffle=False, collate_fn=controlled_collate)
            stats = _aerial_epoch(predictor.model, loader, predictor.device)
        observed = [value for value in stats["class_recall"] if value is not None]
        complete = not stats["missing_classes"]
        beats_majority = stats["accuracy"] > stats["majority_accuracy"]
        fitted = (stats["accuracy"] >= args.min_fit_accuracy and min(observed) >= args.min_fit_recall
                  and stats["stop_recall"] is not None and stats["stop_recall"] >= args.min_fit_recall
                  and beats_majority)
        report["scope"] = "training_route_teacher_fit_diagnostic_not_autonomous_navigation_or_generalization"
        report["learning_check"] = {"all_eight_actions_covered": complete,
            "beats_constant_training_majority": beats_majority,
            "present_actions_fit_passed": fitted, "passed": complete and fitted,
            "thresholds": {"accuracy": args.min_fit_accuracy, "each_present_class_recall": args.min_fit_recall,
                           "stop_recall": args.min_fit_recall}, "teacher_training_set": stats,
            "autonomous_training_route_completion": None, "unseen_route_generalization": None,
            "language_contribution": None}
        report["status"] = "teacher_fit_passed" if complete and fitted else "teacher_fit_incomplete"
    args.output.write_text(json.dumps(report, ensure_ascii=False, indent=2), encoding="utf-8")
    print(json.dumps(report, ensure_ascii=False))


def main():
    if "--dataset" in sys.argv[1:]:
        return _aerial_main(sys.argv[1:])
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--data-root", type=Path, required=True)
    parser.add_argument("--instruction-json", type=Path, required=True)
    parser.add_argument("--output", type=Path, required=True)
    parser.add_argument("--fusion-mode", choices=FUSION_MODES)
    parser.add_argument("--device", choices=("cpu", "cuda"), default="cuda")
    parser.add_argument("--architecture", choices=ARCHITECTURES, default="legacy_waypoint_v1")
    parser.add_argument("--backbone", choices=BACKBONES)
    parser.add_argument("--visual-fusion", choices=FUSIONS)
    args = parser.parse_args()
    if args.output.exists():
        parser.error("验证摘要已经存在，拒绝覆盖；请选择新目录")
    args.fusion_mode = args.fusion_mode or ("query_plus_text" if args.architecture == "grounded_v1" else "text_context_only")
    if args.architecture == "grounded_v1" and args.fusion_mode != "query_plus_text":
        parser.error("grounded_v1仅支持query_plus_text")
    if args.device == "cuda" and not torch.cuda.is_available():
        raise RuntimeError("该验证需要 CUDA，不能回退 CPU 后声称 GPU 验证通过")
    code_root = Path(__file__).resolve().parents[1]
    subprocess_env = dict(os.environ, PYTHONUTF8="1", PYTHONDONTWRITEBYTECODE="1")
    report = {
        "scope": "training_inference_and_replay_integration_not_navigation_performance",
        "python": platform.python_version(), "torch": torch.__version__,
        "gpu": torch.cuda.get_device_name(0) if args.device == "cuda" else None,
        "device": args.device, "real_simulator_executed": False,
        "fusion_mode": args.fusion_mode,
        "architecture": args.architecture,
    }
    paths = load_list(args.data_root, "train.json")
    instructions = load_instructions(args.instruction_json, strip_direction=True)
    selected = []
    for path in paths:
        if len(list(iter_samples([path], 8, instructions))) >= 3:
            selected.append(path)
        if len(selected) == 3:
            break
    if len(selected) != 3:
        raise RuntimeError("没有三条有效轨迹用于集成验证")
    samples = list(iter_samples(selected, 8, instructions))
    report["real_trajectories"] = len(selected)
    report["real_samples"] = len(samples)
    report["trajectory_ids"] = [f"{p.parent.name}/{p.name}" for p in selected]
    report["instruction_sha256"] = hashlib.sha256(args.instruction_json.read_bytes()).hexdigest()
    report["source_list_sha256"] = hashlib.sha256((args.data_root / "train.json").read_bytes()).hexdigest()
    with TemporaryDirectory(prefix="uavnav-stage2-") as temporary:
        root = Path(temporary)
        train_list = root / "train_small.json"
        train_list.write_text(json.dumps([{"dir": str(p.relative_to(args.data_root))} for p in selected]), encoding="utf-8")
        run = fit(
            data_root=str(args.data_root), list_json=str(train_list),
            instruction_json=str(args.instruction_json), epochs=1, batch=4, lr=1e-4,
            imgsz=224, history=8, workers=0, val_ratio=1 / 3, strip_direction=True,
            seed=0, device=args.device, ablate="none", project=str(root / "train"), name="integration",
            fusion_mode=args.fusion_mode,
            architecture=args.architecture,
            backbone=args.backbone or ("resnet50" if args.architecture == "legacy_waypoint_v1" else "resnet18"),
            visual_fusion=args.visual_fusion or ("global" if args.architecture == "legacy_waypoint_v1" else "spatial"),
        )
        report["split_manifest"] = json.loads((run / "split_manifest.json").read_text(encoding="utf-8"))
        report["split_manifest_sha256"] = hashlib.sha256((run / "split_manifest.json").read_bytes()).hexdigest()
        checkpoint = run / "weights" / "best.pt"
        # fit() 为吞吐打开 TF32；独立进程默认数值设置不同。验证统一为 FP32。
        torch.set_float32_matmul_precision("highest")
        torch.backends.cudnn.allow_tf32 = False
        torch.backends.cudnn.benchmark = False
        with patch("torchvision.models._api.load_state_dict_from_url", side_effect=AssertionError("加载 checkpoint 不应下载权重")):
            predictor = WaypointPredictor(checkpoint, device=args.device)
        sample = samples[0]
        batch = collate([sample], predictor.vocab, 224, 8)
        inference_batch = predictor._batch(sample["image"], sample["instruction"], sample["history"])
        max_preprocess_error = max(
            float((batch[key].float() - inference_batch[key].detach().cpu().float()).abs().max())
            for key in ("image", "tokens", "token_mask", "history", "history_length")
        )
        assert max_preprocess_error == 0, f"预处理偏差: {max_preprocess_error}"
        report["preprocess_max_absolute_error"] = max_preprocess_error
        payload = torch.load(checkpoint, map_location="cpu", weights_only=True)
        assert all(torch.isfinite(value).all() for value in payload["model"].values() if torch.is_floating_point(value))
        report["model_config"] = predictor.config
        report["checkpoint_sha256"] = hashlib.sha256(checkpoint.read_bytes()).hexdigest()
        report["checkpoint_state_finite"] = True
        predictor.model.load_state_dict(payload["model"], strict=True)
        with torch.inference_mode():
            reference_output = predictor.model({k: v.to(args.device) for k, v in batch.items() if k != "offset"})[0].cpu().numpy()
        output = predictor.predict(sample["image"], sample["instruction"], sample["history"])
        output_error = float(np.max(np.abs(reference_output - output["body_displacement"])))
        assert output_error < 1e-6
        report["collate_vs_predict_max_absolute_error"] = output_error
        image = Image.open(sample["image"]).convert("RGB")
        array_output = predictor.predict(np.asarray(image), sample["instruction"], sample["history"])
        pil_output = predictor.predict(image, sample["instruction"], sample["history"])
        assert np.allclose(array_output["body_displacement"], pil_output["body_displacement"], atol=1e-6)
        assert np.allclose(output["body_displacement"], pil_output["body_displacement"], atol=1e-6)
        report["pil_numpy_path_consistency"] = True
        worker = (
            "import json,sys,torch; torch.set_float32_matmul_precision('highest'); "
            "torch.backends.cudnn.allow_tf32=False; torch.backends.cudnn.benchmark=False; "
            "from uavnav.avln.inference import WaypointPredictor; "
            "p=WaypointPredictor(sys.argv[1],device=sys.argv[5]); "
            "print(json.dumps(p.predict(sys.argv[2],sys.argv[3],json.loads(sys.argv[4]))))"
        )
        process = subprocess.run(
            [sys.executable, "-B", "-c", worker, str(checkpoint), str(sample["image"]),
             sample["instruction"], json.dumps(sample["history"].tolist()), args.device],
            cwd=code_root, check=True, capture_output=True, text=True, encoding="utf-8", errors="strict", env=subprocess_env,
        )
        independent = json.loads(process.stdout)
        independent_error = float(np.max(np.abs(np.asarray(independent["body_displacement"]) - output["body_displacement"])))
        assert independent_error < 1e-6, f"独立进程输出最大绝对误差: {independent_error}"
        report["independent_process_max_absolute_error"] = independent_error
        replay = rollout_episode(StaticTrajectoryEnv(selected[0]), predictor, sample["instruction"], 8, 3)
        assert replay["status"] == "replay_only" and replay["actions_executed"] is False
        assert replay["steps"] >= 2
        report["real_data_replay_steps"] = replay["steps"]
        report["cli_replay_scope"] = "training-subset trajectories, test split label exercises CLI only; not official test evaluation"
        for policy in ("model", "constant", "previous"):
            output_dir = root / f"eval_{policy}"
            command = [sys.executable, "-B", str(code_root / "evaluate.py"), "--backend", "replay",
                       "--trajectory", str(selected[0]), "--split", "test", "--policy", policy,
                       "--output", str(output_dir), "--max-steps", "3"]
            if policy == "model":
                command += ["--checkpoint", str(checkpoint), "--device", args.device]
            subprocess.run(command, cwd=code_root, check=True, capture_output=True, text=True, encoding="utf-8", errors="strict", env=subprocess_env)
            metrics = json.loads((output_dir / "metrics.json").read_text(encoding="utf-8"))
            assert all(metrics["metrics"][key] is None for key in ("ne", "sr", "osr", "spl"))
            report[f"{policy}_cli_replay_navigation_metrics_null"] = True
        report["n_parameters"] = sum(p.numel() for p in predictor.model.parameters())
        # 只测 batch=1、FP32、RGB路径输入，含读取/预处理/H2D/前向/D2H。
        if args.device == "cuda":
            torch.cuda.reset_peak_memory_stats()
        for _ in range(5):
            predictor.predict(sample["image"], sample["instruction"], sample["history"])
        times = [predictor.predict(sample["image"], sample["instruction"], sample["history"])["latency_ms"] for _ in range(20)]
        report["inference_measurement"] = {
            "batch": 1, "dtype": "fp32", "image_size": 224, "warmup": 5, "samples": 20,
            "latency_scope": "path_read_preprocess_device_transfer_forward_output",
            "p50_ms": float(np.percentile(times, 50)), "p95_ms": float(np.percentile(times, 95)),
            "peak_allocated_vram_gb": torch.cuda.max_memory_allocated() / 1024 ** 3 if args.device == "cuda" else None,
        }
        batch = {k: v for k, v in inference_batch.items()}
        with torch.profiler.profile(activities=[torch.profiler.ProfilerActivity.CPU], with_flops=True) as profiler:
            with torch.inference_mode():
                predictor.model(batch)
            if args.device == "cuda":
                torch.cuda.synchronize()
        report["profiled_supported_ops_flops"] = sum(e.flops for e in profiler.key_averages())
        report["flops_scope"] = "torch_profiler_supported_ops_only_not_complete_network_flops"
    report["status"] = "passed"
    report["temporary_artifacts_removed"] = True
    args.output.parent.mkdir(parents=True, exist_ok=True)
    args.output.write_text(json.dumps(report, ensure_ascii=False, indent=2), encoding="utf-8")
    print(json.dumps(report, ensure_ascii=False, indent=2))


if __name__ == "__main__":
    main()
