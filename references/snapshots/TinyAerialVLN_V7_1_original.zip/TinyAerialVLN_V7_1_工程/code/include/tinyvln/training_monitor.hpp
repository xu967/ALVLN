#pragma once
// Real training hook: progress on stderr and structured metrics in metrics.jsonl.
// Include from a FUTURE trainer; this header does not train a model by itself.
#include <algorithm>
#include <chrono>
#include <cmath>
#include <cstddef>
#include <fstream>
#include <iomanip>
#include <iostream>
#include <stdexcept>
#include <string>

namespace tinyvln {
inline std::string JsonEscape(const std::string& s) {
  std::string out;
  for (char c : s) {
    if (c == '"' || c == '\\') out += '\\';
    if (c == '\n') { out += "\\n"; continue; }
    if (static_cast<unsigned char>(c) < 32) continue;
    out += c;
  }
  return out;
}

class TrainingMonitor {
 public:
  explicit TrainingMonitor(const std::string& jsonl_path)
      : file_(jsonl_path, std::ios::app), begin_(Clock::now()) {
    if (!file_) throw std::runtime_error("METRICS_OPEN_FAILED: " + jsonl_path);
  }

  void Step(std::size_t step, std::size_t total, double loss,
            double accuracy, double lr) {
    if (!std::isfinite(loss) || !std::isfinite(accuracy) || !std::isfinite(lr))
      throw std::runtime_error("TRAIN_NONFINITE_METRIC: loss/accuracy/lr");
    if (total == 0 || step > total || accuracy < 0 || accuracy > 1)
      throw std::runtime_error("TRAIN_METRIC_RANGE: step/total/accuracy");
    const double elapsed = std::chrono::duration<double>(Clock::now() - begin_).count();
    const double eta = step ? elapsed * (static_cast<double>(total - step) / step) : 0;
    file_ << "{\"event\":\"train_step\",\"step\":" << step
          << ",\"total_steps\":" << total << ",\"loss\":" << loss
          << ",\"action_accuracy\":" << accuracy << ",\"lr\":" << lr
          << ",\"elapsed_sec\":" << elapsed << ",\"eta_sec\":" << eta << "}\n";
    file_.flush();
    constexpr int kWidth = 28;
    const int filled = static_cast<int>(kWidth * static_cast<double>(step) / total);
    std::cerr << '\r' << "[TRAIN] [" << std::string(filled, '#')
              << std::string(kWidth - filled, '-') << "] " << step << '/' << total
              << " loss=" << std::fixed << std::setprecision(4) << loss
              << " acc=" << std::setprecision(1) << accuracy * 100 << '%'
              << " ETA=" << std::setprecision(0) << eta << "s" << std::flush;
    if (step == total) std::cerr << '\n';
  }

  void Validation(std::size_t step, double sr, double stop_f1) {
    if (!std::isfinite(sr) || sr < 0 || sr > 1 || !std::isfinite(stop_f1)
        || stop_f1 < 0 || stop_f1 > 1)
      throw std::runtime_error("VAL_METRIC_INVALID");
    file_ << "{\"event\":\"validation\",\"step\":" << step
          << ",\"sr\":" << sr << ",\"stop_f1\":" << stop_f1 << "}\n";
    file_.flush();
  }

  void Status(const std::string& event, const std::string& message) {
    file_ << "{\"event\":\"" << JsonEscape(event) << "\",\"message\":\""
          << JsonEscape(message) << "\"}\n";
    file_.flush();
  }

 private:
  using Clock = std::chrono::steady_clock;
  std::ofstream file_;
  Clock::time_point begin_;
};
}  // namespace tinyvln
