#!/usr/bin/env python3
"""Single-entry CLI: honest preflight, scene creation, dashboard and gated binaries."""
from __future__ import annotations
import argparse
from datetime import datetime
import os
from pathlib import Path
import shutil
import subprocess
import sys

ROOT = Path(__file__).resolve().parents[1]
RUNS = ROOT / 'artifacts' / 'runs'


def doctor() -> int:
    print('=== TinyAerialVLN V7.1 环境自检 ===')
    commands = [('python3', False), ('cmake', True), ('ninja', True),
                ('g++', True), ('nvcc', True), ('gz', True)]
    missing = []
    for cmd, optional in commands:
        found = shutil.which(cmd)
        print(f'{"[OK]" if found else "[WARN]"} {cmd}: {found or "未安装/不在 PATH"}')
        if not found and not optional:
            missing.append(cmd)
    for key in ['artifacts', 'tools', 'code', 'assets']:
        print(f'{"[OK]" if (ROOT / key).exists() else "[ERR]"} project/{key}')
    if not (ROOT / 'config' / 'experiment.yaml').exists():
        print('[WARN][CONFIG_NOT_READY] config/experiment.yaml 尚未建立；训练功能锁定。')
    if not any((ROOT / 'build' / name).is_file() for name in ('tinyvln_train', 'tinyvln_eval_bridge')):
        print('[WARN][BINARY_NOT_BUILT] 自研训练/评测器尚未编译。')
    print('[INFO] 此检测不声称 Gazebo/NVIDIA/SG2002 已经适配成功。')
    return 0 if not missing else 2


def gated_binary(name: str, run_id: str | None) -> int:
    exe = ROOT / 'build' / name
    cfg = ROOT / 'config' / 'experiment.yaml'
    if not exe.is_file() or not os.access(exe, os.X_OK):
        print(f'[ERR][BINARY_NOT_BUILT] {exe} 不存在或不可执行。先按开发门禁实现并编译。', file=sys.stderr)
        return 3
    if not cfg.is_file():
        print(f'[ERR][CONFIG_NOT_READY] 缺少 {cfg}，不得使用 .planned 占位文件训练。', file=sys.stderr)
        return 4
    run_id = run_id or datetime.now().strftime('run_%Y%m%d_%H%M%S')
    if not run_id.replace('_', '').isalnum() or len(run_id) > 70:
        print('[ERR][RUN_ID_INVALID] run ID 只能用字母、数字和下划线，≤70字。', file=sys.stderr)
        return 4
    out = RUNS / run_id
    if out.exists():
        print(f'[ERR][RUN_EXISTS] {out} 已存在，禁止覆盖旧实验。', file=sys.stderr)
        return 4
    out.mkdir(parents=True)
    print(f'[INFO] 启动 {name}; run_id={run_id}; Ctrl+C 请求终止。')
    try:
        return subprocess.call([str(exe), '--config', str(cfg), '--output', str(out)], cwd=ROOT)
    except KeyboardInterrupt:
        print('\n[WARN][USER_INTERRUPT] 请求中止；检查是否生成完整 checkpoint。', file=sys.stderr)
        return 130
    except OSError as exc:
        print(f'[ERR][PROCESS_START_FAILED] {exc}', file=sys.stderr)
        return 5


def menu() -> int:
    print('TinyAerialVLN V7.1 —— 一键工程入口')
    print('1. 环境自检\n2. 生成简单森林场景\n3. 打开训练指标看板\n4. 启动学生训练（需已编译）\n5. 启动评测（需已编译）\n0. 退出')
    try:
        selection = input('请选择 [0-5]: ').strip()
    except EOFError:
        print('[ERR][NO_INPUT] 无交互终端；使用 ./run.sh doctor 等子命令。', file=sys.stderr)
        return 2
    return {'0': lambda: 0, '1': doctor,
            '2': lambda: subprocess.call([sys.executable, str(ROOT / 'tools/scene_tool.py')], cwd=ROOT),
            '3': lambda: subprocess.call([sys.executable, str(ROOT / 'tools/dashboard.py')], cwd=ROOT),
            '4': lambda: gated_binary('tinyvln_train', None),
            '5': lambda: gated_binary('tinyvln_eval_bridge', None)}.get(
                selection, lambda: print('[ERR][MENU_OPTION_INVALID] 请输入 0..5。') or 2)()


def main() -> int:
    p = argparse.ArgumentParser(description='TinyAerialVLN CLI (no fake training)')
    p.add_argument('command', nargs='?', choices=['doctor', 'scene', 'dashboard', 'ui', 'train', 'eval'], default=None)
    p.add_argument('--run-id', default=None)
    p.add_argument('--port', type=int, default=8765)
    p.add_argument('--preset', choices=['forest', 'corridor', 'columns', 'mixed'], default='forest')
    p.add_argument('--seed', type=int, default=42)
    p.add_argument('--count', type=int, default=24)
    args = p.parse_args()
    if args.command is None:
        return menu()
    if args.command == 'doctor':
        return doctor()
    if args.command in ('dashboard', 'ui'):
        return subprocess.call([sys.executable, str(ROOT / 'tools/dashboard.py'), '--port', str(args.port)], cwd=ROOT)
    if args.command == 'scene':
        return subprocess.call([sys.executable, str(ROOT / 'tools/scene_tool.py'), '--preset', args.preset,
                               '--seed', str(args.seed), '--count', str(args.count)], cwd=ROOT)
    if args.command == 'train':
        return gated_binary('tinyvln_train', args.run_id)
    return gated_binary('tinyvln_eval_bridge', args.run_id)


if __name__ == '__main__':
    raise SystemExit(main())
