#!/usr/bin/env python3
"""V7.1 read-only local research cockpit. No training or simulator actions are executed here.

All status values are derived from local files / binary presence. Dashboard does NOT
claim that an available binary, world file or metric proves a validated flight.
"""
from __future__ import annotations

import argparse
from datetime import datetime, timezone
from http.server import BaseHTTPRequestHandler, ThreadingHTTPServer
import json
import math
from pathlib import Path
import re
import shutil
from urllib.parse import urlparse, parse_qs

ROOT = Path(__file__).resolve().parents[1]
RUNS = ROOT / 'artifacts' / 'runs'
SCENES = ROOT / 'artifacts' / 'scenes'
HTML = ROOT / 'assets' / 'dashboard.html'
RUN_ID = re.compile(r'^[A-Za-z0-9_]{1,70}$')
MAX_LOG_TAIL_BYTES = 2 * 1024 * 1024
MAX_EVENTS = 2000
MAX_LINE_BYTES = 64 * 1024


def utc_now():
    return datetime.now(timezone.utc).isoformat(timespec='seconds')


def runs_list():
    if not RUNS.is_dir():
        return []
    return sorted((p.name for p in RUNS.iterdir() if p.is_dir() and not p.is_symlink()
                   and RUN_ID.fullmatch(p.name) and (p / 'metrics.jsonl').is_file()
                   and not (p / 'metrics.jsonl').is_symlink()), reverse=True)[:80]


def metrics_for(name):
    if not RUN_ID.fullmatch(name) or name not in runs_list():
        raise ValueError('RUN_NOT_FOUND')
    path = RUNS / name / 'metrics.jsonl'
    rows, warnings = [], []
    size = path.stat().st_size
    with path.open('rb') as f:
        offset = max(0, size - MAX_LOG_TAIL_BYTES)
        f.seek(offset)
        if offset:
            f.readline()  # discard incomplete head of bounded tail
            warnings.append('LOG_TAIL_LIMIT: 仅加载最新日志；不代表全量训练历史')
        for number, raw in enumerate(f, 1):
            if not raw.endswith(b'\n'):
                warnings.append('LOG_PARTIAL_WRITE: 正在写入最后一行，暂不展示')
                break
            if len(raw) > MAX_LINE_BYTES:
                warnings.append(f'LOG_LINE_TOO_LONG: near_tail_line={number}')
                continue
            try:
                event = json.loads(raw.decode('utf-8'))
            except (UnicodeDecodeError, json.JSONDecodeError):
                warnings.append(f'LOG_JSON_INVALID: near_tail_line={number}')
                continue
            if not isinstance(event, dict) or not isinstance(event.get('event'), str):
                warnings.append(f'LOG_EVENT_INVALID: near_tail_line={number}')
                continue
            # Prevent NaN, Infinity, unexpected object graphs leaking into UI.
            if any(isinstance(v, float) and not math.isfinite(v) for v in event.values()):
                warnings.append(f'LOG_NONFINITE: near_tail_line={number}')
                continue
            rows.append(event)
            if len(rows) > MAX_EVENTS:
                rows.pop(0)
    return {'run_id': name, 'events': rows, 'warnings': warnings[-15:],
            'truncated': size > MAX_LOG_TAIL_BYTES, 'source': 'real_jsonl_only'}


def scene_list():
    if not SCENES.is_dir():
        return []
    scenes = []
    for path in sorted(SCENES.glob('*.json'))[:80]:
        if path.is_symlink():
            continue
        sdf = path.with_suffix('.sdf')
        try:
            spec = json.loads(path.read_text(encoding='utf-8'))
            scenes.append({'name': path.stem, 'preset': str(spec.get('preset', 'unknown')),
                           'seed': spec.get('seed'), 'obstacles': spec.get('placed_obstacles', spec.get('requested_obstacles')),
                           'sdf_exists': sdf.is_file(), 'kind': 'static_geometry_only',
                           'status': 'not_a_flight_simulator'})
        except (OSError, ValueError, TypeError) as exc:
            scenes.append({'name': path.stem, 'status': 'manifest_invalid',
                           'error_code': 'SCENE_MANIFEST_INVALID', 'detail': str(exc)[:180]})
    return scenes


def state_check(key, label, state, detail, command=None):
    value = {'key': key, 'label': label, 'state': state, 'detail': detail}
    if command:
        value['command'] = command
    return value


def status():
    found_runs = runs_list()
    checks = [
        state_check('dashboard', '本地指标看板', 'ready', '只读服务；只显示已记录的 JSONL', './run.sh dashboard --port 8765'),
        state_check('scenes', '程序化静态场景', 'ready' if scene_list() else 'blocked',
                    f'已发现 {len(scene_list())} 份 scene manifest；这不是 RGB 飞行仿真',
                    './run.sh scene --preset forest --seed 42 --count 24'),
        state_check('gazebo', 'Gazebo CLI', 'available_unverified' if shutil.which('gz') else 'blocked',
                    '已发现 gz CLI，但动力学/电机/RGB 尚未验证' if shutil.which('gz') else '当前机器找不到 gz 命令',
                    './run.sh sim doctor'),
        state_check('physics', '四旋翼物理闭环 GZ0–GZ3', 'not_implemented',
                    '尚无通过测试的四电机→动力学→RGB 运行链路'),
        state_check('cf_sil', 'CF-Drone 软件在环', 'not_implemented',
                    '尚未移植 PID 控制核；原 ESP32 固件未改动'),
        state_check('trainer', '自研 C++/CUDA 学生训练器',
                    'available_unverified' if (ROOT / 'build/tinyvln_train').is_file() else 'not_implemented',
                    '发现训练文件但尚未通过训练验证' if (ROOT / 'build/tinyvln_train').is_file() else '尚无已编译训练器；不提供模拟曲线'),
        state_check('model_config', '训练配置', 'ready' if (ROOT / 'config/experiment.yaml').is_file() else 'blocked',
                    '已提供训练配置' if (ROOT / 'config/experiment.yaml').is_file() else '仅有 .planned 占位，不得启动训练'),
        state_check('edge', 'SG2002 NPU 部署', 'not_implemented',
                    '未提供设备实测 cvimodel / camera→UART 端到端结果'),
        state_check('firmware', 'ESP32 固件', 'frozen',
                    '本次只读参考 CF-Drone.zip；没有修改、烧录或验证新固件'),
    ]
    return {'version': '7.1', 'generated_at': utc_now(), 'checks': checks,
            'run_count': len(found_runs), 'scene_count': len(scene_list()),
            'read_only': True, 'no_fake_metrics': True}


def audit():
    return {'schema': 'tinyvln.audit.v1', 'generated_at': utc_now(),
            'project': 'TinyAerialVLN V7.1', 'status': status(),
            'evidence_levels': {'ready': '文件或工具存在；不等于物理闭环验证',
                                'available_unverified': '仅发现资源，缺运行验收',
                                'blocked': '缺前置依赖',
                                'not_implemented': '功能尚未实现',
                                'frozen': '明确冻结，本次不修改'},
            'explicit_limitations': [
                '尚未实现 Gazebo RGB + 四旋翼动力学闭环',
                '尚未实现 CF-Drone 软件在环',
                '尚未实现学生训练或教师蒸馏',
                '尚无 SG2002 端到端推理实测',
                '没有修改 CF-Drone 的 ESP32 固件',
                '静态障碍场景不等于可飞行的模拟器',
                '本页不支持开始训练或修改设备配置'
            ],
            'verification_commands': ['python3 -m unittest discover -s code/tests -p "test_*.py"',
                                      'python3 -m unittest discover -s sim/tests -p "test_*.py"',
                                      './run.sh doctor', './run.sh sim doctor']}


def serve(port):
    class Handler(BaseHTTPRequestHandler):
        def do_GET(self):
            path = urlparse(self.path)
            try:
                if path.path in ('/', '/index.html'):
                    body, ctype, code = HTML.read_bytes(), 'text/html; charset=utf-8', 200
                elif path.path == '/api/health':
                    body, ctype, code = {'status': 'ok', 'read_only': True}, 'application/json', 200
                elif path.path == '/api/runs':
                    body, ctype, code = {'runs': runs_list()}, 'application/json', 200
                elif path.path == '/api/metrics':
                    name = parse_qs(path.query).get('run', [''])[0]
                    body, ctype, code = metrics_for(name), 'application/json', 200
                elif path.path == '/api/scenes':
                    body, ctype, code = {'scenes': scene_list()}, 'application/json', 200
                elif path.path == '/api/status':
                    body, ctype, code = status(), 'application/json', 200
                elif path.path == '/api/audit':
                    body, ctype, code = audit(), 'application/json', 200
                else:
                    self.send_error(404, 'NOT_FOUND'); return
                if not isinstance(body, bytes):
                    body = json.dumps(body, ensure_ascii=False, allow_nan=False).encode('utf-8')
                self.send_response(code)
                self.send_header('Content-Type', ctype)
                self.send_header('Cache-Control', 'no-store')
                self.send_header('X-Content-Type-Options', 'nosniff')
                self.send_header('Content-Security-Policy',
                                 "default-src 'none'; script-src 'unsafe-inline'; style-src 'unsafe-inline'; "
                                 "connect-src 'self'; img-src 'self' data:; base-uri 'none'; form-action 'none'")
                self.send_header('Content-Length', str(len(body)))
                self.end_headers()
                self.wfile.write(body)
            except ValueError as exc:
                self.send_error(404, str(exc))
            except OSError as exc:
                self.send_error(500, f'DASHBOARD_IO_ERROR: {exc}')

        def do_POST(self):
            self.send_error(405, 'READ_ONLY_DASHBOARD')

        def log_message(self, fmt, *args):
            print('[DASHBOARD]', fmt % args)

    httpd = ThreadingHTTPServer(('127.0.0.1', port), Handler)
    print(f'[OK] TinyAerialVLN V7.1 看板: http://127.0.0.1:{port}/')
    print('[INFO] 本地只读，不执行训练、仿真或固件改动。Ctrl+C 退出。')
    try:
        httpd.serve_forever(poll_interval=0.5)
    except KeyboardInterrupt:
        print('\n[INFO] 看板关闭。')
    finally:
        httpd.server_close()


if __name__ == '__main__':
    parser = argparse.ArgumentParser(description='TinyAerialVLN V7.1 local read-only cockpit')
    parser.add_argument('--port', type=int, default=8765)
    args = parser.parse_args()
    if not 1024 <= args.port <= 65535:
        parser.error('DASHBOARD_PORT_INVALID: 端口必须介于 1024..65535')
    serve(args.port)
