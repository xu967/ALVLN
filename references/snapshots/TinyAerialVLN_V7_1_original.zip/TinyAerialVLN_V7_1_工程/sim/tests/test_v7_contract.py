import pathlib
import subprocess
import unittest

ROOT = pathlib.Path(__file__).resolve().parents[2]

class V7Contract(unittest.TestCase):
    def test_static_scene_rejected_as_flight(self):
        scene = ROOT / 'artifacts/scenes/forest_42.sdf'
        r = subprocess.run([str(ROOT/'run.sh'), 'sim', 'smoke', '--world', str(scene), '--dry-run'], capture_output=True, text=True)
        self.assertNotEqual(r.returncode,0)
        self.assertIn('GZ_MOTOR_MODEL_MISSING', r.stderr)
    def test_unimplemented_camera_cannot_false_pass(self):
        r = subprocess.run([str(ROOT/'run.sh'), 'sim', 'camera'],capture_output=True,text=True)
        self.assertNotEqual(r.returncode,0)
        self.assertIn('FEATURE_NOT_IMPLEMENTED', r.stderr)

if __name__ == '__main__': unittest.main()
